/**
 * @author rpeltz
 */
/*
 * XMLCclRequest readystate: 0 Uninitialized 1 Loading 2 Loaded 3 Interactive 4
 * Completed status: 200 Success 405 Method Not Allowed 409 Invalid State 492
 * Non-Fatal Error 493 Memory Error 500 Internal Server Exception
 */
/*
 * Any method that serves as a callback should execute the following to cleanup
 * req.resultText = null; req.status = null; delete req['onreadystatechange']
 * req = null; where req is an instance of the object passed to the render from
 * the DataRequest
 * 
 * config should contain a CCL prog name and a render function name
 * {cclProgram:'1mp_ptsum2_key_info',cclRenderFn:'Child.KeyInfoPanelFactory'}
 * optionally use the Render Manager to queu up render functions(default is
 * false) {cclProgram:'1mp_ptsum2_key_info',cclRenderFn:',useRenderMan:true}
 * 
 * other options: synch : true for synchronous data retrieval cclParam: 'string'
 * allow user to provide input parameters if needed
 * 
 */
Ext.ns('Child');
Child.DataRequest = function(config) {
	// don't proceed unless you have a ccl prog and a render fn
	if (typeof config.cclProgram === 'undefined'
			|| typeof config.renderFn === 'undefined') {
		alert('You must define both the ccl program and the render function');
		return;
	}
	// translate config into a request object
	var req = {
		useRenderMan : false,
		synch : false,
		cclProgram : null,
		renderFn : null,
		cclParam : null,
		resultText : null,
		cclParam : null,
		status : 0
	};
	req.useRenderMan = (typeof config.useRenderMan === 'undefined')
			? false
			: config.useRenderMan;

	req.synch = (typeof config.synch === 'undefined') ? false : config.synch;
	req.cclProgram = (typeof config.cclProgram == 'undefined')
			? ''
			: config.cclProgram;
	req.renderFn = (typeof config.renderFn === 'undefined')
			? false
			: config.renderFn;
	req.cclParam = (typeof config.cclParam === 'undefined')
			? '^MINE^, $PAT_Personid$, $VIS_Encntrid$, $Usr_PersonID$'
			: config.cclParam;

	// delay is to simulate a long running query
	var delayGettingData = new Ext.util.DelayedTask(function() {
				req.resultText = Child.DebugData.JsonStrings[req.cclProgram];
				Child.Logger.Log(req.resultText);
				if (req.useRenderMan) {
					// alert('using renderman for: '+ req.cclProgram);
					Child.RenderManager.addToQ(Child.RenderManager, {
								'renderFn' : req.renderFn,
								'cclProgram' : req.cclProgram,
								'data' : {
									'data' : req.resultText,
									'status' : 'success'
								}
							});
				} else {
					//no renderman - call render function from here
					req.renderFn({
								'cclProgram' : req.cclProgram,
								'data' : req.resultText,
								'status' : 'success'
							});
				}

				Child.DataRequest.cleanUpDataRequest(req);
			});
	delayGettingData.delay(Child.DataRequest.DATA_REQUEST_DELAY);

};
Child.DataRequest.cleanUpDataRequest = function(req) {
	// cleanup to prevent memory leak
	var p;
	for (p in req){
		p = null;
	}
	delete req['onreadystatechange'];
	req = null;
};
// set this to simulate a call for data
Child.DataRequest.DATA_REQUEST_DELAY = 100; 
