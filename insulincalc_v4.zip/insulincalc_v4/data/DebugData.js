Ext.ns('Child');
Child.version = '2.0';
Child.DebugData = {};

/*
 * This file exists in the data folder of each MPage project and contains JSON results from the CCL
 * calls for the page.  The name in quotes is either the actual CCL name, or sometimes for the debug local 
 * version it might be the CCL name with somethat appended to simulate a differend result based on some 
 * condition on the page.  Format for the JSON expected can be determined from the CCL that is called.  The
 * actual data in these files was removed for Patient Privacy reasons as it contained patient data
*/
Child.DebugData.JsonObjects = {
	'1mp_ptsum_init': {"PT_SUMMARY_INFO":{},
	'1mp_bbsum_dashboard': {"RESULTS":{},	
	'1mp_bbsum_avail_unit': {"AVAIL_UNITS":{},
	'1mp_bbsum_trans_unit':{},
	'1mp_bbsum_pending_orders': {},
	'1mp_ptsum2_results_ip': {},	
	'1mp_bbsum_ordhist':{},		
	'1mp_bbsum_documents':{},
	'1mp_bbsum_trans_profile':{}
	};
	
	
var cswRefData = {
}
;

