/**
 * @author rpeltz
 * This is a structure to hold key, text, and title to be used in Patient Summary Help
 */
Ext.ns('Child');
Child.version = '1.0';
Child.PatientSummaryHelpDB = {
	'generic_help':{
		'title': 'MPages Help',
		'text':'MPage Generic Help'
	},
	'patient_info_IP': {
        'title': 'Inpatient Patient Information',
        'text': 'The Title Bar indicates which version of the Patient Summary is in view (Inpatient or Ambulatory), and how many results.</br></br>The second line displays the visit reason, medical service, medical team (if applicable), and the admission date followed by the current hospital day. The following buttons appear if applicable to the patient: Code Status, Advance Directive, Casper, Precautions, and Isolation.</br></br>The patient summary data is current up to the time displayed on the As of button and can be updated by clicking this button. (Note: Use the As of button to refresh the Patient Summary screen. Do not use the standard Refresh button, or the CIS may close.) Clicking on the Gear icon allows a user to switch summary views.'
    },
	'intakeOutput': {
        'title': 'I&O Information',
        'text': 'Displays I&O information for the last 5 days.'
    },
	'vitals': {
        'title': 'Vitals Information',
        'text': 'Displays vitals information for the last 24 hours.'
    },
	'patient_info_AMB': {
        'title': 'Ambulatory Patient Information',
        'text': 'The Title Bar indicates which version of the Patient Summary is in view (Inpatient or Ambulatory), and how many results display.</br></br>The second line displays the visit reason. The following buttons appear if applicable to the patient: Code Status, Advance Directive, Casper, Precautions, and Isolation.</br></br>The patient summary data is current up to the time displayed on the As of button and can be updated by clicking this button. (Note: Use the As of button to refresh the Patient Summary screen. Do not use the standard Refresh button, or the CIS may close.) Clicking on the Gear icon allows a user to switch summary views.'
    },
    'critical_precautions': {
        'title': 'Critical Precautions',
        'text': 'The Critical Precautions panel displays only if a critical precaution has been charted for the patient. Critical precautions include:  Adrenal insufficiency, Ketogenic Diet, Spine Precautions, and Suicide precautions. </br> </br> Currently this information is charted on the "Additional Patient Information Form" available via AdHoc Charting in the following folder: Clinical Care -> Patient Care Information.'
    },
    'problems': {
        'title': 'Problems',
        'text': 'Displays all active problems for the patient.</br></br>To edit the Problem List, go to the Diagnoses and Problems screen in the chart.'
    },
    'diagnoses': {
        'title': 'Diagnoses',
        'text': 'Displays all active "medical" diagnoses on this encounter.</br></br>To edit the Diagnosis List, go to the Diagnoses and Problems screen in the chart.'
    },
    'procedures_IP': {
        'title': 'Procedure History',
        'text': 'Displays all procedures* that have taken place at a Seattle Children\'s Hospital facility since October 15, 2007. This information is pulled directly from Surginet, and should be validated by reading the corresponding operative report.</br></br>Procedures from the current encounter are separated from previous encounters. In addition those that have taken place within the last 90 days display the post operative day count.</br></br>Click the name of the procedure to obtain additional information including: the name of the primary surgeon, additional procedures that may have taken place at the same time, and the operative report.</br></br>*Line placements, bone marrow biopsies, lumbar puncture procedures are excluded from the list if they are the primary and only procedure performed during the case.'
    },
	 'procedures_AMB': {
        'title': 'Procedure History',
        'text': 'Displays all procedures* that have taken place at a Seattle Children\'s Hospital facility since October 15, 2007.  This information is pulled directly from Surginet, and should be validated by reading the corresponding operative report.</br></br>Procedures that have taken place within the last 90 days display the post operative day count.</br></br>Click the name of the procedure to obtain additional information including: the name of the primary surgeon, additional procedures that may have taken place at the same time, and the operative report.</br></br>*Line placements, bone marrow biopsies, lumbar puncture procedures are excluded from the list if they are the primary and only procedure performed during the case.'
    },
    'medications': {
        'title': 'Medications',
        'text': 'Displays scheduled active inpatient medications on this encounter. Clicking on a row displays the ordering provider and start date.'
    },
    'prn_medications': {
        'title': 'PRN Medications',
        'text': 'Displays PRN active inpatient medications on this encounter. Clicking on a row displays the ordering provider and start date.'
    },
    'continuous_infusions': {
        'title': 'Continuous Infusions',
        'text': 'Displays the active continuous infusions on this encounter. Clicking on a row displays the ordering provider, start date, and clinical display line.'
    },
    'respiratory': {
        'title': 'Respiratory',
        'text': 'Displays the active respiratory therapy orders on this encounter. Panel is present only if orders exist.'
    },
    'diet': {
        'title': 'Diet',
        'text': 'Displays the active nutrition orders on this encounter.'
    },
    'dialysis': {
        'title': 'Dialysis',
        'text': 'Displays the active hemodialysis and CRRT orders on this encounter. Panel is present only if orders exist.'
    },
    'discharge_criteria': {
        'title': 'Discharge Criteria',
        'text': 'Displays the most recent active Discharge Criteria order on this encounter.'
    },
    'lab_IP': {
        'title': 'Lab Results',
        'text': '<b>Results:</b><br/>Displays all general lab results that have been completed or updated in the last 72 hours. Abnormal tests are indicated by color and are flagged with an H (high), L (low), or C (critical) indicator. The collection date and time is displayed.  </br></br>Click on a result to see a graph or list of historical results.  Excludes restricted labs. <b>Micro results are found in the micro panel only. AP results and some genetics results are found in the Pathology panel</b>.</br><br/><b>In Process:</b><br/> Displays all lab, micro and AP orders with the order status of Collected, InLab, or InProcess. Excludes autopsy, restricted, pathology non viewable, and lab non viewable orders.</br><br/><b>Ordered:</b></br> Displays all lab, micro, and AP orders for this encounter that have been ordered and not collected.  Excludes autopsy, restricted, AP non-viewable, and lab non-viewable orders.'
    },
	'lab_AMB': {
        'title': 'Lab Results',
        'text': '<b>Results:</b><br/>Displays the last 100 general lab results that have been completed or updated. Abnormal tests are indicated by color and are flagged with an H (high), L (low), or C (critical) indicator. The collection date and time is displayed.</br></br>Click on a result to see a graph or list of historical results. Excludes restricted labs. <b>Micro results are found in the micro panel only. AP results and some genetics results are found in the Pathology panel</b>.</br><br/><b>In Process:</b><br/>All lab, micro and AP orders with the order status of Collected, InLab, or InProcess. Excludes autopsy, restricted, pathology non viewable, and lab non viewable orders.</br><br/><b>Ordered:</b></br>All lab, micro, and AP orders, including future orders, that have been ordered and not collected. Excludes autopsy, restricted, AP non-viewable, and lab non-viewable orders.'
    },
    'radiology_IP': {
        'title': 'Radiology',
        'text': '<b>Completed:</b><br/> Displays all radiology results that have been completed or updated in the last 72 hours. Displays the date and time the exam was performed (excludes results that are not seen on the radiology flow sheet). Click on a result to see the report. The report viewer provides a button to display the image.</br><br/><b>Ordered:</b><br/> Displays all radiology orders in an ordered or future status.'
    },
	'radiology_AMB': {
        'title': 'Radiology',
        'text': '<b>Completed:</b><br/>Displays the last 20 radiology results that have been completed or updated. Displays the date and time the exam was performed (excludes results that are not seen on the radiology flow sheet). Click on a result to see the report. The report viewer provides a button to display the image.</br><br/><b>Ordered:</b><br/> Displays all radiology orders in an ordered or future status.'
    },
    'diagnosis_IP': {
        'title': 'Diagnostics',
        'text': ' Displays all diagnostic reports (sleep studies, EEG, and ECHO) that have been completed or updated in the last 72 hours. Displays the date and time the exam was performed.'
    },
	'diagnosis_AMB': {
        'title': 'Diagnostics',
        'text': 'Displays the last 20 diagnostic reports (sleep studies, EEG, and ECHO) that have been completed or updated.  Displays the date and time the exam was performed.'
    },
    'pathology_IP': {
        'title': 'Pathology',
        'text': ' Displays all pathology reports that have been completed or updated in the last 72 hours.  Displays the date and time the exam was performed. Includes genetics results that are formatted like AP reports. Click on a result to see the report.'
    },
	'pathology_AMB': {
        'title': 'Pathology',
        'text': 'Displays the last 20 pathology reports that have been completed or updated. Displays the date and time the exam was performed. Includes genetics results that are formatted like AP reports. Click on a result to see the report.'
    },
	'documents_IP': {
        'title': 'Documents',
        'text': ' Displays all documents (excluding AP, micro, and diagnostic) that have been completed or updated in the last 72 hours. The information displays the document type, document title, author and date. Click on a result to see the report.'
    },
	'documents_AMB': {
        'title': 'Documents',
        'text': 'Displays the last 20 documents (excluding AP, micro, and diagnostic) that have been completed or updated. The information displays the document type, document title, author and date. Click on a result to see the report.'
    },
	'micro_IP': {
        'title': 'Micro',
        'text': ' Displays all microbiology results that have been completed or updated in the last 72 hours.  Displays the collect date and time. Information includes the culture source, growth indicator (POS/NEG), and organisms if available. Positive cultures are shown in red. Click on a result to see the report.'
    },
	'micro_AMB': {
        'title': 'Micro',
        'text': 'Displays the last 20 microbiology results that have been completed or updated. Displays the collect date and time. Information includes the culture source, growth indicator (POS/NEG), and organisms if available.  Positive cultures are shown in red. Click on a result to see the report.'
    },
    'measurements': {
        'title': 'Measurements',
        'text': 'Displays all height, weight, head circumference, and BMI values that have been charted. The initial display shows only the most recent of each measurement, with a trend indicator comparing the result to the previous result. Click on a measurement to see the historical values.'
    },
    'contact_provider': {
        'title': 'Contact Providers',
        'text': 'Displays buttons for the primary and secondary contact providers.  Click the appropriate provider to send a text page. <b>Be sure to include your name and contact information in the body of the message</b>. After sending the page look for the "page sent" notice.'
    },
    'primary_care_provider': {
        'title': 'Primary Care Provider',
        'text': 'Displays detailed information on the primary care provider.'
    },
    'patient_family': {
        'title': 'Patient/Family',
        'text': 'Displays family and guardian contact information.'
    },
	'prescriptions': {
        'title': 'Prescriptions',
        'text': 'Displays active outpatient prescription information.'
     },
    'documented_meds': {
        'title': 'Documented Meds by Hx',
        'text': 'Displays the documented by history medication information.'
    },
    'home_meds': {
        'title': 'Home Meds',
        'text': 'Displays documented by history medication and active outpatient prescription information.'
    },
    'scheduled_appts': {
    'title': 'Visit Information',
    'text': 'Scheduled Appts Tab - Displays upcoming outpatient scheduled appointments and inpatient preadmits.<br><br>Displays the last 2 years clinic and inpatient visits as well as the name of the provider or service seen by the patient.  In addition, the details from the visit information order display when the desired clinic is selected, if available.'
    },
    'visit_info': {
    'title': 'Visit Information',
    'text': 'Displays visit information.'
    },
	'dme_orders': {
    'title': 'Devices and Supplies',
    'text': 'Displays DME orders for the last 5 years and Home Medical Supplies for the last year.'
    },
	'notifications': {
    'title': 'Notifications',
    'text': 'Please see <a href="{0}" target="_blank" title="Click to open help file">Help file</a> for more information on using the Results and Notifications panel'
     },
    'inpatient_results': {
    'title': 'Results',
    'text': 'Please see <a href="{0}" target="_blank" title="Click to open help file">Help file</a> for more information on using the Results and Notifications panel'
     },
	'additionalInfo': {
    'title': 'Additional Info',
    'text': 'Please see <a href="{0}" target="_blank" title="Click to open help file">Help file</a> for more information on using the Additional Info panel'
       },
	'keyinfo': {
    'title': 'Key Information',
    'text': 'Please see <a href="{0}" target="_blank" title="Click to open help file">Help file</a> for more information on using the Key Information panel'
	},
	'inpatientMeds': {
    'title': 'Inpatient Medications',
    'text': 'Please see <a href="{0}" target="_blank" title="Click to open help file">Help file</a> for more information on using the Inpatient Medications panel'
	},
	'addProbDx':{
    'title': 'Problems and Diagnoses',
    'text': 'Please see <a href="{0}" target="_blank" title="Click to open help file">Help file</a> for more information on using the Problems and Diagnoses panel'
	},
	'rnssAdmitReason': {
        'title': 'Reason for Admission and Past Medical History',
        'text': 'Displays the patient\'s reason for admission, pre-existing conditions, problems and diagnoses, and procedures performed during this admission.'
    },
	'rnssDeviceReview': {
        'title': 'System and Device Review',
        'text': 'Provides direct links to iView and Caredex Other.'
    },
	'rnssMedsReview': {
        'title': 'Medication Preferences and eMAR Review',
        'text': 'Displays any documented medication preferences for this admission and provides a direct link to the eMAR.'
    },
	'rnssLabReview': {
        'title': 'Lab Review',
        'text': 'Displays recent general lab and microbiology results as well as several lab-related links.'
    },
	'rnssTasks': {
        'title': 'Tasks',
        'text': 'Displays overdue tasks in red, and upcoming tasks (next 12 hours) in black.'
    },
	'rnssCarePlanning': {
        'title': 'Care Planning',
        'text': 'Displays problems and interventions from the Nursing Plan of Care PowerForm.'
    },
	'rnssDischargePlanning': {
        'title': 'Discharge Planning',
        'text': 'Displays discharge needs from the care plan, completed and in-progress discharge education, and provider-entered discharge criteria.'
    },
	'rnssSafetyChecklist': {
        'title': 'Safety Checklist',
        'text': 'Provides a direct link to the Safety Check PowerForm.'
    }
}
