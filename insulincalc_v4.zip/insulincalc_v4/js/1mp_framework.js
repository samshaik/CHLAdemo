/**
 * @author rpeltz
 */
/*
 * Global variable to help with debug and deployment
 */

Ext = window.Ext || {};
var jsonInfo; // holds on to basic patient info
//var App = new Ext.App({}); // used for alerts and status

Ext.ns('Child');
Child.version = '1.0';

Child.Framework = function() {
	
};

Child.Framework.ORDERID = '';
Child.Framework.USERID = 'testUser';

Child.Framework.VERSION = '2.0';

Child.Framework.APP_FOLDER = 'InsulinCalc_v4';

Child.Framework.WEB_ASSET_FILE_LOCATION = function() {
	var location = '';


			location = '../../common/new/';

	return location;


}();

Child.Framework.ENV_IS_TEST = function() {
	return (DOMAIN_NAME.toLowerCase().indexOf('test') > -1);
}();

Child.Framework.HTML_HELP_FILE_LOCATION = Child.Framework.WEB_ASSET_FILE_LOCATION + 'help/';

Child.Framework.HELP_SUMMARY = Child.Framework.WEB_ASSET_FILE_LOCATION + 'help/InsulinCalcHelp.pdf';

Child.Framework.HELP_FILE_LOCATION = Child.Framework.WEB_ASSET_FILE_LOCATION + 'help/';

Ext.BLANK_IMAGE_URL = Child.Framework.WEB_ASSET_FILE_LOCATION + 'img/s.gif';

Child.Framework.queryString = function(key) {
    //example of getting a location from the URL  
    key = key.replace(/[*+?^$.\[\]{}()|\\\/]/g, "\\$&"); // escape RegEx meta chars
    var match = location.search.match(new RegExp("[?&]"+key+"=([^&]+)(&|$)"));
    return match && decodeURIComponent(match[1].replace(/\+/g, " "));

};

Child.Framework.renderCaclculator = function() {
	//alert("renderCaclculator");
	if (!Child.CardLayouts.CardOneRendered ) {
		var InpatientCardOneLayout = Child.CardLayouts.GetCardOneLayoutPanel();
		Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL).add(InpatientCardOneLayout);
		Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL).getLayout()
				.setActiveItem(Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT);
	} else {
		Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL).getLayout()
				.setActiveItem(Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT);
	}

};

Child.Framework.calculatorInit = function(renderParams) {

	Child.NavigationPanelFactory.UpdateMainNavToolBar({
		type : 'calculator'
	});

	Child.NavigationPanelFactory.currentLocation = Child.NavigationPanelFactory.LOCATIONS.CARD_ONE;
	
	Child.Framework.renderCaclculator();

	// set up logging
	if (jQuery.hotkeys) {
		$(document).bind('keydown', 'Ctrl+/', function(evt) {
			if (jsonInfo['INSULIN_CALC']['USER_DEVELOPER'] === 'YES') {
				Child.Logger.HotKeyHandler();
			}
		});
	}

	renderParams = null; // make available for gc
};


Ext.onReady(function() {

	var screenHeight = window.screen.availHeight;
	var heightOfCard = $(window).height();
	var widthOfCard = $(window).width();
		
	if(screenHeight < heightOfCard) {
//		alert('resize to ' + screenHeight + '  ' + 800);
		window.resizeTo(780, (screenHeight - 20));
	}

	Ext.QuickTips.init();
	Ext.apply(Ext.QuickTips.getQuickTip(), {
			dismissDelay : 0,
			hideDelay : 200 
	});
	Ext.state.Manager.setProvider(new Ext.state.CookieProvider());
	var HELP_FILE_LOCATION = Child.Framework.WEB_ASSET_FILE_LOCATION + 'Help_Summary.pdf';

	var ordid = Child.Framework.queryString('ordid');
	if (ordid !== undefined) {
		Child.Framework.ORDERID = ordid;
	}

	var userid = Child.Framework.queryString('userid');
	if (userid !== undefined && userid !== null) {
		Child.Framework.USERID = userid;
	}
	//alert("encid: " + encid);
 
    //alert("onReady");
	window.port = new Ext.Viewport({
		id : 'port',
		layout : 'fit',
		items : [{
			id : Child.GlobalDomIds.MAIN_PANEL,
			xtype : 'panel',
			layout : 'card',
			activeItem : 0,
			border : false,
			layoutOnCardChange : true,
			frame : false,
			items : [{
						id : 'loading-card',
						layout : 'fit',
						html : '<div class="loading-indicator">Loading...</div>'
					}],
			tbar : Child.NavigationPanelFactory.InitMainNavToolBar()
		}]

	});

	Child.Framework.calculatorInit();
// call init
//	Child.DataRequest({
//				cclProgram : '1mp_icalc_init',
//				renderFn : Child.Framework.calculatorInit
//			});

});
