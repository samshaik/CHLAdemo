/**
 * @author rpeltz
 */
Ext = window.Ext || {};
Ext.ns('Child');
Child.version = '2.0';
Child.Logger = function(msg, type) {

};
Child.Logger.HotKeyHandler = function() {
	if (Child.Logger.ShouldLog === true) {
		// turn it off
		Child.Logger.ShouldLog = false;
		if (Child.Logger.WinHandle) {
			Child.Logger.WinHandle.close();
			Child.Logger.WinHandle = null;
		}
	} else {
		Child.Logger.ShouldLog = true;
		Child.Logger.Log("Logging intiated at " + new Date());
	}
};
Child.Logger.OpenLog = function() {
	if (!Child.Logger.WinHandle) {
		Child.Logger.WinHandle = window
				.open(
						'',
						'Logger',
						'width=400,height=300,resizable=1,scrollbars=1,location=0,menubar=0,toolbar=0,titlebar=0');
		Child.Logger.WinHandle.document
				.write('<html><body><div id="msg"></div></body></html>');
	}
	
};
Child.Logger.WinHandle = null;

Child.Logger.Log = function(msg, type) {
	
	if (Child.Logger.ShouldLog === true) {
		Child.Logger.OpenLog();
		// Child.Logger.WinHandle.document.write("<div>" + msg + "</div>");
		var msgDiv = Child.Logger.WinHandle.document.getElementById("msg");
		msgDiv.innerHTML = msg;
		// Child.Logger.WinHandle.focus(); no need for focus
	}

};


Child.Logger.ShouldLog = false;

Child.Logger.IsLogWinOpen = function() {
	var returnVal = false;
	if (Child.Logger.WinHandle) {
		returnVal = !Child.Logger.WinHandle.closed;
	}
	return returnVal;
};


/**
 * @author rpeltz
 */

Ext.ns('Child');
Child.version = '2.0';
Child.CardLayouts = function() {
};

Child.CardLayouts.buildHtmlHelpFileToolBarBtn = function(filename) {
	if(filename !== '') {
		return {
			xtype : 'button',
			icon : Child.Framework.WEB_ASSET_FILE_LOCATION + 'img/helpIconSmall.gif',
			tooltip : "Click for Help",
			handler : function(theButton, event) {
				// id : 'help',
				// collapsible : true,
				// qtip : "Click for Help",
				// handler : function(event, toolEl, panel) {
//				var win = window.open(Child.Framework.HTML_HELP_FILE_LOCATION + filename, '_blank', 'menubar=no,toolbar=yes,resizable=yes,scrollbars=yes');
				Child.WebServices.applink(100, Child.Framework.HTML_HELP_FILE_LOCATION + filename, null, null, null, null, null, "menubar=no,toolbar=yes,resizable=yes,scrollbars=yes");
			}
		};
	}
	else {
		return '';
	}
};

Child.CardLayouts.buildWindowExpandPanelToolBarBtn = function(configs) {
	return {
		xtype : 'button',
		// id : 'window',
		// qtip : 'toggle panel',
		// collapsible : true,
		icon : Child.Framework.WEB_ASSET_FILE_LOCATION + 'img/glass.png',
		tooltip : "Click to Expand panel",
		handler : function(theButton, event) {
			if (!Ext.getCmp('THE_POPUP_WINDOW')) {
				// Just incase this is NOT a modal window, do not open another
				// one until the previous is closed
				var configOptions = '';
				if (configs) {
					configOptions = configs;
				}

				var heightOfCard = window.port.getSize().height - 20;
				var widthOfCard = window.port.getSize().width - 20;

				var popupHeight = 520; // heightOfCard;
				if (configOptions.height) {
					popupHeight = configOptions.height;
				}

				if (popupHeight > heightOfCard) {
					popupHeight = heightOfCard;
				}

				var popupWidth = 800; // widthOfCard;
				if (configOptions.width) {
					popupWidth = configOptions.width;
				}

				if (popupWidth > widthOfCard) {
					popupWidth = widthOfCard;
				}

				var setMaximizable = true;
				if (configOptions.maximizable === false) {
					setMaximizable = configOptions.maximizable;
				}
				var thePanel = theButton.ownerCt.ownerCt;
				var theContainer = thePanel.ownerCt;
				theContainer.removeAll(false);
				// thePanel.tools.window.hide();
				theButton.hide();

				var thePopUpWindow = new Ext.Window({
					id : 'THE_POPUP_WINDOW',
					layout : 'fit',
					modal : true,
					width : popupWidth,
					height : popupHeight,
					autoHeight : false,
					y : 10,
					resizable : true,
					animateTarget : theContainer.id,
					stateful : false,
					autoScroll : false,
					forceLayout : true,
					closeAction : 'close',
					bbar : new Ext.Toolbar({
								buttonAlign : 'right',
								items : [new Ext.Toolbar.Button({
											tooltip : 'Close',
											overflowText : 'Close',
											text : 'Close',
											handler : function() {
												var tWin = Ext
														.getCmp('THE_POPUP_WINDOW');
												tWin.close();
											}
										})]
							}),
					items : [thePanel],
					maximizable : setMaximizable,
					listeners : {
						beforeclose : function(popupWindow) {
							popupWindow.removeAll(false);
							theContainer.insert(0, thePanel);
							// thePanel.tools.window.show();
							theButton.show();

							theContainer.doLayout();
						}
					}
				});

				thePopUpWindow.show();

			}
		}
	};
};

Child.CardLayouts.buildFrameworkToolBar = function(panelTitle, helpFileName, skipExpandOption, tbId, configs) {
	var expandTool = '';
	if(!skipExpandOption) {
		expandTool = Child.CardLayouts.buildWindowExpandPanelToolBarBtn(configs);
	}
	return {
		cls : 'x-panel-header',
		id : tbId,
		items : [expandTool, 
				{
					xtype : 'tbtext',
					cls : 'panel-header',
					text : panelTitle
				}, {
					xtype : 'tbfill'
				},
				Child.CardLayouts.buildHtmlHelpFileToolBarBtn(helpFileName)]
	};
};

Child.CardLayouts.GetCardOneLayoutPanel = function() {

	var viewportHeight;
	viewportHeight = Ext.getCmp('MAIN_PANEL').body.getHeight() - 10;
	var skipExpandTool = true;	// set to true to skip expand (magnifying glass) tool for all panels
	
	return new Ext.Panel({
		id : Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT,
		hideMode : 'offsets',
		layout : {
			type : 'hbox',
			pack : 'start',
			align : 'stretch'
		},
		height : viewportHeight,
		border : false,
		items : [{
			flex : 1,
			baseCls : 'x-plain',
			layout : 'anchor',
			padding : '0px 0px 0px 0px',
			items : {
				border : false,
				anchor : '100% 100%',
				id : Child.GlobalDomIds.INSULIN_ORDERS_CARD_1,
				border : false,
				layout : {
					type : 'vbox',
					pack : 'start',
					align : 'stretch',
					defaultMargins : {
						top : 0,
						right : 0,
						bottom : 2,
						left : 0
					}
				},
				items : [{
					xtype : 'panel',
					border : false,
					//height : 450, //250,
					flex: 1,
					layout : 'fit',
					items : {
						xtype : 'panel',
						border : false,
						layout : 'fit',
						id : Child.GlobalDomIds.INSULIN_ORDERS_CARD_1_PANEL_1_ID,
//						tbar : Child.CardLayouts.buildFrameworkToolBar(
//								'Insulin Orders', 'dummy.html', skipExpandTool, 'FRAMEWORK_TOOLBAR_' + Child.GlobalDomIds.INSULIN_ORDERS_CARD_1_PANEL_1_ID),
						items : {
							border : false,
		                    listeners: { 
		                    	render: {
		                        	fn: function(){
		                                this.setLoading("Loading...");
		                            }
		                    	}
		                    }
//							html : '<div class="loading-indicator">Loading..</div>'
						}
					}
				}]
			}
		}],
		listeners : {

			afterlayout : function(pnl, layout) {
				Child.LoadData.InpatientCardOne();
			},
			options : {
				single : true
			}
		}

	});
	
};



//set up flags indicating the card are laid out
//init to false, set true when loading indicator rendered
Child.CardLayouts.CardOneRendered = false;

Ext.ns("CHILD.InsulinCalcEngine");

function TestMe() {
    CHILD.InsulinCalcEngine.startup();
    alert('done');
}

CHILD.InsulinCalcEngine.startup = function startup() {
    var uji = new CHILD.InsulinCalcEngine.UserAndJsonInputs();
    uji.PatientAgeYears = 5;
    uji.IsU100StandardInsulin = true;
    uji.DisplayLine = "";
    uji.AdminTime = "Breakfast";
    uji.CarbInsulinRatio = 14;
    uji.CorrectionFactor = 17;
    uji.TargetBloodGlucose = 100;
    uji.Increment = 0.5;
    uji.GramsOfCarbsEaten = 200;
    uji.CurrentBloodGlucose = 300;
    uji.IsMoreThan3HoursSinceLastInsulin = false;
    uji.IsSickDay = false;
    uji.SickDayFactor = 1.0;
    // Validate all the uji inputs here first!
    var insulinData = new CHILD.InsulinCalcEngine.InsulinData(uji);
    var ic = insulinData.InsulinToCoverCarbs;
};

CHILD.InsulinCalcEngine.UserAndJsonInputs = (function () {
    function UserAndJsonInputs() { }
    return UserAndJsonInputs;
})();
CHILD.InsulinCalcEngine.IsLikeSnack = function(uji) {

	return uji.AdminTime.toLowerCase() === Child.GlobalDomIds.snacks || uji.AdminTime.toLowerCase() === Child.GlobalDomIds.sickday;
	
};

CHILD.InsulinCalcEngine.InsulinData = (function () {
    function InsulinData(uji) {
    	var idx = 0;
    	// First perform some field edits to set variables at calc limit and set up error msgs to be returned.
    	var errArray = new Array();
		var fatalErr = CHILD.InsulinCalcEngine.scrubInputForErrors(errArray, uji);
    	
		if(!fatalErr) {
			// Insulin To Cover Carbs
	        var ret = uji.GramsOfCarbsEaten / uji.CarbInsulinRatio;
	        this.InsulinToCoverCarbs = uji.IsU100StandardInsulin ? ret : ret * 0.1;
	        // Insulin to Correct BG At Meals
	        ret = ((uji.CurrentBloodGlucose - uji.TargetBloodGlucose) / uji.CorrectionFactor) * uji.SickDayFactor;
	        ret = uji.IsU100StandardInsulin ? ret : ret * 0.1;
	        this.InsulinToCorrectBGatMeals = ret > 0 ? ret : 0;
	        // Insulin to Deliver At Meals
	        this.InsulinToDeliveratMeals = this.InsulinToCoverCarbs + this.InsulinToCorrectBGatMeals;
	        
	        // Insulin To Correct at Bedtime is now treated same as daytime, 20151116swood3 stop halving bedtime dose
	        // stop checking for BG hyperglycemic
        	this.InsulinToCorrectAtBedtime = this.InsulinToCorrectBGatMeals;
       	    this.InsulinToDeliverBedtime = this.InsulinToCoverCarbs + this.InsulinToCorrectAtBedtime;
	        
	        // Max Target For Age
	        if (uji.PatientAgeYears < 5) {
	            this.MaxTargetBGForAge = CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo.value;
	        } else if (uji.PatientAgeYears >= 12) {
	            this.MaxTargetBGForAge = CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo.value;
	        } else {
	            this.MaxTargetBGForAge = CHILD.InsulinCalcConstants.TargetBGMax5to12yo.value;
	        }
	        // Insulin To Deliver At Snacks
	        // if snack and > 3 hours since rapid and BG above target then add insulin to cover carbs too
	 		if(CHILD.InsulinCalcEngine.IsLikeSnack(uji)) {
	 			if(uji.CurrentBloodGlucose === '') {
	    	        this.InsulinToDeliveratSnacks = this.InsulinToCoverCarbs;
	 			} else {
	 				if(uji.CurrentBloodGlucose <= uji.TargetBloodGlucose) {
		    	        this.InsulinToDeliveratSnacks = this.InsulinToCoverCarbs;
	 				} else {
	 					var numHrs = 3;
	 					var tempMsg = 'Calculated insulin for snack';
	 					if(uji.IsSickDay) {
	 						numHrs = 2;
	 						tempMsg = 'Calculated insulin for sick day';
	 					}
			        	if (uji.IsMoreThan3HoursSinceLastInsulin) {
//			        		if(uji.CurrentBloodGlucose > uji.TargetBloodGlucose) {
			    	        	this.InsulinToDeliveratSnacks = this.InsulinToCoverCarbs + this.InsulinToCorrectBGatMeals;
		    	    	    	idx = errArray.push();
								errArray[idx] = Ext.String.format('It has been more than {2} hours since the last rapid-acting insulin was given and the Current Blood Glucose ({0}) is above the Target Blood Glucose ({1}). {3} <b>WILL INCLUDE</b> insulin to cover Current Blood Glucose.', 
								uji.CurrentBloodGlucose, 
								uji.TargetBloodGlucose,
								numHrs,
								tempMsg);
//			        		}
	        			} else {
		            		this.InsulinToDeliveratSnacks = this.InsulinToCoverCarbs;
		            		idx = errArray.push();
	    	        		errArray[idx] = Ext.String.format('It has not been more than {0} hours since the last rapid-acting insulin was given.  {1} <b>WILL NOT INCLUDE</b> insulin to cover the Current Blood Glucose.  Please see the MAR for more information.',
	    	        		numHrs,
	    	        		tempMsg);
	        			}
 					}
	 			}
 			}
	
	 		//Rounded Insulin To Deliver
	        switch (uji.AdminTime.toLowerCase()) {
	            case "breakfast":
	            case "lunch":
	            case "dinner":
	            case "meals":
	                this.RoundedInsulinToDeliver = CHILD.InsulinCalcEngine.GetRoundedDown(this.InsulinToDeliveratMeals, uji);
	                break;
	            case "snacks":
	            case "sickday":
	                this.RoundedInsulinToDeliver = CHILD.InsulinCalcEngine.GetRoundedDown(this.InsulinToDeliveratSnacks, uji);
	               break;
	            case "bedtime":
	                this.RoundedInsulinToDeliver = CHILD.InsulinCalcEngine.GetRoundedDown(this.InsulinToDeliverBedtime, uji);
	                break;
	            default:
	            	break;
	        }
	
//       		this.roundingStr = Ext.String.format('(Rounded down to the nearest {0} units)', uji.Increment);
	        
	        if(!uji.IsU100StandardInsulin && this.RoundedInsulinToDeliver > 0) {
	         	// dilute warning message
	       		idx = errArray.push();
	       		errArray[idx] = Ext.String.format('Chart {0} units of DILUTE insulin.  On the U100 syringe draw 10 units/mL insulin to the {1} unit mark.', this.RoundedInsulinToDeliver, this.RoundedInsulinToDeliver * 10);
	        }
	        
	        var multiplier = 1;
	        if(!uji.IsU100StandardInsulin) {
	        	// Dilute insulin use 0.1 as multiplier
	        	multiplier = 0.1;
	        }

	        var tmpCarbCover = ((uji.GramsOfCarbsEaten / uji.CarbInsulinRatio) * multiplier).toFixed(2);
	        var tmpBGCover = '';
			if(uji.CurrentBloodGlucose > uji.TargetBloodGlucose) {
	        	tmpBGCover = (uji.SickDayFactor * (((uji.CurrentBloodGlucose - uji.TargetBloodGlucose)/ uji.CorrectionFactor) * multiplier)).toFixed(2);
			} else {
				tmpBGCover = '0';
			}

			if(uji.AdminTime.toLowerCase() === Child.GlobalDomIds.bedtime) { 

				// 20151112 swood3 stop using hyper threshold at bedtime
				if(uji.CurrentBloodGlucose >= uji.TargetBloodGlucose) {
		    	    tmpBGCover = (uji.SickDayFactor * (((uji.CurrentBloodGlucose - uji.TargetBloodGlucose)/ uji.CorrectionFactor) * multiplier)).toFixed(2);
				} else {
					tmpBGCover = '0';
				}
			}
			
			if(uji.IsMoreThan3HoursSinceLastInsulin === false) {
				if(CHILD.InsulinCalcEngine.IsLikeSnack(uji)) {
					tmpBGCover = '0';
				}
			}
        	
        	this.formula = Ext.String.format('Dose to administer = {0} + {1} = {2} = {3}',
        		tmpCarbCover,
        		tmpBGCover,
        		(Number(tmpCarbCover) + Number(tmpBGCover)).toFixed(2),
        		this.RoundedInsulinToDeliver) + Ext.String.format('</br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Rounded down to the nearest {0} units)', uji.Increment);
		}

        // add array of errors to the return object
		this.ErrorArray = errArray;
        
    }
    return InsulinData;
})();

CHILD.InsulinCalcEngine.GetRoundedDown = function (raw, uji){
    var ret = 0;
    switch (uji.Increment) {
        case 1:
            ret = Math.floor(raw);
            break;
        case 0.5:
            var floor = Math.floor(raw);
            ret = raw >= (floor + 0.5) ? floor + 0.5 : floor;
            break;
        case 0.1:
            raw = raw * 10;
            ret = Math.floor(raw) / 10;
            break;
        default:
        	break;
    }
    return ret;
};

CHILD.InsulinCalcEngine.scrubInputForOrderEntryErrors = function(errArray, uji) {

	var idx = 0;
	var fatalErr = false;
	var tmpAdminTime = uji.AdminTime.toLowerCase();

	if(tmpAdminTime !== 'breakfast' &&
		tmpAdminTime !== 'lunch' &&
		tmpAdminTime !== 'dinner' &&
		tmpAdminTime !== 'meals' &&
		tmpAdminTime !== 'snacks' &&
		tmpAdminTime !== 'sickday' &&
		tmpAdminTime !== 'bedtime') {
		errArray.push();
		errArray[idx] = Ext.String.format('ORDER ERROR: Unexpected Admin Time <b>({0})</b> from the order', uji.AdminTime);
		idx++;
		fatalErr = true;
	}
	
	if(uji.Increment !== 0.5 && uji.Increment !== 0.1 && uji.Increment !== 1) {
		errArray.push();
		errArray[idx] = Ext.String.format('ORDER ERROR: Increment not = 0.1, 0.5 or 1.0');
		idx++;
		fatalErr = true;
	}
	
	return fatalErr;

};

CHILD.InsulinCalcEngine.scrubInputForErrors = function(errArray, uji) {

	var fatalErr = false;
	var idx = 0;
	var tmpAdminTime = uji.AdminTime.toLowerCase();
	
	if(!CHILD.InsulinCalcEngine.scrubInputForOrderEntryErrors(errArray, uji)) {
		//not any fatal order entry errors - continue with other edits
		if(uji.GramsOfCarbsEaten > CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value) {
			uji.GramsOfCarbsEaten = CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value;
			errArray.push();
			errArray[idx] = Ext.String.format('The calculated dose only covers {0} grams of carbohydrates; Call MD for additional recommendations.', CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value);
			idx++;
		}
		
		if (uji.CurrentBloodGlucose > CHILD.InsulinCalcConstants.BGLimtForCalc.value) {
			uji.CurrentBloodGlucose = CHILD.InsulinCalcConstants.BGLimtForCalc.value;
			if(!((CHILD.InsulinCalcEngine.IsLikeSnack(uji)) && !uji.IsMoreThan3HoursSinceLastInsulin)) {
				errArray.push();
				errArray[idx] = Ext.String.format('The Calculated Dose only covers hyperglycemia up to {0} mg/dL;  Call MD for additional recommendations.', CHILD.InsulinCalcConstants.BGLimtForCalc.value);
				idx++;
			}
		}
		
		if(	!((CHILD.InsulinCalcEngine.IsLikeSnack(uji)) && uji.CurrentBloodGlucose === "") ) {
			if(uji.CurrentBloodGlucose < CHILD.InsulinCalcConstants.BGCriticalHypoThreshold.value) {
				errArray.push();
				if(uji.PatientAgeYears <= 5) {
					errArray[idx] = Ext.String.format('The patient is CRITICALLY HYPOGLYCEMIC. Administer 10 grams of simple carbohydrates, and CALL MD.  Check blood sugar in 15 minutes.');
				} else {
					errArray[idx] = Ext.String.format('The patient is CRITICALLY HYPOGLYCEMIC. Administer 15 grams of simple carbohydrates, and CALL MD.  Check blood sugar in 15 minutes.');
				}
				idx++;
				fatalErr = true;
			} else {
				if(uji.CurrentBloodGlucose <CHILD.InsulinCalcConstants.BGHypoThreshold.value) {
					errArray.push();
					if(uji.PatientAgeYears <= 5) {
						errArray[idx] = Ext.String.format('The patient is HYPOGLYCEMIC. Administer 10 grams of simple carbohydrates, and recheck blood sugar in 15 minutes.');
					} else {
						errArray[idx] = Ext.String.format('The patient is HYPOGLYCEMIC. Administer 15 grams of simple carbohydrates, and recheck blood sugar in 15 minutes.');
					}
					idx++;
					fatalErr = true;
				}
			}
		}
		
		if(uji.TargetBloodGlucose > CHILD.InsulinCalcConstants.TargetBGMax.value ||
			uji.TargetBloodGlucose < CHILD.InsulinCalcConstants.TargetBGMin.value) {
			errArray.push();
			errArray[idx] = Ext.String.format('ERROR: Target Blood Glucose is outside the allowable range of ({0} - {1}).', CHILD.InsulinCalcConstants.TargetBGMin.value, CHILD.InsulinCalcConstants.TargetBGMax.value);
			idx++;
			fatalErr = true;
		}
	}
	
	return fatalErr;

};
 
CHILD.InsulinCalcEngine.editCarbsEaten = function(uji) {

	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;	//OK WARN ERROR
	theReturnObj.msg = '';
	theReturnObj.formula = '';
    var multiplier = 1;
	if(!uji.IsU100StandardInsulin) {
		// Dilute insulin use 0.1 as multiplier
	    multiplier = 0.1;
	}
	if(uji.IsU100StandardInsulin) {
		if(uji.GramsOfCarbsEaten === '') {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Carbs Eaten is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.CarbsEatenMin.value, CHILD.InsulinCalcConstants.CarbsEatenMax.value);
		} else {
			if (uji.GramsOfCarbsEaten < CHILD.InsulinCalcConstants.CarbsEatenMin.value ||
				uji.GramsOfCarbsEaten > CHILD.InsulinCalcConstants.CarbsEatenMax.value) {
				theReturnObj.status = Child.GlobalDomIds.ERROR;
				theReturnObj.msg = Ext.String.format('Carbs Eaten is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.CarbsEatenMin.value, CHILD.InsulinCalcConstants.CarbsEatenMax.value);
			} else if(uji.GramsOfCarbsEaten <= CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value) {
				theReturnObj.status = Child.GlobalDomIds.OK;
				theReturnObj.formula = Ext.String.format('Carbohydrate coverage = {0} / {1} = {2} units', uji.GramsOfCarbsEaten, uji.CarbInsulinRatio, ((uji.GramsOfCarbsEaten / uji.CarbInsulinRatio) * multiplier).toFixed(2));
			} else {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Carbs entered are OVER calculator limit. {0} gms will be used', CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value);
				theReturnObj.formula = Ext.String.format('Carbohydrate coverage = {0} / {1} = {2} units', CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value, uji.CarbInsulinRatio, ((CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value / uji.CarbInsulinRatio) * multiplier).toFixed(2));
			}
		}
	} else {
		if(uji.GramsOfCarbsEaten === '') {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Carbs Eaten is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.CarbsEatenDiluteMin.value, CHILD.InsulinCalcConstants.CarbsEatenDiluteMax.value);
		} else {
			//Dilute edits
			if (uji.GramsOfCarbsEaten < CHILD.InsulinCalcConstants.CarbsEatenDiluteMin.value ||
				uji.GramsOfCarbsEaten > CHILD.InsulinCalcConstants.CarbsEatenDiluteMax.value) {
				theReturnObj.status = Child.GlobalDomIds.ERROR;
				theReturnObj.msg = Ext.String.format('Carbs Eaten is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.CarbsEatenDiluteMin.value, CHILD.InsulinCalcConstants.CarbsEatenDiluteMax.value);
			} else if(uji.GramsOfCarbsEaten <= CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value) {
				theReturnObj.status = Child.GlobalDomIds.OK;
				theReturnObj.formula = Ext.String.format('Carbohydrate coverage = {0} / {1} = {2} units', uji.GramsOfCarbsEaten, uji.CarbInsulinRatio, ((uji.GramsOfCarbsEaten / uji.CarbInsulinRatio) * multiplier).toFixed(2));
			} else {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Carbs entered are OVER calculator limit. {0} gms will be used', CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value);
				theReturnObj.formula = Ext.String.format('Carbohydrate coverage = {0} / {1} = {2} units', CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value, uji.CarbInsulinRatio, ((CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value / uji.CarbInsulinRatio) * multiplier).toFixed(2));
			}
		}
	}
	
	return theReturnObj;

};

CHILD.InsulinCalcEngine.editBGForCalc = function(uji) {

	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;	//OK WARN ERROR HYPOCRIT HYPO
	theReturnObj.msg = '';
	theReturnObj.formula = '';
    var multiplier = 1;
	if(!uji.IsU100StandardInsulin) {
		// Dilute insulin use 0.1 as multiplier
	    multiplier = 0.1;
	}

	if(	uji.AdminTime.toLowerCase() === Child.GlobalDomIds.snacks &&
		uji.IsSickDay === false &&
		uji.CurrentBloodGlucose === "" ) {
			theReturnObj.status = Child.GlobalDomIds.OK;
			theReturnObj.formula = Ext.String.format('Blood Glucose for Calculation not taken');
	} else {
		if(uji.CurrentBloodGlucose > 0 && uji.CurrentBloodGlucose < CHILD.InsulinCalcConstants.BGCriticalHypoThreshold.value) {
			theReturnObj.status = Child.GlobalDomIds.HYPOCRIT;
			if(uji.PatientAgeYears <= 5) {
				theReturnObj.formula = 'The patient is CRITICALLY HYPOGLYCEMIC. Administer 10 grams of simple';
			} else {
				theReturnObj.formula = 'The patient is CRITICALLY HYPOGLYCEMIC. Administer 15 grams of simple';
			}
			theReturnObj.msg = Ext.String.format('carbohydrates, and CALL MD.  Check blood sugar in 15 minutes');
		} else {
			if(uji.CurrentBloodGlucose > 0 && uji.CurrentBloodGlucose <CHILD.InsulinCalcConstants.BGHypoThreshold.value) {
				theReturnObj.status = Child.GlobalDomIds.HYPO;
				if(uji.PatientAgeYears <= 5) {
					theReturnObj.formula = 'The patient is HYPOGLYCEMIC. Administer 10 grams of simple';
				} else {
					theReturnObj.formula = 'The patient is HYPOGLYCEMIC. Administer 15 grams of simple';
				}
				theReturnObj.msg = Ext.String.format('carbohydrates, and recheck blood sugar in 15 minutes');
			} else if(uji.CurrentBloodGlucose > CHILD.InsulinCalcConstants.BGMaximum.value ||
				uji.CurrentBloodGlucose < CHILD.InsulinCalcConstants.BGMinimum.value) {
				theReturnObj.status = Child.GlobalDomIds.ERROR;
				theReturnObj.msg = Ext.String.format('Blood Glucose for Calculation is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.BGMinimum.value, CHILD.InsulinCalcConstants.BGMaximum.value);
			} else if (uji.CurrentBloodGlucose <= CHILD.InsulinCalcConstants.BGLimtForCalc.value) {
				theReturnObj.status = Child.GlobalDomIds.OK;

				if(!uji.IsMoreThan3HoursSinceLastInsulin && (CHILD.InsulinCalcEngine.IsLikeSnack(uji))) {
						theReturnObj.formula = Ext.String.format('Correction for High BG = 0 units');
				} else {
					if(uji.CurrentBloodGlucose > uji.TargetBloodGlucose) {
						if(uji.SickDayFactor === 1) {
							theReturnObj.formula = Ext.String.format('Correction for High BG = ({0} - {1}) / {2} = {3} units', uji.CurrentBloodGlucose, uji.TargetBloodGlucose, uji.CorrectionFactor, (((uji.CurrentBloodGlucose - uji.TargetBloodGlucose) / uji.CorrectionFactor) * multiplier).toFixed(2));
						} else {
							theReturnObj.formula = Ext.String.format('Correction for High BG = {4} * (({0} - {1}) / {2}) = {3} units', uji.CurrentBloodGlucose, uji.TargetBloodGlucose, uji.CorrectionFactor, 
							(uji.SickDayFactor * ((uji.CurrentBloodGlucose - uji.TargetBloodGlucose) / uji.CorrectionFactor) * multiplier).toFixed(2), uji.SickDayFactor);
						}
					} else {
						theReturnObj.formula = Ext.String.format('Correction for High BG = 0 units');
					}
				}
			} else {
				
				// Over calculator BG limit logic
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('BG > Calc limit of {0} - Calculation will use BG of {0}', CHILD.InsulinCalcConstants.BGLimtForCalc.value);
				if(!uji.IsMoreThan3HoursSinceLastInsulin && (CHILD.InsulinCalcEngine.IsLikeSnack(uji))) {
					theReturnObj.formula = Ext.String.format('Correction for High BG = 0 units');
					theReturnObj.msg = '';
					theReturnObj.status = Child.GlobalDomIds.OK;
				}
				else {
					if(uji.SickDayFactor === 1) {
						theReturnObj.formula = Ext.String.format('Correction for High BG = ({0} - {1}) / {2} = {3} units', CHILD.InsulinCalcConstants.BGLimtForCalc.value, uji.TargetBloodGlucose, uji.CorrectionFactor, (((CHILD.InsulinCalcConstants.BGLimtForCalc.value - uji.TargetBloodGlucose) / uji.CorrectionFactor) * multiplier).toFixed(2));
					} else {
						theReturnObj.formula = Ext.String.format('Correction for High BG = {4} * (({0} - {1}) / {2}) = {3} units', 
						CHILD.InsulinCalcConstants.BGLimtForCalc.value, 
						uji.TargetBloodGlucose, 
						uji.CorrectionFactor, 
						(uji.SickDayFactor * ((CHILD.InsulinCalcConstants.BGLimtForCalc.value - uji.TargetBloodGlucose) / uji.CorrectionFactor) * multiplier).toFixed(2),
						uji.SickDayFactor);
					}
				}
			}
		}
	}

//	if(!returnFormula) {
//		if(theReturnObj.status !== Child.GlobalDomIds.ERROR) {
//			theReturnObj.formula = '';
//			theReturnObj.msg = '';
//		}
//	}

	return theReturnObj;

};

CHILD.InsulinCalcEngine.editBOHBForCalc = function(uji) {

	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;		//OK - WARN - ERROR
	theReturnObj.msg = '';
	theReturnObj.formula = '';

	if(uji.SickDayFactor !== 1.0 && uji.SickDayFactor !== 1.5 && uji.SickDayFactor !== 2.0) {
		theReturnObj.status = Child.GlobalDomIds.ERROR;
		theReturnObj.msg = Ext.String.format('Invalid Ketones (Serum or Urine) value selected.');
	} if(uji.IsMoreThan3HoursSinceLastInsulin === false) {
		theReturnObj.status = Child.GlobalDomIds.WARN;
		theReturnObj.formula = Ext.String.format('Sick day factor = {0}', uji.SickDayFactor);
		theReturnObj.msg = Ext.String.format('Rapid-acting insulin given - No Ketones adjustment');
	} else {
		theReturnObj.formula = Ext.String.format('Sick day factor = {0}', uji.SickDayFactor);
//		var returnVal = CHILD.InsulinCalcEngine.editBGForCalc(uji, true);
//		if(returnVal.status !== Child.GlobalDomIds.ERROR) {
//			theReturnObj.formula = returnVal.formula; //Ext.String.format('Correction for Sick Day High BG = {0} * {1} = {2} units', "?", uji.SickDayFactor, "?");
//			theReturnObj.msg = returnVal.msg;
//		}
	}
	
	return theReturnObj;

};

CHILD.InsulinCalcEngine.editCarbRatio = function(uji) {

	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;		//OK - WARN - ERROR
	theReturnObj.msg = '';
	theReturnObj.formula = '';
	var unitVal = 1;
//	if(uji.Increment === 0.1) {
	if(!uji.IsU100StandardInsulin) {
		unitVal = 0.1;
	}

	if(	uji.CarbInsulinRatio === 0) {
		theReturnObj.status = Child.GlobalDomIds.ERROR;
		theReturnObj.msg = Ext.String.format('Insulin/Carb Ratio may not be 0');
	} else if(	uji.CarbInsulinRatio < CHILD.InsulinCalcConstants.InsulinCarbRatioMin.value) {//InsulinCarbRatioDiluteMin
		theReturnObj.status = Child.GlobalDomIds.ERROR;
		theReturnObj.msg = Ext.String.format('Insulin/Carb Ratio is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.InsulinCarbRatioMin.value, CHILD.InsulinCalcConstants.InsulinCarbRatioMax.value);
		theReturnObj.formula = Ext.String.format('{1} unit of insulin covers {0} grams of carbohydrates eaten', uji.CarbInsulinRatio,unitVal);
	} 
	else if (uji.CarbInsulinRatio > CHILD.InsulinCalcConstants.InsulinCarbRatioMax.value) {
		theReturnObj.status = Child.GlobalDomIds.ERROR;
		theReturnObj.msg = Ext.String.format('Insulin/Carb Ratio is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.InsulinCarbRatioMin.value, CHILD.InsulinCalcConstants.InsulinCarbRatioMax.value);
		theReturnObj.formula = Ext.String.format('{1} unit of insulin covers {0} grams of carbohydrates eaten', uji.CarbInsulinRatio,unitVal);
	} else {
		theReturnObj.status = Child.GlobalDomIds.OK;
		theReturnObj.formula = Ext.String.format('{1} unit of insulin covers {0} grams of carbohydrates eaten', uji.CarbInsulinRatio,unitVal);
	}

	return theReturnObj;

};

 CHILD.InsulinCalcEngine.editCorrectionFactor = function(uji) {
 	
	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;		//OK - WARN - ERROR
	theReturnObj.msg = '';
	theReturnObj.formula = '';

	if(uji.IsU100StandardInsulin) {
		if(	uji.CorrectionFactor < CHILD.InsulinCalcConstants.CorrectionFactorMin.value) {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Correction Factor is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.CorrectionFactorMin.value, CHILD.InsulinCalcConstants.CorrectionFactorMax.value);
			theReturnObj.formula = Ext.String.format('1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		} 
		else if (uji.CorrectionFactor > CHILD.InsulinCalcConstants.CorrectionFactorMax.value) {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Correction Factor is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.CorrectionFactorMin.value, CHILD.InsulinCalcConstants.CorrectionFactorMax.value);
			theReturnObj.formula = Ext.String.format('1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		} else if (uji.CorrectionFactor > CHILD.InsulinCalcConstants.CorrectionFactorWarnMax.value) {
			theReturnObj.status = Child.GlobalDomIds.WARN;
			theReturnObj.msg = Ext.String.format('Correction Factor is outside recommended range ({0} - {1})', CHILD.InsulinCalcConstants.CorrectionFactorMin.value, CHILD.InsulinCalcConstants.CorrectionFactorWarnMax.value);
			theReturnObj.formula = Ext.String.format('1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		} else {
			theReturnObj.status = Child.GlobalDomIds.OK;
			theReturnObj.formula = Ext.String.format('1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		}
	} else {
		if(	uji.CorrectionFactor < CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin.value) {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Dilute 10 units/mL Correction Factor is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin.value, CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax.value);
			theReturnObj.formula = Ext.String.format('0.1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		} 
		else if (uji.CorrectionFactor > CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax.value) {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Dilute 10 units/mL Correction Factor is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin.value, CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax.value);
			theReturnObj.formula = Ext.String.format('0.1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		} else {
			theReturnObj.status = Child.GlobalDomIds.OK;
			theReturnObj.formula = Ext.String.format('0.1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		}
	}


	return theReturnObj;
	
};

CHILD.InsulinCalcEngine.editTargetBG = function(uji) {

	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;		//OK - WARN - ERROR
	theReturnObj.msg = '';

	// Over all min and max that causes error, different for nighttime
	if(uji.AdminTime.toLowerCase() === Child.GlobalDomIds.bedtime) {
		if(	uji.TargetBloodGlucose > CHILD.InsulinCalcConstants.TargetBGMaxNighttime.value ||
			uji.TargetBloodGlucose < CHILD.InsulinCalcConstants.TargetBGMinNighttime.value) {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Target BG is ouside acceptable range of ({0} - {1}) for nighttime', 
				CHILD.InsulinCalcConstants.TargetBGMinNighttime.value, CHILD.InsulinCalcConstants.TargetBGMaxNighttime.value);

		}
	} else if(uji.TargetBloodGlucose > CHILD.InsulinCalcConstants.TargetBGMax.value ||
		uji.TargetBloodGlucose < CHILD.InsulinCalcConstants.TargetBGMin.value) {
		theReturnObj.status = Child.GlobalDomIds.ERROR;
		theReturnObj.msg = Ext.String.format('Target BG is ouside acceptable range of ({0} - {1})', CHILD.InsulinCalcConstants.TargetBGMin.value, CHILD.InsulinCalcConstants.TargetBGMax.value);
	} else {			
		// Warning levels vary by age, or nighttime for any age
		if(uji.PatientAgeYears < 5) {
			if(	uji.TargetBloodGlucose > CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo.value) {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Target BG is GREATER THAN acceptable maximum of {0} for age {1}', CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo.value, uji.PatientAgeYears);
			} else if(	uji.TargetBloodGlucose < CHILD.InsulinCalcConstants.TargetBGMinLessThan5yo.value) {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Target BG is LESS THAN acceptable minimum  of {0} for age {1}', CHILD.InsulinCalcConstants.TargetBGMinLessThan5yo.value, uji.PatientAgeYears);
			} else {
				theReturnObj.status = Child.GlobalDomIds.OK;
			}
		} else if(uji.PatientAgeYears >= 12) {
			if(	uji.TargetBloodGlucose > CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo.value) {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Target BG is GREATER THAN acceptable maximum of {0} for age {1}', CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo.value, uji.PatientAgeYears);
			} else if(	uji.TargetBloodGlucose < CHILD.InsulinCalcConstants.TargetBGMinGreaterThan12yo.value) {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Target BG is LESS THAN acceptable minimum  of {0} for age {1}', CHILD.InsulinCalcConstants.TargetBGMinGreaterThan12yo.value, uji.PatientAgeYears);
			} else {
				theReturnObj.status = Child.GlobalDomIds.OK;
			}
		} else {
			if(	uji.TargetBloodGlucose > CHILD.InsulinCalcConstants.TargetBGMax5to12yo.value) {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Target BG is GREATER THAN acceptable maximum of {0} for age {1}', CHILD.InsulinCalcConstants.TargetBGMax5to12yo.value, uji.PatientAgeYears);
			} else if(	uji.TargetBloodGlucose < CHILD.InsulinCalcConstants.TargetBGMin5to12yo.value) {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Target BG is LESS THAN acceptable minimum  of {0} for age {1}', CHILD.InsulinCalcConstants.TargetBGMin5to12yo.value, uji.PatientAgeYears);
			} else {
				theReturnObj.status = Child.GlobalDomIds.OK;
			}
		}
	}
	
	return theReturnObj;

};
	
CHILD.InsulinCalcEngine.editTargetSickDay = function(uji) {

	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;		//OK - WARN - ERROR
	theReturnObj.msg = '';
//	theReturnObj.status = Child.GlobalDomIds.WARN;		//OK - WARN - ERROR
//	theReturnObj.msg = 'Contact MD about sick day order if this is not a sick day.';

	if(uji.IsSickDay !== true && uji.IsSickDay !== false) {
		theReturnObj.status = Child.GlobalDomIds.ERROR;
		theReturnObj.msg = Ext.String.format('Sick Day value must be YES or NO');
	}
	
	return theReturnObj;
};

Ext.ns("CHILD.InsulinCalcConstants");

CHILD.InsulinCalcConstants.STRING_EMPTY                         = "";
CHILD.InsulinCalcConstants.CalculatorAction                     = {Inform: "inform", Enforce: "enforce", Calculator_Logic: "Calculator Logic", Order_Entry_Trap: "Order Entry Trap"};
CHILD.InsulinCalcConstants.Units                                = { GM: "gm", MG_PER_Dl: "mg/dL", GM_1_UNIT: "gm: 1 unit" };
CHILD.InsulinCalcConstants.ConstantType                         = function ConstantType(value, units, calculatorAction) {this.value = value; this.units = units; this.calculatorAction = calculatorAction;};

CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc               = new CHILD.InsulinCalcConstants.ConstantType(250, CHILD.InsulinCalcConstants.Units.GM, CHILD.InsulinCalcConstants.CalculatorAction.Inform);
CHILD.InsulinCalcConstants.CarbsEatenMin                        = new CHILD.InsulinCalcConstants.ConstantType(0, CHILD.InsulinCalcConstants.Units.GM, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);
CHILD.InsulinCalcConstants.CarbsEatenMax                        = new CHILD.InsulinCalcConstants.ConstantType(300, CHILD.InsulinCalcConstants.Units.GM, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);
CHILD.InsulinCalcConstants.CarbsEatenDiluteMin                  = new CHILD.InsulinCalcConstants.ConstantType(0, CHILD.InsulinCalcConstants.Units.GM, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);
CHILD.InsulinCalcConstants.CarbsEatenDiluteMax                  = new CHILD.InsulinCalcConstants.ConstantType(99, CHILD.InsulinCalcConstants.Units.GM, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);

CHILD.InsulinCalcConstants.BGLimtForCalc                        = new CHILD.InsulinCalcConstants.ConstantType(600, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Inform);
CHILD.InsulinCalcConstants.BGMinimum                            = new CHILD.InsulinCalcConstants.ConstantType(1, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);
CHILD.InsulinCalcConstants.BGMaximum                            = new CHILD.InsulinCalcConstants.ConstantType(2000, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);
//CHILD.InsulinCalcConstants.BGHyperThresholdBedtimeCorrection    = new CHILD.InsulinCalcConstants.ConstantType(300, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Calculator_Logic);
CHILD.InsulinCalcConstants.BGCriticalHypoThreshold              = new CHILD.InsulinCalcConstants.ConstantType(60, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Calculator_Logic);
CHILD.InsulinCalcConstants.BGHypoThreshold                      = new CHILD.InsulinCalcConstants.ConstantType(80, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Calculator_Logic);

CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo               = new CHILD.InsulinCalcConstants.ConstantType(200, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.TargetBGMax5to12yo                   = new CHILD.InsulinCalcConstants.ConstantType(180, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo           = new CHILD.InsulinCalcConstants.ConstantType(150, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.TargetBGMaxNighttime          	 	= new CHILD.InsulinCalcConstants.ConstantType(250, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);

CHILD.InsulinCalcConstants.TargetBGMax                          = new CHILD.InsulinCalcConstants.ConstantType(250, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);
CHILD.InsulinCalcConstants.TargetBGMin                          = new CHILD.InsulinCalcConstants.ConstantType(80, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);

CHILD.InsulinCalcConstants.TargetBGMinLessThan5yo               = new CHILD.InsulinCalcConstants.ConstantType(100, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.TargetBGMin5to12yo                   = new CHILD.InsulinCalcConstants.ConstantType(80, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.TargetBGMinGreaterThan12yo           = new CHILD.InsulinCalcConstants.ConstantType(80, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.TargetBGMinNighttime           		= new CHILD.InsulinCalcConstants.ConstantType(100, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);

CHILD.InsulinCalcConstants.InsulinCarbRatioMin                  = new CHILD.InsulinCalcConstants.ConstantType(3, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.InsulinCarbRatioMax                  = new CHILD.InsulinCalcConstants.ConstantType(100, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);

CHILD.InsulinCalcConstants.CorrectionFactorMin                  = new CHILD.InsulinCalcConstants.ConstantType(20, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.CorrectionFactorWarnMax              = new CHILD.InsulinCalcConstants.ConstantType(150, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.CorrectionFactorMax                  = new CHILD.InsulinCalcConstants.ConstantType(350, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);

CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin         = new CHILD.InsulinCalcConstants.ConstantType(10, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax         = new CHILD.InsulinCalcConstants.ConstantType(100, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);


// 20151112 swood3 commenting out these strings that are not used
// FOR: txtInsulinToCoverCarbs
// if over max CARBS for calculation 
//CHILD.InsulinCalcConstants.Msg_MaxCarbsForDoseCalc_DoesNotCoverCalc =
//    "Max Carbohydrates for Dose Calculation [{0}] / (Carb/Insulin Ratio) [{1}]  -- Dose Calculation Does NOT Cover Total Carbs Eaten!";
// such as msg = Ext.String.Format(msg, Constants.CarbsEatenLimitForCalc.value, txtICRatio.Text);
// else    
//CHILD.InsulinCalcConstants.Msg_MaxCarbsForDoseCalc_DoesCoverCalc =
//    "Net carbohydrates eaten [{0}] / (carb/insulin ratio) [{1}]";
// such as msg = Ext.String.Format(msg, txtGramsCarbsEaten.Text, txtICRatio.Text);  

// FOR txtInsulinToCorrectBGAtMeals
// if over max BG for calculation    
//CHILD.InsulinCalcConstants.MSG_InsulinToCorrectMealtimes_BG_IsOverCalc =
//    "Amount of insulin to correct BG at mealtimes: If (Adjusted Max Calc BG [{0}] - Target BG[{1}])/CF[{2}] is a positive number, display the answer, otherwise display 0";
// such as: msg = Ext.String.Format(msg, CHILD.InsulinCalcConstants.BGLimtForCalc.value, txtTargetBloodGlucose.Text, txtCorrectionFactor.Text);
// else    
//CHILD.InsulinCalcConstants.MSG_InsulinToCorrectMealtimes_BG_IsNotOverCalc =
//   "Amount of insulin to correct BG at mealtimes: If (Current BG [{0}] - Target BG[{1}])/CF[{2}] is a positive number, display the answer, otherwise display 0";
// such as: msg = Ext.String.Format(msg, txtCurrentBG.Text, txtTargetBloodGlucose.Text, txtCorrectionFactor.Text);

// FOR txtInsulinToDeliverAtMeals    
//CHILD.InsulinCalcConstants.MSG_InsulinToDeliverAtMealsCalc =
//    "Amount of insulin to DELIVER at mealtimes: Carb insulin [{0}] + glucose insulin [{1}];  or, Insulin to cover carbs + Insulin to Correct BG at Mealtime";
// such as  msg = Ext.String.Format(msg, txtInsulinToCoverCarbs.Text, txtInsulinToCorrectBGAtMeals.Text);

// FOR txtInsulinToCorrectAtBedtime
// if over max BG for calculation    
//CHILD.InsulinCalcConstants.MSG_IsBG_Over_True_At_BedTimeCalc =
//   "Amount of insulin to correct BG at bedtimes: Half of mealtime BG insulin to correct [{0}] if Adjusted Max BG [{1}] > bed BG threshold [{2}], otherwise 0";
// such as msg = Ext.String.Format(msg, txtInsulinToCorrectAtBedtime.Text, CHILD.InsulinCalcConstants.BGLimtForCalc.value, Constants.BGHyperThresholdBedtimeCorrection.value);
// else
//CHILD.InsulinCalcConstants.MSG_IsBG_Over_False_At_BedTimeCalc =
//    "Amount of insulin to correct BG at bedtimes: Half of mealtime BG insulin to correct [{0}] if current BG [{1}] > bed BG threshold [{2}], otherwise 0";
// such as msg = Ext.String.Format(msg, txtInsulinToCorrectAtBedtime.Text, txtCurrentBG.Text, Constants.BGHyperThresholdBedtimeCorrection.value);            

// FOR txtInsulinToDeliverAtBedtime
//CHILD.InsulinCalcConstants.MSG_InsulinToDeliverAtBedtimeCalc =
//    "Carb Insulin [{0}] + Insulin To Correct At Bedtime [{1}]   NOTE: Insulin to Correct at Bedtime = Half of mealtime BG insulin [{2}] to correct if current BG [{3}] > bed BG threshold [{4}], otherwise 0";
// such as msg = Ext.String.Format(msg, txtInsulinToCoverCarbs.Text, txtInsulinToCorrectAtBedtime.Text, txtInsulinToCorrectBGAtMeals.Text, txtCurrentBG.Text, Constants.BGHyperThresholdBedtimeCorrection.value);

// FOR txtRoundedInsulinToDeliver
//CHILD.InsulinCalcConstants.MSG_RoundedInsulinToDeliverCalc =
//    "Total amount of Insulin To Deliver as appropriate for the time selected with the value and rounded down to nearest value of Insulin Units Increments selected [{0}]";
// such as msg = Ext.String.Format(msg, lbInsulinIncrements.SelectedItem);

// FOR txtInsulinToDeliverAtSnack
//CHILD.InsulinCalcConstants.MSG_InsulinToDeliverSnackCalc =
//    "Total amount of insulin to administer at snacks: Carb insulin only if BG < Target BG, Carb Insulin + Meal Insulin if > 3 hrs since last rapid insulin AND BG > Target";

/**
 * @author rpeltz
 */
Ext.ns('Child');
Ext.define('Child.RenderManagerClass', {
    extend: 'Ext.util.Observable',
	constructor : function(config) {
				this.renderQ = [];
				this.renderInProcess = false;
				this.startTime = 0;
				this.addToQ = function(rm, renderInfo) {
					var item = renderInfo;
					this.renderQ.push(item);
					this.listQ();
					rm.fireEvent('iteminq', this, 'item in q');
				};
				this.processQ = function() {
					if (this.renderQ.length > 0
							&& this.renderInProcess === false) {
						var item = this.renderQ.shift();
						var renderFn = item.renderFn;
						
						Child.Framework.debugLog(item.cclProgram, 'warn');
						this.startTime = new Date();
						
						var renderData = item.data;
						this.renderInProcess = true;
						renderFn(renderData);
					}
				};
				this.listQ = function() {
					var qString = '';
					for (var i = 0; i < this.renderQ.length; i++) {
						qString += i + ': ' + this.renderQ[i].cclProgram + ';';
					}
					if (qString.length === 0) {
						qString = 'empty q';
					}

					// alert(qString);
					// if (console){
					// console.log(qString);
					// }
					
					Child.Framework.debugLog(qString, 'info');
					
				};
				this.addEvents('rendercompleted', 'iteminq');
				this.listeners = config.listerners;
				this.callParent(arguments);
//				Child.RenderManagerClass.callParent.constructor.call(config);
//				Child.RenderManagerClass.superclass.constructor.call(this.config);
			}
		});

//Child.RenderManager = new Child.RenderManagerClass({});
Child.RenderManager = Ext.create(Child.RenderManagerClass,{});

Child.RenderManager.on('iteminq', function(pnl, aVar) {
			// alert('iteminq: ' + aVar);
			Child.RenderManager.processQ();
		});
Child.RenderManager.on('rendercompleted', function(pnl, aVar) {
			// alert('rendercompleted: ' + aVar);
			// Ext.Msg.alert('Render completed', aVar);
			
			var elapsedTime = 0;
			if(this.startTime !== 0) {
				var now = new Date();
				elapsedTime = now - this.startTime;
			}
			Child.Framework.debugLog('Render completed: ' + aVar + ' Elapsed Time : ' + elapsedTime, 'warn');
			
			Child.RenderManager.renderInProcess = false;
			this.listQ();
			
			
//			var delayProcessingNextItem = new Ext.util.DelayedTask(function() {
				Child.RenderManager.processQ();
//			});
			
//			delayProcessingNextItem.delay(20);
			
		});
/**
 * @author rpeltz
 */
Ext.ns('Child');
Child.version = '2.0';
Child.NavigationPanelFactory = function() {
};
Child.NavigationPanelFactory.LOCATIONS = function() {
	return {
		CARD_ONE : 'CARD_ONE',
		ABOUT : 'ABOUT',
		CONSTANTS : 'CONSTANTS',
//		CCLDATA : 'CCLDATA',
		MAIN_HELP : 'MAIN_HELP',
		REFRESH : 'REFRESH'
	};
}();

Child.NavigationPanelFactory.currentLocation = '';
Child.NavigationPanelFactory.navHandler = function(location) {
	// Ext.Msg.alert('Click', 'You clicked on ' + location);

	if (location !== Child.NavigationPanelFactory.LOCATIONS.REFRESH
			&& location !== Child.NavigationPanelFactory.LOCATIONS.ABOUT
			&& location !== Child.NavigationPanelFactory.LOCATIONS.CONSTANTS
//			&& location !== Child.NavigationPanelFactory.LOCATIONS.CCLDATA
			&& location !== Child.NavigationPanelFactory.LOCATIONS.MAIN_HELP) {
		Child.NavigationPanelFactory.currentLocation = location;
		Child.NavigationPanelFactory.SetButtonsInactive('main_nav_toolbar');
		this.removeClass('main-toolbar-button-inactive');
		this.addClass('main-toolbar-button-active');
	}
	switch (location) {
		case Child.NavigationPanelFactory.LOCATIONS.CARD_ONE :
			if (!Child.CardLayouts.CardOneRendered) {
				var InpatientCardOneLayout = Child.CardLayouts
						.GetCardOneLayoutPanel();
				Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL)
						.add(InpatientCardOneLayout);
				Ext
						.getCmp(Child.GlobalDomIds.MAIN_PANEL)
						.getLayout()
						.setActiveItem(Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT);

			} else {
				Ext
						.getCmp(Child.GlobalDomIds.MAIN_PANEL)
						.getLayout()
						.setActiveItem(Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT);
			}
			break;
		case Child.NavigationPanelFactory.LOCATIONS.MAIN_HELP :
			var url = Child.Framework.HELP_SUMMARY;
//			window.open(url, "_blank", "height=800,width=650,left=600,top=0,resizable=yes,scrollbars=yes");
			Child.WebServices.applink(100, url, null, null, null, null, null, "height=800,width=650,left=600,top=0,resizable=yes,scrollbars=yes");
			break;
		case Child.NavigationPanelFactory.LOCATIONS.REFRESH :
			// reset inpatient data
			Child.CardLayouts.CardOneRendered =  false;
		
			switch (Child.NavigationPanelFactory.currentLocation) {
				case Child.NavigationPanelFactory.LOCATIONS.CARD_ONE :
					Child.NavigationPanelFactory.CardOneRefresh();
					Ext
							.getCmp(Child.GlobalDomIds.MAIN_PANEL)
							.getLayout()
							.setActiveItem(Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT);
					break;
					default :
					window.location.reload();
					break;
			}
			break;
		case Child.NavigationPanelFactory.LOCATIONS.ABOUT :
			Child.AboutPopup();
			break;
		case Child.NavigationPanelFactory.LOCATIONS.CONSTANTS:
			Child.ConstantsPopup();
			break;
//		case Child.NavigationPanelFactory.LOCATIONS.CCLDATA:
//			Child.CCLValues_Popup(Child.IcalcPanelFactory.data);
//			break;
		default :
			break;
	}

};


Child.NavigationPanelFactory.SetButtonsInactive = function(tbarId) {
	var toolbarItems = Ext.getCmp(tbarId).items.items;
	for (var i = 0; i < toolbarItems.length; i++) {
		var item = toolbarItems[i];
		item.removeClass('main-toolbar-button-active');
		item.addClass('main-toolbar-button-inactive');
	}

};

Child.NavigationPanelFactory.InitMainNavToolBar = function() {
	var toolbar = new Ext.Toolbar({
				id : 'main_nav_toolbar',
				items : []
			});
	Child.NavigationPanelFactory.UpdateMainNavToolBar();
	return toolbar;
};
Child.NavigationPanelFactory.UpdateMainNavToolBar = function(config) {
	var toolbarArray = [];
	var type = 'calculator'; // default
	var title = 'Insulin Calculator';// default
	var titleLocation = 1;// default inpatient location of title
	toolbarArray = Child.NavigationPanelFactory.GetCalculatorToolBarArray();
	var toolbar = Ext.getCmp('main_nav_toolbar');
	// the listeners below control the centering fo the toolbar title
	// Ext does not provide an easy way to center in a toolbar so
	// we adjust after we know how much room is available
//	toolbar.addListener('afterlayout', function(tb, layout) {
//		var totalWidth = $(".x-toolbar-left").width();
//		var usedWidth = $(".x-toolbar-left-row").width();
//		var availWidth = totalWidth - usedWidth;
//		var theId = this.type + '_main_toolbar_title_id';
//
//		tb.insertButton(this.titleLocation, {
//					text : this.title,
//					id : theId,
//					width : availWidth,
//					xtype : 'tbtext',
//					cls : 'section-header'
//				});
//
//			// alert('winW: ' + $(window).width());
//		}, {
//			type : type,
//			title : title,
//			titleLocation : titleLocation
//		}, {
//			single : true
//			// ,
//			// target : Ext.fly('main_nav_toolbar')
//		});
//	toolbar.addListener('resize', function(tb, layout) {
//				var totalWidth = $(".x-toolbar-left").width();
//				var usedWidth = $(".x-toolbar-left-row").width();
//				var availWidth = totalWidth - usedWidth;
//				var theId = this.type + '_main_toolbar_title_id';
//				// tb.remove(theId);
//				tb.remove(this.type + '_main_toolbar_title_id');
//				tb.insertButton(this.titleLocation, {
//							text : this.title,
//							id : theId,
//							width : availWidth,
//							xtype : 'tbtext',
//							cls : 'section-header'
//						});
//			}, {
//				type : type,
//				title : title,
//				titleLocation : titleLocation
//			});
	if (toolbar) {
		toolbar.removeAll();
		toolbar.add(toolbarArray);
//		toolbar.doLayout();
	}

};

Child.NavigationPanelFactory.GetCalculatorToolBarArray = function() {
	var toolBarArray = [];

/*	var ipcardOneBtn = new Ext.Button({
				text : 'Inpatient Card One',
				cls : 'main-toolbar-button-active'
			});
	ipcardOneBtn
			.on(
					'click',
					Ext
							.createDelegate(
									Child.NavigationPanelFactory.navHandler,
									ipcardOneBtn,
									[Child.NavigationPanelFactory.LOCATIONS.CARD_ONE]));
	toolBarArray.push(ipcardOneBtn);
	toolBarArray.push('-');
*/
	var logoPnl= new Ext.Panel (
	{
		id : 'LOGO_PANEL_ID',
		xtype : 'panel',
		border : false,
		cls : 'logo-icon',
//		cls : 'patient-name'
		html : '<img style="float:left;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + 'img/logo.png"/>'
	}
	);

	toolBarArray.push(logoPnl);
	
	var namePnl = new Ext.Panel(
	{
		id : Child.GlobalDomIds.PATIENT_NAME_ID,
		xtype : 'panel',
		html : '',
		padding : '0px 0px 0px 10px',
		cls : 'patient-name'
	});

	toolBarArray.push(namePnl);

	toolBarArray.push('->');
//	var refreshBtn = new Ext.Button({
//				text : 'Refresh',
//				cls : 'main-toolbar-button-inactive',
//				iconCls : 'refresh-icon'
//			});
//	refreshBtn.on('click', Ext.bind(
//					Child.NavigationPanelFactory.navHandler,
//					refreshBtn,
//					[Child.NavigationPanelFactory.LOCATIONS.REFRESH]));
//	toolBarArray.push(refreshBtn);
//	toolBarArray.push('-');

	var mainHelpMenuItem = new Ext.menu.Item({
				text : 'Help'
			});
	mainHelpMenuItem.on('click', Ext.bind(
					Child.NavigationPanelFactory.navHandler,
					mainHelpMenuItem,
					[Child.NavigationPanelFactory.LOCATIONS.MAIN_HELP]));

	var aboutMenuItem = new Ext.menu.Item({
				text : 'About'
			});
	aboutMenuItem.on('click', Ext.bind(
					Child.NavigationPanelFactory.navHandler,
					aboutMenuItem,
					[Child.NavigationPanelFactory.LOCATIONS.ABOUT]));

	var constantsMenuItem = new Ext.menu.Item({
				text : 'Constants'
			});
	constantsMenuItem.on('click', Ext.bind(
					Child.NavigationPanelFactory.navHandler,
					constantsMenuItem,
					[Child.NavigationPanelFactory.LOCATIONS.CONSTANTS]));

//	var cclDataMenuItem = new Ext.menu.Item({
//				text : 'CCL Data'
//			});
//	cclDataMenuItem.on('click', Ext.bind(
//					Child.NavigationPanelFactory.navHandler,
//					cclDataMenuItem,
//					[Child.NavigationPanelFactory.LOCATIONS.CCLDATA]));

	var helpBtn = new Ext.Button({
				text : 'Help',
				cls : 'main-toolbar-button-inactive',
				iconCls : 'help-icon',
				menu : [mainHelpMenuItem, aboutMenuItem, constantsMenuItem]
			});

	toolBarArray.push(helpBtn);
	return toolBarArray;
};


Child.NavigationPanelFactory.CardOneRefresh = function() {
	Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL)
			.remove(Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT);
	var ptLayout = Child.CardLayouts
			.GetCardOneLayoutPanel();
	Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL).add(ptLayout);
};

/**
 * @author rpeltz/swood3
 */
Ext.ns('Child');
Child.version = '2.0';
Child.LoadData = function() {
};

Child.LoadData.InpatientCardOne = function() {
	//alert("encounterid1: " + Child.Framework.ORDERID);
	if (!Child.CardLayouts.CardOneRendered) {
	//alert("encounterid2: " + Child.Framework.ORDERID);
		Child.DataRequest({
					cclProgram : '1mp_icalc_data',
					cclParam: '^MINE^,' + Child.Framework.ORDERID,
					renderMan : true,
					renderFn : Child.IcalcPanelFactory.icalcRender
				});
		Child.CardLayouts.CardOneRendered = true;
	}
};
Child.LoadData.InpatientCardTwo = function() {
	if (!Child.CardLayouts.InpatientCardTwoRendered) {
		//load data here
		Child.CardLayouts.InpatientCardTwoRendered = true;
	}
};
Child.LoadData.OutpatientCardOne = function() {
	// check for undefined
	if (!Child.CardLayouts.OutpatientCardOneRendered) {
		// call documents
		Child.DataRequest({
					cclProgram : '1mp_ptsum_documents_amb',
					renderMan : true,
					renderFn : Child.DocumentPanelFactory.docRender
				});
		Child.CardLayouts.OutpatientCardOneRendered = true;

	}
};
Child.LoadData.OutpatientCardTwo = function() {
	if (!Child.CardLayouts.OutpatientCardTwoRendered) {
		//load data here
		Child.CardLayouts.OutpatientCardTwoRendered = true;
	}
};

var beginTime;
var renderCount = 0;
var renderDone = function(renderSrc) {
	renderCount = renderCount + 1;
	if (renderCount === 7) {
		var endTime = new Date();
		// alert(endTime - beginTime);
	}
};

Child.LoadData.LogCcl = function(logData) {

	//remove " from log data
	var scrubLogData = logData.replace(/\"/g, '|');
	scrubLogData = scrubLogData.replace(/\^/g, '|');
	
	Child.DataRequest({
		cclProgram : '1com_write_log',
		ajaxMethod: 'POST',
		cclParam : '^MINE^, 0, ^' + scrubLogData + '^',
		renderFn : Child.LoadData.LogCclRender
	});
};

Child.LoadData.LogCclRender = function(renderParams) {

	var theData = renderParams.data;
	
};

Child.LoadData.Column2_Panel_1_Tab2 = function() {

	if (!Child.CardLayouts.InpatientCardOneColumnTwoPanel1Tab2Rendered) {
		// call documents
		Child.DataRequest({
			cclProgram : '1mp_ptsum_documents_ip',
			renderMan : true,
			renderFn : Child.TabTestPanelFactory.docRender
		});
		Child.CardLayouts.InpatientCardOneColumnTwoPanel1Tab2Rendered = true;
	}

};

Child.LoadData.Column2_Panel_1_Tab3 = function() {
		alert('Call Tab 3 CCL here');

};


/**
 * @author rpeltz/swood3
 */
Ext.ns('Child');
Child.version = '1.0';
Child.IcalcPanelFactory = function() {};
Child.IcalcPanelFactory.data = null;

Child.IcalcPanelFactory.icalcRender = function(renderParams){

    var panelId;
    var containerId;
    
    containerId = Child.GlobalDomIds.INSULIN_ORDERS_CARD_1_PANEL_1_ID;
    panelId = Child.GlobalDomIds.getChildPanelID(containerId);
    Child.IcalcPanelFactory.data = renderParams.data;
    var container = Ext.getCmp(containerId);
    if (renderParams.status == 'fail') {
        renderError([containerId]);
        return;
    }
    
   	// Log the data from the ccl call
    var jsonStr = Ext.JSON.encode(Child.IcalcPanelFactory.data);
    Child.LoadData.LogCcl(jsonStr);
    
    renderParams = null; // make available for gc
	var icalcPanel = '';
	var mealWarnMsg = '';

	if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISSICKDAY.toLowerCase() === 'true' && Child.IcalcPanelFactory.data.INSULIN_CALC.DIFFERENTPRODUCT === "true") {
		if(Child.IcalcPanelFactory.data.INSULIN_CALC.SICKINSULINTYPE === '') {
			mealWarnMsg = '<div class="calc-heading-bold">Sick Day insulin management is in effect.  The Sick day insulin order you selected:</br></br>&nbsp;&nbsp;&nbsp;&nbsp;' 
				+ Child.IcalcPanelFactory.data.INSULIN_CALC.INSULINTYPE 
				+ '</br></br>does NOT match other insulin order(s).</br></br>&nbsp;&nbsp;' 
				+ '</br>Please resolve.</br></br>Press Cancel to select another order.</div>';
		} else {
			mealWarnMsg = '<div class="calc-heading-bold">Sick Day insulin management is in effect.  The insulin you selected:</br></br>&nbsp;&nbsp;&nbsp;&nbsp;' 
				+ Child.IcalcPanelFactory.data.INSULIN_CALC.INSULINTYPE 
				+ '</br></br>is not the same product as the Sick Day insulin.</br></br>&nbsp;&nbsp;' 
				+ Child.IcalcPanelFactory.data.INSULIN_CALC.SICKINSULINTYPE 
				+ '</br></br>Please resolve.</br></br>Press Cancel to select another order.</div>';
		}
	    icalcPanel = Child.IcalcPanelFactory.BuildWarningMsgPanel(panelId, Child.IcalcPanelFactory.data, containerId, mealWarnMsg, true, false);
	} else if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISSICKDAY.toLowerCase() === 'true' && Child.IcalcPanelFactory.data.INSULIN_CALC.SICKINSULINTYPE !== '') {
		mealWarnMsg = '<div class="calc-error-red">STOP.  Do not use this order, patient is on sick day management - use PRN sick day managment order</div>';
	    icalcPanel = Child.IcalcPanelFactory.BuildWarningMsgPanel(panelId, Child.IcalcPanelFactory.data, containerId, mealWarnMsg, true, true);
	} else if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISNIGHTMEAL.toLowerCase() === "true") {
		mealWarnMsg = '<div class="calc-heading-bold">You have selected a meal/snack insulin dose after 2100; a night-time insulin order which is less aggressive in correcting hyperglycemia may be more appropriate.  Please review MAR for alternate orders.</br></br>Press Cancel to select another order.</div>';
	    icalcPanel = Child.IcalcPanelFactory.BuildWarningMsgPanel(panelId, Child.IcalcPanelFactory.data, containerId, mealWarnMsg, false, false);
	} else if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISDAYBED.toLowerCase() === "true") {
		mealWarnMsg = '<div class="calc-heading-bold">You have selected a bedtime/nighttime insulin dose outside the timeframe intended. Please review MAR for alternate orders.</br></br>Press Cancel to select another order.</div>';
	    icalcPanel = Child.IcalcPanelFactory.BuildWarningMsgPanel(panelId, Child.IcalcPanelFactory.data, containerId, mealWarnMsg, false, false);
	} else {
	    icalcPanel = Child.IcalcPanelFactory.BuildPanel(panelId, Child.IcalcPanelFactory.data, containerId);
	}

    container.removeAll();
    container.insert(0, icalcPanel);
//    container.doLayout(false,true);
    
	// for some reason the buttons on the form are always off the bottom of the page
    // unless we do a layout on the card at this point
    var theCard = Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL);
//	theCard.doLayout();
	
};

Child.IcalcPanelFactory.SwapPanels = function(panelId, icalcData, containerId) {

	var icalcPanel = Child.IcalcPanelFactory.BuildPanel(panelId, icalcData, containerId);

    var container = Ext.getCmp(containerId);
    container.removeAll();
    container.insert(0, icalcPanel);
//    container.doLayout(false,true);
    
	// for some reason the buttons on the form are always off the bottom of the page
    // unless we do a layout on the card at this point
    var theCard = Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL);
//	theCard.doLayout();

};

Child.IcalcPanelFactory.CarbRatioVerified = false;
Child.IcalcPanelFactory.CorrectionFactorVerified = false;
Child.IcalcPanelFactory.TargetBGVerified = false;
Child.IcalcPanelFactory.TargetSickDayVerified = false;
Child.IcalcPanelFactory.FatalBGError = false;
Child.IcalcPanelFactory.FatalCarbsError = false;
Child.IcalcPanelFactory.FatalBOHBError	= false;
Child.IcalcPanelFactory.FatalCarbRatioError = false;
Child.IcalcPanelFactory.FatalCorrectionFactorError = false;
Child.IcalcPanelFactory.FatalTargetBGError = false;
Child.IcalcPanelFactory.FatalTargetSickDayError = false;

Child.IcalcPanelFactory.BuildOrderDisplay = function(icalcData, includeSickDayDisplayLine) {
	
    var theOrderIcon = '';
	var theSickDayIcon = '';
    
    switch(icalcData.INSULIN_CALC.ADMINTIME.toLowerCase()) {
		case Child.GlobalDomIds.snacks:
			theOrderIcon = 'img/Snack_64.png';
			break;
		case Child.GlobalDomIds.lunch:
			theOrderIcon = 'img/Lunch_64.png';
			break;
		case Child.GlobalDomIds.dinner:
			theOrderIcon = 'img/Dinner_64.png';
			break;
		case Child.GlobalDomIds.breakfast:
			theOrderIcon = 'img/BF_64.png';
			break;
		case Child.GlobalDomIds.bedtime:
			theOrderIcon = 'img/Bed_64.png';
			break;
		case Child.GlobalDomIds.meals:
			theOrderIcon = 'img/meal_64.png';
			break;
		case Child.GlobalDomIds.sickday:
			theOrderIcon = 'img/sickday_64.png';
			break;
//		case Child.GlobalDomIds.nightmeal:
//			theOrderIcon = 'img/Bedtime_64.png';
//			break;
		default:
			theOrderIcon = 'img/questionMark.gif';
			break;
    }

   	if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISNIGHTMEAL.toLowerCase() === "true") {
   		// if this flag is set, then override the icon to the night meal one
			theOrderIcon = 'img/Bedtime_64.png';
   	}
   	if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISBADFREQUENCY.toLowerCase() === 'true') {
   		// if this flag is set, then override the icon to the blue question mark one
		theOrderIcon = 'img/questionMark_64.png';
   	}
   	if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISDAYBED.toLowerCase() === 'true') {
   		// if this flag is set, then override the icon to the Day Bed Icon one
		theOrderIcon = 'img/dayBed_64.png';
   	}
   	if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISSICKDAY.toLowerCase() === 'true' && 
   	   Child.IcalcPanelFactory.data.INSULIN_CALC.ADMINTIME.toLowerCase() !== 'sickday') {
   		// if there is sickday order and the admintime is not sickday, set the sickday icon
		theSickDayIcon = '<img style="float:left;padding-right:10px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + 'img/sickday_64.png' + '">';
   	}

    var lastAdminStr = '';
	var lastAdminTitleStr = '';
//	if(icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.snacks || icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.sickday) {
		lastAdminStr = icalcData.INSULIN_CALC.LASTADMININFO;
		lastAdminTitleStr = 'Last Rapid-Acting Insulin (per MAR): ';
//	}
	
    var orderDisplay = 
    	'<table width="100%">' +
    		'<tr>' +
    			'<td width="50%">' + 
    				'<span class="calc-heading-blue">Order Display</span>' + 
    			'</td>' + 
    			'<td width="50%">' + 
    				'<span class="calc-last-dose-bold" style="float:right;">' + lastAdminTitleStr + '</span>' + 
    			'</td>' +
    		'</tr>' + 
    		'<tr>' +
    			'<td width="50%">' + 
    				'<span class="calc-heading-grey">' + icalcData.INSULIN_CALC.ADMINTIME + ' - ' + icalcData.INSULIN_CALC.FREQUENCY  + '</span>' + 
    			'</td>' + 
    			'<td width="50%">' + 
    				'<span class="calc-last-dose-bold" style="float:right;">' + lastAdminStr + '</span>' + 
    			'</td>' +
    		'</tr>' + 
    	'</table>' + 
    	'<div class="calc-heading-bold">' + icalcData.INSULIN_CALC.INSULINTYPE + '</div>' +
    	
    	'<div><table width="100%">' +
    		'<tr>' +
    			'<td width="10%">' + 
    				'<span class="calc-body"><img style="float:left;padding-right:10px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theOrderIcon + '"></span>' +
    			'</td>' + 
    			'<td width="90%">'; 
     
    if(includeSickDayDisplayLine && icalcData.INSULIN_CALC.SICKDISPLAYLINE && icalcData.INSULIN_CALC.SICKDISPLAYLINE !== '') {
    	var spaceIcon = '<img class="largeIcon" style="float:left;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + 'img/s.gif' + '">';
    	orderDisplay = orderDisplay + '<span class="calc-heading-bold">Insulin Clicked on MAR:</span></br>' + icalcData.INSULIN_CALC.DISPLAYLINE + '</td></tr>';
	    var tempSickday = '';
	    if(theSickDayIcon !== '') {
	    	tempSickday = theSickDayIcon;
	    }
    	orderDisplay = orderDisplay +  '<tr><td width="10%">' + tempSickday + '</td><td width="90%"><span class="calc-heading-bold">SickDay Insulin:</span></br>' + icalcData.INSULIN_CALC.SICKDISPLAYLINE + '</span></td></tr></table></div>';
    } else {
	    if(theSickDayIcon !== '') {
	    	orderDisplay = orderDisplay + theSickDayIcon;
	    }
    	orderDisplay = orderDisplay + icalcData.INSULIN_CALC.DISPLAYLINE + '</td></tr></table></div>';
    }
    
	return orderDisplay;

};

Child.IcalcPanelFactory.BuildWarningMsgPanel = function(panelId, icalcData, containerId, mealWarnMsg, hardStop, skipOrdersPanel){

	var orderDisplay = '';
	if(!skipOrdersPanel) {
		orderDisplay = Child.IcalcPanelFactory.BuildOrderDisplay(icalcData, hardStop);
	}
	
	var orderDisplayHeight = 130;
	if(icalcData.INSULIN_CALC.SICKDISPLAYLINE && icalcData.INSULIN_CALC.SICKDISPLAYLINE !== '') {
		orderDisplayHeight = 200;
	}

	var theFormPanel = new Ext.form.Panel({
        id: panelId,
        frame: true,
        title: null,
        flex : 1.0,
//        flex : 0.80,
        border : false,
		layout : {
			type : 'vbox'
			,padding : 1
			,pack : 'start'
			,align : 'stretch'
		},
//        defaults: {
//        	anchor: '100%'
//        },
        fieldDefaults: {
    	    defaultType: 'textfield',
	        labelWidth: 10
        },
        items: [

		{
            xtype: 'panel'
            ,border : false
            ,hidden : skipOrdersPanel
            ,height : orderDisplayHeight
 			,layout : 'fit',
            items: [
            {
            	xtype : 'panel',
            	border : false,
       			layout : 'fit',
       			items : {
       				xtype : 'panel',
	            	padding : 5,
    	        	border : false,
        			html: orderDisplay
       			}
            }]
        }, {
        	xtype : 'panel',
        	height : 6,
        	border : false,
        	cls : 'class-spacer-panel'
        }, {
            	xtype : 'panel',
            	border : false,
       			layout : 'fit',
       			items : {
       				xtype : 'panel',
	            	padding : 5,
    	        	border : false,
        			html: mealWarnMsg
       			}
        }, {

        	xtype : 'panel',
        	height : 40,
        	border : false,
	    	layout : {
    			type : 'hbox',
    			pack : 'start',
    			align : 'stretch'
        	},
        	items : [
        	{
        		flex : 1,
				xtype : 'panel',
				border : false,
        		buttonAlign: 'center',
		        buttons: [
		        {
		            text: 'Continue',
		            hidden: hardStop,
		            listeners: {
		                click: {
		        			fn: function() {
		        				Child.IcalcPanelFactory.SwapPanels(panelId, icalcData, containerId);
		        			}
		                }
		            }
		        }, {
		    		xtype : 'panel',
		    		border : false,
		    		width : 150
		   		}, {
		            text: 'Cancel',
		            disabled : false,
		            listeners: {
		                click: {
		                    fn: function(){
		                    	window.close();
		                    }
		                }
		            }
		        }]
			}]
        }]
	});

	return theFormPanel;

};

Child.IcalcPanelFactory.BuildPanel = function(panelId, icalcData, containerId){

	Child.IcalcPanelFactory.CarbRatioVerified = false;
	Child.IcalcPanelFactory.CorrectionFactorVerified = false;
	Child.IcalcPanelFactory.TargetBGVerified = false;
	if(icalcData.INSULIN_CALC.ISSICKDAY === 'true') {
		Child.IcalcPanelFactory.TargetSickDayVerified = false;
	} else {
		Child.IcalcPanelFactory.TargetSickDayVerified = true;
	}
	
//	if(icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.nightmeal) {
//		var r = confirm('You have selected a meal or snack order and it is after 21:00.  You may be giving too much insulin and perhaps should be using the BedTime order.\n\nPress OK to Continue or Cancel to select another order');
//		if(r!==true) {
//			window.close();
//		}
//	}

	if(icalcData.INSULIN_CALC.ISU100STANDARDINSULIN === 'true') {
		Child.Framework.HELP_SUMMARY = Child.Framework.WEB_ASSET_FILE_LOCATION + 'help/InsulinCalcHelp.pdf';
	} else {
		Child.Framework.HELP_SUMMARY = Child.Framework.WEB_ASSET_FILE_LOCATION + 'help/InsulinCalcHelp_Dilute.pdf';
	}
	
	var theNameHtml = '<div class="patient-name-class">' + icalcData.INSULIN_CALC.PATIENTNAME + '</div>' +
		'<div class="MRN-class">MRN:&nbsp;' + icalcData.INSULIN_CALC.MRN + '</div>' + 
		'<div class="age-display-class">AGE:&nbsp;' + icalcData.INSULIN_CALC.PATIENTAGEDISPLAY + '</div>';
		
	var namePnl = Ext.getCmp(Child.GlobalDomIds.PATIENT_NAME_ID);
	namePnl.update(theNameHtml);

	var uji = new CHILD.InsulinCalcEngine.UserAndJsonInputs();
    uji.PatientAgeYears = icalcData.INSULIN_CALC.PATIENTAGEYEARS;
    uji.IsU100StandardInsulin = (icalcData.INSULIN_CALC.ISU100STANDARDINSULIN === 'true');
    uji.DisplayLine = icalcData.INSULIN_CALC.DISPLAYLINE;
    uji.AdminTime = icalcData.INSULIN_CALC.ADMINTIME;
    uji.CarbInsulinRatio = icalcData.INSULIN_CALC.CARBGRAMSPERINSULINUNIT;
    uji.CorrectionFactor = icalcData.INSULIN_CALC.CORRECTIONFACTOR;
    uji.TargetBloodGlucose = icalcData.INSULIN_CALC.TARGETBLOODGLUCOSE;
	uji.Increment = Number(icalcData.INSULIN_CALC.INCREMENT);
	
	var rapidInsulinQuestion = '<span class="calc-heading-bold-large">Rapid-acting insulin in past 3 hrs?</span>';
	
	if(icalcData.INSULIN_CALC.ISSICKDAY === 'true') {
		uji.IsSickDay = true;
    	uji.IsMoreThan3HoursSinceLastInsulin = true;
		rapidInsulinQuestion = '<span class="calc-heading-bold-large">Have you given Rapid-acting insulin in the last 2 hrs?</span>';
	} else {
		uji.IsSickDay = false;
		uji.IsMoreThan3HoursSinceLastInsulin = false;
	}
	uji.SickDayFactor = 1.0; //default value
	
//	if(!uji.IsU100StandardInsulin) {
//		uji.Increment = 0.1;
//	} else if(icalcData.INSULIN_CALC.ISINCREMENTONE === 'true') {
//	    uji.Increment = 1;
//	} else {
//	    uji.Increment = 0.5;
//	}

 
	var DisplayCalculatorErrors = function(insulinData) {
		
        var errCt = insulinData.ErrorArray.length;
		var resultErrs = '';

		if(errCt > 0) {
			resultErrs = '<span><ul>';
			var lineFeed = '';
			for(i=0; i<errCt; i++) {
				resultErrs = resultErrs + lineFeed + '<li><span class="calc-warnings">' + insulinData.ErrorArray[i] + '</span></li>';
			}
			resultErrs = resultErrs + '</ul></span>';
		}
		
		var theErrorField = Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultErrorDisplayFieldId);
		theErrorField.setValue(resultErrs);

	};
    
    var runStdInsulinCalc = function(panelId, uji){
    
	    	var theResultfield = Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultFieldId);
		    // Validate all the uji inputs here first!
		    var insulinData = new CHILD.InsulinCalcEngine.InsulinData(uji);
	    	
	    	var ic = insulinData.RoundedInsulinToDeliver;
	    	var theResultFormula = insulinData.formula;
//			var theLabel = Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultLabelId);
        
        	if(ic !== undefined) {
        		// calculation did NOT return a fatal error
	        	theResultfield.setValue(ic);
    	    	theResultfield.enable();
        	
				if(theResultFormula !== undefined) {
					theResultfield.ownerCt.setFieldLabel(formatInsulinResultLabel(theResultFormula, true));
					theResultfield.ownerCt.enable();
				}
        	} else {
				theResultfield.ownerCt.setFieldLabel(formatInsulinResultLabel('', false));
        	}
				
			DisplayCalculatorErrors(insulinData);
//        	var errCt = insulinData.ErrorArray.length;
//			var resultErrs = '';
//
//			if(errCt > 0) {
//				resultErrs = '<span><ul>';
//				var lineFeed = '';
//				for(i=0; i<errCt; i++) {
//					resultErrs = resultErrs + lineFeed + '<li><span class="calc-warnings">' + insulinData.ErrorArray[i] + '</span></li>';
////					lineFeed = '</br>';
//				}
//				resultErrs = resultErrs + '</ul></span>';
//			}
//			
//			var theErrorField = Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultErrorDisplayFieldId);
//			theErrorField.setValue(resultErrs);

		return uji;
    };
    
//    var theOrderIcon = '';
//    
//    switch(icalcData.INSULIN_CALC.ADMINTIME.toLowerCase()) {
//		case Child.GlobalDomIds.snacks:
//			theOrderIcon = 'img/Snack_64.png';
//			break;
//		case Child.GlobalDomIds.lunch:
//			theOrderIcon = 'img/Lunch_64.png';
//			break;
//		case Child.GlobalDomIds.dinner:
//			theOrderIcon = 'img/Dinner_64.png';
//			break;
//		case Child.GlobalDomIds.breakfast:
//			theOrderIcon = 'img/BF_64.png';
//			break;
//		case Child.GlobalDomIds.bedtime:
//			theOrderIcon = 'img/Bed_64.png';
//			break;
//		case Child.GlobalDomIds.meals:
//			theOrderIcon = 'img/meal_64.png';
//			break;
//		case Child.GlobalDomIds.nightmeal:
//			theOrderIcon = 'img/Bedtime_64.png';
//			break;
//		default:
//			theOrderIcon = '';
//			break;
//    }

	var theCarbRatioCheckIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
	var theCarbRatioErrMsg = '';
	var theCarbRatioFormula = '';
	Child.IcalcPanelFactory.FatalCarbRatioError = false;

	var returnVal = CHILD.InsulinCalcEngine.editCarbRatio(uji);

	switch(returnVal.status) {
		case Child.GlobalDomIds.OK:
			theCarbRatioCheckIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
			theCarbRatioErrMsg = returnVal.msg;
			theCarbRatioFormula = returnVal.formula;
			break;
			
		case Child.GlobalDomIds.ERROR:
			theCarbRatioCheckIcon = Child.GlobalDomIds.RED_X_IMG;
			Child.IcalcPanelFactory.FatalCarbRatioError = true;
			theCarbRatioFormula = returnVal.formula;
			theCarbRatioErrMsg = returnVal.msg;
			break;
			
		case Child.GlobalDomIds.WARN:
			theCarbRatioCheckIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
			theCarbRatioErrMsg = returnVal.msg;
			theCarbRatioFormula = returnVal.formula;
			break;
		default:
			break;
	}

	var theCorrectionFactorErrMsg = '';
	var theCorrectionFactorIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
	var theCorrectionFactorFormula = '';
	Child.IcalcPanelFactory.FatalCorrectionFactorError = false;

	returnVal = CHILD.InsulinCalcEngine.editCorrectionFactor(uji);

	switch(returnVal.status) {
		case Child.GlobalDomIds.OK:
			theCorrectionFactorIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
			theCorrectionFactorErrMsg = returnVal.msg;
			theCorrectionFactorFormula = returnVal.formula;
			break;
			
		case Child.GlobalDomIds.ERROR:
			theCorrectionFactorIcon = Child.GlobalDomIds.RED_X_IMG;
			Child.IcalcPanelFactory.FatalCorrectionFactorError = true;
			theCorrectionFactorFormula = returnVal.formula;
			theCorrectionFactorErrMsg = returnVal.msg;
			break;
			
		case Child.GlobalDomIds.WARN:
			theCorrectionFactorIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
			theCorrectionFactorErrMsg = returnVal.msg;
			theCorrectionFactorFormula = returnVal.formula;
			break;
		default:
			break;
	}

	var theTargetBGCheckIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
	var theTargetBGErrMsg = '';
	Child.IcalcPanelFactory.FatalTargetBGError = false;
	
	returnVal = CHILD.InsulinCalcEngine.editTargetBG(uji);

	switch(returnVal.status) {
		case Child.GlobalDomIds.OK:
			theTargetBGCheckIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
			theTargetBGErrMsg = returnVal.msg;
			break;
			
		case Child.GlobalDomIds.ERROR:
			theTargetBGCheckIcon = Child.GlobalDomIds.RED_X_IMG;
			Child.IcalcPanelFactory.FatalTargetBGError = true;
			theTargetBGErrMsg = returnVal.msg;
			break;
			
		case Child.GlobalDomIds.WARN:
			theTargetBGCheckIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
			theTargetBGErrMsg = returnVal.msg;
			break;
		default:
			break;
	}


	var theTargetSickDayCheckIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
	var theTargetSickDayErrMsg = '';
	Child.IcalcPanelFactory.FatalTargetSickDayError = false;
	
	returnVal = CHILD.InsulinCalcEngine.editTargetSickDay(uji);

	switch(returnVal.status) {
		case Child.GlobalDomIds.OK:
			theTargetSickDayCheckIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
			theTargetSickDayErrMsg = returnVal.msg;
			break;
			
		case Child.GlobalDomIds.ERROR:
			theTargetSickDayCheckIcon = Child.GlobalDomIds.RED_X_IMG;
			Child.IcalcPanelFactory.FatalTargetSickDayError = true;
			theTargetSickDayErrMsg = returnVal.msg;
			break;
			
		case Child.GlobalDomIds.WARN:
			theTargetSickDayCheckIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
			theTargetSickDayErrMsg = returnVal.msg;
			break;
		default:
			break;
	}


	var VerifyFieldProcess = function(panelId, fieldId, labelId) {

		var theField = Ext.getCmp(panelId + fieldId);
		theField.enable();
		
		
		var theLabel = Ext.getCmp(panelId + labelId);

		switch(fieldId) {
			case Child.GlobalDomIds.carbRatioId:
				if(theCarbRatioCheckIcon === Child.GlobalDomIds.GREY_CHECK_IMG) {
					theCarbRatioCheckIcon  = Child.GlobalDomIds.GREEN_CHECK_IMG;
				}
				Child.IcalcPanelFactory.CarbRatioVerified = true;
				break;
			case Child.GlobalDomIds.correctionFactorId:
				if(theCorrectionFactorIcon === Child.GlobalDomIds.GREY_CHECK_IMG) {
					theCorrectionFactorIcon  = Child.GlobalDomIds.GREEN_CHECK_IMG;
				}
				Child.IcalcPanelFactory.CorrectionFactorVerified = true;
				break;
		
			case Child.GlobalDomIds.targetBGId:
				if(theTargetBGCheckIcon === Child.GlobalDomIds.GREY_CHECK_IMG) {
					theTargetBGCheckIcon  = Child.GlobalDomIds.GREEN_CHECK_IMG;
				}
				Child.IcalcPanelFactory.TargetBGVerified = true;
				break;
			case Child.GlobalDomIds.targetSickDayId:
				if(theTargetSickDayCheckIcon === Child.GlobalDomIds.GREY_CHECK_IMG) {
					theTargetSickDayCheckIcon  = Child.GlobalDomIds.GREEN_CHECK_IMG;
				}
				Child.IcalcPanelFactory.TargetSickDayVerified = true;
				break;
			default:
				break;
		}
 
		theLabel.enable();

		var theNewHtml = buildHtmlForLabel(labelId, panelId);
		var theGroupField = theField.ownerCt;
		theGroupField.setFieldLabel(theNewHtml);
//		theLabel.update(theNewHtml);

	};
	
	var CheckForAllVerified = function(panelId) {

		if(	Child.IcalcPanelFactory.CarbRatioVerified &&
			Child.IcalcPanelFactory.CorrectionFactorVerified &&
			Child.IcalcPanelFactory.TargetBGVerified &&
			Child.IcalcPanelFactory.TargetSickDayVerified) {
			// Clear extra verify msg from orders header
			var theOrderHeader = Ext.getCmp(panelId + Child.GlobalDomIds._OrderParmsLabelId);
			theOrderHeader.setValue('<span class="calc-heading-blue">Parameters From Order</span>');
				
			// All are verified, enable the Patient value fields
			var theCarbsField = Ext.getCmp(panelId + Child.GlobalDomIds.carbsEatenFieldId);
			theCarbsField.enable();
			var theCarbsLabel = Ext.getCmp(panelId + Child.GlobalDomIds.carbsEatenLabelId);
			theCarbsLabel.enable();

			var theBGField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
			theBGField.enable();
			var theBGLabel = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseLabelId);
			theBGLabel.enable();
			
			var theBOHBField = Ext.getCmp(panelId + Child.GlobalDomIds.BOHBFieldId);
			theBOHBField.enable();
			var theBOHBLabel = Ext.getCmp(panelId + Child.GlobalDomIds.BOHBLabelId);
			theBOHBLabel.enable();
			
			var the3HourChk = Ext.getCmp(panelId + Child.GlobalDomIds._3hrInsulinRBGroup);
           	the3HourChk.enable();
           	var the3HourChkLabel = Ext.getCmp(panelId + Child.GlobalDomIds._ISMORETHAN3HOURSSINCELASTINSULIN_LABEL);
           	the3HourChkLabel.enable();

//			var theBGRisingChk = Ext.getCmp(panelId + '_BGRisingRBGroup'); //Child.GlobalDomIds._3hrInsulinRBGroup);
//           	theBGRisingChk.enable();
//           	var theBGRisingChkLabel = Ext.getCmp(panelId + '_BGRisingRadio');//Child.GlobalDomIds._ISMORETHAN3HOURSSINCELASTINSULIN_LABEL);
//           	theBGRisingChkLabel.enable();

			
//			var theBG3HourChk = Ext.getCmp(panelId + Child.GlobalDomIds._BG_AND_3hrInsulinRBGroup);
//           	theBG3HourChk.enable();
//           	var theBG3HourChkLabel = Ext.getCmp(panelId + Child.GlobalDomIds._BGRISINGANDRAPIDINSULINLABEL);
//           	theBG3HourChkLabel.enable();

           	theCarbsField.focus(true, 10);
		}

	};
	
	var theLabelHeight = 45;
	var theHeaderLabelHeight = 25;
	var theLabelWidth = 500;
	var theFieldlHeight = 30;
	var theFieldWidth = 65;
	var theRowHeight = 45;
	var theTextLabelWidth = theLabelWidth - 50;

	var formatBGLabel = function(imgStr, errMsg, theCurrentBGFormula, hypglycemic) {
		
		var tempLabel =	'';
		if(hypglycemic) {
			tempLabel = '<table>' +
		     				'<tr>' +
			       				'<td width="' + theTextLabelWidth + 'px">' +
					    			'<span class="calc-heading-bold-large">Blood Glucose for Calculation</span></br>' +
					    			'<span class="calc-error">&nbsp;&nbsp;' + theCurrentBGFormula + '</span></br>' +
									'<span class="calc-error">&nbsp;&nbsp;' + errMsg + '</span>' + 
					       		'</td>' +
					       		'<td>' +
					       			imgStr +
								'</td>' + 
							'</tr>' +
						'</table>';
		} else {
			tempLabel = '<table>' +
		     				'<tr>' +
			       				'<td width="' + theTextLabelWidth + 'px">' +
					    			'<span class="calc-heading-bold-large">Blood Glucose for Calculation</span></br>' +
					    			'<span class="calc-body">&nbsp;&nbsp;' + theCurrentBGFormula + '</span></br>' +
									'<span class="calc-error">&nbsp;&nbsp;' + errMsg + '</span>' + 
					       		'</td>' +
					       		'<td>' +
					       			imgStr +
								'</td>' + 
							'</tr>' +
						'</table>';
		}
			
		return tempLabel;
	
	};

	var formatCarbsEatenLabel = function(imgStr, errMsg, theCarbsEatenFormula) {
		
		var tempLabel =	'<table>' +
							'<tr>' +
				    			'<td width="' + theTextLabelWidth + 'px">' +
									'<span class="calc-heading-bold-large">Carbs Eaten</span></br>' +
									'<span class="calc-body">&nbsp;&nbsp;' + theCarbsEatenFormula + '</span></br>' +
									'<span class="calc-error">&nbsp;&nbsp;' + errMsg + '</span>' + 
								'</td>' +
								'<td>' +
									imgStr +
								'</td>' + 
							'</tr>' +
						'</table>';
	
		return tempLabel;

	};
	
	var formatBOHBLabel = function(imgStr, errMsg, theBOHBFormula) {
		
		var tempLabel =	'<table>' +
							'<tr>' +
				    			'<td width="' + theTextLabelWidth + 'px">' +
									'<span class="calc-heading-bold-large">Ketones (Serum or Urine) for Sick Day Calculation</span></br>' +
									'<span class="calc-body">&nbsp;&nbsp;' + theBOHBFormula + '</span></br>' +
									'<span class="calc-error">&nbsp;&nbsp;' + errMsg + '</span>' + 
								'</td>' +
								'<td>' +
									imgStr +
								'</td>' + 
							'</tr>' +
						'</table>';
	
		return tempLabel;

	};
	
	var formatInsulinResultLabel = function(theResultFormula, dispArrow) {
		
		var arrowImg = '';
		if(dispArrow) {
	    	arrowImg = '<img style="float:right;padding-right:10px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + Child.GlobalDomIds.RIGHT_ARROW_IMG + '">';
	    }
		
		var tempLabel = '<span class="calc-heading-bold-large">' + icalcData.INSULIN_CALC.INSULINTYPE + '</span>' +  arrowImg + '</br>' +
			'<span class="calc-body">&nbsp;&nbsp;&nbsp;&nbsp;' + theResultFormula + '</span>';

		return tempLabel;
		
	};

	var labelBGforCalcInitial = formatBGLabel('&nbsp;', '', '', false);
	var labelCarbsEatenInitial = formatCarbsEatenLabel('&nbsp;', '', '');
	var labelBOHBInitial = formatBOHBLabel('&nbsp;', '', '');

	var buildHtmlForLabel = function(labelId, panelId) {

		var theToolTip = 'data-qtip="Click to verify value"';
		var theErrMsg = '';
		var theHtml = '';
		var tmpTip = '';
		var tip = '';
		var theLabel;
		var theSickDayMsg = '';
		
		if(icalcData.INSULIN_CALC.SICKDISPLAYLINE && icalcData.INSULIN_CALC.SICKDISPLAYLINE !== '') {
			theSickDayMsg = '<span class="calc-error">&nbsp;&nbsp;(From Sick Day Order)</span>';
		}
		
		switch (labelId) {
			case Child.GlobalDomIds._carbRatioLabelId:
				if(theCarbRatioCheckIcon !== Child.GlobalDomIds.GREEN_CHECK_IMG) {
					theLabel = Ext.getCmp(panelId + Child.GlobalDomIds._carbRatioLabelId);
					tip = 'Click to Verify';
					if(theLabel !== undefined) {
						if(!theLabel.disabled) {
							tip = 'Value Verified';
						}
					}
					if(theCarbRatioErrMsg === '') {
						tmpTip = Ext.String.format('{0}', tip);
					} else {
						tmpTip = Ext.String.format('</br>{0}', tip);
					}
					theToolTip = 'data-qtip="' + theCarbRatioErrMsg +  tmpTip + '"';
					theErrMsg = '</br><span class="calc-error">&nbsp;&nbsp;' + theCarbRatioErrMsg + '</span>';
				} else {
					theToolTip = 'data-qtip="Value Verified"';
				}

				theHtml = 	'<table>' +
						      	'<tr>' +
						       		'<td width="' + theTextLabelWidth + 'px">' +
										'<span class="calc-heading-bold-large">Insulin/Carb Ratio</span>' + theSickDayMsg + '</br>' +
										'<span class="calc-body">&nbsp;&nbsp;' + theCarbRatioFormula + '</span>' +
										theErrMsg +
									'</td>' +
								    '<td>' +
								    	'<img ' + theToolTip + ' id="' + panelId + Child.GlobalDomIds._carbRatioCheckID + '" class="clickable-disabled" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theCarbRatioCheckIcon + '">' +
									'</td>' + 
								'</tr>' +
							'</table>';
				break;
				
			case Child.GlobalDomIds._correctionFactorLabelId:
				if(theCorrectionFactorIcon !== Child.GlobalDomIds.GREEN_CHECK_IMG) {
					theLabel = Ext.getCmp(panelId + Child.GlobalDomIds._correctionFactorLabelId);
					tip = 'Click to Verify';
					if(theLabel !== undefined) {
						if(!theLabel.disabled) {
							tip = 'Value Verified';
						}
					}
					if(theCorrectionFactorErrMsg === '') {
						tmpTip = Ext.String.format('{0}', tip);
					} else {
						tmpTip = Ext.String.format('</br>{0}', tip);
					}
					theToolTip = 'data-qtip="' + theCorrectionFactorErrMsg + tmpTip + '"';
					theErrMsg = '</br><span class="calc-error">&nbsp;&nbsp;' + theCorrectionFactorErrMsg + '</span>';
				} else {
					theToolTip = 'data-qtip="Value Verified"';
				}

			    theHtml = 	'<table>' +
				       			'<tr>' +
				       				'<td width="' + theTextLabelWidth + 'px">' +
						       			'<span class="calc-heading-bold-large">Correction Factor</span>' + theSickDayMsg + '</br>' +
						       			'<span class="calc-body">&nbsp;&nbsp;' + theCorrectionFactorFormula + '</span>' +
										theErrMsg +
						       		'</td>' +
						       		'<td>' +
						       			'<img ' + theToolTip + ' id="' + panelId + Child.GlobalDomIds._correctionFactorCheckID + '" class="clickable-disabled" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theCorrectionFactorIcon + '">' +
									'</td>' + 
								'</tr>' +
							'</table>';
				break;
				
			case Child.GlobalDomIds._targetBGLabelId:
				if(theTargetBGCheckIcon !== Child.GlobalDomIds.GREEN_CHECK_IMG) {
					theLabel = Ext.getCmp(panelId + Child.GlobalDomIds._targetBGLabelId);
					tip = 'Click to Verify';
					if(theLabel !== undefined) {
						if(!theLabel.disabled) {
							tip = 'Value Verified';
						}
					}
					if(theTargetBGErrMsg === '') {
						tmpTip = Ext.String.format('{0}', tip);
					} else {
						tmpTip = Ext.String.format('</br>{0}', tip);
					}
					theToolTip = 'data-qtip="' + theTargetBGErrMsg + tmpTip + '"';
					theErrMsg = '</br><span class="calc-error">&nbsp;&nbsp;' + theTargetBGErrMsg + '</span>';
				} else {
					theToolTip = 'data-qtip="Value Verified"';
				}

				theHtml = 	'<table>' +
				       			'<tr>' +
				       				'<td width="' + theTextLabelWidth + 'px">' +
						    			'<span class="calc-heading-bold-large">Target Blood Glucose</span>' + theSickDayMsg + '</br>' +
						    			'<span class="calc-body">&nbsp;&nbsp;Glucose target above which correction must be applied</span>' +
										theErrMsg +
						    		'</td>' +
						    		'<td>' +
						    			'<img ' + theToolTip + ' id="' + panelId + Child.GlobalDomIds._targetBGCheckID + '" class="clickable-disabled" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theTargetBGCheckIcon + '">' +
									'</td>' + 
								'</tr>' +
							'</table>';
				break;
			
			case Child.GlobalDomIds._targetSickDayLabelId:
				if(theTargetSickDayCheckIcon !== Child.GlobalDomIds.GREEN_CHECK_IMG) {
					theLabel = Ext.getCmp(panelId + Child.GlobalDomIds._targetSickDayLabelId);
					tip = 'Click to Verify';
					if(theLabel !== undefined) {
						if(!theLabel.disabled) {
							tip = 'Value Verified';
						}
					}
					if(theTargetSickDayErrMsg === '') {
						tmpTip = Ext.String.format('{0}', tip);
					} else {
						tmpTip = Ext.String.format('</br>{0}', tip);
					}
					theToolTip = 'data-qtip="' + theTargetSickDayErrMsg + tmpTip + '"';
					theErrMsg = '</br><span class="calc-error">&nbsp;&nbsp;' + theTargetSickDayErrMsg + '</span>';
				} else {
					theToolTip = 'data-qtip="Value Verified"';
				}

				theHtml = 	'<table>' +
				       			'<tr>' +
				       				'<td width="' + theTextLabelWidth + 'px">' +
						    			'<span class="calc-heading-bold-large">Sick Day Management?</span></br>' +
						    			'<span class="calc-body">&nbsp;&nbsp;Should insulin be adjusted for serum/urine ketones?</span>' +
										theErrMsg +
						    		'</td>' +
						    		'<td>' +
						    			'<img ' + theToolTip + ' id="' + panelId + Child.GlobalDomIds._targetSickDayCheckID + '" class="clickable-disabled" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theTargetSickDayCheckIcon + '">' +
									'</td>' + 
								'</tr>' +
							'</table>';
				break;
			
			default:
				break;
		}
		
		return theHtml;

	};

	var clearResultInformation = function() {
		
		var theResultfield = Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultFieldId);
		theResultfield.setValue(null);
		
		var theResultLabel = theResultfield.ownerCt;	//Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultLabelId);
		theResultLabel.setFieldLabel(formatInsulinResultLabel('', false));
		
		var theResultErrorsLabel = Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultErrorDisplayFieldId);
		theResultErrorsLabel.setValue('');
	
	};
	
	var orderDisplay = Child.IcalcPanelFactory.BuildOrderDisplay(icalcData, true);

    var notRequiredFieldCls = 'x-form-empty-field';
	if(uji.AdminTime.toLowerCase() === Child.GlobalDomIds.snacks && uji.IsSickDay === false) {
		notRequiredFieldCls = 'not-required-class';
	}

	var CheckForEnableCalcBtn = function() {

		var theCalcBtn = Ext.getCmp(panelId + Child.GlobalDomIds._CALCULATE_BTN);

		if(	!Child.IcalcPanelFactory.FatalBGError &&
			!Child.IcalcPanelFactory.FatalCarbsError &&
			!Child.IcalcPanelFactory.FatalCarbRatioError &&
			!Child.IcalcPanelFactory.FatalCorrectionFactorError &&
			!Child.IcalcPanelFactory.FatalTargetBGError &&
			!Child.IcalcPanelFactory.FatalBOHBError) {

			var theCarbsField = Ext.getCmp(panelId + Child.GlobalDomIds.carbsEatenFieldId);
			var theBGField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
			var theBOHBFactor = Ext.getCmp(panelId + Child.GlobalDomIds.BOHBFieldId);
				
			if(	((theBOHBFactor.getValue() !== null && uji.IsSickDay === true) || (theBOHBFactor.getValue() === null && uji.IsSickDay === false)) && 
				(theCarbsField.getValue() !== null && theCarbsField.getValue() !== '') && 
				((theBGField.getValue() !== null && theCarbsField.getValue() !== '') || (uji.AdminTime.toLowerCase() === Child.GlobalDomIds.snacks && (theBGField.getValue() === null || theCarbsField.getValue() !== '') && uji.IsSickDay === false)) ) {
				theCalcBtn.enable();
//				var theBtnPanel = Ext.getCmp('testpanelhere');
//				theBtnPanel.focus();
//				theBtnPanel.setActive(true);
				theCalcBtn.focus();
				theCalcBtn.setActive(true);
   			}
		} else {
			theCalcBtn.disable();
		}

	};
    	
	var threeHrInsulinRadioGroup = new Ext.form.RadioGroup({
		columns : [50, 50],
		allowBlank : false,
		id : panelId + Child.GlobalDomIds._3hrInsulinRBGroup,
		disabled : true,
		width : 150,
		height : 25,
		stateful : false,
		items : [{
					boxLabel : 'Yes',
					disabled : false,
					id : panelId + Child.GlobalDomIds._3hrInsulinYes,
					name : panelId + Child.GlobalDomIds.rb_3HrYesNo,
					checked : !uji.IsMoreThan3HoursSinceLastInsulin,
					handler : function fn(checkbox, checked) {
						if(checked === true) {
		            		uji.IsMoreThan3HoursSinceLastInsulin = false;
	
		            		var theBGForCalcField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
		            		theBGForCalcField.fireEvent('blur', theBGForCalcField);
			            	var theBOHBField = Ext.getCmp(panelId + Child.GlobalDomIds.BOHBFieldId);
			            	if(theBOHBField.getValue() !== null) {
			            		var theRecords = new Array();
			            		theRecords.push(theBOHBField.store.getAt(theBOHBField.getValue()));
				            	theBOHBField.fireEvent('select', theBOHBField, theRecords, theBOHBField.getValue());
			            	}
						}
					}
				}, {
					boxLabel : 'No',
					id : panelId + Child.GlobalDomIds._3hrInsulinNo,
					name : panelId + Child.GlobalDomIds.rb_3HrYesNo,
					disabled : false,
					checked : uji.IsMoreThan3HoursSinceLastInsulin,
					handler : function fn(checkbox, checked) {
						if(checked === true) {
		            		uji.IsMoreThan3HoursSinceLastInsulin = true;
	
		            		var theBGForCalcField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
		            		theBGForCalcField.fireEvent('blur', theBGForCalcField);
			            	var theBOHBField = Ext.getCmp(panelId + Child.GlobalDomIds.BOHBFieldId);
			            	if(theBOHBField.getValue() !== null) {
			            		var theRecords = new Array();
			            		theRecords.push(theBOHBField.store.getAt(theBOHBField.getValue()));
				            	theBOHBField.fireEvent('select', theBOHBField, theRecords, theBOHBField.getValue());
			            	}
						}
					}
				}]
	});

	var patientValuesHeight = 214;
	if (!(icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.snacks || icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.sickday)) {
		patientValuesHeight = 190;
	}

	var orderDisplayHeight = 130;
	if(icalcData.INSULIN_CALC.SICKDISPLAYLINE && icalcData.INSULIN_CALC.SICKDISPLAYLINE !== '') {
		orderDisplayHeight = 200;
	}

	var orderInformationPanel = new Ext.panel.Panel(
	{
        xtype: 'panel'
        ,border:true
        ,height : orderDisplayHeight
		,layout : 'fit',
        items: [
        {
        	xtype : 'panel',
   			layout : 'fit',
   			border : true,
   			items : {
   				xtype : 'panel',
       			id : Child.GlobalDomIds.ORDER_INFORMATION_PANEL_ID,
            	padding : '0 5 0 5',
	        	border : false,
    			html: orderDisplay
   			}
        }]
   	});
	
	var spacerPanel6 = {
    	xtype : 'panel',
    	height : 6,
    	border : false,
    	cls : 'class-spacer-panel'
	};

	var spacerPanel3 = {
    	xtype : 'panel',
    	height : 3,
    	border : false,
    	cls : 'class-spacer-panel'
	};

	var parametersPanel = new Ext.panel.Panel(
	{
        xtype: 'panel'
        ,border:true
       	,id : Child.GlobalDomIds.ORDER_PARAMETERS_PANEL_ID
        ,height : (theRowHeight * 5) + 10
		,layout : 'fit',
        items: [
        {
        	xtype : 'panel',
        	border : true,
			layout : {
				type : 'vbox'
				,pack : 'start'
				,align : 'stretch'
			},
        	items : [
	        {
	        	xtype : 'fieldcontainer',
	        	border : false,
	           	padding : '0 5 0 5',
	        	hideLabel : true,
	        	height : theHeaderLabelHeight,
	        	items: [
					{
			       		xtype: 'displayfield',
			       		id : panelId + Child.GlobalDomIds._OrderParmsLabelId, 
			        	disabled: false,
			        	height : theHeaderLabelHeight,
			       		width: theLabelWidth + theFieldWidth,
			       		value: '<span class="calc-heading-blue">Parameters From Order</span><span style="float:right;padding-right:30px;" class="calc-verify-heading">Click checkmark below to verify:</span>'
	        		}
	        	]
	        }, {
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
	        	border : false,
            	padding : '0 5 0 5',
	        	id : panelId + Child.GlobalDomIds._carbRatioLabelId,
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		labelSeparator : '',
	       		fieldLabel:	buildHtmlForLabel(Child.GlobalDomIds._carbRatioLabelId, panelId),
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
	        		{
			       		xtype: 'numberfield',
			        	id : panelId + Child.GlobalDomIds.carbRatioId,
			        	readOnly : true,
						width : theFieldWidth,
						height : theFieldlHeight,
			        	disabled: true,
						value: icalcData.INSULIN_CALC.CARBGRAMSPERINSULINUNIT
	        		}
	        	],
		        listeners: {
		            afterrender: {
		    			fn: function() {
		    				if(Ext.fly(panelId + Child.GlobalDomIds._carbRatioCheckID)) {
								Ext.fly(panelId + Child.GlobalDomIds._carbRatioCheckID).on("click", function() {
									VerifyFieldProcess(panelId, Child.GlobalDomIds.carbRatioId, Child.GlobalDomIds._carbRatioLabelId );
									CheckForAllVerified(panelId);
								}, {
									panelId : panelId
								});
		    				}
		                }
		            }
		        }
	        }, {
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
			    id : panelId + Child.GlobalDomIds._correctionFactorLabelId,
	        	border : false,
	            	padding : '0 5 0 5',
			    disabled: true,
			    labelHeight : theLabelHeight,
			    labelWidth: theLabelWidth,
			    fieldLabel:	buildHtmlForLabel(Child.GlobalDomIds._correctionFactorLabelId, panelId),
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
	        		{
			       		xtype: 'numberfield',
			        	id : panelId + Child.GlobalDomIds.correctionFactorId,
			        	readOnly : true,
						width : theFieldWidth,
						height : theFieldlHeight,
			        	disabled: true,
						value: icalcData.INSULIN_CALC.CORRECTIONFACTOR
	        		}
	        	],
		        listeners: {
		            afterrender: {
		    			fn: function() {
		    				if(Ext.fly(panelId + Child.GlobalDomIds._correctionFactorCheckID)) {
								Ext.fly(panelId + Child.GlobalDomIds._correctionFactorCheckID).on("click", function() {
									VerifyFieldProcess(panelId, Child.GlobalDomIds.correctionFactorId, Child.GlobalDomIds._correctionFactorLabelId );
									CheckForAllVerified(panelId);
								}, {
									panelId : panelId
								});
		    				}
		                }
		            }
		        }
	        }, {
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
	        	border : false,
	            	padding : '0 5 0 5',
	        	id : panelId + Child.GlobalDomIds._targetBGLabelId,
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		fieldLabel:	buildHtmlForLabel(Child.GlobalDomIds._targetBGLabelId, panelId),
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
					{
			       		xtype: 'numberfield',
			        	id : panelId + Child.GlobalDomIds.targetBGId,
			        	readOnly : true,
						width : theFieldWidth,
						height : theFieldlHeight,
			        	disabled: true,
						value: icalcData.INSULIN_CALC.TARGETBLOODGLUCOSE
	        		}, {
	        			xtype : 'displayfield',
	        			height : theLabelHeight,
	        			disabled : false,
	        			width : 100,
	        			fieldLabel: ' ',
	        			labelSeparator : '',
	        			labelPad : 0,
	        			value : '</br>' + CHILD.InsulinCalcConstants.BGLimtForCalc.units
	        		}
	        	],
		        listeners: {
		            afterrender: {
		    			fn: function() {
		    				if(Ext.fly(panelId + Child.GlobalDomIds._targetBGCheckID)) {
								Ext.fly(panelId + Child.GlobalDomIds._targetBGCheckID).on("click", function() {
									VerifyFieldProcess(panelId, Child.GlobalDomIds.targetBGId, Child.GlobalDomIds._targetBGLabelId );
									CheckForAllVerified(panelId);
								}, {
									panelId : panelId
								});
		    				}
		                }
		            }
		        }
	        }
	        ,{
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
	        	hidden : icalcData.INSULIN_CALC.ISSICKDAY !== 'true',
	        	border : false,
	            	padding : '0 5 0 5',
	        	id : panelId + Child.GlobalDomIds._targetSickDayLabelId,
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		fieldLabel:	buildHtmlForLabel(Child.GlobalDomIds._targetSickDayLabelId, panelId),
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
					{
			       		xtype: 'textfield',
			        	id : panelId + Child.GlobalDomIds.targetSickDayId,
			        	readOnly : true,
						width : theFieldWidth,
						height : theFieldlHeight,
			        	disabled: true,
						value: icalcData.INSULIN_CALC.ISSICKDAY === 'true' ? 'YES' : 'NO'
	        		}
	        	],
		        listeners: {
		            afterrender: {
		    			fn: function() {
		    				if(Ext.fly(panelId + Child.GlobalDomIds._targetSickDayCheckID)) {
								Ext.fly(panelId + Child.GlobalDomIds._targetSickDayCheckID).on("click", function() {
									VerifyFieldProcess(panelId, Child.GlobalDomIds.targetSickDayId, Child.GlobalDomIds._targetSickDayLabelId );
									CheckForAllVerified(panelId);
								}, {
									panelId : panelId
								});
		    				}
		                }
		            }
		        }
	        }]
        }]
	});
	
	var patientValuesPanel = new Ext.form.Panel(
	{
    	xtype : 'panel',
    	id : Child.GlobalDomIds.PATIENT_VALUES_PANEL_ID,
    	border : true,
    	height : patientValuesHeight,
		layout : 'fit',
    	items : [
        {
        	xtype : 'panel',
        	border : true,
			layout : {
				type : 'vbox'
				,pack : 'start'
				,align : 'stretch'
			},
        	items : [
	        {

        	
	        	xtype : 'fieldcontainer',
	        	border : false,
	           	padding : '0 5 0 5',
	        	hideLabel : true,
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
				{
			    	xtype: 'displayfield',
			       	disabled: false,
			       	height : theHeaderLabelHeight,
			     	width: theLabelWidth,
			       	value: '<span class="calc-heading-blue">Enter Patient Values</span>'
	        	}]
	        }, {
	        	xtype : 'fieldcontainer',
	        	hidden : !(icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.snacks || icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.sickday),
	        	height : 25,
		       	border : false,
	           	padding : '0 5 0 5',
	        	id : panelId + Child.GlobalDomIds._ISMORETHAN3HOURSSINCELASTINSULIN_LABEL,
	        	disabled: true,
	        	labelHeight : 25,
	       		labelWidth: theLabelWidth,
	       		fieldLabel: rapidInsulinQuestion, //'<span class="calc-heading-bold-large">Rapid-acting insulin in past 3 hrs?</span>'
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
	        		threeHrInsulinRadioGroup
	        	]
	        }, {
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
	        	border : false,
	        	padding : '0 5 0 5',
	        	id : panelId + Child.GlobalDomIds.carbsEatenLabelId,
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		fieldLabel: labelCarbsEatenInitial,
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
	    		{
		       		xtype: 'numberfield',
		        	id : panelId + Child.GlobalDomIds.carbsEatenFieldId,
					width : theFieldWidth,
					height : theFieldlHeight,
					tabIndex : 1,
		        	emptyText : ' ',
			        hideTrigger: true,
			        keyNavEnabled: false,
			        mouseWheelEnabled: false,
		        	disabled: true,
			        listeners: {
			            blur: {
			    			fn: function(theField) {
	
								var theCalcBtn = Ext.getCmp(panelId + Child.GlobalDomIds._CALCULATE_BTN);
								var theCurrentLabel = theField.ownerCt.getFieldLabel();
	
							    if(theField.getValue() !== null || theCurrentLabel.indexOf('src="../img/') !== -1) {
								    var theValue = theField.getValue();
				    				if(theValue === null) {
				    					theValue = '';
				    				}
				    				uji.GramsOfCarbsEaten = theValue;
				    				
				    				var theLabel = Ext.getCmp(panelId + Child.GlobalDomIds.carbsEatenLabelId);
									var theCarbsEatenIcon = '';
									var theErrMsg = '';
									var theCarbsEatenFormula = '';
				    				
									Child.IcalcPanelFactory.FatalCarbsError = false;
									var returnVal = CHILD.InsulinCalcEngine.editCarbsEaten(uji);
									
									switch(returnVal.status) {
										case Child.GlobalDomIds.OK:
				    						theCarbsEatenIcon = Child.GlobalDomIds.GREEN_CHECK_IMG;
				    						theErrMsg = returnVal.msg;
				    						theCarbsEatenFormula = returnVal.formula;
											break;
											
										case Child.GlobalDomIds.ERROR:
			    							theCarbsEatenIcon = Child.GlobalDomIds.RED_X_IMG;
											Child.IcalcPanelFactory.FatalCarbsError = true;
				    						theErrMsg = returnVal.msg;
											break;
											
										case Child.GlobalDomIds.WARN:
				    						theCarbsEatenIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
				    						theErrMsg = returnVal.msg;
				    						theCarbsEatenFormula = returnVal.formula;
											break;
										default:
											break;
									}
									
									var theLabelStr = formatCarbsEatenLabel('<img data-qtip="' + theErrMsg + '" class="non-clickable" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theCarbsEatenIcon + '">', theErrMsg, theCarbsEatenFormula);
	
									var theGroupField = theField.ownerCt;
									theGroupField.setFieldLabel(theLabelStr);
	//				    				theLabel.update(theLabelStr);
				    				
							    	clearResultInformation();
							    	
									if(returnVal.status === Child.GlobalDomIds.ERROR) {
										theField.focus(true,10);
									}
									
									CheckForEnableCalcBtn();
			    				}
			    				
			                }
			            }
			        }
	    		}, {
	    			xtype : 'displayfield',
	    			height : theLabelHeight,
	    			disabled : false,
	    			fieldLabel: ' ',
	    			labelPad : 0,
	    			labelSeparator : '',
	    			value : '</br>' + CHILD.InsulinCalcConstants.CarbsEatenMin.units
	        	}]
	        }, {
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
	        	hidden : uji.IsSickDay === false,
	        	border : false,
	        	padding : '0 5 0 5',
	        	id : panelId + Child.GlobalDomIds.BOHBLabelId,
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		fieldLabel: labelBOHBInitial,
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
	       		{
		       		xtype: 'combo',
		        	id : panelId + Child.GlobalDomIds.BOHBFieldId,
					width : 210,
					height : theFieldlHeight-4,
					tabIndex : 2,
					cls : 'x-combo-list-item',//notRequiredFieldCls,
	        		disabled: true,
		           	store: new Ext.data.ArrayStore({
		           		fields: ['dispText', 'factor', 'index'],
		               	data : [
	    	           		['BOHB under 0.6 mmol/L',       1.0, 0],
	        	       		['BOHB 0.6 - 1.5 mmol/L',       1.5, 1],
	            	   		['BOHB over 1.5 mmol/L',        2.0, 2],
	    	           		['Urine Ketones Neg - Small', 1.0, 3],
	        	       		['Urine Ketones Moderate',    1.5, 4],
	            	   		['Urine Ketones Large',       2.0, 5]
	             		]
	         		}),
	            	displayField:'dispText',
	            	valueField: 'index',
	            	querymode: 'local',
	            	typeAhead: false,
	            	triggerAction: 'all',
	            	lazyRender: true,
	            	lazyInit : false,
	            	forceSelection : true,
	            	emptyText: 'Select value',
	            	value : null,
	            	valueNotFoundText : 'Select value',
		        	listeners: {
		        		focus : {
		        			fn: function(theCombo) {
		        				theCombo.doQuery(theCombo.allQuery, true);
		        				theCombo.expand();
		        			}
		        		},
		        		select: {
		        			fn: function(theCombo, records, index) {
		        				var record = records[0];
		        				
							    if(record.data.dispText !== "") {
				    				if(uji.IsMoreThan3HoursSinceLastInsulin === false) {
				    					uji.SickDayFactor = 1.0;
				    				} else {
									    uji.SickDayFactor = record.data.factor; //theField.store.getAt(newValue).data.factor;
								    }
								    
									var theBOHBIcon = '';
									var theErrMsg = '';
									var theBOHBFormula = '';
									
									Child.IcalcPanelFactory.FatalBOHBError = false;
									var returnVal = CHILD.InsulinCalcEngine.editBOHBForCalc(uji);
									
									switch(returnVal.status) {
										case Child.GlobalDomIds.OK:
				    						theBOHBIcon = Child.GlobalDomIds.GREEN_CHECK_IMG;
				    						theErrMsg = returnVal.msg;
				    						theBOHBFormula = returnVal.formula;
											break;
											
										case Child.GlobalDomIds.ERROR:
			    							theBOHBIcon = Child.GlobalDomIds.RED_X_IMG;
											Child.IcalcPanelFactory.FatalBOHBError = true;
				    						theErrMsg = returnVal.msg;
											break;
											
										case Child.GlobalDomIds.WARN:
				    						theBOHBIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
				    						theErrMsg = returnVal.msg;
				    						theBOHBFormula = returnVal.formula;
											break;
											
										default:
											break;
									}
	
				    				var theLabelStr = formatBOHBLabel('<img data-qtip="' + theErrMsg + '" class="non-clickable" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theBOHBIcon + '">', theErrMsg, theBOHBFormula);
	
				    				
									var theGroupField = theCombo.ownerCt;
									theGroupField.setFieldLabel(theLabelStr);
	
							    	clearResultInformation();
				    				
									if(returnVal.status === Child.GlobalDomIds.ERROR) {
										theField.focus(true,10);
									}
									
									//fire change on bg for calc field, just incase this is a change to the BOHB field
									var theBGForCalcField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
									if(theBGForCalcField.getValue() !== "") {
										theBGForCalcField.fireEvent('blur', theBGForCalcField);
									}
									
									CheckForEnableCalcBtn();
							    }
			    			}
		            	}
		        	}
				}]
	        }, {
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
	        	id : panelId + Child.GlobalDomIds.bloodGlucoseLabelId,
	        	border : false,
	        	padding : '0 5 0 5',
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		fieldLabel: labelBGforCalcInitial,
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
	       		{
		       		xtype: 'numberfield',
		        	id : panelId + Child.GlobalDomIds.bloodGlucoseFieldId,
					width : theFieldWidth,
					height : theFieldlHeight,
//					padding : '0 0 10 0',
					tabIndex : 3,
				    hideTrigger: true,
	    			keyNavEnabled: false,
	    			mouseWheelEnabled: false,
						emptyCls : notRequiredFieldCls,
			        	disabled: true,
			        	emptyText : ' '
				        ,listeners: {
				        	blur : {
				    			fn: function(theField) {
								    
									var theCalcBtn = Ext.getCmp(panelId + Child.GlobalDomIds._CALCULATE_BTN);
									var theCurrentLabel = theField.ownerCt.getFieldLabel();
		
								    if(theField.getValue() !== null || theCurrentLabel.indexOf('src="../img/') !== -1) {
	
//								    if(theField.getValue() !== null || theCalcBtn.disabled === false) {
									    var theValue = theField.getValue();
					    				if(theValue === null) {
					    					theValue = '';
					    				}
					    				uji.CurrentBloodGlucose = theValue;
	
										var theBGIcon = '';
										var theErrMsg = '';
										var theCurrentBGFormula = '';
										var hypoglycemic = false;
					    				
										Child.IcalcPanelFactory.FatalBGError = false;
										var returnVal = CHILD.InsulinCalcEngine.editBGForCalc(uji);
										
										switch(returnVal.status) {
											case Child.GlobalDomIds.OK:
					    						theBGIcon = Child.GlobalDomIds.GREEN_CHECK_IMG;
					    						theErrMsg = returnVal.msg;
					    						theCurrentBGFormula = returnVal.formula;
												break;
												
											case Child.GlobalDomIds.ERROR:
				    							theBGIcon = Child.GlobalDomIds.RED_X_IMG;
												Child.IcalcPanelFactory.FatalBGError = true;
					    						theErrMsg = returnVal.msg;
												break;
												
											case Child.GlobalDomIds.WARN:
					    						theBGIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
					    						theErrMsg = returnVal.msg;
					    						theCurrentBGFormula = returnVal.formula;
												break;
												
											case Child.GlobalDomIds.HYPOCRIT:
					    						theBGIcon = Child.GlobalDomIds.CRITHYPO_IMG;
												Child.IcalcPanelFactory.FatalBGError = true;
					    						theErrMsg = returnVal.msg;
					    						theCurrentBGFormula = returnVal.formula;
					    						hypoglycemic = true;
												break;
												
											case Child.GlobalDomIds.HYPO:
					    						theBGIcon = Child.GlobalDomIds.HYPO_IMG;
												Child.IcalcPanelFactory.FatalBGError = true;
					    						theErrMsg = returnVal.msg;
					    						theCurrentBGFormula = returnVal.formula;
					    						hypoglycemic = true;
												break;
												
											default:
												break;
										}
	
					    				var theLabelStr = formatBGLabel('<img data-qtip="' + theErrMsg + '" class="non-clickable" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theBGIcon + '">', theErrMsg, theCurrentBGFormula, hypoglycemic);
										var theGroupField = theField.ownerCt;
										theGroupField.setFieldLabel(theLabelStr);
	
								    	clearResultInformation();
					    				
										if(returnVal.status === Child.GlobalDomIds.ERROR ||
											returnVal.status === Child.GlobalDomIds.HYPOCRIT ||
											returnVal.status === Child.GlobalDomIds.HYPO) {
											theField.focus(true,10);
										}
										
										CheckForEnableCalcBtn();
								    } 
				    			}
				            }
				        }
	        		}, {
	        			xtype : 'displayfield',
	        			height : theLabelHeight,
	        			disabled : false,
	        			fieldLabel: ' ',
	        			labelSeparator : '',
	        			labelPad : 0,
	        			value : '</br>' + CHILD.InsulinCalcConstants.BGLimtForCalc.units
	        		}
	        	]
        	}]
        }]
   	});
   	
   	var buttonPanel = new Ext.panel.Panel(
   	{
    	xtype : 'panel',
    	height : 38,
    	id : Child.GlobalDomIds.BUTTON_PANEL_ID,
    	border : true,
    	layout : 'fit',
    	items : [{
			xtype : 'panel',
			border : true,
    		buttonAlign: 'center',
	        buttons: [{
	            text: 'Clear',
	            margin : '5 0 5 0',
	            listeners: {
	                click: {
	        			fn: function() {
							var theCarbsField = Ext.getCmp(panelId + Child.GlobalDomIds.carbsEatenFieldId);
		        			theCarbsField.setValue(null);
							var theGlucoseField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
		        			theGlucoseField.setValue(null);
							var theBOHBField = Ext.getCmp(panelId + Child.GlobalDomIds.BOHBFieldId);
		        			theBOHBField.setValue(null);

							if(uji.IsSickDay) {
		        				var the3HourNoChk = Ext.getCmp(panelId + Child.GlobalDomIds._3hrInsulinNo);
								the3HourNoChk.setValue(true);
							} else {
			        			var the3HourYesChk = Ext.getCmp(panelId + Child.GlobalDomIds._3hrInsulinYes);
								the3HourYesChk.setValue(true);
							}

							clearResultInformation();
		        			
							var theCalcBtn = Ext.getCmp(panelId + Child.GlobalDomIds._CALCULATE_BTN);
							theCalcBtn.disable();
							
		        			theCarbsField.focus(true);
	
		        			// reset labels to remove icons
							theCarbsField.ownerCt.setFieldLabel(labelCarbsEatenInitial);
							theGlucoseField.ownerCt.setFieldLabel(labelBGforCalcInitial);
							theBOHBField.ownerCt.setFieldLabel(labelBOHBInitial);
	                    }
	                }
	            }
    	}, {
    		xtype : 'panel',
    		border : false,
    		width : 150
   		}, {
	            text: 'Calculate',
	            id : panelId + Child.GlobalDomIds._CALCULATE_BTN,
	            enableKeyEvents: false,
	            tabIndex : 4,
	            disabled : true,
	            listeners: {
	                click: {
	                    fn: function(){
							//Get input fields again - just in case calculate pressed again (field can be overridden in calc engine call
	                    	var theField = Ext.getCmp(panelId + Child.GlobalDomIds.carbsEatenFieldId);
	                    	uji.GramsOfCarbsEaten = theField.getValue();
	                    	
	                    	theField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
	                    	uji.CurrentBloodGlucose = theField.getValue();
	                    	if(uji.CurrentBloodGlucose === null) {
	                    		uji.CurrentBloodGlucose = '';
	                    	}
	                    	
	                    	var the3HourYesChk = Ext.getCmp(panelId + Child.GlobalDomIds._3hrInsulinYes);
	                    	if(the3HourYesChk.checked) {
		                    	uji.IsMoreThan3HoursSinceLastInsulin = false;
	                    	} else {
		                    	uji.IsMoreThan3HoursSinceLastInsulin = true;
	                    	}

	                    	runStdInsulinCalc(panelId, uji);
	                    }
	                }
	            }
	        }]
		}]
    });
   	
	var calculatedValuesHeight = 165;
	if(icalcData.INSULIN_CALC.SICKDISPLAYLINE && icalcData.INSULIN_CALC.SICKDISPLAYLINE !== '') {
		calculatedValuesHeight = 235;
	}
    var calculatedValuesPanel = new Ext.panel.Panel(
    {
    	xtype : 'panel',
    	id : Child.GlobalDomIds.CALCULATED_VALUE_PANEL_ID,
    	border : true,
    	layout : 'fit',
    	height : calculatedValuesHeight,
    	items : [
    	{
    		xtype : 'panel',
    		border : true,
       		layout : {
       			type : 'vbox',
       			align: 'stretch',
       			pack: 'start'
       		},
        	items : [
		    {
	        	xtype : 'fieldcontainer',
	        	border : false,
	        	disabled: false,
            	padding : '2 5 0 5',
	        	height: theHeaderLabelHeight,
	        	labelHeight : theHeaderLabelHeight,
	       		labelWidth: theLabelWidth,
	       		labelSeparator: false,
	       		fieldLabel: '<span class="calc-heading-blue">Calculated Dose to Administer</span>',
	        	hideLabel : false
		    }, {
		       	xtype : 'fieldcontainer',
		       	height : theRowHeight,
	        	border : false,
            	padding : '0 5 0 5',
		       	id : panelId + Child.GlobalDomIds.insulinResultLabelId,
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		fieldLabel: formatInsulinResultLabel('', false),
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
        		{
		       		xtype: 'numberfield',
		        	id : panelId + Child.GlobalDomIds.insulinResultFieldId,
		        	readOnly : true,
					width : theFieldWidth,
					height : theFieldlHeight,
					allowDecimals : true,
					decimalPrecision : 2,
		        	disabled: true
        		}, {
        			xtype : 'displayfield',
        			id : panelId + Child.GlobalDomIds._insulinResultsUnitFieldId,
        			height : theLabelHeight,
        			flex : 1,
	        		disabled : false,
        			fieldLabel: ' ',
        			labelSeparator : '',
        			labelPad : 0,
        			value : '</br>units'
        		}]
		    }, {    	
		   		xtype : 'fieldcontainer',
		       	height : 90,
	        	border : false,
            	padding : '0 5 0 5',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
				{
		       		xtype: 'displayfield',
		        	id : panelId + Child.GlobalDomIds.insulinResultErrorDisplayFieldId,
		        	readOnly : true,
		        	hideLabel : true,
					height : 90,
		        	disabled: false
        		}]
		    }]
    	}]
    });
    
	var theFormPanel = new Ext.form.Panel({
        id: panelId,
        frame: true,
        border : false,
        title: null,
        flex : 1.0,
        autoScroll : true,
		layout : {
			type : 'vbox'
			,padding : 1
			,pack : 'start'
			,align : 'stretch'
		},
        fieldDefaults: {
    	    defaultType: 'textfield',
	        labelWidth: 10
        },
        items: [
			orderInformationPanel, 
	        spacerPanel6, 
	        parametersPanel, 
	        spacerPanel6, 
	        patientValuesPanel, 
	        spacerPanel3, 
	        buttonPanel, 
			spacerPanel3, 
	        calculatedValuesPanel
        ]
    });

    return theFormPanel;
    
};


/**
 * @author rpeltz
 */
Ext.ns('Child');
Child.version = '1.0';
Child.GlobalDomIds = function(){
	return {
		MAIN_PANEL:'MAIN_PANEL',
		
		INSULIN_ORDERS_LAYOUT:'INSULIN_ORDERS_LAYOUT',

		INSULIN_ORDERS_CARD_1:'INSULIN_ORDERS_CARD_1',
		INSULIN_ORDERS_CARD_1_PANEL_1_ID:'INSULIN_ORDERS_CARD_1_PANEL_1_ID',
		INSULIN_ORDERS_ID: 'INSULIN_ORDERS_ID',

		INSULIN_STANDARD_CALC_POPUP_ID: 'INSULIN_STANDARD_CALC_POPUP_ID',
		INSULIN_DILUTE_CALC_POPUP_ID: 'INSULIN_DILUTE_CALC_POPUP_ID',
		INSULIN_STANDARD_CALC_PANEL_ID: 'INSULIN_STANDARD_CALC_PANEL_ID',
		INSULIN_DILUTE_CALC_PANEL_ID: 'INSULIN_DILUTE_CALC_PANEL_ID',
		
		PATIENT_NAME_ID: 'PATIENT_NAME_ID',
		insulinResultFieldId: '_insulinResultFieldId',
		insulinResultLabelId: '_insulinResultLabelId',
		insulinResultErrorDisplayFieldId: '_insulinResultErrorDisplayFieldId',
		carbRatioId: '_carbRatioId',
		correctionFactorId: '_correctionFactorId',
		targetBGId: '_targetBGId',
		carbsEatenFieldId: '_carbsEatenFieldId',
		carbsEatenLabelId: '_carbsEatenLabelId',
		bloodGlucoseFieldId: '_bloodGlucoseFieldId',
		bloodGlucoseLabelId: '_bloodGlucoseLabelId',

		_ISMORETHAN3HOURSSINCELASTINSULIN_LABEL: '_ISMORETHAN3HOURSSINCELASTINSULIN_LABEL',
		_3hrInsulinRBGroup: '_3hrInsulinRBGroup',
		_3hrInsulinYes: '_3hrInsulinYes',
		rb_3HrYesNo: 'rb_3HrYesNo',
		_3hrInsulinNo: '_3hrInsulinNo',
		
//		_BGRISINGANDRAPIDINSULINLABEL: '_BGRISINGANDRAPIDINSULINLABEL',
//		_BG_AND_3hrInsulinRBGroup: '_BG_AND_3hrInsulinRBGroup',
//		_BG_AND_3hrInsulinYes: '_BG_AND_3hrInsulinYes',
//		_rb_BG_AND_3HrYesNo: '_rb_BG_AND_3HrYesNo',
//		_BG_AND_3hrInsulinNo: '_BG_AND_3hrInsulinNo',

		_carbRatioLabelId: '_carbRatioLabelId',
		_correctionFactorLabelId: '_correctionFactorLabelId',
		_targetBGLabelId: '_targetBGLabelId',
		_carbRatioCheckID: '_carbRatioCheckID',
		_correctionFactorCheckID: '_correctionFactorCheckID',
		_targetBGCheckID: '_targetBGCheckID',
		ORDER_INFORMATION_PANEL_ID: 'ORDER_INFORMATION_PANEL_ID',
		ORDER_PARAMETERS_PANEL_ID: 'ORDER_PARAMETERS_PANEL_ID',
		PATIENT_VALUES_PANEL_ID: 'PATIENT_VALUES_PANEL_ID',
		BUTTON_PANEL_ID: 'BUTTON_PANEL_ID',
		CALCULATED_VALUE_PANEL_ID: 'CALCULATED_VALUE_PANEL_ID',
		_CALCULATE_BTN: '_CALCULATE_BTN',
		_insulinResultsUnitFieldId: '_insulinResultsUnitFieldId',
		_OrderParmsLabelId: '_OrderParmsLabelId',
		_targetSickDayLabelId: '_targetSickDayLabelId',
		targetSickDayId: 'targetSickDayId',
		BOHBLabelId: 'BOHBLabelId',
		BOHBFieldId: 'BOHBFieldId',
		
		OK: 'OK',
		WARN: 'WARN',
		ERROR: 'ERROR',
		HYPOCRIT: 'HYPOCRIT',
		HYPO: 'HYPO',
		
		snacks:'snacks',
		lunch:'lunch',
		dinner:'dinner',
		breakfast:'breakfast',
		bedtime:'bedtime',
		meals:'meals',
		nightmeal:'nightmeal',
		sickday: 'sickday',
		
		RIGHT_ARROW_IMG:'img/green_arrow_32.gif',
		YELLOW_CAUTION_IMG:'img/yellow_caution_32.gif',
		GREEN_CHECK_IMG:'img/green_check_32.gif',
		YELLOW_CHECK_IMG:'img/yellow_check_32.gif',
		GREY_CHECK_IMG:'img/grey_check_32.gif',
		RED_X_IMG:'img/red_x_32.gif',
		CRITHYPO_IMG:'img/BG_Crit_32.png',
		HYPO_IMG:'img/BG_Low_32.png'
			

	};
}();

Child.GlobalDomIds.getChildPanelID = function(globalID){
	return globalID + '_child';
};
/**
 * @author rpeltz
 */
/*
 * Global variable to help with debug and deployment
 */


var jsonInfo; // holds on to basic patient info
//var App = new Ext.App({}); // used for alerts and status

Ext.ns('Child');
Child.version = '1.0';

Child.Framework = function() {
	
};

Child.Framework.ORDERID = '';
Child.Framework.USERID = 'testUser';

Child.Framework.VERSION = '2.0';

Child.Framework.APP_FOLDER = 'InsulinCalc_v4';

Child.Framework.WEB_ASSET_FILE_LOCATION = function() {
	var location = '';


			location = '../../common/new/';

	return location;


}();

Child.Framework.ENV_IS_TEST = function() {
	return (DOMAIN_NAME.toLowerCase().indexOf('test') > -1);
}();

Child.Framework.HTML_HELP_FILE_LOCATION = Child.Framework.WEB_ASSET_FILE_LOCATION + 'help/';

Child.Framework.HELP_SUMMARY = Child.Framework.WEB_ASSET_FILE_LOCATION + 'help/InsulinCalcHelp.pdf';

Child.Framework.HELP_FILE_LOCATION = Child.Framework.WEB_ASSET_FILE_LOCATION + 'help/';

Ext.BLANK_IMAGE_URL = Child.Framework.WEB_ASSET_FILE_LOCATION + 'img/s.gif';

Child.Framework.queryString = function(key) {
    //example of getting a location from the URL  
    key = key.replace(/[*+?^$.\[\]{}()|\\\/]/g, "\\$&"); // escape RegEx meta chars
    var match = location.search.match(new RegExp("[?&]"+key+"=([^&]+)(&|$)"));
    return match && decodeURIComponent(match[1].replace(/\+/g, " "));

};

Child.Framework.renderCaclculator = function() {
	//alert("renderCaclculator");
	if (!Child.CardLayouts.CardOneRendered ) {
		var InpatientCardOneLayout = Child.CardLayouts.GetCardOneLayoutPanel();
		Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL).add(InpatientCardOneLayout);
		Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL).getLayout()
				.setActiveItem(Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT);
	} else {
		Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL).getLayout()
				.setActiveItem(Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT);
	}

};

Child.Framework.calculatorInit = function(renderParams) {

	Child.NavigationPanelFactory.UpdateMainNavToolBar({
		type : 'calculator'
	});

	Child.NavigationPanelFactory.currentLocation = Child.NavigationPanelFactory.LOCATIONS.CARD_ONE;
	
	Child.Framework.renderCaclculator();

	// set up logging
	if (jQuery.hotkeys) {
		$(document).bind('keydown', 'Ctrl+/', function(evt) {
			if (jsonInfo['INSULIN_CALC']['USER_DEVELOPER'] === 'YES') {
				Child.Logger.HotKeyHandler();
			}
		});
	}

	renderParams = null; // make available for gc
};


Ext.onReady(function() {

	var screenHeight = window.screen.availHeight;
	var heightOfCard = $(window).height();
	var widthOfCard = $(window).width();
		
	if(screenHeight < heightOfCard) {
//		alert('resize to ' + screenHeight + '  ' + 800);
		window.resizeTo(780, (screenHeight - 20));
	}

	Ext.QuickTips.init();
	Ext.apply(Ext.QuickTips.getQuickTip(), {
			dismissDelay : 0,
			hideDelay : 200 
	});
	Ext.state.Manager.setProvider(new Ext.state.CookieProvider());
	var HELP_FILE_LOCATION = Child.Framework.WEB_ASSET_FILE_LOCATION + 'Help_Summary.pdf';

	var ordid = Child.Framework.queryString('ordid');
	if (ordid !== undefined) {
		Child.Framework.ORDERID = ordid;
	}

	var userid = Child.Framework.queryString('userid');
	if (userid !== undefined && userid !== null) {
		Child.Framework.USERID = userid;
	}
	//alert("encid: " + encid);
 
    //alert("onReady");
	window.port = new Ext.Viewport({
		id : 'port',
		layout : 'fit',
		items : [{
			id : Child.GlobalDomIds.MAIN_PANEL,
			xtype : 'panel',
			layout : 'card',
			activeItem : 0,
			border : false,
			layoutOnCardChange : true,
			frame : false,
			items : [{
						id : 'loading-card',
						layout : 'fit',
						html : '<div class="loading-indicator">Loading...</div>'
					}],
			tbar : Child.NavigationPanelFactory.InitMainNavToolBar()
		}]

	});

	Child.Framework.calculatorInit();
// call init
//	Child.DataRequest({
//				cclProgram : '1mp_icalc_init',
//				renderFn : Child.Framework.calculatorInit
//			});

});
/**
 * @author rpeltz
 */
Ext.ns('Child');
Child.AboutPopup =  function () {
	var popup;
	var getIdInfo = '';
	var getIdInfoAlt = '';
	var linkToTestCode = '';
	var imgPath = '';
//	var userId = jsonInfo['PT_SUMMARY_INFO']['USER_ID'];
//	var patientId = jsonInfo['PT_SUMMARY_INFO']['PERSON_ID'];
//	var encounterId = jsonInfo['PT_SUMMARY_INFO']['ENCNTR_ID'];
	var orderIdQuery = 'QueryString OrderId : ' + Child.Framework.ORDERID;
//	var orderIdJSON = 'JSON OrderId : ' + 

	var browserDisplay = 'Browser: ' + navigator.appName + ' '
			+ navigator.userAgent + ' ';
	if (document.all) {
		var version = /MSIE \d+.\d+/;
		browserDisplay += navigator.appVersion.match(version);
	}

	var loc = 'WEB Server DNS: ' + window.location.hostname;

//	var isUserDBA = (jsonInfo['PT_SUMMARY_INFO']['USER_DBA'] == 'YES');
//	var isUserDev = (jsonInfo['PT_SUMMARY_INFO']['USER_DEVELOPER'] == 'YES');
//	if (isUserDBA || isUserDev) {
//		getIdInfo = String
//				.format(
//						'<br />Person Id: {0}<br />Encounter Id: {1}<br />User Id: {2}<br />',
//						patientId, encounterId, userId);
//		getIdInfoAlt = Ext.String.format(
//				'<br />Patient,Encounter,User: {0},{1},{2}<br />', patientId,
//				encounterId, userId);
//		imgPath = Ext.String.format('<br />Web Asset Folder Path: {0}<br />',
//				Child.Framework.WEB_ASSET_FILE_LOCATION);
//	}
//	if (isUserDev) {
//		linkToTestCode = '<br /><a href="javascript:CCLNEWSESSIONWINDOW(%22CCLLINK(\'ccl_readfile\',  \'^MINE^,^1mp_ptsum_test.html^\', 1)%22,\'_blank\',\'height=500,width=800,resizable=yes\',0,0);"> Link to Test</a><br />';
//	}

	if (popup === undefined) {
		popup = new Ext.Window({
			layout : 'fit',
			width : 300,
			height : 400,
			closeAction : 'hide',
			stateful : false,
			plain : true,
			modal : false,
			title : 'Seattle Childrens MPages',
			items : new Ext.Panel({
						id : 'pnlAbout',
						labelWidth : 75,
						frame : false,
						html : '<div style="padding:15px;text-align:left;">vers.'
								+ Child.Framework.VERSION
								+ '<br />Env: '
//								+ jsonInfo['PT_SUMMARY_INFO']['DOMAIN_NAME']
								+ '<br />HTML Env: '
								+ DOMAIN_NAME
								+ '<br />'
								+ loc
								+ '<br />'
								+ getIdInfo
								+ getIdInfoAlt
								+ imgPath
								+ orderIdQuery
								+ linkToTestCode
								+ '<br />'
								+ browserDisplay + '</div>'
					})
		});
	}
	popup.show();
};
Child.CCLValues_Popup = function (uji) {

	var ccl_popup;

	if (ccl_popup === undefined) {
		ccl_popup = new Ext.Window({
			layout : 'fit',
			width : 400,
			height : 450,
			closeAction : 'hide',
			stateful : false,
			plain : true,
			modal : false,
			title : 'Seattle Childrens MPages',
			items : new Ext.Panel({
						id : 'pnlcclValues',
//						labelWidth : 75,
						frame : false,
						html : '<table width="100%" border="1" cellspacing="0px"><tr width="100%"><th class="const-table-header" >LABEL</th><th class="const-table-header" >VALUE</th></tr>'
								+ Ext.String.format('<tr><td>PatientAgeYears : </td><td>{0}</td></tr>', 
									uji.PatientAgeYears)
								+ Ext.String.format('<tr><td>IsU100StandardInsulin</td><td>{0}</td></tr>', 
									uji.IsU100StandardInsulin)
								+ Ext.String.format('<tr><td>DisplayLine</td><td>{0}</td></tr>', 
									uji.DisplayLine)
								+ Ext.String.format('<tr><td>AdminTime</td><td>{0}</td></tr>', 
									uji.AdminTime)
								+ Ext.String.format('<tr><td>CarbInsulinRatio</td><td>{0}</td></tr>', 
									uji.CarbInsulinRatio)
								+ Ext.String.format('<tr><td>CorrectionFactor</td><td>{0}</td></tr>', 
									uji.CorrectionFactor)
								+ Ext.String.format('<tr><td>TargetBloodGlucose</td><td>{0}</td></tr>', 
									uji.TargetBloodGlucose)
								+ Ext.String.format('<tr><td>Increment</td><td>{0}</td></tr>', 
									uji.Increment)
								+ Ext.String.format('<tr><td>GramsOfCarbsEaten</td><td>{0}</td></tr>', 
									uji.GramsOfCarbsEaten)
								+ Ext.String.format('<tr><td>CurrentBloodGlucose</td><td>{0}</td></tr>', 
									uji.CurrentBloodGlucose)
								+ Ext.String.format('<tr><td>IsMoreThan3HoursSinceLastInsulin</td><td>{0}</td></tr>', 
									uji.IsMoreThan3HoursSinceLastInsulin)
								+ '</table>'
					})
		});
	}
	ccl_popup.show();

};

Child.ConstantsPopup =  function () {
//	alert('constants go here');

	var constants_popup;

	if (constants_popup === undefined) {
		constants_popup = new Ext.Window({
			layout : 'fit',
			width : 600,
			height : 450,
			closeAction : 'hide',
			stateful : false,
			plain : true,
			modal : false,
			title : 'Seattle Childrens MPages',
			items : new Ext.Panel({
						id : 'pnlConstants',
//						labelWidth : 75,
						frame : false,
						html : '<table width="100%" border="1" cellspacing="0px"><tr width="100%"><th class="const-table-header" >CONSTANT</th><th class="const-table-header" >VALUE</th><th class="const-table-header" >UNIT</th><th class="const-table-header" >ACTION TAKEN</th></tr>'
								+ Ext.String.format('<tr><td>Carbs Eaten Limit for Calc : </td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value,
									CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.units,
									CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.calculatorAction)
								+ Ext.String.format('<tr><td>Carbs Eaten Min</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CarbsEatenMin.value,
									CHILD.InsulinCalcConstants.CarbsEatenMin.units,
									CHILD.InsulinCalcConstants.CarbsEatenMin.calculatorAction)
								+ Ext.String.format('<tr><td>Carbs Eaten Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CarbsEatenMax.value,
									CHILD.InsulinCalcConstants.CarbsEatenMax.units,
									CHILD.InsulinCalcConstants.CarbsEatenMax.calculatorAction)
								+ Ext.String.format('<tr><td>Carbs Eaten Min - DILUTE</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CarbsEatenDiluteMin.value,
									CHILD.InsulinCalcConstants.CarbsEatenDiluteMin.units,
									CHILD.InsulinCalcConstants.CarbsEatenDiluteMin.calculatorAction)
								+ Ext.String.format('<tr><td>Carbs Eaten Max - DILUTE</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CarbsEatenDiluteMax.value,
									CHILD.InsulinCalcConstants.CarbsEatenDiluteMax.units,
									CHILD.InsulinCalcConstants.CarbsEatenDiluteMax.calculatorAction)
								+ Ext.String.format('<tr><td>Blood Glucose Limit for calc</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.BGLimtForCalc.value,
									CHILD.InsulinCalcConstants.BGLimtForCalc.units,
									CHILD.InsulinCalcConstants.BGLimtForCalc.calculatorAction)
//								+ Ext.String.format('<tr><td>Blood Glucose Hyper Threshold Bedtime Correction</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
//									CHILD.InsulinCalcConstants.BGHyperThresholdBedtimeCorrection.value,
//									CHILD.InsulinCalcConstants.BGHyperThresholdBedtimeCorrection.units,
//									CHILD.InsulinCalcConstants.BGHyperThresholdBedtimeCorrection.calculatorAction)
								+ Ext.String.format('<tr><td>Blood Glucose Min</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.BGMinimum.value,
									CHILD.InsulinCalcConstants.BGMinimum.units,
									CHILD.InsulinCalcConstants.BGMinimum.calculatorAction)
								+ Ext.String.format('<tr><td>Blood Glucose Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.BGMaximum.value,
									CHILD.InsulinCalcConstants.BGMaximum.units,
									CHILD.InsulinCalcConstants.BGMaximum.calculatorAction)
								+ Ext.String.format('<tr><td>Blood Glucose Critical Hypo Threshold</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.BGCriticalHypoThreshold.value,
									CHILD.InsulinCalcConstants.BGCriticalHypoThreshold.units,
									CHILD.InsulinCalcConstants.BGCriticalHypoThreshold.calculatorAction)
								+ Ext.String.format('<tr><td>Blood Glucose Hypo Threshold</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.BGHypoThreshold.value,
									CHILD.InsulinCalcConstants.BGHypoThreshold.units,
									CHILD.InsulinCalcConstants.BGHypoThreshold.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMax.value,
									CHILD.InsulinCalcConstants.TargetBGMax.units,
									CHILD.InsulinCalcConstants.TargetBGMax.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Min</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMin.value,
									CHILD.InsulinCalcConstants.TargetBGMin.units,
									CHILD.InsulinCalcConstants.TargetBGMin.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Max < 5 yo</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo.value,
									CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo.units,
									CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Min < 5 yo</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMinLessThan5yo.value,
									CHILD.InsulinCalcConstants.TargetBGMinLessThan5yo.units,
									CHILD.InsulinCalcConstants.TargetBGMinLessThan5yo.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Max 5-12 yo</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMax5to12yo.value,
									CHILD.InsulinCalcConstants.TargetBGMax5to12yo.units,
									CHILD.InsulinCalcConstants.TargetBGMax5to12yo.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Min 5-12 yo</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMin5to12yo.value,
									CHILD.InsulinCalcConstants.TargetBGMin5to12yo.units,
									CHILD.InsulinCalcConstants.TargetBGMin5to12yo.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Max >= 12 yo</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo.value,
									CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo.units,
									CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Min >= 12 yo</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMinGreaterThan12yo.value,
									CHILD.InsulinCalcConstants.TargetBGMinGreaterThan12yo.units,
									CHILD.InsulinCalcConstants.TargetBGMinGreaterThan12yo.calculatorAction)
								+ Ext.String.format('<tr><td>Insulin Carb Ratio Min</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.InsulinCarbRatioMin.value,
									CHILD.InsulinCalcConstants.InsulinCarbRatioMin.units,
									CHILD.InsulinCalcConstants.InsulinCarbRatioMin.calculatorAction)
								+ Ext.String.format('<tr><td>Insulin Carb Ration Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.InsulinCarbRatioMax.value,
									CHILD.InsulinCalcConstants.InsulinCarbRatioMax.units,
									CHILD.InsulinCalcConstants.InsulinCarbRatioMax.calculatorAction)
								+ Ext.String.format('<tr><td>Correction Factor Min</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CorrectionFactorMin.value,
									CHILD.InsulinCalcConstants.CorrectionFactorMin.units,
									CHILD.InsulinCalcConstants.CorrectionFactorMin.calculatorAction)
								+ Ext.String.format('<tr><td>Correction Factor Warning Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CorrectionFactorWarnMax.value,
									CHILD.InsulinCalcConstants.CorrectionFactorWarnMax.units,
									CHILD.InsulinCalcConstants.CorrectionFactorWarnMax.calculatorAction)
								+ Ext.String.format('<tr><td>Correction Factor Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CorrectionFactorMax.value,
									CHILD.InsulinCalcConstants.CorrectionFactorMax.units,
									CHILD.InsulinCalcConstants.CorrectionFactorMax.calculatorAction)
								+ Ext.String.format('<tr><td>U10 Dilute Correction Factor Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax.value,
									CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax.units,
									CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax.calculatorAction)
								+ Ext.String.format('<tr><td>U10 Dilute Correction Factor Min</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin.value,
									CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin.units,
									CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin.calculatorAction)
								+ '</table>'
					})
		});
	}
	constants_popup.show();
	
};