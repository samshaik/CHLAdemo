/**
 * @author rpeltz
 */

Ext.ns('Child');
Child.version = '2.0';
Child.Logger = function(msg, type) {

};
Child.Logger.HotKeyHandler = function() {
	if (Child.Logger.ShouldLog === true) {
		// turn it off
		Child.Logger.ShouldLog = false;
		if (Child.Logger.WinHandle) {
			Child.Logger.WinHandle.close();
			Child.Logger.WinHandle = null;
		}
	} else {
		Child.Logger.ShouldLog = true;
		Child.Logger.Log("Logging intiated at " + new Date());
	}
};
Child.Logger.OpenLog = function() {
	if (!Child.Logger.WinHandle) {
		Child.Logger.WinHandle = window
				.open(
						'',
						'Logger',
						'width=400,height=300,resizable=1,scrollbars=1,location=0,menubar=0,toolbar=0,titlebar=0');
		Child.Logger.WinHandle.document
				.write('<html><body><div id="msg"></div></body></html>');
	}
	
};
Child.Logger.WinHandle = null;

Child.Logger.Log = function(msg, type) {
	
	if (Child.Logger.ShouldLog === true) {
		Child.Logger.OpenLog();
		// Child.Logger.WinHandle.document.write("<div>" + msg + "</div>");
		var msgDiv = Child.Logger.WinHandle.document.getElementById("msg");
		msgDiv.innerHTML = msg;
		// Child.Logger.WinHandle.focus(); no need for focus
	}

};


Child.Logger.ShouldLog = false;

Child.Logger.IsLogWinOpen = function() {
	var returnVal = false;
	if (Child.Logger.WinHandle) {
		returnVal = !Child.Logger.WinHandle.closed;
	}
	return returnVal;
};


