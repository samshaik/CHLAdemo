/**
 * @author rpeltz
 */

Ext.ns('Child');
Child.version = '2.0';
Child.CardLayouts = function() {
};

Child.CardLayouts.buildHtmlHelpFileToolBarBtn = function(filename) {
	if(filename !== '') {
		return {
			xtype : 'button',
			icon : Child.Framework.WEB_ASSET_FILE_LOCATION + 'img/helpIconSmall.gif',
			tooltip : "Click for Help",
			handler : function(theButton, event) {
				// id : 'help',
				// collapsible : true,
				// qtip : "Click for Help",
				// handler : function(event, toolEl, panel) {
//				var win = window.open(Child.Framework.HTML_HELP_FILE_LOCATION + filename, '_blank', 'menubar=no,toolbar=yes,resizable=yes,scrollbars=yes');
				Child.WebServices.applink(100, Child.Framework.HTML_HELP_FILE_LOCATION + filename, null, null, null, null, null, "menubar=no,toolbar=yes,resizable=yes,scrollbars=yes");
			}
		};
	}
	else {
		return '';
	}
};

Child.CardLayouts.buildWindowExpandPanelToolBarBtn = function(configs) {
	return {
		xtype : 'button',
		// id : 'window',
		// qtip : 'toggle panel',
		// collapsible : true,
		icon : Child.Framework.WEB_ASSET_FILE_LOCATION + 'img/glass.png',
		tooltip : "Click to Expand panel",
		handler : function(theButton, event) {
			if (!Ext.getCmp('THE_POPUP_WINDOW')) {
				// Just incase this is NOT a modal window, do not open another
				// one until the previous is closed
				var configOptions = '';
				if (configs) {
					configOptions = configs;
				}

				var heightOfCard = window.port.getSize().height - 20;
				var widthOfCard = window.port.getSize().width - 20;

				var popupHeight = 520; // heightOfCard;
				if (configOptions.height) {
					popupHeight = configOptions.height;
				}

				if (popupHeight > heightOfCard) {
					popupHeight = heightOfCard;
				}

				var popupWidth = 800; // widthOfCard;
				if (configOptions.width) {
					popupWidth = configOptions.width;
				}

				if (popupWidth > widthOfCard) {
					popupWidth = widthOfCard;
				}

				var setMaximizable = true;
				if (configOptions.maximizable === false) {
					setMaximizable = configOptions.maximizable;
				}
				var thePanel = theButton.ownerCt.ownerCt;
				var theContainer = thePanel.ownerCt;
				theContainer.removeAll(false);
				// thePanel.tools.window.hide();
				theButton.hide();

				var thePopUpWindow = new Ext.Window({
					id : 'THE_POPUP_WINDOW',
					layout : 'fit',
					modal : true,
					width : popupWidth,
					height : popupHeight,
					autoHeight : false,
					y : 10,
					resizable : true,
					animateTarget : theContainer.id,
					stateful : false,
					autoScroll : false,
					forceLayout : true,
					closeAction : 'close',
					bbar : new Ext.Toolbar({
								buttonAlign : 'right',
								items : [new Ext.Toolbar.Button({
											tooltip : 'Close',
											overflowText : 'Close',
											text : 'Close',
											handler : function() {
												var tWin = Ext
														.getCmp('THE_POPUP_WINDOW');
												tWin.close();
											}
										})]
							}),
					items : [thePanel],
					maximizable : setMaximizable,
					listeners : {
						beforeclose : function(popupWindow) {
							popupWindow.removeAll(false);
							theContainer.insert(0, thePanel);
							// thePanel.tools.window.show();
							theButton.show();

							theContainer.doLayout();
						}
					}
				});

				thePopUpWindow.show();

			}
		}
	};
};

Child.CardLayouts.buildFrameworkToolBar = function(panelTitle, helpFileName, skipExpandOption, tbId, configs) {
	var expandTool = '';
	if(!skipExpandOption) {
		expandTool = Child.CardLayouts.buildWindowExpandPanelToolBarBtn(configs);
	}
	return {
		cls : 'x-panel-header',
		id : tbId,
		items : [expandTool, 
				{
					xtype : 'tbtext',
					cls : 'panel-header',
					text : panelTitle
				}, {
					xtype : 'tbfill'
				},
				Child.CardLayouts.buildHtmlHelpFileToolBarBtn(helpFileName)]
	};
};

Child.CardLayouts.GetCardOneLayoutPanel = function() {

	var viewportHeight;
	viewportHeight = Ext.getCmp('MAIN_PANEL').body.getHeight() - 10;
	var skipExpandTool = true;	// set to true to skip expand (magnifying glass) tool for all panels
	
	return new Ext.Panel({
		id : Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT,
		hideMode : 'offsets',
		layout : {
			type : 'hbox',
			pack : 'start',
			align : 'stretch'
		},
		height : viewportHeight,
		border : false,
		items : [{
			flex : 1,
			baseCls : 'x-plain',
			layout : 'anchor',
			padding : '0px 0px 0px 0px',
			items : {
				border : false,
				anchor : '100% 100%',
				id : Child.GlobalDomIds.INSULIN_ORDERS_CARD_1,
				border : false,
				layout : {
					type : 'vbox',
					pack : 'start',
					align : 'stretch',
					defaultMargins : {
						top : 0,
						right : 0,
						bottom : 2,
						left : 0
					}
				},
				items : [{
					xtype : 'panel',
					border : false,
					//height : 450, //250,
					flex: 1,
					layout : 'fit',
					items : {
						xtype : 'panel',
						border : false,
						layout : 'fit',
						id : Child.GlobalDomIds.INSULIN_ORDERS_CARD_1_PANEL_1_ID,
//						tbar : Child.CardLayouts.buildFrameworkToolBar(
//								'Insulin Orders', 'dummy.html', skipExpandTool, 'FRAMEWORK_TOOLBAR_' + Child.GlobalDomIds.INSULIN_ORDERS_CARD_1_PANEL_1_ID),
						items : {
							border : false,
		                    listeners: { 
		                    	render: {
		                        	fn: function(){
		                                this.setLoading("Loading...");
		                            }
		                    	}
		                    }
//							html : '<div class="loading-indicator">Loading..</div>'
						}
					}
				}]
			}
		}],
		listeners : {

			afterlayout : function(pnl, layout) {
				Child.LoadData.InpatientCardOne();
			},
			options : {
				single : true
			}
		}

	});
	
};



//set up flags indicating the card are laid out
//init to false, set true when loading indicator rendered
Child.CardLayouts.CardOneRendered = false;

