/**
 * @author rpeltz
 */
Ext.ns('Child');
Child.version = '2.0';
Child.NavigationPanelFactory = function() {
};
Child.NavigationPanelFactory.LOCATIONS = function() {
	return {
		CARD_ONE : 'CARD_ONE',
		ABOUT : 'ABOUT',
		CONSTANTS : 'CONSTANTS',
//		CCLDATA : 'CCLDATA',
		MAIN_HELP : 'MAIN_HELP',
		REFRESH : 'REFRESH'
	};
}();

Child.NavigationPanelFactory.currentLocation = '';
Child.NavigationPanelFactory.navHandler = function(location) {
	// Ext.Msg.alert('Click', 'You clicked on ' + location);

	if (location !== Child.NavigationPanelFactory.LOCATIONS.REFRESH
			&& location !== Child.NavigationPanelFactory.LOCATIONS.ABOUT
			&& location !== Child.NavigationPanelFactory.LOCATIONS.CONSTANTS
//			&& location !== Child.NavigationPanelFactory.LOCATIONS.CCLDATA
			&& location !== Child.NavigationPanelFactory.LOCATIONS.MAIN_HELP) {
		Child.NavigationPanelFactory.currentLocation = location;
		Child.NavigationPanelFactory.SetButtonsInactive('main_nav_toolbar');
		this.removeClass('main-toolbar-button-inactive');
		this.addClass('main-toolbar-button-active');
	}
	switch (location) {
		case Child.NavigationPanelFactory.LOCATIONS.CARD_ONE :
			if (!Child.CardLayouts.CardOneRendered) {
				var InpatientCardOneLayout = Child.CardLayouts
						.GetCardOneLayoutPanel();
				Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL)
						.add(InpatientCardOneLayout);
				Ext
						.getCmp(Child.GlobalDomIds.MAIN_PANEL)
						.getLayout()
						.setActiveItem(Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT);

			} else {
				Ext
						.getCmp(Child.GlobalDomIds.MAIN_PANEL)
						.getLayout()
						.setActiveItem(Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT);
			}
			break;
		case Child.NavigationPanelFactory.LOCATIONS.MAIN_HELP :
			var url = Child.Framework.HELP_SUMMARY;
//			window.open(url, "_blank", "height=800,width=650,left=600,top=0,resizable=yes,scrollbars=yes");
			Child.WebServices.applink(100, url, null, null, null, null, null, "height=800,width=650,left=600,top=0,resizable=yes,scrollbars=yes");
			break;
		case Child.NavigationPanelFactory.LOCATIONS.REFRESH :
			// reset inpatient data
			Child.CardLayouts.CardOneRendered =  false;
		
			switch (Child.NavigationPanelFactory.currentLocation) {
				case Child.NavigationPanelFactory.LOCATIONS.CARD_ONE :
					Child.NavigationPanelFactory.CardOneRefresh();
					Ext
							.getCmp(Child.GlobalDomIds.MAIN_PANEL)
							.getLayout()
							.setActiveItem(Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT);
					break;
					default :
					window.location.reload();
					break;
			}
			break;
		case Child.NavigationPanelFactory.LOCATIONS.ABOUT :
			Child.AboutPopup();
			break;
		case Child.NavigationPanelFactory.LOCATIONS.CONSTANTS:
			Child.ConstantsPopup();
			break;
//		case Child.NavigationPanelFactory.LOCATIONS.CCLDATA:
//			Child.CCLValues_Popup(Child.IcalcPanelFactory.data);
//			break;
		default :
			break;
	}

};


Child.NavigationPanelFactory.SetButtonsInactive = function(tbarId) {
	var toolbarItems = Ext.getCmp(tbarId).items.items;
	for (var i = 0; i < toolbarItems.length; i++) {
		var item = toolbarItems[i];
		item.removeClass('main-toolbar-button-active');
		item.addClass('main-toolbar-button-inactive');
	}

};

Child.NavigationPanelFactory.InitMainNavToolBar = function() {
	var toolbar = new Ext.Toolbar({
				id : 'main_nav_toolbar',
				items : []
			});
	Child.NavigationPanelFactory.UpdateMainNavToolBar();
	return toolbar;
};
Child.NavigationPanelFactory.UpdateMainNavToolBar = function(config) {
	var toolbarArray = [];
	var type = 'calculator'; // default
	var title = 'Insulin Calculator';// default
	var titleLocation = 1;// default inpatient location of title
	toolbarArray = Child.NavigationPanelFactory.GetCalculatorToolBarArray();
	var toolbar = Ext.getCmp('main_nav_toolbar');
	// the listeners below control the centering fo the toolbar title
	// Ext does not provide an easy way to center in a toolbar so
	// we adjust after we know how much room is available
//	toolbar.addListener('afterlayout', function(tb, layout) {
//		var totalWidth = $(".x-toolbar-left").width();
//		var usedWidth = $(".x-toolbar-left-row").width();
//		var availWidth = totalWidth - usedWidth;
//		var theId = this.type + '_main_toolbar_title_id';
//
//		tb.insertButton(this.titleLocation, {
//					text : this.title,
//					id : theId,
//					width : availWidth,
//					xtype : 'tbtext',
//					cls : 'section-header'
//				});
//
//			// alert('winW: ' + $(window).width());
//		}, {
//			type : type,
//			title : title,
//			titleLocation : titleLocation
//		}, {
//			single : true
//			// ,
//			// target : Ext.fly('main_nav_toolbar')
//		});
//	toolbar.addListener('resize', function(tb, layout) {
//				var totalWidth = $(".x-toolbar-left").width();
//				var usedWidth = $(".x-toolbar-left-row").width();
//				var availWidth = totalWidth - usedWidth;
//				var theId = this.type + '_main_toolbar_title_id';
//				// tb.remove(theId);
//				tb.remove(this.type + '_main_toolbar_title_id');
//				tb.insertButton(this.titleLocation, {
//							text : this.title,
//							id : theId,
//							width : availWidth,
//							xtype : 'tbtext',
//							cls : 'section-header'
//						});
//			}, {
//				type : type,
//				title : title,
//				titleLocation : titleLocation
//			});
	if (toolbar) {
		toolbar.removeAll();
		toolbar.add(toolbarArray);
//		toolbar.doLayout();
	}

};

Child.NavigationPanelFactory.GetCalculatorToolBarArray = function() {
	var toolBarArray = [];

/*	var ipcardOneBtn = new Ext.Button({
				text : 'Inpatient Card One',
				cls : 'main-toolbar-button-active'
			});
	ipcardOneBtn
			.on(
					'click',
					Ext
							.createDelegate(
									Child.NavigationPanelFactory.navHandler,
									ipcardOneBtn,
									[Child.NavigationPanelFactory.LOCATIONS.CARD_ONE]));
	toolBarArray.push(ipcardOneBtn);
	toolBarArray.push('-');
*/
	var logoPnl= new Ext.Panel (
	{
		id : 'LOGO_PANEL_ID',
		xtype : 'panel',
		border : false,
		cls : 'logo-icon',
//		cls : 'patient-name'
		html : '<img style="float:left;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + 'img/logo.png"/>'
	}
	);

	toolBarArray.push(logoPnl);
	
	var namePnl = new Ext.Panel(
	{
		id : Child.GlobalDomIds.PATIENT_NAME_ID,
		xtype : 'panel',
		html : '',
		padding : '0px 0px 0px 10px',
		cls : 'patient-name'
	});

	toolBarArray.push(namePnl);

	toolBarArray.push('->');
//	var refreshBtn = new Ext.Button({
//				text : 'Refresh',
//				cls : 'main-toolbar-button-inactive',
//				iconCls : 'refresh-icon'
//			});
//	refreshBtn.on('click', Ext.bind(
//					Child.NavigationPanelFactory.navHandler,
//					refreshBtn,
//					[Child.NavigationPanelFactory.LOCATIONS.REFRESH]));
//	toolBarArray.push(refreshBtn);
//	toolBarArray.push('-');

	var mainHelpMenuItem = new Ext.menu.Item({
				text : 'Help'
			});
	mainHelpMenuItem.on('click', Ext.bind(
					Child.NavigationPanelFactory.navHandler,
					mainHelpMenuItem,
					[Child.NavigationPanelFactory.LOCATIONS.MAIN_HELP]));

	var aboutMenuItem = new Ext.menu.Item({
				text : 'About'
			});
	aboutMenuItem.on('click', Ext.bind(
					Child.NavigationPanelFactory.navHandler,
					aboutMenuItem,
					[Child.NavigationPanelFactory.LOCATIONS.ABOUT]));

	var constantsMenuItem = new Ext.menu.Item({
				text : 'Constants'
			});
	constantsMenuItem.on('click', Ext.bind(
					Child.NavigationPanelFactory.navHandler,
					constantsMenuItem,
					[Child.NavigationPanelFactory.LOCATIONS.CONSTANTS]));

//	var cclDataMenuItem = new Ext.menu.Item({
//				text : 'CCL Data'
//			});
//	cclDataMenuItem.on('click', Ext.bind(
//					Child.NavigationPanelFactory.navHandler,
//					cclDataMenuItem,
//					[Child.NavigationPanelFactory.LOCATIONS.CCLDATA]));

	var helpBtn = new Ext.Button({
				text : 'Help',
				cls : 'main-toolbar-button-inactive',
				iconCls : 'help-icon',
				menu : [mainHelpMenuItem, aboutMenuItem, constantsMenuItem]
			});

	toolBarArray.push(helpBtn);
	return toolBarArray;
};


Child.NavigationPanelFactory.CardOneRefresh = function() {
	Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL)
			.remove(Child.GlobalDomIds.INSULIN_ORDERS_LAYOUT);
	var ptLayout = Child.CardLayouts
			.GetCardOneLayoutPanel();
	Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL).add(ptLayout);
};

