/**
 * @author rpeltz/swood3
 */
Ext.ns('Child');
Child.version = '2.0';
Child.LoadData = function() {
};

Child.LoadData.InpatientCardOne = function() {
	//alert("encounterid1: " + Child.Framework.ORDERID);
	if (!Child.CardLayouts.CardOneRendered) {
	//alert("encounterid2: " + Child.Framework.ORDERID);
		Child.DataRequest({
					cclProgram : '1mp_icalc_data',
					cclParam: '^MINE^,' + Child.Framework.ORDERID,
					renderMan : true,
					renderFn : Child.IcalcPanelFactory.icalcRender
				});
		Child.CardLayouts.CardOneRendered = true;
	}
};
Child.LoadData.InpatientCardTwo = function() {
	if (!Child.CardLayouts.InpatientCardTwoRendered) {
		//load data here
		Child.CardLayouts.InpatientCardTwoRendered = true;
	}
};
Child.LoadData.OutpatientCardOne = function() {
	// check for undefined
	if (!Child.CardLayouts.OutpatientCardOneRendered) {
		// call documents
		Child.DataRequest({
					cclProgram : '1mp_ptsum_documents_amb',
					renderMan : true,
					renderFn : Child.DocumentPanelFactory.docRender
				});
		Child.CardLayouts.OutpatientCardOneRendered = true;

	}
};
Child.LoadData.OutpatientCardTwo = function() {
	if (!Child.CardLayouts.OutpatientCardTwoRendered) {
		//load data here
		Child.CardLayouts.OutpatientCardTwoRendered = true;
	}
};

var beginTime;
var renderCount = 0;
var renderDone = function(renderSrc) {
	renderCount = renderCount + 1;
	if (renderCount === 7) {
		var endTime = new Date();
		// alert(endTime - beginTime);
	}
};

Child.LoadData.LogCcl = function(logData) {

	//remove " from log data
	var scrubLogData = logData.replace(/\"/g, '|');
	scrubLogData = scrubLogData.replace(/\^/g, '|');
	
	Child.DataRequest({
		cclProgram : '1com_write_log',
		ajaxMethod: 'POST',
		cclParam : '^MINE^, 0, ^' + scrubLogData + '^',
		renderFn : Child.LoadData.LogCclRender
	});
};

Child.LoadData.LogCclRender = function(renderParams) {

	var theData = renderParams.data;
	
};

Child.LoadData.Column2_Panel_1_Tab2 = function() {

	if (!Child.CardLayouts.InpatientCardOneColumnTwoPanel1Tab2Rendered) {
		// call documents
		Child.DataRequest({
			cclProgram : '1mp_ptsum_documents_ip',
			renderMan : true,
			renderFn : Child.TabTestPanelFactory.docRender
		});
		Child.CardLayouts.InpatientCardOneColumnTwoPanel1Tab2Rendered = true;
	}

};

Child.LoadData.Column2_Panel_1_Tab3 = function() {
		alert('Call Tab 3 CCL here');

};


