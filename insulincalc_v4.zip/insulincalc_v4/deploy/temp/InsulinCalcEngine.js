Ext.ns("CHILD.InsulinCalcEngine");

function TestMe() {
    CHILD.InsulinCalcEngine.startup();
    alert('done');
}

CHILD.InsulinCalcEngine.startup = function startup() {
    var uji = new CHILD.InsulinCalcEngine.UserAndJsonInputs();
    uji.PatientAgeYears = 5;
    uji.IsU100StandardInsulin = true;
    uji.DisplayLine = "";
    uji.AdminTime = "Breakfast";
    uji.CarbInsulinRatio = 14;
    uji.CorrectionFactor = 17;
    uji.TargetBloodGlucose = 100;
    uji.Increment = 0.5;
    uji.GramsOfCarbsEaten = 200;
    uji.CurrentBloodGlucose = 300;
    uji.IsMoreThan3HoursSinceLastInsulin = false;
    uji.IsSickDay = false;
    uji.SickDayFactor = 1.0;
    // Validate all the uji inputs here first!
    var insulinData = new CHILD.InsulinCalcEngine.InsulinData(uji);
    var ic = insulinData.InsulinToCoverCarbs;
};

CHILD.InsulinCalcEngine.UserAndJsonInputs = (function () {
    function UserAndJsonInputs() { }
    return UserAndJsonInputs;
})();
CHILD.InsulinCalcEngine.IsLikeSnack = function(uji) {

	return uji.AdminTime.toLowerCase() === Child.GlobalDomIds.snacks || uji.AdminTime.toLowerCase() === Child.GlobalDomIds.sickday;
	
};

CHILD.InsulinCalcEngine.InsulinData = (function () {
    function InsulinData(uji) {
    	var idx = 0;
    	// First perform some field edits to set variables at calc limit and set up error msgs to be returned.
    	var errArray = new Array();
		var fatalErr = CHILD.InsulinCalcEngine.scrubInputForErrors(errArray, uji);
    	
		if(!fatalErr) {
			// Insulin To Cover Carbs
	        var ret = uji.GramsOfCarbsEaten / uji.CarbInsulinRatio;
	        this.InsulinToCoverCarbs = uji.IsU100StandardInsulin ? ret : ret * 0.1;
	        // Insulin to Correct BG At Meals
	        ret = ((uji.CurrentBloodGlucose - uji.TargetBloodGlucose) / uji.CorrectionFactor) * uji.SickDayFactor;
	        ret = uji.IsU100StandardInsulin ? ret : ret * 0.1;
	        this.InsulinToCorrectBGatMeals = ret > 0 ? ret : 0;
	        // Insulin to Deliver At Meals
	        this.InsulinToDeliveratMeals = this.InsulinToCoverCarbs + this.InsulinToCorrectBGatMeals;
	        
	        // Insulin To Correct at Bedtime is now treated same as daytime, 20151116swood3 stop halving bedtime dose
	        // stop checking for BG hyperglycemic
        	this.InsulinToCorrectAtBedtime = this.InsulinToCorrectBGatMeals;
       	    this.InsulinToDeliverBedtime = this.InsulinToCoverCarbs + this.InsulinToCorrectAtBedtime;
	        
	        // Max Target For Age
	        if (uji.PatientAgeYears < 5) {
	            this.MaxTargetBGForAge = CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo.value;
	        } else if (uji.PatientAgeYears >= 12) {
	            this.MaxTargetBGForAge = CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo.value;
	        } else {
	            this.MaxTargetBGForAge = CHILD.InsulinCalcConstants.TargetBGMax5to12yo.value;
	        }
	        // Insulin To Deliver At Snacks
	        // if snack and > 3 hours since rapid and BG above target then add insulin to cover carbs too
	 		if(CHILD.InsulinCalcEngine.IsLikeSnack(uji)) {
	 			if(uji.CurrentBloodGlucose === '') {
	    	        this.InsulinToDeliveratSnacks = this.InsulinToCoverCarbs;
	 			} else {
	 				if(uji.CurrentBloodGlucose <= uji.TargetBloodGlucose) {
		    	        this.InsulinToDeliveratSnacks = this.InsulinToCoverCarbs;
	 				} else {
	 					var numHrs = 3;
	 					var tempMsg = 'Calculated insulin for snack';
	 					if(uji.IsSickDay) {
	 						numHrs = 2;
	 						tempMsg = 'Calculated insulin for sick day';
	 					}
			        	if (uji.IsMoreThan3HoursSinceLastInsulin) {
//			        		if(uji.CurrentBloodGlucose > uji.TargetBloodGlucose) {
			    	        	this.InsulinToDeliveratSnacks = this.InsulinToCoverCarbs + this.InsulinToCorrectBGatMeals;
		    	    	    	idx = errArray.push();
								errArray[idx] = Ext.String.format('It has been more than {2} hours since the last rapid-acting insulin was given and the Current Blood Glucose ({0}) is above the Target Blood Glucose ({1}). {3} <b>WILL INCLUDE</b> insulin to cover Current Blood Glucose.', 
								uji.CurrentBloodGlucose, 
								uji.TargetBloodGlucose,
								numHrs,
								tempMsg);
//			        		}
	        			} else {
		            		this.InsulinToDeliveratSnacks = this.InsulinToCoverCarbs;
		            		idx = errArray.push();
	    	        		errArray[idx] = Ext.String.format('It has not been more than {0} hours since the last rapid-acting insulin was given.  {1} <b>WILL NOT INCLUDE</b> insulin to cover the Current Blood Glucose.  Please see the MAR for more information.',
	    	        		numHrs,
	    	        		tempMsg);
	        			}
 					}
	 			}
 			}
	
	 		//Rounded Insulin To Deliver
	        switch (uji.AdminTime.toLowerCase()) {
	            case "breakfast":
	            case "lunch":
	            case "dinner":
	            case "meals":
	                this.RoundedInsulinToDeliver = CHILD.InsulinCalcEngine.GetRoundedDown(this.InsulinToDeliveratMeals, uji);
	                break;
	            case "snacks":
	            case "sickday":
	                this.RoundedInsulinToDeliver = CHILD.InsulinCalcEngine.GetRoundedDown(this.InsulinToDeliveratSnacks, uji);
	               break;
	            case "bedtime":
	                this.RoundedInsulinToDeliver = CHILD.InsulinCalcEngine.GetRoundedDown(this.InsulinToDeliverBedtime, uji);
	                break;
	            default:
	            	break;
	        }
	
//       		this.roundingStr = Ext.String.format('(Rounded down to the nearest {0} units)', uji.Increment);
	        
	        if(!uji.IsU100StandardInsulin && this.RoundedInsulinToDeliver > 0) {
	         	// dilute warning message
	       		idx = errArray.push();
	       		errArray[idx] = Ext.String.format('Chart {0} units of DILUTE insulin.  On the U100 syringe draw 10 units/mL insulin to the {1} unit mark.', this.RoundedInsulinToDeliver, this.RoundedInsulinToDeliver * 10);
	        }
	        
	        var multiplier = 1;
	        if(!uji.IsU100StandardInsulin) {
	        	// Dilute insulin use 0.1 as multiplier
	        	multiplier = 0.1;
	        }

	        var tmpCarbCover = ((uji.GramsOfCarbsEaten / uji.CarbInsulinRatio) * multiplier).toFixed(2);
	        var tmpBGCover = '';
			if(uji.CurrentBloodGlucose > uji.TargetBloodGlucose) {
	        	tmpBGCover = (uji.SickDayFactor * (((uji.CurrentBloodGlucose - uji.TargetBloodGlucose)/ uji.CorrectionFactor) * multiplier)).toFixed(2);
			} else {
				tmpBGCover = '0';
			}

			if(uji.AdminTime.toLowerCase() === Child.GlobalDomIds.bedtime) { 

				// 20151112 swood3 stop using hyper threshold at bedtime
				if(uji.CurrentBloodGlucose >= uji.TargetBloodGlucose) {
		    	    tmpBGCover = (uji.SickDayFactor * (((uji.CurrentBloodGlucose - uji.TargetBloodGlucose)/ uji.CorrectionFactor) * multiplier)).toFixed(2);
				} else {
					tmpBGCover = '0';
				}
			}
			
			if(uji.IsMoreThan3HoursSinceLastInsulin === false) {
				if(CHILD.InsulinCalcEngine.IsLikeSnack(uji)) {
					tmpBGCover = '0';
				}
			}
        	
        	this.formula = Ext.String.format('Dose to administer = {0} + {1} = {2} = {3}',
        		tmpCarbCover,
        		tmpBGCover,
        		(Number(tmpCarbCover) + Number(tmpBGCover)).toFixed(2),
        		this.RoundedInsulinToDeliver) + Ext.String.format('</br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Rounded down to the nearest {0} units)', uji.Increment);
		}

        // add array of errors to the return object
		this.ErrorArray = errArray;
        
    }
    return InsulinData;
})();

CHILD.InsulinCalcEngine.GetRoundedDown = function (raw, uji){
    var ret = 0;
    switch (uji.Increment) {
        case 1:
            ret = Math.floor(raw);
            break;
        case 0.5:
            var floor = Math.floor(raw);
            ret = raw >= (floor + 0.5) ? floor + 0.5 : floor;
            break;
        case 0.1:
            raw = raw * 10;
            ret = Math.floor(raw) / 10;
            break;
        default:
        	break;
    }
    return ret;
};

CHILD.InsulinCalcEngine.scrubInputForOrderEntryErrors = function(errArray, uji) {

	var idx = 0;
	var fatalErr = false;
	var tmpAdminTime = uji.AdminTime.toLowerCase();

	if(tmpAdminTime !== 'breakfast' &&
		tmpAdminTime !== 'lunch' &&
		tmpAdminTime !== 'dinner' &&
		tmpAdminTime !== 'meals' &&
		tmpAdminTime !== 'snacks' &&
		tmpAdminTime !== 'sickday' &&
		tmpAdminTime !== 'bedtime') {
		errArray.push();
		errArray[idx] = Ext.String.format('ORDER ERROR: Unexpected Admin Time <b>({0})</b> from the order', uji.AdminTime);
		idx++;
		fatalErr = true;
	}
	
	if(uji.Increment !== 0.5 && uji.Increment !== 0.1 && uji.Increment !== 1) {
		errArray.push();
		errArray[idx] = Ext.String.format('ORDER ERROR: Increment not = 0.1, 0.5 or 1.0');
		idx++;
		fatalErr = true;
	}
	
	return fatalErr;

};

CHILD.InsulinCalcEngine.scrubInputForErrors = function(errArray, uji) {

	var fatalErr = false;
	var idx = 0;
	var tmpAdminTime = uji.AdminTime.toLowerCase();
	
	if(!CHILD.InsulinCalcEngine.scrubInputForOrderEntryErrors(errArray, uji)) {
		//not any fatal order entry errors - continue with other edits
		if(uji.GramsOfCarbsEaten > CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value) {
			uji.GramsOfCarbsEaten = CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value;
			errArray.push();
			errArray[idx] = Ext.String.format('The calculated dose only covers {0} grams of carbohydrates; Call MD for additional recommendations.', CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value);
			idx++;
		}
		
		if (uji.CurrentBloodGlucose > CHILD.InsulinCalcConstants.BGLimtForCalc.value) {
			uji.CurrentBloodGlucose = CHILD.InsulinCalcConstants.BGLimtForCalc.value;
			if(!((CHILD.InsulinCalcEngine.IsLikeSnack(uji)) && !uji.IsMoreThan3HoursSinceLastInsulin)) {
				errArray.push();
				errArray[idx] = Ext.String.format('The Calculated Dose only covers hyperglycemia up to {0} mg/dL;  Call MD for additional recommendations.', CHILD.InsulinCalcConstants.BGLimtForCalc.value);
				idx++;
			}
		}
		
		if(	!((CHILD.InsulinCalcEngine.IsLikeSnack(uji)) && uji.CurrentBloodGlucose === "") ) {
			if(uji.CurrentBloodGlucose < CHILD.InsulinCalcConstants.BGCriticalHypoThreshold.value) {
				errArray.push();
				if(uji.PatientAgeYears <= 5) {
					errArray[idx] = Ext.String.format('The patient is CRITICALLY HYPOGLYCEMIC. Administer 10 grams of simple carbohydrates, and CALL MD.  Check blood sugar in 15 minutes.');
				} else {
					errArray[idx] = Ext.String.format('The patient is CRITICALLY HYPOGLYCEMIC. Administer 15 grams of simple carbohydrates, and CALL MD.  Check blood sugar in 15 minutes.');
				}
				idx++;
				fatalErr = true;
			} else {
				if(uji.CurrentBloodGlucose <CHILD.InsulinCalcConstants.BGHypoThreshold.value) {
					errArray.push();
					if(uji.PatientAgeYears <= 5) {
						errArray[idx] = Ext.String.format('The patient is HYPOGLYCEMIC. Administer 10 grams of simple carbohydrates, and recheck blood sugar in 15 minutes.');
					} else {
						errArray[idx] = Ext.String.format('The patient is HYPOGLYCEMIC. Administer 15 grams of simple carbohydrates, and recheck blood sugar in 15 minutes.');
					}
					idx++;
					fatalErr = true;
				}
			}
		}
		
		if(uji.TargetBloodGlucose > CHILD.InsulinCalcConstants.TargetBGMax.value ||
			uji.TargetBloodGlucose < CHILD.InsulinCalcConstants.TargetBGMin.value) {
			errArray.push();
			errArray[idx] = Ext.String.format('ERROR: Target Blood Glucose is outside the allowable range of ({0} - {1}).', CHILD.InsulinCalcConstants.TargetBGMin.value, CHILD.InsulinCalcConstants.TargetBGMax.value);
			idx++;
			fatalErr = true;
		}
	}
	
	return fatalErr;

};
 
CHILD.InsulinCalcEngine.editCarbsEaten = function(uji) {

	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;	//OK WARN ERROR
	theReturnObj.msg = '';
	theReturnObj.formula = '';
    var multiplier = 1;
	if(!uji.IsU100StandardInsulin) {
		// Dilute insulin use 0.1 as multiplier
	    multiplier = 0.1;
	}
	if(uji.IsU100StandardInsulin) {
		if(uji.GramsOfCarbsEaten === '') {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Carbs Eaten is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.CarbsEatenMin.value, CHILD.InsulinCalcConstants.CarbsEatenMax.value);
		} else {
			if (uji.GramsOfCarbsEaten < CHILD.InsulinCalcConstants.CarbsEatenMin.value ||
				uji.GramsOfCarbsEaten > CHILD.InsulinCalcConstants.CarbsEatenMax.value) {
				theReturnObj.status = Child.GlobalDomIds.ERROR;
				theReturnObj.msg = Ext.String.format('Carbs Eaten is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.CarbsEatenMin.value, CHILD.InsulinCalcConstants.CarbsEatenMax.value);
			} else if(uji.GramsOfCarbsEaten <= CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value) {
				theReturnObj.status = Child.GlobalDomIds.OK;
				theReturnObj.formula = Ext.String.format('Carbohydrate coverage = {0} / {1} = {2} units', uji.GramsOfCarbsEaten, uji.CarbInsulinRatio, ((uji.GramsOfCarbsEaten / uji.CarbInsulinRatio) * multiplier).toFixed(2));
			} else {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Carbs entered are OVER calculator limit. {0} gms will be used', CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value);
				theReturnObj.formula = Ext.String.format('Carbohydrate coverage = {0} / {1} = {2} units', CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value, uji.CarbInsulinRatio, ((CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value / uji.CarbInsulinRatio) * multiplier).toFixed(2));
			}
		}
	} else {
		if(uji.GramsOfCarbsEaten === '') {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Carbs Eaten is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.CarbsEatenDiluteMin.value, CHILD.InsulinCalcConstants.CarbsEatenDiluteMax.value);
		} else {
			//Dilute edits
			if (uji.GramsOfCarbsEaten < CHILD.InsulinCalcConstants.CarbsEatenDiluteMin.value ||
				uji.GramsOfCarbsEaten > CHILD.InsulinCalcConstants.CarbsEatenDiluteMax.value) {
				theReturnObj.status = Child.GlobalDomIds.ERROR;
				theReturnObj.msg = Ext.String.format('Carbs Eaten is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.CarbsEatenDiluteMin.value, CHILD.InsulinCalcConstants.CarbsEatenDiluteMax.value);
			} else if(uji.GramsOfCarbsEaten <= CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value) {
				theReturnObj.status = Child.GlobalDomIds.OK;
				theReturnObj.formula = Ext.String.format('Carbohydrate coverage = {0} / {1} = {2} units', uji.GramsOfCarbsEaten, uji.CarbInsulinRatio, ((uji.GramsOfCarbsEaten / uji.CarbInsulinRatio) * multiplier).toFixed(2));
			} else {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Carbs entered are OVER calculator limit. {0} gms will be used', CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value);
				theReturnObj.formula = Ext.String.format('Carbohydrate coverage = {0} / {1} = {2} units', CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value, uji.CarbInsulinRatio, ((CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value / uji.CarbInsulinRatio) * multiplier).toFixed(2));
			}
		}
	}
	
	return theReturnObj;

};

CHILD.InsulinCalcEngine.editBGForCalc = function(uji) {

	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;	//OK WARN ERROR HYPOCRIT HYPO
	theReturnObj.msg = '';
	theReturnObj.formula = '';
    var multiplier = 1;
	if(!uji.IsU100StandardInsulin) {
		// Dilute insulin use 0.1 as multiplier
	    multiplier = 0.1;
	}

	if(	uji.AdminTime.toLowerCase() === Child.GlobalDomIds.snacks &&
		uji.IsSickDay === false &&
		uji.CurrentBloodGlucose === "" ) {
			theReturnObj.status = Child.GlobalDomIds.OK;
			theReturnObj.formula = Ext.String.format('Blood Glucose for Calculation not taken');
	} else {
		if(uji.CurrentBloodGlucose > 0 && uji.CurrentBloodGlucose < CHILD.InsulinCalcConstants.BGCriticalHypoThreshold.value) {
			theReturnObj.status = Child.GlobalDomIds.HYPOCRIT;
			if(uji.PatientAgeYears <= 5) {
				theReturnObj.formula = 'The patient is CRITICALLY HYPOGLYCEMIC. Administer 10 grams of simple';
			} else {
				theReturnObj.formula = 'The patient is CRITICALLY HYPOGLYCEMIC. Administer 15 grams of simple';
			}
			theReturnObj.msg = Ext.String.format('carbohydrates, and CALL MD.  Check blood sugar in 15 minutes');
		} else {
			if(uji.CurrentBloodGlucose > 0 && uji.CurrentBloodGlucose <CHILD.InsulinCalcConstants.BGHypoThreshold.value) {
				theReturnObj.status = Child.GlobalDomIds.HYPO;
				if(uji.PatientAgeYears <= 5) {
					theReturnObj.formula = 'The patient is HYPOGLYCEMIC. Administer 10 grams of simple';
				} else {
					theReturnObj.formula = 'The patient is HYPOGLYCEMIC. Administer 15 grams of simple';
				}
				theReturnObj.msg = Ext.String.format('carbohydrates, and recheck blood sugar in 15 minutes');
			} else if(uji.CurrentBloodGlucose > CHILD.InsulinCalcConstants.BGMaximum.value ||
				uji.CurrentBloodGlucose < CHILD.InsulinCalcConstants.BGMinimum.value) {
				theReturnObj.status = Child.GlobalDomIds.ERROR;
				theReturnObj.msg = Ext.String.format('Blood Glucose for Calculation is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.BGMinimum.value, CHILD.InsulinCalcConstants.BGMaximum.value);
			} else if (uji.CurrentBloodGlucose <= CHILD.InsulinCalcConstants.BGLimtForCalc.value) {
				theReturnObj.status = Child.GlobalDomIds.OK;

				if(!uji.IsMoreThan3HoursSinceLastInsulin && (CHILD.InsulinCalcEngine.IsLikeSnack(uji))) {
						theReturnObj.formula = Ext.String.format('Correction for High BG = 0 units');
				} else {
					if(uji.CurrentBloodGlucose > uji.TargetBloodGlucose) {
						if(uji.SickDayFactor === 1) {
							theReturnObj.formula = Ext.String.format('Correction for High BG = ({0} - {1}) / {2} = {3} units', uji.CurrentBloodGlucose, uji.TargetBloodGlucose, uji.CorrectionFactor, (((uji.CurrentBloodGlucose - uji.TargetBloodGlucose) / uji.CorrectionFactor) * multiplier).toFixed(2));
						} else {
							theReturnObj.formula = Ext.String.format('Correction for High BG = {4} * (({0} - {1}) / {2}) = {3} units', uji.CurrentBloodGlucose, uji.TargetBloodGlucose, uji.CorrectionFactor, 
							(uji.SickDayFactor * ((uji.CurrentBloodGlucose - uji.TargetBloodGlucose) / uji.CorrectionFactor) * multiplier).toFixed(2), uji.SickDayFactor);
						}
					} else {
						theReturnObj.formula = Ext.String.format('Correction for High BG = 0 units');
					}
				}
			} else {
				
				// Over calculator BG limit logic
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('BG > Calc limit of {0} - Calculation will use BG of {0}', CHILD.InsulinCalcConstants.BGLimtForCalc.value);
				if(!uji.IsMoreThan3HoursSinceLastInsulin && (CHILD.InsulinCalcEngine.IsLikeSnack(uji))) {
					theReturnObj.formula = Ext.String.format('Correction for High BG = 0 units');
					theReturnObj.msg = '';
					theReturnObj.status = Child.GlobalDomIds.OK;
				}
				else {
					if(uji.SickDayFactor === 1) {
						theReturnObj.formula = Ext.String.format('Correction for High BG = ({0} - {1}) / {2} = {3} units', CHILD.InsulinCalcConstants.BGLimtForCalc.value, uji.TargetBloodGlucose, uji.CorrectionFactor, (((CHILD.InsulinCalcConstants.BGLimtForCalc.value - uji.TargetBloodGlucose) / uji.CorrectionFactor) * multiplier).toFixed(2));
					} else {
						theReturnObj.formula = Ext.String.format('Correction for High BG = {4} * (({0} - {1}) / {2}) = {3} units', 
						CHILD.InsulinCalcConstants.BGLimtForCalc.value, 
						uji.TargetBloodGlucose, 
						uji.CorrectionFactor, 
						(uji.SickDayFactor * ((CHILD.InsulinCalcConstants.BGLimtForCalc.value - uji.TargetBloodGlucose) / uji.CorrectionFactor) * multiplier).toFixed(2),
						uji.SickDayFactor);
					}
				}
			}
		}
	}

//	if(!returnFormula) {
//		if(theReturnObj.status !== Child.GlobalDomIds.ERROR) {
//			theReturnObj.formula = '';
//			theReturnObj.msg = '';
//		}
//	}

	return theReturnObj;

};

CHILD.InsulinCalcEngine.editBOHBForCalc = function(uji) {

	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;		//OK - WARN - ERROR
	theReturnObj.msg = '';
	theReturnObj.formula = '';

	if(uji.SickDayFactor !== 1.0 && uji.SickDayFactor !== 1.5 && uji.SickDayFactor !== 2.0) {
		theReturnObj.status = Child.GlobalDomIds.ERROR;
		theReturnObj.msg = Ext.String.format('Invalid Ketones (Serum or Urine) value selected.');
	} if(uji.IsMoreThan3HoursSinceLastInsulin === false) {
		theReturnObj.status = Child.GlobalDomIds.WARN;
		theReturnObj.formula = Ext.String.format('Sick day factor = {0}', uji.SickDayFactor);
		theReturnObj.msg = Ext.String.format('Rapid-acting insulin given - No Ketones adjustment');
	} else {
		theReturnObj.formula = Ext.String.format('Sick day factor = {0}', uji.SickDayFactor);
//		var returnVal = CHILD.InsulinCalcEngine.editBGForCalc(uji, true);
//		if(returnVal.status !== Child.GlobalDomIds.ERROR) {
//			theReturnObj.formula = returnVal.formula; //Ext.String.format('Correction for Sick Day High BG = {0} * {1} = {2} units', "?", uji.SickDayFactor, "?");
//			theReturnObj.msg = returnVal.msg;
//		}
	}
	
	return theReturnObj;

};

CHILD.InsulinCalcEngine.editCarbRatio = function(uji) {

	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;		//OK - WARN - ERROR
	theReturnObj.msg = '';
	theReturnObj.formula = '';
	var unitVal = 1;
//	if(uji.Increment === 0.1) {
	if(!uji.IsU100StandardInsulin) {
		unitVal = 0.1;
	}

	if(	uji.CarbInsulinRatio === 0) {
		theReturnObj.status = Child.GlobalDomIds.ERROR;
		theReturnObj.msg = Ext.String.format('Insulin/Carb Ratio may not be 0');
	} else if(	uji.CarbInsulinRatio < CHILD.InsulinCalcConstants.InsulinCarbRatioMin.value) {//InsulinCarbRatioDiluteMin
		theReturnObj.status = Child.GlobalDomIds.ERROR;
		theReturnObj.msg = Ext.String.format('Insulin/Carb Ratio is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.InsulinCarbRatioMin.value, CHILD.InsulinCalcConstants.InsulinCarbRatioMax.value);
		theReturnObj.formula = Ext.String.format('{1} unit of insulin covers {0} grams of carbohydrates eaten', uji.CarbInsulinRatio,unitVal);
	} 
	else if (uji.CarbInsulinRatio > CHILD.InsulinCalcConstants.InsulinCarbRatioMax.value) {
		theReturnObj.status = Child.GlobalDomIds.ERROR;
		theReturnObj.msg = Ext.String.format('Insulin/Carb Ratio is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.InsulinCarbRatioMin.value, CHILD.InsulinCalcConstants.InsulinCarbRatioMax.value);
		theReturnObj.formula = Ext.String.format('{1} unit of insulin covers {0} grams of carbohydrates eaten', uji.CarbInsulinRatio,unitVal);
	} else {
		theReturnObj.status = Child.GlobalDomIds.OK;
		theReturnObj.formula = Ext.String.format('{1} unit of insulin covers {0} grams of carbohydrates eaten', uji.CarbInsulinRatio,unitVal);
	}

	return theReturnObj;

};

 CHILD.InsulinCalcEngine.editCorrectionFactor = function(uji) {
 	
	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;		//OK - WARN - ERROR
	theReturnObj.msg = '';
	theReturnObj.formula = '';

	if(uji.IsU100StandardInsulin) {
		if(	uji.CorrectionFactor < CHILD.InsulinCalcConstants.CorrectionFactorMin.value) {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Correction Factor is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.CorrectionFactorMin.value, CHILD.InsulinCalcConstants.CorrectionFactorMax.value);
			theReturnObj.formula = Ext.String.format('1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		} 
		else if (uji.CorrectionFactor > CHILD.InsulinCalcConstants.CorrectionFactorMax.value) {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Correction Factor is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.CorrectionFactorMin.value, CHILD.InsulinCalcConstants.CorrectionFactorMax.value);
			theReturnObj.formula = Ext.String.format('1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		} else if (uji.CorrectionFactor > CHILD.InsulinCalcConstants.CorrectionFactorWarnMax.value) {
			theReturnObj.status = Child.GlobalDomIds.WARN;
			theReturnObj.msg = Ext.String.format('Correction Factor is outside recommended range ({0} - {1})', CHILD.InsulinCalcConstants.CorrectionFactorMin.value, CHILD.InsulinCalcConstants.CorrectionFactorWarnMax.value);
			theReturnObj.formula = Ext.String.format('1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		} else {
			theReturnObj.status = Child.GlobalDomIds.OK;
			theReturnObj.formula = Ext.String.format('1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		}
	} else {
		if(	uji.CorrectionFactor < CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin.value) {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Dilute 10 units/mL Correction Factor is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin.value, CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax.value);
			theReturnObj.formula = Ext.String.format('0.1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		} 
		else if (uji.CorrectionFactor > CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax.value) {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Dilute 10 units/mL Correction Factor is outside acceptable range ({0} - {1})', CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin.value, CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax.value);
			theReturnObj.formula = Ext.String.format('0.1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		} else {
			theReturnObj.status = Child.GlobalDomIds.OK;
			theReturnObj.formula = Ext.String.format('0.1 unit of insulin will decrease blood glucose by {0} mg/dL', uji.CorrectionFactor);
		}
	}


	return theReturnObj;
	
};

CHILD.InsulinCalcEngine.editTargetBG = function(uji) {

	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;		//OK - WARN - ERROR
	theReturnObj.msg = '';

	// Over all min and max that causes error, different for nighttime
	if(uji.AdminTime.toLowerCase() === Child.GlobalDomIds.bedtime) {
		if(	uji.TargetBloodGlucose > CHILD.InsulinCalcConstants.TargetBGMaxNighttime.value ||
			uji.TargetBloodGlucose < CHILD.InsulinCalcConstants.TargetBGMinNighttime.value) {
			theReturnObj.status = Child.GlobalDomIds.ERROR;
			theReturnObj.msg = Ext.String.format('Target BG is ouside acceptable range of ({0} - {1}) for nighttime', 
				CHILD.InsulinCalcConstants.TargetBGMinNighttime.value, CHILD.InsulinCalcConstants.TargetBGMaxNighttime.value);

		}
	} else if(uji.TargetBloodGlucose > CHILD.InsulinCalcConstants.TargetBGMax.value ||
		uji.TargetBloodGlucose < CHILD.InsulinCalcConstants.TargetBGMin.value) {
		theReturnObj.status = Child.GlobalDomIds.ERROR;
		theReturnObj.msg = Ext.String.format('Target BG is ouside acceptable range of ({0} - {1})', CHILD.InsulinCalcConstants.TargetBGMin.value, CHILD.InsulinCalcConstants.TargetBGMax.value);
	} else {			
		// Warning levels vary by age, or nighttime for any age
		if(uji.PatientAgeYears < 5) {
			if(	uji.TargetBloodGlucose > CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo.value) {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Target BG is GREATER THAN acceptable maximum of {0} for age {1}', CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo.value, uji.PatientAgeYears);
			} else if(	uji.TargetBloodGlucose < CHILD.InsulinCalcConstants.TargetBGMinLessThan5yo.value) {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Target BG is LESS THAN acceptable minimum  of {0} for age {1}', CHILD.InsulinCalcConstants.TargetBGMinLessThan5yo.value, uji.PatientAgeYears);
			} else {
				theReturnObj.status = Child.GlobalDomIds.OK;
			}
		} else if(uji.PatientAgeYears >= 12) {
			if(	uji.TargetBloodGlucose > CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo.value) {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Target BG is GREATER THAN acceptable maximum of {0} for age {1}', CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo.value, uji.PatientAgeYears);
			} else if(	uji.TargetBloodGlucose < CHILD.InsulinCalcConstants.TargetBGMinGreaterThan12yo.value) {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Target BG is LESS THAN acceptable minimum  of {0} for age {1}', CHILD.InsulinCalcConstants.TargetBGMinGreaterThan12yo.value, uji.PatientAgeYears);
			} else {
				theReturnObj.status = Child.GlobalDomIds.OK;
			}
		} else {
			if(	uji.TargetBloodGlucose > CHILD.InsulinCalcConstants.TargetBGMax5to12yo.value) {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Target BG is GREATER THAN acceptable maximum of {0} for age {1}', CHILD.InsulinCalcConstants.TargetBGMax5to12yo.value, uji.PatientAgeYears);
			} else if(	uji.TargetBloodGlucose < CHILD.InsulinCalcConstants.TargetBGMin5to12yo.value) {
				theReturnObj.status = Child.GlobalDomIds.WARN;
				theReturnObj.msg = Ext.String.format('Target BG is LESS THAN acceptable minimum  of {0} for age {1}', CHILD.InsulinCalcConstants.TargetBGMin5to12yo.value, uji.PatientAgeYears);
			} else {
				theReturnObj.status = Child.GlobalDomIds.OK;
			}
		}
	}
	
	return theReturnObj;

};
	
CHILD.InsulinCalcEngine.editTargetSickDay = function(uji) {

	var theReturnObj =  new Object();
	theReturnObj.status = Child.GlobalDomIds.OK;		//OK - WARN - ERROR
	theReturnObj.msg = '';
//	theReturnObj.status = Child.GlobalDomIds.WARN;		//OK - WARN - ERROR
//	theReturnObj.msg = 'Contact MD about sick day order if this is not a sick day.';

	if(uji.IsSickDay !== true && uji.IsSickDay !== false) {
		theReturnObj.status = Child.GlobalDomIds.ERROR;
		theReturnObj.msg = Ext.String.format('Sick Day value must be YES or NO');
	}
	
	return theReturnObj;
};

