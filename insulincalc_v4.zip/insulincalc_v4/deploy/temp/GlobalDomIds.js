/**
 * @author rpeltz
 */
Ext.ns('Child');
Child.version = '1.0';
Child.GlobalDomIds = function(){
	return {
		MAIN_PANEL:'MAIN_PANEL',
		
		INSULIN_ORDERS_LAYOUT:'INSULIN_ORDERS_LAYOUT',

		INSULIN_ORDERS_CARD_1:'INSULIN_ORDERS_CARD_1',
		INSULIN_ORDERS_CARD_1_PANEL_1_ID:'INSULIN_ORDERS_CARD_1_PANEL_1_ID',
		INSULIN_ORDERS_ID: 'INSULIN_ORDERS_ID',

		INSULIN_STANDARD_CALC_POPUP_ID: 'INSULIN_STANDARD_CALC_POPUP_ID',
		INSULIN_DILUTE_CALC_POPUP_ID: 'INSULIN_DILUTE_CALC_POPUP_ID',
		INSULIN_STANDARD_CALC_PANEL_ID: 'INSULIN_STANDARD_CALC_PANEL_ID',
		INSULIN_DILUTE_CALC_PANEL_ID: 'INSULIN_DILUTE_CALC_PANEL_ID',
		
		PATIENT_NAME_ID: 'PATIENT_NAME_ID',
		insulinResultFieldId: '_insulinResultFieldId',
		insulinResultLabelId: '_insulinResultLabelId',
		insulinResultErrorDisplayFieldId: '_insulinResultErrorDisplayFieldId',
		carbRatioId: '_carbRatioId',
		correctionFactorId: '_correctionFactorId',
		targetBGId: '_targetBGId',
		carbsEatenFieldId: '_carbsEatenFieldId',
		carbsEatenLabelId: '_carbsEatenLabelId',
		bloodGlucoseFieldId: '_bloodGlucoseFieldId',
		bloodGlucoseLabelId: '_bloodGlucoseLabelId',

		_ISMORETHAN3HOURSSINCELASTINSULIN_LABEL: '_ISMORETHAN3HOURSSINCELASTINSULIN_LABEL',
		_3hrInsulinRBGroup: '_3hrInsulinRBGroup',
		_3hrInsulinYes: '_3hrInsulinYes',
		rb_3HrYesNo: 'rb_3HrYesNo',
		_3hrInsulinNo: '_3hrInsulinNo',
		
//		_BGRISINGANDRAPIDINSULINLABEL: '_BGRISINGANDRAPIDINSULINLABEL',
//		_BG_AND_3hrInsulinRBGroup: '_BG_AND_3hrInsulinRBGroup',
//		_BG_AND_3hrInsulinYes: '_BG_AND_3hrInsulinYes',
//		_rb_BG_AND_3HrYesNo: '_rb_BG_AND_3HrYesNo',
//		_BG_AND_3hrInsulinNo: '_BG_AND_3hrInsulinNo',

		_carbRatioLabelId: '_carbRatioLabelId',
		_correctionFactorLabelId: '_correctionFactorLabelId',
		_targetBGLabelId: '_targetBGLabelId',
		_carbRatioCheckID: '_carbRatioCheckID',
		_correctionFactorCheckID: '_correctionFactorCheckID',
		_targetBGCheckID: '_targetBGCheckID',
		ORDER_INFORMATION_PANEL_ID: 'ORDER_INFORMATION_PANEL_ID',
		ORDER_PARAMETERS_PANEL_ID: 'ORDER_PARAMETERS_PANEL_ID',
		PATIENT_VALUES_PANEL_ID: 'PATIENT_VALUES_PANEL_ID',
		BUTTON_PANEL_ID: 'BUTTON_PANEL_ID',
		CALCULATED_VALUE_PANEL_ID: 'CALCULATED_VALUE_PANEL_ID',
		_CALCULATE_BTN: '_CALCULATE_BTN',
		_insulinResultsUnitFieldId: '_insulinResultsUnitFieldId',
		_OrderParmsLabelId: '_OrderParmsLabelId',
		_targetSickDayLabelId: '_targetSickDayLabelId',
		targetSickDayId: 'targetSickDayId',
		BOHBLabelId: 'BOHBLabelId',
		BOHBFieldId: 'BOHBFieldId',
		
		OK: 'OK',
		WARN: 'WARN',
		ERROR: 'ERROR',
		HYPOCRIT: 'HYPOCRIT',
		HYPO: 'HYPO',
		
		snacks:'snacks',
		lunch:'lunch',
		dinner:'dinner',
		breakfast:'breakfast',
		bedtime:'bedtime',
		meals:'meals',
		nightmeal:'nightmeal',
		sickday: 'sickday',
		
		RIGHT_ARROW_IMG:'img/green_arrow_32.gif',
		YELLOW_CAUTION_IMG:'img/yellow_caution_32.gif',
		GREEN_CHECK_IMG:'img/green_check_32.gif',
		YELLOW_CHECK_IMG:'img/yellow_check_32.gif',
		GREY_CHECK_IMG:'img/grey_check_32.gif',
		RED_X_IMG:'img/red_x_32.gif',
		CRITHYPO_IMG:'img/BG_Crit_32.png',
		HYPO_IMG:'img/BG_Low_32.png'
			

	};
}();

Child.GlobalDomIds.getChildPanelID = function(globalID){
	return globalID + '_child';
};
