/**
 * @author rpeltz/swood3
 */
Ext.ns('Child');
Child.version = '1.0';
Child.IcalcPanelFactory = function() {};
Child.IcalcPanelFactory.data = null;

Child.IcalcPanelFactory.icalcRender = function(renderParams){

    var panelId;
    var containerId;
    
    containerId = Child.GlobalDomIds.INSULIN_ORDERS_CARD_1_PANEL_1_ID;
    panelId = Child.GlobalDomIds.getChildPanelID(containerId);
    Child.IcalcPanelFactory.data = renderParams.data;
    var container = Ext.getCmp(containerId);
    if (renderParams.status == 'fail') {
        renderError([containerId]);
        return;
    }
    
   	// Log the data from the ccl call
    var jsonStr = Ext.JSON.encode(Child.IcalcPanelFactory.data);
    Child.LoadData.LogCcl(jsonStr);
    
    renderParams = null; // make available for gc
	var icalcPanel = '';
	var mealWarnMsg = '';

	if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISSICKDAY.toLowerCase() === 'true' && Child.IcalcPanelFactory.data.INSULIN_CALC.DIFFERENTPRODUCT === "true") {
		if(Child.IcalcPanelFactory.data.INSULIN_CALC.SICKINSULINTYPE === '') {
			mealWarnMsg = '<div class="calc-heading-bold">Sick Day insulin management is in effect.  The Sick day insulin order you selected:</br></br>&nbsp;&nbsp;&nbsp;&nbsp;' 
				+ Child.IcalcPanelFactory.data.INSULIN_CALC.INSULINTYPE 
				+ '</br></br>does NOT match other insulin order(s).</br></br>&nbsp;&nbsp;' 
				+ '</br>Please resolve.</br></br>Press Cancel to select another order.</div>';
		} else {
			mealWarnMsg = '<div class="calc-heading-bold">Sick Day insulin management is in effect.  The insulin you selected:</br></br>&nbsp;&nbsp;&nbsp;&nbsp;' 
				+ Child.IcalcPanelFactory.data.INSULIN_CALC.INSULINTYPE 
				+ '</br></br>is not the same product as the Sick Day insulin.</br></br>&nbsp;&nbsp;' 
				+ Child.IcalcPanelFactory.data.INSULIN_CALC.SICKINSULINTYPE 
				+ '</br></br>Please resolve.</br></br>Press Cancel to select another order.</div>';
		}
	    icalcPanel = Child.IcalcPanelFactory.BuildWarningMsgPanel(panelId, Child.IcalcPanelFactory.data, containerId, mealWarnMsg, true, false);
	} else if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISSICKDAY.toLowerCase() === 'true' && Child.IcalcPanelFactory.data.INSULIN_CALC.SICKINSULINTYPE !== '') {
		mealWarnMsg = '<div class="calc-error-red">STOP.  Do not use this order, patient is on sick day management - use PRN sick day managment order</div>';
	    icalcPanel = Child.IcalcPanelFactory.BuildWarningMsgPanel(panelId, Child.IcalcPanelFactory.data, containerId, mealWarnMsg, true, true);
	} else if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISNIGHTMEAL.toLowerCase() === "true") {
		mealWarnMsg = '<div class="calc-heading-bold">You have selected a meal/snack insulin dose after 2100; a night-time insulin order which is less aggressive in correcting hyperglycemia may be more appropriate.  Please review MAR for alternate orders.</br></br>Press Cancel to select another order.</div>';
	    icalcPanel = Child.IcalcPanelFactory.BuildWarningMsgPanel(panelId, Child.IcalcPanelFactory.data, containerId, mealWarnMsg, false, false);
	} else if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISDAYBED.toLowerCase() === "true") {
		mealWarnMsg = '<div class="calc-heading-bold">You have selected a bedtime/nighttime insulin dose outside the timeframe intended. Please review MAR for alternate orders.</br></br>Press Cancel to select another order.</div>';
	    icalcPanel = Child.IcalcPanelFactory.BuildWarningMsgPanel(panelId, Child.IcalcPanelFactory.data, containerId, mealWarnMsg, false, false);
	} else {
	    icalcPanel = Child.IcalcPanelFactory.BuildPanel(panelId, Child.IcalcPanelFactory.data, containerId);
	}

    container.removeAll();
    container.insert(0, icalcPanel);
//    container.doLayout(false,true);
    
	// for some reason the buttons on the form are always off the bottom of the page
    // unless we do a layout on the card at this point
    var theCard = Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL);
//	theCard.doLayout();
	
};

Child.IcalcPanelFactory.SwapPanels = function(panelId, icalcData, containerId) {

	var icalcPanel = Child.IcalcPanelFactory.BuildPanel(panelId, icalcData, containerId);

    var container = Ext.getCmp(containerId);
    container.removeAll();
    container.insert(0, icalcPanel);
//    container.doLayout(false,true);
    
	// for some reason the buttons on the form are always off the bottom of the page
    // unless we do a layout on the card at this point
    var theCard = Ext.getCmp(Child.GlobalDomIds.MAIN_PANEL);
//	theCard.doLayout();

};

Child.IcalcPanelFactory.CarbRatioVerified = false;
Child.IcalcPanelFactory.CorrectionFactorVerified = false;
Child.IcalcPanelFactory.TargetBGVerified = false;
Child.IcalcPanelFactory.TargetSickDayVerified = false;
Child.IcalcPanelFactory.FatalBGError = false;
Child.IcalcPanelFactory.FatalCarbsError = false;
Child.IcalcPanelFactory.FatalBOHBError	= false;
Child.IcalcPanelFactory.FatalCarbRatioError = false;
Child.IcalcPanelFactory.FatalCorrectionFactorError = false;
Child.IcalcPanelFactory.FatalTargetBGError = false;
Child.IcalcPanelFactory.FatalTargetSickDayError = false;

Child.IcalcPanelFactory.BuildOrderDisplay = function(icalcData, includeSickDayDisplayLine) {
	
    var theOrderIcon = '';
	var theSickDayIcon = '';
    
    switch(icalcData.INSULIN_CALC.ADMINTIME.toLowerCase()) {
		case Child.GlobalDomIds.snacks:
			theOrderIcon = 'img/Snack_64.png';
			break;
		case Child.GlobalDomIds.lunch:
			theOrderIcon = 'img/Lunch_64.png';
			break;
		case Child.GlobalDomIds.dinner:
			theOrderIcon = 'img/Dinner_64.png';
			break;
		case Child.GlobalDomIds.breakfast:
			theOrderIcon = 'img/BF_64.png';
			break;
		case Child.GlobalDomIds.bedtime:
			theOrderIcon = 'img/Bed_64.png';
			break;
		case Child.GlobalDomIds.meals:
			theOrderIcon = 'img/meal_64.png';
			break;
		case Child.GlobalDomIds.sickday:
			theOrderIcon = 'img/sickday_64.png';
			break;
//		case Child.GlobalDomIds.nightmeal:
//			theOrderIcon = 'img/Bedtime_64.png';
//			break;
		default:
			theOrderIcon = 'img/questionMark.gif';
			break;
    }

   	if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISNIGHTMEAL.toLowerCase() === "true") {
   		// if this flag is set, then override the icon to the night meal one
			theOrderIcon = 'img/Bedtime_64.png';
   	}
   	if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISBADFREQUENCY.toLowerCase() === 'true') {
   		// if this flag is set, then override the icon to the blue question mark one
		theOrderIcon = 'img/questionMark_64.png';
   	}
   	if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISDAYBED.toLowerCase() === 'true') {
   		// if this flag is set, then override the icon to the Day Bed Icon one
		theOrderIcon = 'img/dayBed_64.png';
   	}
   	if(Child.IcalcPanelFactory.data.INSULIN_CALC.ISSICKDAY.toLowerCase() === 'true' && 
   	   Child.IcalcPanelFactory.data.INSULIN_CALC.ADMINTIME.toLowerCase() !== 'sickday') {
   		// if there is sickday order and the admintime is not sickday, set the sickday icon
		theSickDayIcon = '<img style="float:left;padding-right:10px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + 'img/sickday_64.png' + '">';
   	}

    var lastAdminStr = '';
	var lastAdminTitleStr = '';
//	if(icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.snacks || icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.sickday) {
		lastAdminStr = icalcData.INSULIN_CALC.LASTADMININFO;
		lastAdminTitleStr = 'Last Rapid-Acting Insulin (per MAR): ';
//	}
	
    var orderDisplay = 
    	'<table width="100%">' +
    		'<tr>' +
    			'<td width="50%">' + 
    				'<span class="calc-heading-blue">Order Display</span>' + 
    			'</td>' + 
    			'<td width="50%">' + 
    				'<span class="calc-last-dose-bold" style="float:right;">' + lastAdminTitleStr + '</span>' + 
    			'</td>' +
    		'</tr>' + 
    		'<tr>' +
    			'<td width="50%">' + 
    				'<span class="calc-heading-grey">' + icalcData.INSULIN_CALC.ADMINTIME + ' - ' + icalcData.INSULIN_CALC.FREQUENCY  + '</span>' + 
    			'</td>' + 
    			'<td width="50%">' + 
    				'<span class="calc-last-dose-bold" style="float:right;">' + lastAdminStr + '</span>' + 
    			'</td>' +
    		'</tr>' + 
    	'</table>' + 
    	'<div class="calc-heading-bold">' + icalcData.INSULIN_CALC.INSULINTYPE + '</div>' +
    	
    	'<div><table width="100%">' +
    		'<tr>' +
    			'<td width="10%">' + 
    				'<span class="calc-body"><img style="float:left;padding-right:10px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theOrderIcon + '"></span>' +
    			'</td>' + 
    			'<td width="90%">'; 
     
    if(includeSickDayDisplayLine && icalcData.INSULIN_CALC.SICKDISPLAYLINE && icalcData.INSULIN_CALC.SICKDISPLAYLINE !== '') {
    	var spaceIcon = '<img class="largeIcon" style="float:left;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + 'img/s.gif' + '">';
    	orderDisplay = orderDisplay + '<span class="calc-heading-bold">Insulin Clicked on MAR:</span></br>' + icalcData.INSULIN_CALC.DISPLAYLINE + '</td></tr>';
	    var tempSickday = '';
	    if(theSickDayIcon !== '') {
	    	tempSickday = theSickDayIcon;
	    }
    	orderDisplay = orderDisplay +  '<tr><td width="10%">' + tempSickday + '</td><td width="90%"><span class="calc-heading-bold">SickDay Insulin:</span></br>' + icalcData.INSULIN_CALC.SICKDISPLAYLINE + '</span></td></tr></table></div>';
    } else {
	    if(theSickDayIcon !== '') {
	    	orderDisplay = orderDisplay + theSickDayIcon;
	    }
    	orderDisplay = orderDisplay + icalcData.INSULIN_CALC.DISPLAYLINE + '</td></tr></table></div>';
    }
    
	return orderDisplay;

};

Child.IcalcPanelFactory.BuildWarningMsgPanel = function(panelId, icalcData, containerId, mealWarnMsg, hardStop, skipOrdersPanel){

	var orderDisplay = '';
	if(!skipOrdersPanel) {
		orderDisplay = Child.IcalcPanelFactory.BuildOrderDisplay(icalcData, hardStop);
	}
	
	var orderDisplayHeight = 130;
	if(icalcData.INSULIN_CALC.SICKDISPLAYLINE && icalcData.INSULIN_CALC.SICKDISPLAYLINE !== '') {
		orderDisplayHeight = 200;
	}

	var theFormPanel = new Ext.form.Panel({
        id: panelId,
        frame: true,
        title: null,
        flex : 1.0,
//        flex : 0.80,
        border : false,
		layout : {
			type : 'vbox'
			,padding : 1
			,pack : 'start'
			,align : 'stretch'
		},
//        defaults: {
//        	anchor: '100%'
//        },
        fieldDefaults: {
    	    defaultType: 'textfield',
	        labelWidth: 10
        },
        items: [

		{
            xtype: 'panel'
            ,border : false
            ,hidden : skipOrdersPanel
            ,height : orderDisplayHeight
 			,layout : 'fit',
            items: [
            {
            	xtype : 'panel',
            	border : false,
       			layout : 'fit',
       			items : {
       				xtype : 'panel',
	            	padding : 5,
    	        	border : false,
        			html: orderDisplay
       			}
            }]
        }, {
        	xtype : 'panel',
        	height : 6,
        	border : false,
        	cls : 'class-spacer-panel'
        }, {
            	xtype : 'panel',
            	border : false,
       			layout : 'fit',
       			items : {
       				xtype : 'panel',
	            	padding : 5,
    	        	border : false,
        			html: mealWarnMsg
       			}
        }, {

        	xtype : 'panel',
        	height : 40,
        	border : false,
	    	layout : {
    			type : 'hbox',
    			pack : 'start',
    			align : 'stretch'
        	},
        	items : [
        	{
        		flex : 1,
				xtype : 'panel',
				border : false,
        		buttonAlign: 'center',
		        buttons: [
		        {
		            text: 'Continue',
		            hidden: hardStop,
		            listeners: {
		                click: {
		        			fn: function() {
		        				Child.IcalcPanelFactory.SwapPanels(panelId, icalcData, containerId);
		        			}
		                }
		            }
		        }, {
		    		xtype : 'panel',
		    		border : false,
		    		width : 150
		   		}, {
		            text: 'Cancel',
		            disabled : false,
		            listeners: {
		                click: {
		                    fn: function(){
		                    	window.close();
		                    }
		                }
		            }
		        }]
			}]
        }]
	});

	return theFormPanel;

};

Child.IcalcPanelFactory.BuildPanel = function(panelId, icalcData, containerId){

	Child.IcalcPanelFactory.CarbRatioVerified = false;
	Child.IcalcPanelFactory.CorrectionFactorVerified = false;
	Child.IcalcPanelFactory.TargetBGVerified = false;
	if(icalcData.INSULIN_CALC.ISSICKDAY === 'true') {
		Child.IcalcPanelFactory.TargetSickDayVerified = false;
	} else {
		Child.IcalcPanelFactory.TargetSickDayVerified = true;
	}
	
//	if(icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.nightmeal) {
//		var r = confirm('You have selected a meal or snack order and it is after 21:00.  You may be giving too much insulin and perhaps should be using the BedTime order.\n\nPress OK to Continue or Cancel to select another order');
//		if(r!==true) {
//			window.close();
//		}
//	}

	if(icalcData.INSULIN_CALC.ISU100STANDARDINSULIN === 'true') {
		Child.Framework.HELP_SUMMARY = Child.Framework.WEB_ASSET_FILE_LOCATION + 'help/InsulinCalcHelp.pdf';
	} else {
		Child.Framework.HELP_SUMMARY = Child.Framework.WEB_ASSET_FILE_LOCATION + 'help/InsulinCalcHelp_Dilute.pdf';
	}
	
	var theNameHtml = '<div class="patient-name-class">' + icalcData.INSULIN_CALC.PATIENTNAME + '</div>' +
		'<div class="MRN-class">MRN:&nbsp;' + icalcData.INSULIN_CALC.MRN + '</div>' + 
		'<div class="age-display-class">AGE:&nbsp;' + icalcData.INSULIN_CALC.PATIENTAGEDISPLAY + '</div>';
		
	var namePnl = Ext.getCmp(Child.GlobalDomIds.PATIENT_NAME_ID);
	namePnl.update(theNameHtml);

	var uji = new CHILD.InsulinCalcEngine.UserAndJsonInputs();
    uji.PatientAgeYears = icalcData.INSULIN_CALC.PATIENTAGEYEARS;
    uji.IsU100StandardInsulin = (icalcData.INSULIN_CALC.ISU100STANDARDINSULIN === 'true');
    uji.DisplayLine = icalcData.INSULIN_CALC.DISPLAYLINE;
    uji.AdminTime = icalcData.INSULIN_CALC.ADMINTIME;
    uji.CarbInsulinRatio = icalcData.INSULIN_CALC.CARBGRAMSPERINSULINUNIT;
    uji.CorrectionFactor = icalcData.INSULIN_CALC.CORRECTIONFACTOR;
    uji.TargetBloodGlucose = icalcData.INSULIN_CALC.TARGETBLOODGLUCOSE;
	uji.Increment = Number(icalcData.INSULIN_CALC.INCREMENT);
	
	var rapidInsulinQuestion = '<span class="calc-heading-bold-large">Rapid-acting insulin in past 3 hrs?</span>';
	
	if(icalcData.INSULIN_CALC.ISSICKDAY === 'true') {
		uji.IsSickDay = true;
    	uji.IsMoreThan3HoursSinceLastInsulin = true;
		rapidInsulinQuestion = '<span class="calc-heading-bold-large">Have you given Rapid-acting insulin in the last 2 hrs?</span>';
	} else {
		uji.IsSickDay = false;
		uji.IsMoreThan3HoursSinceLastInsulin = false;
	}
	uji.SickDayFactor = 1.0; //default value
	
//	if(!uji.IsU100StandardInsulin) {
//		uji.Increment = 0.1;
//	} else if(icalcData.INSULIN_CALC.ISINCREMENTONE === 'true') {
//	    uji.Increment = 1;
//	} else {
//	    uji.Increment = 0.5;
//	}

 
	var DisplayCalculatorErrors = function(insulinData) {
		
        var errCt = insulinData.ErrorArray.length;
		var resultErrs = '';

		if(errCt > 0) {
			resultErrs = '<span><ul>';
			var lineFeed = '';
			for(i=0; i<errCt; i++) {
				resultErrs = resultErrs + lineFeed + '<li><span class="calc-warnings">' + insulinData.ErrorArray[i] + '</span></li>';
			}
			resultErrs = resultErrs + '</ul></span>';
		}
		
		var theErrorField = Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultErrorDisplayFieldId);
		theErrorField.setValue(resultErrs);

	};
    
    var runStdInsulinCalc = function(panelId, uji){
    
	    	var theResultfield = Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultFieldId);
		    // Validate all the uji inputs here first!
		    var insulinData = new CHILD.InsulinCalcEngine.InsulinData(uji);
	    	
	    	var ic = insulinData.RoundedInsulinToDeliver;
	    	var theResultFormula = insulinData.formula;
//			var theLabel = Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultLabelId);
        
        	if(ic !== undefined) {
        		// calculation did NOT return a fatal error
	        	theResultfield.setValue(ic);
    	    	theResultfield.enable();
        	
				if(theResultFormula !== undefined) {
					theResultfield.ownerCt.setFieldLabel(formatInsulinResultLabel(theResultFormula, true));
					theResultfield.ownerCt.enable();
				}
        	} else {
				theResultfield.ownerCt.setFieldLabel(formatInsulinResultLabel('', false));
        	}
				
			DisplayCalculatorErrors(insulinData);
//        	var errCt = insulinData.ErrorArray.length;
//			var resultErrs = '';
//
//			if(errCt > 0) {
//				resultErrs = '<span><ul>';
//				var lineFeed = '';
//				for(i=0; i<errCt; i++) {
//					resultErrs = resultErrs + lineFeed + '<li><span class="calc-warnings">' + insulinData.ErrorArray[i] + '</span></li>';
////					lineFeed = '</br>';
//				}
//				resultErrs = resultErrs + '</ul></span>';
//			}
//			
//			var theErrorField = Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultErrorDisplayFieldId);
//			theErrorField.setValue(resultErrs);

		return uji;
    };
    
//    var theOrderIcon = '';
//    
//    switch(icalcData.INSULIN_CALC.ADMINTIME.toLowerCase()) {
//		case Child.GlobalDomIds.snacks:
//			theOrderIcon = 'img/Snack_64.png';
//			break;
//		case Child.GlobalDomIds.lunch:
//			theOrderIcon = 'img/Lunch_64.png';
//			break;
//		case Child.GlobalDomIds.dinner:
//			theOrderIcon = 'img/Dinner_64.png';
//			break;
//		case Child.GlobalDomIds.breakfast:
//			theOrderIcon = 'img/BF_64.png';
//			break;
//		case Child.GlobalDomIds.bedtime:
//			theOrderIcon = 'img/Bed_64.png';
//			break;
//		case Child.GlobalDomIds.meals:
//			theOrderIcon = 'img/meal_64.png';
//			break;
//		case Child.GlobalDomIds.nightmeal:
//			theOrderIcon = 'img/Bedtime_64.png';
//			break;
//		default:
//			theOrderIcon = '';
//			break;
//    }

	var theCarbRatioCheckIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
	var theCarbRatioErrMsg = '';
	var theCarbRatioFormula = '';
	Child.IcalcPanelFactory.FatalCarbRatioError = false;

	var returnVal = CHILD.InsulinCalcEngine.editCarbRatio(uji);

	switch(returnVal.status) {
		case Child.GlobalDomIds.OK:
			theCarbRatioCheckIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
			theCarbRatioErrMsg = returnVal.msg;
			theCarbRatioFormula = returnVal.formula;
			break;
			
		case Child.GlobalDomIds.ERROR:
			theCarbRatioCheckIcon = Child.GlobalDomIds.RED_X_IMG;
			Child.IcalcPanelFactory.FatalCarbRatioError = true;
			theCarbRatioFormula = returnVal.formula;
			theCarbRatioErrMsg = returnVal.msg;
			break;
			
		case Child.GlobalDomIds.WARN:
			theCarbRatioCheckIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
			theCarbRatioErrMsg = returnVal.msg;
			theCarbRatioFormula = returnVal.formula;
			break;
		default:
			break;
	}

	var theCorrectionFactorErrMsg = '';
	var theCorrectionFactorIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
	var theCorrectionFactorFormula = '';
	Child.IcalcPanelFactory.FatalCorrectionFactorError = false;

	returnVal = CHILD.InsulinCalcEngine.editCorrectionFactor(uji);

	switch(returnVal.status) {
		case Child.GlobalDomIds.OK:
			theCorrectionFactorIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
			theCorrectionFactorErrMsg = returnVal.msg;
			theCorrectionFactorFormula = returnVal.formula;
			break;
			
		case Child.GlobalDomIds.ERROR:
			theCorrectionFactorIcon = Child.GlobalDomIds.RED_X_IMG;
			Child.IcalcPanelFactory.FatalCorrectionFactorError = true;
			theCorrectionFactorFormula = returnVal.formula;
			theCorrectionFactorErrMsg = returnVal.msg;
			break;
			
		case Child.GlobalDomIds.WARN:
			theCorrectionFactorIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
			theCorrectionFactorErrMsg = returnVal.msg;
			theCorrectionFactorFormula = returnVal.formula;
			break;
		default:
			break;
	}

	var theTargetBGCheckIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
	var theTargetBGErrMsg = '';
	Child.IcalcPanelFactory.FatalTargetBGError = false;
	
	returnVal = CHILD.InsulinCalcEngine.editTargetBG(uji);

	switch(returnVal.status) {
		case Child.GlobalDomIds.OK:
			theTargetBGCheckIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
			theTargetBGErrMsg = returnVal.msg;
			break;
			
		case Child.GlobalDomIds.ERROR:
			theTargetBGCheckIcon = Child.GlobalDomIds.RED_X_IMG;
			Child.IcalcPanelFactory.FatalTargetBGError = true;
			theTargetBGErrMsg = returnVal.msg;
			break;
			
		case Child.GlobalDomIds.WARN:
			theTargetBGCheckIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
			theTargetBGErrMsg = returnVal.msg;
			break;
		default:
			break;
	}


	var theTargetSickDayCheckIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
	var theTargetSickDayErrMsg = '';
	Child.IcalcPanelFactory.FatalTargetSickDayError = false;
	
	returnVal = CHILD.InsulinCalcEngine.editTargetSickDay(uji);

	switch(returnVal.status) {
		case Child.GlobalDomIds.OK:
			theTargetSickDayCheckIcon = Child.GlobalDomIds.GREY_CHECK_IMG;
			theTargetSickDayErrMsg = returnVal.msg;
			break;
			
		case Child.GlobalDomIds.ERROR:
			theTargetSickDayCheckIcon = Child.GlobalDomIds.RED_X_IMG;
			Child.IcalcPanelFactory.FatalTargetSickDayError = true;
			theTargetSickDayErrMsg = returnVal.msg;
			break;
			
		case Child.GlobalDomIds.WARN:
			theTargetSickDayCheckIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
			theTargetSickDayErrMsg = returnVal.msg;
			break;
		default:
			break;
	}


	var VerifyFieldProcess = function(panelId, fieldId, labelId) {

		var theField = Ext.getCmp(panelId + fieldId);
		theField.enable();
		
		
		var theLabel = Ext.getCmp(panelId + labelId);

		switch(fieldId) {
			case Child.GlobalDomIds.carbRatioId:
				if(theCarbRatioCheckIcon === Child.GlobalDomIds.GREY_CHECK_IMG) {
					theCarbRatioCheckIcon  = Child.GlobalDomIds.GREEN_CHECK_IMG;
				}
				Child.IcalcPanelFactory.CarbRatioVerified = true;
				break;
			case Child.GlobalDomIds.correctionFactorId:
				if(theCorrectionFactorIcon === Child.GlobalDomIds.GREY_CHECK_IMG) {
					theCorrectionFactorIcon  = Child.GlobalDomIds.GREEN_CHECK_IMG;
				}
				Child.IcalcPanelFactory.CorrectionFactorVerified = true;
				break;
		
			case Child.GlobalDomIds.targetBGId:
				if(theTargetBGCheckIcon === Child.GlobalDomIds.GREY_CHECK_IMG) {
					theTargetBGCheckIcon  = Child.GlobalDomIds.GREEN_CHECK_IMG;
				}
				Child.IcalcPanelFactory.TargetBGVerified = true;
				break;
			case Child.GlobalDomIds.targetSickDayId:
				if(theTargetSickDayCheckIcon === Child.GlobalDomIds.GREY_CHECK_IMG) {
					theTargetSickDayCheckIcon  = Child.GlobalDomIds.GREEN_CHECK_IMG;
				}
				Child.IcalcPanelFactory.TargetSickDayVerified = true;
				break;
			default:
				break;
		}
 
		theLabel.enable();

		var theNewHtml = buildHtmlForLabel(labelId, panelId);
		var theGroupField = theField.ownerCt;
		theGroupField.setFieldLabel(theNewHtml);
//		theLabel.update(theNewHtml);

	};
	
	var CheckForAllVerified = function(panelId) {

		if(	Child.IcalcPanelFactory.CarbRatioVerified &&
			Child.IcalcPanelFactory.CorrectionFactorVerified &&
			Child.IcalcPanelFactory.TargetBGVerified &&
			Child.IcalcPanelFactory.TargetSickDayVerified) {
			// Clear extra verify msg from orders header
			var theOrderHeader = Ext.getCmp(panelId + Child.GlobalDomIds._OrderParmsLabelId);
			theOrderHeader.setValue('<span class="calc-heading-blue">Parameters From Order</span>');
				
			// All are verified, enable the Patient value fields
			var theCarbsField = Ext.getCmp(panelId + Child.GlobalDomIds.carbsEatenFieldId);
			theCarbsField.enable();
			var theCarbsLabel = Ext.getCmp(panelId + Child.GlobalDomIds.carbsEatenLabelId);
			theCarbsLabel.enable();

			var theBGField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
			theBGField.enable();
			var theBGLabel = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseLabelId);
			theBGLabel.enable();
			
			var theBOHBField = Ext.getCmp(panelId + Child.GlobalDomIds.BOHBFieldId);
			theBOHBField.enable();
			var theBOHBLabel = Ext.getCmp(panelId + Child.GlobalDomIds.BOHBLabelId);
			theBOHBLabel.enable();
			
			var the3HourChk = Ext.getCmp(panelId + Child.GlobalDomIds._3hrInsulinRBGroup);
           	the3HourChk.enable();
           	var the3HourChkLabel = Ext.getCmp(panelId + Child.GlobalDomIds._ISMORETHAN3HOURSSINCELASTINSULIN_LABEL);
           	the3HourChkLabel.enable();

//			var theBGRisingChk = Ext.getCmp(panelId + '_BGRisingRBGroup'); //Child.GlobalDomIds._3hrInsulinRBGroup);
//           	theBGRisingChk.enable();
//           	var theBGRisingChkLabel = Ext.getCmp(panelId + '_BGRisingRadio');//Child.GlobalDomIds._ISMORETHAN3HOURSSINCELASTINSULIN_LABEL);
//           	theBGRisingChkLabel.enable();

			
//			var theBG3HourChk = Ext.getCmp(panelId + Child.GlobalDomIds._BG_AND_3hrInsulinRBGroup);
//           	theBG3HourChk.enable();
//           	var theBG3HourChkLabel = Ext.getCmp(panelId + Child.GlobalDomIds._BGRISINGANDRAPIDINSULINLABEL);
//           	theBG3HourChkLabel.enable();

           	theCarbsField.focus(true, 10);
		}

	};
	
	var theLabelHeight = 45;
	var theHeaderLabelHeight = 25;
	var theLabelWidth = 500;
	var theFieldlHeight = 30;
	var theFieldWidth = 65;
	var theRowHeight = 45;
	var theTextLabelWidth = theLabelWidth - 50;

	var formatBGLabel = function(imgStr, errMsg, theCurrentBGFormula, hypglycemic) {
		
		var tempLabel =	'';
		if(hypglycemic) {
			tempLabel = '<table>' +
		     				'<tr>' +
			       				'<td width="' + theTextLabelWidth + 'px">' +
					    			'<span class="calc-heading-bold-large">Blood Glucose for Calculation</span></br>' +
					    			'<span class="calc-error">&nbsp;&nbsp;' + theCurrentBGFormula + '</span></br>' +
									'<span class="calc-error">&nbsp;&nbsp;' + errMsg + '</span>' + 
					       		'</td>' +
					       		'<td>' +
					       			imgStr +
								'</td>' + 
							'</tr>' +
						'</table>';
		} else {
			tempLabel = '<table>' +
		     				'<tr>' +
			       				'<td width="' + theTextLabelWidth + 'px">' +
					    			'<span class="calc-heading-bold-large">Blood Glucose for Calculation</span></br>' +
					    			'<span class="calc-body">&nbsp;&nbsp;' + theCurrentBGFormula + '</span></br>' +
									'<span class="calc-error">&nbsp;&nbsp;' + errMsg + '</span>' + 
					       		'</td>' +
					       		'<td>' +
					       			imgStr +
								'</td>' + 
							'</tr>' +
						'</table>';
		}
			
		return tempLabel;
	
	};

	var formatCarbsEatenLabel = function(imgStr, errMsg, theCarbsEatenFormula) {
		
		var tempLabel =	'<table>' +
							'<tr>' +
				    			'<td width="' + theTextLabelWidth + 'px">' +
									'<span class="calc-heading-bold-large">Carbs Eaten</span></br>' +
									'<span class="calc-body">&nbsp;&nbsp;' + theCarbsEatenFormula + '</span></br>' +
									'<span class="calc-error">&nbsp;&nbsp;' + errMsg + '</span>' + 
								'</td>' +
								'<td>' +
									imgStr +
								'</td>' + 
							'</tr>' +
						'</table>';
	
		return tempLabel;

	};
	
	var formatBOHBLabel = function(imgStr, errMsg, theBOHBFormula) {
		
		var tempLabel =	'<table>' +
							'<tr>' +
				    			'<td width="' + theTextLabelWidth + 'px">' +
									'<span class="calc-heading-bold-large">Ketones (Serum or Urine) for Sick Day Calculation</span></br>' +
									'<span class="calc-body">&nbsp;&nbsp;' + theBOHBFormula + '</span></br>' +
									'<span class="calc-error">&nbsp;&nbsp;' + errMsg + '</span>' + 
								'</td>' +
								'<td>' +
									imgStr +
								'</td>' + 
							'</tr>' +
						'</table>';
	
		return tempLabel;

	};
	
	var formatInsulinResultLabel = function(theResultFormula, dispArrow) {
		
		var arrowImg = '';
		if(dispArrow) {
	    	arrowImg = '<img style="float:right;padding-right:10px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + Child.GlobalDomIds.RIGHT_ARROW_IMG + '">';
	    }
		
		var tempLabel = '<span class="calc-heading-bold-large">' + icalcData.INSULIN_CALC.INSULINTYPE + '</span>' +  arrowImg + '</br>' +
			'<span class="calc-body">&nbsp;&nbsp;&nbsp;&nbsp;' + theResultFormula + '</span>';

		return tempLabel;
		
	};

	var labelBGforCalcInitial = formatBGLabel('&nbsp;', '', '', false);
	var labelCarbsEatenInitial = formatCarbsEatenLabel('&nbsp;', '', '');
	var labelBOHBInitial = formatBOHBLabel('&nbsp;', '', '');

	var buildHtmlForLabel = function(labelId, panelId) {

		var theToolTip = 'data-qtip="Click to verify value"';
		var theErrMsg = '';
		var theHtml = '';
		var tmpTip = '';
		var tip = '';
		var theLabel;
		var theSickDayMsg = '';
		
		if(icalcData.INSULIN_CALC.SICKDISPLAYLINE && icalcData.INSULIN_CALC.SICKDISPLAYLINE !== '') {
			theSickDayMsg = '<span class="calc-error">&nbsp;&nbsp;(From Sick Day Order)</span>';
		}
		
		switch (labelId) {
			case Child.GlobalDomIds._carbRatioLabelId:
				if(theCarbRatioCheckIcon !== Child.GlobalDomIds.GREEN_CHECK_IMG) {
					theLabel = Ext.getCmp(panelId + Child.GlobalDomIds._carbRatioLabelId);
					tip = 'Click to Verify';
					if(theLabel !== undefined) {
						if(!theLabel.disabled) {
							tip = 'Value Verified';
						}
					}
					if(theCarbRatioErrMsg === '') {
						tmpTip = Ext.String.format('{0}', tip);
					} else {
						tmpTip = Ext.String.format('</br>{0}', tip);
					}
					theToolTip = 'data-qtip="' + theCarbRatioErrMsg +  tmpTip + '"';
					theErrMsg = '</br><span class="calc-error">&nbsp;&nbsp;' + theCarbRatioErrMsg + '</span>';
				} else {
					theToolTip = 'data-qtip="Value Verified"';
				}

				theHtml = 	'<table>' +
						      	'<tr>' +
						       		'<td width="' + theTextLabelWidth + 'px">' +
										'<span class="calc-heading-bold-large">Insulin/Carb Ratio</span>' + theSickDayMsg + '</br>' +
										'<span class="calc-body">&nbsp;&nbsp;' + theCarbRatioFormula + '</span>' +
										theErrMsg +
									'</td>' +
								    '<td>' +
								    	'<img ' + theToolTip + ' id="' + panelId + Child.GlobalDomIds._carbRatioCheckID + '" class="clickable-disabled" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theCarbRatioCheckIcon + '">' +
									'</td>' + 
								'</tr>' +
							'</table>';
				break;
				
			case Child.GlobalDomIds._correctionFactorLabelId:
				if(theCorrectionFactorIcon !== Child.GlobalDomIds.GREEN_CHECK_IMG) {
					theLabel = Ext.getCmp(panelId + Child.GlobalDomIds._correctionFactorLabelId);
					tip = 'Click to Verify';
					if(theLabel !== undefined) {
						if(!theLabel.disabled) {
							tip = 'Value Verified';
						}
					}
					if(theCorrectionFactorErrMsg === '') {
						tmpTip = Ext.String.format('{0}', tip);
					} else {
						tmpTip = Ext.String.format('</br>{0}', tip);
					}
					theToolTip = 'data-qtip="' + theCorrectionFactorErrMsg + tmpTip + '"';
					theErrMsg = '</br><span class="calc-error">&nbsp;&nbsp;' + theCorrectionFactorErrMsg + '</span>';
				} else {
					theToolTip = 'data-qtip="Value Verified"';
				}

			    theHtml = 	'<table>' +
				       			'<tr>' +
				       				'<td width="' + theTextLabelWidth + 'px">' +
						       			'<span class="calc-heading-bold-large">Correction Factor</span>' + theSickDayMsg + '</br>' +
						       			'<span class="calc-body">&nbsp;&nbsp;' + theCorrectionFactorFormula + '</span>' +
										theErrMsg +
						       		'</td>' +
						       		'<td>' +
						       			'<img ' + theToolTip + ' id="' + panelId + Child.GlobalDomIds._correctionFactorCheckID + '" class="clickable-disabled" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theCorrectionFactorIcon + '">' +
									'</td>' + 
								'</tr>' +
							'</table>';
				break;
				
			case Child.GlobalDomIds._targetBGLabelId:
				if(theTargetBGCheckIcon !== Child.GlobalDomIds.GREEN_CHECK_IMG) {
					theLabel = Ext.getCmp(panelId + Child.GlobalDomIds._targetBGLabelId);
					tip = 'Click to Verify';
					if(theLabel !== undefined) {
						if(!theLabel.disabled) {
							tip = 'Value Verified';
						}
					}
					if(theTargetBGErrMsg === '') {
						tmpTip = Ext.String.format('{0}', tip);
					} else {
						tmpTip = Ext.String.format('</br>{0}', tip);
					}
					theToolTip = 'data-qtip="' + theTargetBGErrMsg + tmpTip + '"';
					theErrMsg = '</br><span class="calc-error">&nbsp;&nbsp;' + theTargetBGErrMsg + '</span>';
				} else {
					theToolTip = 'data-qtip="Value Verified"';
				}

				theHtml = 	'<table>' +
				       			'<tr>' +
				       				'<td width="' + theTextLabelWidth + 'px">' +
						    			'<span class="calc-heading-bold-large">Target Blood Glucose</span>' + theSickDayMsg + '</br>' +
						    			'<span class="calc-body">&nbsp;&nbsp;Glucose target above which correction must be applied</span>' +
										theErrMsg +
						    		'</td>' +
						    		'<td>' +
						    			'<img ' + theToolTip + ' id="' + panelId + Child.GlobalDomIds._targetBGCheckID + '" class="clickable-disabled" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theTargetBGCheckIcon + '">' +
									'</td>' + 
								'</tr>' +
							'</table>';
				break;
			
			case Child.GlobalDomIds._targetSickDayLabelId:
				if(theTargetSickDayCheckIcon !== Child.GlobalDomIds.GREEN_CHECK_IMG) {
					theLabel = Ext.getCmp(panelId + Child.GlobalDomIds._targetSickDayLabelId);
					tip = 'Click to Verify';
					if(theLabel !== undefined) {
						if(!theLabel.disabled) {
							tip = 'Value Verified';
						}
					}
					if(theTargetSickDayErrMsg === '') {
						tmpTip = Ext.String.format('{0}', tip);
					} else {
						tmpTip = Ext.String.format('</br>{0}', tip);
					}
					theToolTip = 'data-qtip="' + theTargetSickDayErrMsg + tmpTip + '"';
					theErrMsg = '</br><span class="calc-error">&nbsp;&nbsp;' + theTargetSickDayErrMsg + '</span>';
				} else {
					theToolTip = 'data-qtip="Value Verified"';
				}

				theHtml = 	'<table>' +
				       			'<tr>' +
				       				'<td width="' + theTextLabelWidth + 'px">' +
						    			'<span class="calc-heading-bold-large">Sick Day Management?</span></br>' +
						    			'<span class="calc-body">&nbsp;&nbsp;Should insulin be adjusted for serum/urine ketones?</span>' +
										theErrMsg +
						    		'</td>' +
						    		'<td>' +
						    			'<img ' + theToolTip + ' id="' + panelId + Child.GlobalDomIds._targetSickDayCheckID + '" class="clickable-disabled" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theTargetSickDayCheckIcon + '">' +
									'</td>' + 
								'</tr>' +
							'</table>';
				break;
			
			default:
				break;
		}
		
		return theHtml;

	};

	var clearResultInformation = function() {
		
		var theResultfield = Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultFieldId);
		theResultfield.setValue(null);
		
		var theResultLabel = theResultfield.ownerCt;	//Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultLabelId);
		theResultLabel.setFieldLabel(formatInsulinResultLabel('', false));
		
		var theResultErrorsLabel = Ext.getCmp(panelId + Child.GlobalDomIds.insulinResultErrorDisplayFieldId);
		theResultErrorsLabel.setValue('');
	
	};
	
	var orderDisplay = Child.IcalcPanelFactory.BuildOrderDisplay(icalcData, true);

    var notRequiredFieldCls = 'x-form-empty-field';
	if(uji.AdminTime.toLowerCase() === Child.GlobalDomIds.snacks && uji.IsSickDay === false) {
		notRequiredFieldCls = 'not-required-class';
	}

	var CheckForEnableCalcBtn = function() {

		var theCalcBtn = Ext.getCmp(panelId + Child.GlobalDomIds._CALCULATE_BTN);

		if(	!Child.IcalcPanelFactory.FatalBGError &&
			!Child.IcalcPanelFactory.FatalCarbsError &&
			!Child.IcalcPanelFactory.FatalCarbRatioError &&
			!Child.IcalcPanelFactory.FatalCorrectionFactorError &&
			!Child.IcalcPanelFactory.FatalTargetBGError &&
			!Child.IcalcPanelFactory.FatalBOHBError) {

			var theCarbsField = Ext.getCmp(panelId + Child.GlobalDomIds.carbsEatenFieldId);
			var theBGField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
			var theBOHBFactor = Ext.getCmp(panelId + Child.GlobalDomIds.BOHBFieldId);
				
			if(	((theBOHBFactor.getValue() !== null && uji.IsSickDay === true) || (theBOHBFactor.getValue() === null && uji.IsSickDay === false)) && 
				(theCarbsField.getValue() !== null && theCarbsField.getValue() !== '') && 
				((theBGField.getValue() !== null && theCarbsField.getValue() !== '') || (uji.AdminTime.toLowerCase() === Child.GlobalDomIds.snacks && (theBGField.getValue() === null || theCarbsField.getValue() !== '') && uji.IsSickDay === false)) ) {
				theCalcBtn.enable();
//				var theBtnPanel = Ext.getCmp('testpanelhere');
//				theBtnPanel.focus();
//				theBtnPanel.setActive(true);
				theCalcBtn.focus();
				theCalcBtn.setActive(true);
   			}
		} else {
			theCalcBtn.disable();
		}

	};
    	
	var threeHrInsulinRadioGroup = new Ext.form.RadioGroup({
		columns : [50, 50],
		allowBlank : false,
		id : panelId + Child.GlobalDomIds._3hrInsulinRBGroup,
		disabled : true,
		width : 150,
		height : 25,
		stateful : false,
		items : [{
					boxLabel : 'Yes',
					disabled : false,
					id : panelId + Child.GlobalDomIds._3hrInsulinYes,
					name : panelId + Child.GlobalDomIds.rb_3HrYesNo,
					checked : !uji.IsMoreThan3HoursSinceLastInsulin,
					handler : function fn(checkbox, checked) {
						if(checked === true) {
		            		uji.IsMoreThan3HoursSinceLastInsulin = false;
	
		            		var theBGForCalcField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
		            		theBGForCalcField.fireEvent('blur', theBGForCalcField);
			            	var theBOHBField = Ext.getCmp(panelId + Child.GlobalDomIds.BOHBFieldId);
			            	if(theBOHBField.getValue() !== null) {
			            		var theRecords = new Array();
			            		theRecords.push(theBOHBField.store.getAt(theBOHBField.getValue()));
				            	theBOHBField.fireEvent('select', theBOHBField, theRecords, theBOHBField.getValue());
			            	}
						}
					}
				}, {
					boxLabel : 'No',
					id : panelId + Child.GlobalDomIds._3hrInsulinNo,
					name : panelId + Child.GlobalDomIds.rb_3HrYesNo,
					disabled : false,
					checked : uji.IsMoreThan3HoursSinceLastInsulin,
					handler : function fn(checkbox, checked) {
						if(checked === true) {
		            		uji.IsMoreThan3HoursSinceLastInsulin = true;
	
		            		var theBGForCalcField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
		            		theBGForCalcField.fireEvent('blur', theBGForCalcField);
			            	var theBOHBField = Ext.getCmp(panelId + Child.GlobalDomIds.BOHBFieldId);
			            	if(theBOHBField.getValue() !== null) {
			            		var theRecords = new Array();
			            		theRecords.push(theBOHBField.store.getAt(theBOHBField.getValue()));
				            	theBOHBField.fireEvent('select', theBOHBField, theRecords, theBOHBField.getValue());
			            	}
						}
					}
				}]
	});

	var patientValuesHeight = 214;
	if (!(icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.snacks || icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.sickday)) {
		patientValuesHeight = 190;
	}

	var orderDisplayHeight = 130;
	if(icalcData.INSULIN_CALC.SICKDISPLAYLINE && icalcData.INSULIN_CALC.SICKDISPLAYLINE !== '') {
		orderDisplayHeight = 200;
	}

	var orderInformationPanel = new Ext.panel.Panel(
	{
        xtype: 'panel'
        ,border:true
        ,height : orderDisplayHeight
		,layout : 'fit',
        items: [
        {
        	xtype : 'panel',
   			layout : 'fit',
   			border : true,
   			items : {
   				xtype : 'panel',
       			id : Child.GlobalDomIds.ORDER_INFORMATION_PANEL_ID,
            	padding : '0 5 0 5',
	        	border : false,
    			html: orderDisplay
   			}
        }]
   	});
	
	var spacerPanel6 = {
    	xtype : 'panel',
    	height : 6,
    	border : false,
    	cls : 'class-spacer-panel'
	};

	var spacerPanel3 = {
    	xtype : 'panel',
    	height : 3,
    	border : false,
    	cls : 'class-spacer-panel'
	};

	var parametersPanel = new Ext.panel.Panel(
	{
        xtype: 'panel'
        ,border:true
       	,id : Child.GlobalDomIds.ORDER_PARAMETERS_PANEL_ID
        ,height : (theRowHeight * 5) + 10
		,layout : 'fit',
        items: [
        {
        	xtype : 'panel',
        	border : true,
			layout : {
				type : 'vbox'
				,pack : 'start'
				,align : 'stretch'
			},
        	items : [
	        {
	        	xtype : 'fieldcontainer',
	        	border : false,
	           	padding : '0 5 0 5',
	        	hideLabel : true,
	        	height : theHeaderLabelHeight,
	        	items: [
					{
			       		xtype: 'displayfield',
			       		id : panelId + Child.GlobalDomIds._OrderParmsLabelId, 
			        	disabled: false,
			        	height : theHeaderLabelHeight,
			       		width: theLabelWidth + theFieldWidth,
			       		value: '<span class="calc-heading-blue">Parameters From Order</span><span style="float:right;padding-right:30px;" class="calc-verify-heading">Click checkmark below to verify:</span>'
	        		}
	        	]
	        }, {
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
	        	border : false,
            	padding : '0 5 0 5',
	        	id : panelId + Child.GlobalDomIds._carbRatioLabelId,
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		labelSeparator : '',
	       		fieldLabel:	buildHtmlForLabel(Child.GlobalDomIds._carbRatioLabelId, panelId),
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
	        		{
			       		xtype: 'numberfield',
			        	id : panelId + Child.GlobalDomIds.carbRatioId,
			        	readOnly : true,
						width : theFieldWidth,
						height : theFieldlHeight,
			        	disabled: true,
						value: icalcData.INSULIN_CALC.CARBGRAMSPERINSULINUNIT
	        		}
	        	],
		        listeners: {
		            afterrender: {
		    			fn: function() {
		    				if(Ext.fly(panelId + Child.GlobalDomIds._carbRatioCheckID)) {
								Ext.fly(panelId + Child.GlobalDomIds._carbRatioCheckID).on("click", function() {
									VerifyFieldProcess(panelId, Child.GlobalDomIds.carbRatioId, Child.GlobalDomIds._carbRatioLabelId );
									CheckForAllVerified(panelId);
								}, {
									panelId : panelId
								});
		    				}
		                }
		            }
		        }
	        }, {
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
			    id : panelId + Child.GlobalDomIds._correctionFactorLabelId,
	        	border : false,
	            	padding : '0 5 0 5',
			    disabled: true,
			    labelHeight : theLabelHeight,
			    labelWidth: theLabelWidth,
			    fieldLabel:	buildHtmlForLabel(Child.GlobalDomIds._correctionFactorLabelId, panelId),
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
	        		{
			       		xtype: 'numberfield',
			        	id : panelId + Child.GlobalDomIds.correctionFactorId,
			        	readOnly : true,
						width : theFieldWidth,
						height : theFieldlHeight,
			        	disabled: true,
						value: icalcData.INSULIN_CALC.CORRECTIONFACTOR
	        		}
	        	],
		        listeners: {
		            afterrender: {
		    			fn: function() {
		    				if(Ext.fly(panelId + Child.GlobalDomIds._correctionFactorCheckID)) {
								Ext.fly(panelId + Child.GlobalDomIds._correctionFactorCheckID).on("click", function() {
									VerifyFieldProcess(panelId, Child.GlobalDomIds.correctionFactorId, Child.GlobalDomIds._correctionFactorLabelId );
									CheckForAllVerified(panelId);
								}, {
									panelId : panelId
								});
		    				}
		                }
		            }
		        }
	        }, {
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
	        	border : false,
	            	padding : '0 5 0 5',
	        	id : panelId + Child.GlobalDomIds._targetBGLabelId,
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		fieldLabel:	buildHtmlForLabel(Child.GlobalDomIds._targetBGLabelId, panelId),
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
					{
			       		xtype: 'numberfield',
			        	id : panelId + Child.GlobalDomIds.targetBGId,
			        	readOnly : true,
						width : theFieldWidth,
						height : theFieldlHeight,
			        	disabled: true,
						value: icalcData.INSULIN_CALC.TARGETBLOODGLUCOSE
	        		}, {
	        			xtype : 'displayfield',
	        			height : theLabelHeight,
	        			disabled : false,
	        			width : 100,
	        			fieldLabel: ' ',
	        			labelSeparator : '',
	        			labelPad : 0,
	        			value : '</br>' + CHILD.InsulinCalcConstants.BGLimtForCalc.units
	        		}
	        	],
		        listeners: {
		            afterrender: {
		    			fn: function() {
		    				if(Ext.fly(panelId + Child.GlobalDomIds._targetBGCheckID)) {
								Ext.fly(panelId + Child.GlobalDomIds._targetBGCheckID).on("click", function() {
									VerifyFieldProcess(panelId, Child.GlobalDomIds.targetBGId, Child.GlobalDomIds._targetBGLabelId );
									CheckForAllVerified(panelId);
								}, {
									panelId : panelId
								});
		    				}
		                }
		            }
		        }
	        }
	        ,{
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
	        	hidden : icalcData.INSULIN_CALC.ISSICKDAY !== 'true',
	        	border : false,
	            	padding : '0 5 0 5',
	        	id : panelId + Child.GlobalDomIds._targetSickDayLabelId,
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		fieldLabel:	buildHtmlForLabel(Child.GlobalDomIds._targetSickDayLabelId, panelId),
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
					{
			       		xtype: 'textfield',
			        	id : panelId + Child.GlobalDomIds.targetSickDayId,
			        	readOnly : true,
						width : theFieldWidth,
						height : theFieldlHeight,
			        	disabled: true,
						value: icalcData.INSULIN_CALC.ISSICKDAY === 'true' ? 'YES' : 'NO'
	        		}
	        	],
		        listeners: {
		            afterrender: {
		    			fn: function() {
		    				if(Ext.fly(panelId + Child.GlobalDomIds._targetSickDayCheckID)) {
								Ext.fly(panelId + Child.GlobalDomIds._targetSickDayCheckID).on("click", function() {
									VerifyFieldProcess(panelId, Child.GlobalDomIds.targetSickDayId, Child.GlobalDomIds._targetSickDayLabelId );
									CheckForAllVerified(panelId);
								}, {
									panelId : panelId
								});
		    				}
		                }
		            }
		        }
	        }]
        }]
	});
	
	var patientValuesPanel = new Ext.form.Panel(
	{
    	xtype : 'panel',
    	id : Child.GlobalDomIds.PATIENT_VALUES_PANEL_ID,
    	border : true,
    	height : patientValuesHeight,
		layout : 'fit',
    	items : [
        {
        	xtype : 'panel',
        	border : true,
			layout : {
				type : 'vbox'
				,pack : 'start'
				,align : 'stretch'
			},
        	items : [
	        {

        	
	        	xtype : 'fieldcontainer',
	        	border : false,
	           	padding : '0 5 0 5',
	        	hideLabel : true,
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
				{
			    	xtype: 'displayfield',
			       	disabled: false,
			       	height : theHeaderLabelHeight,
			     	width: theLabelWidth,
			       	value: '<span class="calc-heading-blue">Enter Patient Values</span>'
	        	}]
	        }, {
	        	xtype : 'fieldcontainer',
	        	hidden : !(icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.snacks || icalcData.INSULIN_CALC.ADMINTIME.toLowerCase() === Child.GlobalDomIds.sickday),
	        	height : 25,
		       	border : false,
	           	padding : '0 5 0 5',
	        	id : panelId + Child.GlobalDomIds._ISMORETHAN3HOURSSINCELASTINSULIN_LABEL,
	        	disabled: true,
	        	labelHeight : 25,
	       		labelWidth: theLabelWidth,
	       		fieldLabel: rapidInsulinQuestion, //'<span class="calc-heading-bold-large">Rapid-acting insulin in past 3 hrs?</span>'
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
	        		threeHrInsulinRadioGroup
	        	]
	        }, {
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
	        	border : false,
	        	padding : '0 5 0 5',
	        	id : panelId + Child.GlobalDomIds.carbsEatenLabelId,
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		fieldLabel: labelCarbsEatenInitial,
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
	    		{
		       		xtype: 'numberfield',
		        	id : panelId + Child.GlobalDomIds.carbsEatenFieldId,
					width : theFieldWidth,
					height : theFieldlHeight,
					tabIndex : 1,
		        	emptyText : ' ',
			        hideTrigger: true,
			        keyNavEnabled: false,
			        mouseWheelEnabled: false,
		        	disabled: true,
			        listeners: {
			            blur: {
			    			fn: function(theField) {
	
								var theCalcBtn = Ext.getCmp(panelId + Child.GlobalDomIds._CALCULATE_BTN);
								var theCurrentLabel = theField.ownerCt.getFieldLabel();
	
							    if(theField.getValue() !== null || theCurrentLabel.indexOf('src="../img/') !== -1) {
								    var theValue = theField.getValue();
				    				if(theValue === null) {
				    					theValue = '';
				    				}
				    				uji.GramsOfCarbsEaten = theValue;
				    				
				    				var theLabel = Ext.getCmp(panelId + Child.GlobalDomIds.carbsEatenLabelId);
									var theCarbsEatenIcon = '';
									var theErrMsg = '';
									var theCarbsEatenFormula = '';
				    				
									Child.IcalcPanelFactory.FatalCarbsError = false;
									var returnVal = CHILD.InsulinCalcEngine.editCarbsEaten(uji);
									
									switch(returnVal.status) {
										case Child.GlobalDomIds.OK:
				    						theCarbsEatenIcon = Child.GlobalDomIds.GREEN_CHECK_IMG;
				    						theErrMsg = returnVal.msg;
				    						theCarbsEatenFormula = returnVal.formula;
											break;
											
										case Child.GlobalDomIds.ERROR:
			    							theCarbsEatenIcon = Child.GlobalDomIds.RED_X_IMG;
											Child.IcalcPanelFactory.FatalCarbsError = true;
				    						theErrMsg = returnVal.msg;
											break;
											
										case Child.GlobalDomIds.WARN:
				    						theCarbsEatenIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
				    						theErrMsg = returnVal.msg;
				    						theCarbsEatenFormula = returnVal.formula;
											break;
										default:
											break;
									}
									
									var theLabelStr = formatCarbsEatenLabel('<img data-qtip="' + theErrMsg + '" class="non-clickable" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theCarbsEatenIcon + '">', theErrMsg, theCarbsEatenFormula);
	
									var theGroupField = theField.ownerCt;
									theGroupField.setFieldLabel(theLabelStr);
	//				    				theLabel.update(theLabelStr);
				    				
							    	clearResultInformation();
							    	
									if(returnVal.status === Child.GlobalDomIds.ERROR) {
										theField.focus(true,10);
									}
									
									CheckForEnableCalcBtn();
			    				}
			    				
			                }
			            }
			        }
	    		}, {
	    			xtype : 'displayfield',
	    			height : theLabelHeight,
	    			disabled : false,
	    			fieldLabel: ' ',
	    			labelPad : 0,
	    			labelSeparator : '',
	    			value : '</br>' + CHILD.InsulinCalcConstants.CarbsEatenMin.units
	        	}]
	        }, {
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
	        	hidden : uji.IsSickDay === false,
	        	border : false,
	        	padding : '0 5 0 5',
	        	id : panelId + Child.GlobalDomIds.BOHBLabelId,
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		fieldLabel: labelBOHBInitial,
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
	       		{
		       		xtype: 'combo',
		        	id : panelId + Child.GlobalDomIds.BOHBFieldId,
					width : 210,
					height : theFieldlHeight-4,
					tabIndex : 2,
					cls : 'x-combo-list-item',//notRequiredFieldCls,
	        		disabled: true,
		           	store: new Ext.data.ArrayStore({
		           		fields: ['dispText', 'factor', 'index'],
		               	data : [
	    	           		['BOHB under 0.6 mmol/L',       1.0, 0],
	        	       		['BOHB 0.6 - 1.5 mmol/L',       1.5, 1],
	            	   		['BOHB over 1.5 mmol/L',        2.0, 2],
	    	           		['Urine Ketones Neg - Small', 1.0, 3],
	        	       		['Urine Ketones Moderate',    1.5, 4],
	            	   		['Urine Ketones Large',       2.0, 5]
	             		]
	         		}),
	            	displayField:'dispText',
	            	valueField: 'index',
	            	querymode: 'local',
	            	typeAhead: false,
	            	triggerAction: 'all',
	            	lazyRender: true,
	            	lazyInit : false,
	            	forceSelection : true,
	            	emptyText: 'Select value',
	            	value : null,
	            	valueNotFoundText : 'Select value',
		        	listeners: {
		        		focus : {
		        			fn: function(theCombo) {
		        				theCombo.doQuery(theCombo.allQuery, true);
		        				theCombo.expand();
		        			}
		        		},
		        		select: {
		        			fn: function(theCombo, records, index) {
		        				var record = records[0];
		        				
							    if(record.data.dispText !== "") {
				    				if(uji.IsMoreThan3HoursSinceLastInsulin === false) {
				    					uji.SickDayFactor = 1.0;
				    				} else {
									    uji.SickDayFactor = record.data.factor; //theField.store.getAt(newValue).data.factor;
								    }
								    
									var theBOHBIcon = '';
									var theErrMsg = '';
									var theBOHBFormula = '';
									
									Child.IcalcPanelFactory.FatalBOHBError = false;
									var returnVal = CHILD.InsulinCalcEngine.editBOHBForCalc(uji);
									
									switch(returnVal.status) {
										case Child.GlobalDomIds.OK:
				    						theBOHBIcon = Child.GlobalDomIds.GREEN_CHECK_IMG;
				    						theErrMsg = returnVal.msg;
				    						theBOHBFormula = returnVal.formula;
											break;
											
										case Child.GlobalDomIds.ERROR:
			    							theBOHBIcon = Child.GlobalDomIds.RED_X_IMG;
											Child.IcalcPanelFactory.FatalBOHBError = true;
				    						theErrMsg = returnVal.msg;
											break;
											
										case Child.GlobalDomIds.WARN:
				    						theBOHBIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
				    						theErrMsg = returnVal.msg;
				    						theBOHBFormula = returnVal.formula;
											break;
											
										default:
											break;
									}
	
				    				var theLabelStr = formatBOHBLabel('<img data-qtip="' + theErrMsg + '" class="non-clickable" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theBOHBIcon + '">', theErrMsg, theBOHBFormula);
	
				    				
									var theGroupField = theCombo.ownerCt;
									theGroupField.setFieldLabel(theLabelStr);
	
							    	clearResultInformation();
				    				
									if(returnVal.status === Child.GlobalDomIds.ERROR) {
										theField.focus(true,10);
									}
									
									//fire change on bg for calc field, just incase this is a change to the BOHB field
									var theBGForCalcField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
									if(theBGForCalcField.getValue() !== "") {
										theBGForCalcField.fireEvent('blur', theBGForCalcField);
									}
									
									CheckForEnableCalcBtn();
							    }
			    			}
		            	}
		        	}
				}]
	        }, {
	        	xtype : 'fieldcontainer',
	        	height : theRowHeight,
	        	id : panelId + Child.GlobalDomIds.bloodGlucoseLabelId,
	        	border : false,
	        	padding : '0 5 0 5',
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		fieldLabel: labelBGforCalcInitial,
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
	       		{
		       		xtype: 'numberfield',
		        	id : panelId + Child.GlobalDomIds.bloodGlucoseFieldId,
					width : theFieldWidth,
					height : theFieldlHeight,
//					padding : '0 0 10 0',
					tabIndex : 3,
				    hideTrigger: true,
	    			keyNavEnabled: false,
	    			mouseWheelEnabled: false,
						emptyCls : notRequiredFieldCls,
			        	disabled: true,
			        	emptyText : ' '
				        ,listeners: {
				        	blur : {
				    			fn: function(theField) {
								    
									var theCalcBtn = Ext.getCmp(panelId + Child.GlobalDomIds._CALCULATE_BTN);
									var theCurrentLabel = theField.ownerCt.getFieldLabel();
		
								    if(theField.getValue() !== null || theCurrentLabel.indexOf('src="../img/') !== -1) {
	
//								    if(theField.getValue() !== null || theCalcBtn.disabled === false) {
									    var theValue = theField.getValue();
					    				if(theValue === null) {
					    					theValue = '';
					    				}
					    				uji.CurrentBloodGlucose = theValue;
	
										var theBGIcon = '';
										var theErrMsg = '';
										var theCurrentBGFormula = '';
										var hypoglycemic = false;
					    				
										Child.IcalcPanelFactory.FatalBGError = false;
										var returnVal = CHILD.InsulinCalcEngine.editBGForCalc(uji);
										
										switch(returnVal.status) {
											case Child.GlobalDomIds.OK:
					    						theBGIcon = Child.GlobalDomIds.GREEN_CHECK_IMG;
					    						theErrMsg = returnVal.msg;
					    						theCurrentBGFormula = returnVal.formula;
												break;
												
											case Child.GlobalDomIds.ERROR:
				    							theBGIcon = Child.GlobalDomIds.RED_X_IMG;
												Child.IcalcPanelFactory.FatalBGError = true;
					    						theErrMsg = returnVal.msg;
												break;
												
											case Child.GlobalDomIds.WARN:
					    						theBGIcon = Child.GlobalDomIds.YELLOW_CAUTION_IMG;
					    						theErrMsg = returnVal.msg;
					    						theCurrentBGFormula = returnVal.formula;
												break;
												
											case Child.GlobalDomIds.HYPOCRIT:
					    						theBGIcon = Child.GlobalDomIds.CRITHYPO_IMG;
												Child.IcalcPanelFactory.FatalBGError = true;
					    						theErrMsg = returnVal.msg;
					    						theCurrentBGFormula = returnVal.formula;
					    						hypoglycemic = true;
												break;
												
											case Child.GlobalDomIds.HYPO:
					    						theBGIcon = Child.GlobalDomIds.HYPO_IMG;
												Child.IcalcPanelFactory.FatalBGError = true;
					    						theErrMsg = returnVal.msg;
					    						theCurrentBGFormula = returnVal.formula;
					    						hypoglycemic = true;
												break;
												
											default:
												break;
										}
	
					    				var theLabelStr = formatBGLabel('<img data-qtip="' + theErrMsg + '" class="non-clickable" style="float:right;padding-right:30px;" src="' + Child.Framework.WEB_ASSET_FILE_LOCATION + theBGIcon + '">', theErrMsg, theCurrentBGFormula, hypoglycemic);
										var theGroupField = theField.ownerCt;
										theGroupField.setFieldLabel(theLabelStr);
	
								    	clearResultInformation();
					    				
										if(returnVal.status === Child.GlobalDomIds.ERROR ||
											returnVal.status === Child.GlobalDomIds.HYPOCRIT ||
											returnVal.status === Child.GlobalDomIds.HYPO) {
											theField.focus(true,10);
										}
										
										CheckForEnableCalcBtn();
								    } 
				    			}
				            }
				        }
	        		}, {
	        			xtype : 'displayfield',
	        			height : theLabelHeight,
	        			disabled : false,
	        			fieldLabel: ' ',
	        			labelSeparator : '',
	        			labelPad : 0,
	        			value : '</br>' + CHILD.InsulinCalcConstants.BGLimtForCalc.units
	        		}
	        	]
        	}]
        }]
   	});
   	
   	var buttonPanel = new Ext.panel.Panel(
   	{
    	xtype : 'panel',
    	height : 38,
    	id : Child.GlobalDomIds.BUTTON_PANEL_ID,
    	border : true,
    	layout : 'fit',
    	items : [{
			xtype : 'panel',
			border : true,
    		buttonAlign: 'center',
	        buttons: [{
	            text: 'Clear',
	            margin : '5 0 5 0',
	            listeners: {
	                click: {
	        			fn: function() {
							var theCarbsField = Ext.getCmp(panelId + Child.GlobalDomIds.carbsEatenFieldId);
		        			theCarbsField.setValue(null);
							var theGlucoseField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
		        			theGlucoseField.setValue(null);
							var theBOHBField = Ext.getCmp(panelId + Child.GlobalDomIds.BOHBFieldId);
		        			theBOHBField.setValue(null);

							if(uji.IsSickDay) {
		        				var the3HourNoChk = Ext.getCmp(panelId + Child.GlobalDomIds._3hrInsulinNo);
								the3HourNoChk.setValue(true);
							} else {
			        			var the3HourYesChk = Ext.getCmp(panelId + Child.GlobalDomIds._3hrInsulinYes);
								the3HourYesChk.setValue(true);
							}

							clearResultInformation();
		        			
							var theCalcBtn = Ext.getCmp(panelId + Child.GlobalDomIds._CALCULATE_BTN);
							theCalcBtn.disable();
							
		        			theCarbsField.focus(true);
	
		        			// reset labels to remove icons
							theCarbsField.ownerCt.setFieldLabel(labelCarbsEatenInitial);
							theGlucoseField.ownerCt.setFieldLabel(labelBGforCalcInitial);
							theBOHBField.ownerCt.setFieldLabel(labelBOHBInitial);
	                    }
	                }
	            }
    	}, {
    		xtype : 'panel',
    		border : false,
    		width : 150
   		}, {
	            text: 'Calculate',
	            id : panelId + Child.GlobalDomIds._CALCULATE_BTN,
	            enableKeyEvents: false,
	            tabIndex : 4,
	            disabled : true,
	            listeners: {
	                click: {
	                    fn: function(){
							//Get input fields again - just in case calculate pressed again (field can be overridden in calc engine call
	                    	var theField = Ext.getCmp(panelId + Child.GlobalDomIds.carbsEatenFieldId);
	                    	uji.GramsOfCarbsEaten = theField.getValue();
	                    	
	                    	theField = Ext.getCmp(panelId + Child.GlobalDomIds.bloodGlucoseFieldId);
	                    	uji.CurrentBloodGlucose = theField.getValue();
	                    	if(uji.CurrentBloodGlucose === null) {
	                    		uji.CurrentBloodGlucose = '';
	                    	}
	                    	
	                    	var the3HourYesChk = Ext.getCmp(panelId + Child.GlobalDomIds._3hrInsulinYes);
	                    	if(the3HourYesChk.checked) {
		                    	uji.IsMoreThan3HoursSinceLastInsulin = false;
	                    	} else {
		                    	uji.IsMoreThan3HoursSinceLastInsulin = true;
	                    	}

	                    	runStdInsulinCalc(panelId, uji);
	                    }
	                }
	            }
	        }]
		}]
    });
   	
	var calculatedValuesHeight = 165;
	if(icalcData.INSULIN_CALC.SICKDISPLAYLINE && icalcData.INSULIN_CALC.SICKDISPLAYLINE !== '') {
		calculatedValuesHeight = 235;
	}
    var calculatedValuesPanel = new Ext.panel.Panel(
    {
    	xtype : 'panel',
    	id : Child.GlobalDomIds.CALCULATED_VALUE_PANEL_ID,
    	border : true,
    	layout : 'fit',
    	height : calculatedValuesHeight,
    	items : [
    	{
    		xtype : 'panel',
    		border : true,
       		layout : {
       			type : 'vbox',
       			align: 'stretch',
       			pack: 'start'
       		},
        	items : [
		    {
	        	xtype : 'fieldcontainer',
	        	border : false,
	        	disabled: false,
            	padding : '2 5 0 5',
	        	height: theHeaderLabelHeight,
	        	labelHeight : theHeaderLabelHeight,
	       		labelWidth: theLabelWidth,
	       		labelSeparator: false,
	       		fieldLabel: '<span class="calc-heading-blue">Calculated Dose to Administer</span>',
	        	hideLabel : false
		    }, {
		       	xtype : 'fieldcontainer',
		       	height : theRowHeight,
	        	border : false,
            	padding : '0 5 0 5',
		       	id : panelId + Child.GlobalDomIds.insulinResultLabelId,
	        	disabled: true,
	        	labelHeight : theLabelHeight,
	       		labelWidth: theLabelWidth,
	       		fieldLabel: formatInsulinResultLabel('', false),
	       		labelSeparator : '',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
        		{
		       		xtype: 'numberfield',
		        	id : panelId + Child.GlobalDomIds.insulinResultFieldId,
		        	readOnly : true,
					width : theFieldWidth,
					height : theFieldlHeight,
					allowDecimals : true,
					decimalPrecision : 2,
		        	disabled: true
        		}, {
        			xtype : 'displayfield',
        			id : panelId + Child.GlobalDomIds._insulinResultsUnitFieldId,
        			height : theLabelHeight,
        			flex : 1,
	        		disabled : false,
        			fieldLabel: ' ',
        			labelSeparator : '',
        			labelPad : 0,
        			value : '</br>units'
        		}]
		    }, {    	
		   		xtype : 'fieldcontainer',
		       	height : 90,
	        	border : false,
            	padding : '0 5 0 5',
	       		layout : {
	       			type : 'hbox',
	       			align: 'middle',
	       			pack: 'start'
	       		},
	        	items: [
				{
		       		xtype: 'displayfield',
		        	id : panelId + Child.GlobalDomIds.insulinResultErrorDisplayFieldId,
		        	readOnly : true,
		        	hideLabel : true,
					height : 90,
		        	disabled: false
        		}]
		    }]
    	}]
    });
    
	var theFormPanel = new Ext.form.Panel({
        id: panelId,
        frame: true,
        border : false,
        title: null,
        flex : 1.0,
        autoScroll : true,
		layout : {
			type : 'vbox'
			,padding : 1
			,pack : 'start'
			,align : 'stretch'
		},
        fieldDefaults: {
    	    defaultType: 'textfield',
	        labelWidth: 10
        },
        items: [
			orderInformationPanel, 
	        spacerPanel6, 
	        parametersPanel, 
	        spacerPanel6, 
	        patientValuesPanel, 
	        spacerPanel3, 
	        buttonPanel, 
			spacerPanel3, 
	        calculatedValuesPanel
        ]
    });

    return theFormPanel;
    
};


