Ext.ns("CHILD.InsulinCalcConstants");

CHILD.InsulinCalcConstants.STRING_EMPTY                         = "";
CHILD.InsulinCalcConstants.CalculatorAction                     = {Inform: "inform", Enforce: "enforce", Calculator_Logic: "Calculator Logic", Order_Entry_Trap: "Order Entry Trap"};
CHILD.InsulinCalcConstants.Units                                = { GM: "gm", MG_PER_Dl: "mg/dL", GM_1_UNIT: "gm: 1 unit" };
CHILD.InsulinCalcConstants.ConstantType                         = function ConstantType(value, units, calculatorAction) {this.value = value; this.units = units; this.calculatorAction = calculatorAction;};

CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc               = new CHILD.InsulinCalcConstants.ConstantType(250, CHILD.InsulinCalcConstants.Units.GM, CHILD.InsulinCalcConstants.CalculatorAction.Inform);
CHILD.InsulinCalcConstants.CarbsEatenMin                        = new CHILD.InsulinCalcConstants.ConstantType(0, CHILD.InsulinCalcConstants.Units.GM, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);
CHILD.InsulinCalcConstants.CarbsEatenMax                        = new CHILD.InsulinCalcConstants.ConstantType(300, CHILD.InsulinCalcConstants.Units.GM, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);
CHILD.InsulinCalcConstants.CarbsEatenDiluteMin                  = new CHILD.InsulinCalcConstants.ConstantType(0, CHILD.InsulinCalcConstants.Units.GM, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);
CHILD.InsulinCalcConstants.CarbsEatenDiluteMax                  = new CHILD.InsulinCalcConstants.ConstantType(99, CHILD.InsulinCalcConstants.Units.GM, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);

CHILD.InsulinCalcConstants.BGLimtForCalc                        = new CHILD.InsulinCalcConstants.ConstantType(600, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Inform);
CHILD.InsulinCalcConstants.BGMinimum                            = new CHILD.InsulinCalcConstants.ConstantType(1, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);
CHILD.InsulinCalcConstants.BGMaximum                            = new CHILD.InsulinCalcConstants.ConstantType(2000, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);
//CHILD.InsulinCalcConstants.BGHyperThresholdBedtimeCorrection    = new CHILD.InsulinCalcConstants.ConstantType(300, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Calculator_Logic);
CHILD.InsulinCalcConstants.BGCriticalHypoThreshold              = new CHILD.InsulinCalcConstants.ConstantType(60, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Calculator_Logic);
CHILD.InsulinCalcConstants.BGHypoThreshold                      = new CHILD.InsulinCalcConstants.ConstantType(80, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Calculator_Logic);

CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo               = new CHILD.InsulinCalcConstants.ConstantType(200, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.TargetBGMax5to12yo                   = new CHILD.InsulinCalcConstants.ConstantType(180, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo           = new CHILD.InsulinCalcConstants.ConstantType(150, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.TargetBGMaxNighttime          	 	= new CHILD.InsulinCalcConstants.ConstantType(250, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);

CHILD.InsulinCalcConstants.TargetBGMax                          = new CHILD.InsulinCalcConstants.ConstantType(250, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);
CHILD.InsulinCalcConstants.TargetBGMin                          = new CHILD.InsulinCalcConstants.ConstantType(80, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Enforce);

CHILD.InsulinCalcConstants.TargetBGMinLessThan5yo               = new CHILD.InsulinCalcConstants.ConstantType(100, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.TargetBGMin5to12yo                   = new CHILD.InsulinCalcConstants.ConstantType(80, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.TargetBGMinGreaterThan12yo           = new CHILD.InsulinCalcConstants.ConstantType(80, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.TargetBGMinNighttime           		= new CHILD.InsulinCalcConstants.ConstantType(100, CHILD.InsulinCalcConstants.Units.MG_PER_Dl, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);

CHILD.InsulinCalcConstants.InsulinCarbRatioMin                  = new CHILD.InsulinCalcConstants.ConstantType(3, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.InsulinCarbRatioMax                  = new CHILD.InsulinCalcConstants.ConstantType(100, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);

CHILD.InsulinCalcConstants.CorrectionFactorMin                  = new CHILD.InsulinCalcConstants.ConstantType(20, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.CorrectionFactorWarnMax              = new CHILD.InsulinCalcConstants.ConstantType(150, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.CorrectionFactorMax                  = new CHILD.InsulinCalcConstants.ConstantType(350, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);

CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin         = new CHILD.InsulinCalcConstants.ConstantType(10, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);
CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax         = new CHILD.InsulinCalcConstants.ConstantType(100, CHILD.InsulinCalcConstants.Units.GM_1_UNIT, CHILD.InsulinCalcConstants.CalculatorAction.Order_Entry_Trap);


// 20151112 swood3 commenting out these strings that are not used
// FOR: txtInsulinToCoverCarbs
// if over max CARBS for calculation 
//CHILD.InsulinCalcConstants.Msg_MaxCarbsForDoseCalc_DoesNotCoverCalc =
//    "Max Carbohydrates for Dose Calculation [{0}] / (Carb/Insulin Ratio) [{1}]  -- Dose Calculation Does NOT Cover Total Carbs Eaten!";
// such as msg = Ext.String.Format(msg, Constants.CarbsEatenLimitForCalc.value, txtICRatio.Text);
// else    
//CHILD.InsulinCalcConstants.Msg_MaxCarbsForDoseCalc_DoesCoverCalc =
//    "Net carbohydrates eaten [{0}] / (carb/insulin ratio) [{1}]";
// such as msg = Ext.String.Format(msg, txtGramsCarbsEaten.Text, txtICRatio.Text);  

// FOR txtInsulinToCorrectBGAtMeals
// if over max BG for calculation    
//CHILD.InsulinCalcConstants.MSG_InsulinToCorrectMealtimes_BG_IsOverCalc =
//    "Amount of insulin to correct BG at mealtimes: If (Adjusted Max Calc BG [{0}] - Target BG[{1}])/CF[{2}] is a positive number, display the answer, otherwise display 0";
// such as: msg = Ext.String.Format(msg, CHILD.InsulinCalcConstants.BGLimtForCalc.value, txtTargetBloodGlucose.Text, txtCorrectionFactor.Text);
// else    
//CHILD.InsulinCalcConstants.MSG_InsulinToCorrectMealtimes_BG_IsNotOverCalc =
//   "Amount of insulin to correct BG at mealtimes: If (Current BG [{0}] - Target BG[{1}])/CF[{2}] is a positive number, display the answer, otherwise display 0";
// such as: msg = Ext.String.Format(msg, txtCurrentBG.Text, txtTargetBloodGlucose.Text, txtCorrectionFactor.Text);

// FOR txtInsulinToDeliverAtMeals    
//CHILD.InsulinCalcConstants.MSG_InsulinToDeliverAtMealsCalc =
//    "Amount of insulin to DELIVER at mealtimes: Carb insulin [{0}] + glucose insulin [{1}];  or, Insulin to cover carbs + Insulin to Correct BG at Mealtime";
// such as  msg = Ext.String.Format(msg, txtInsulinToCoverCarbs.Text, txtInsulinToCorrectBGAtMeals.Text);

// FOR txtInsulinToCorrectAtBedtime
// if over max BG for calculation    
//CHILD.InsulinCalcConstants.MSG_IsBG_Over_True_At_BedTimeCalc =
//   "Amount of insulin to correct BG at bedtimes: Half of mealtime BG insulin to correct [{0}] if Adjusted Max BG [{1}] > bed BG threshold [{2}], otherwise 0";
// such as msg = Ext.String.Format(msg, txtInsulinToCorrectAtBedtime.Text, CHILD.InsulinCalcConstants.BGLimtForCalc.value, Constants.BGHyperThresholdBedtimeCorrection.value);
// else
//CHILD.InsulinCalcConstants.MSG_IsBG_Over_False_At_BedTimeCalc =
//    "Amount of insulin to correct BG at bedtimes: Half of mealtime BG insulin to correct [{0}] if current BG [{1}] > bed BG threshold [{2}], otherwise 0";
// such as msg = Ext.String.Format(msg, txtInsulinToCorrectAtBedtime.Text, txtCurrentBG.Text, Constants.BGHyperThresholdBedtimeCorrection.value);            

// FOR txtInsulinToDeliverAtBedtime
//CHILD.InsulinCalcConstants.MSG_InsulinToDeliverAtBedtimeCalc =
//    "Carb Insulin [{0}] + Insulin To Correct At Bedtime [{1}]   NOTE: Insulin to Correct at Bedtime = Half of mealtime BG insulin [{2}] to correct if current BG [{3}] > bed BG threshold [{4}], otherwise 0";
// such as msg = Ext.String.Format(msg, txtInsulinToCoverCarbs.Text, txtInsulinToCorrectAtBedtime.Text, txtInsulinToCorrectBGAtMeals.Text, txtCurrentBG.Text, Constants.BGHyperThresholdBedtimeCorrection.value);

// FOR txtRoundedInsulinToDeliver
//CHILD.InsulinCalcConstants.MSG_RoundedInsulinToDeliverCalc =
//    "Total amount of Insulin To Deliver as appropriate for the time selected with the value and rounded down to nearest value of Insulin Units Increments selected [{0}]";
// such as msg = Ext.String.Format(msg, lbInsulinIncrements.SelectedItem);

// FOR txtInsulinToDeliverAtSnack
//CHILD.InsulinCalcConstants.MSG_InsulinToDeliverSnackCalc =
//    "Total amount of insulin to administer at snacks: Carb insulin only if BG < Target BG, Carb Insulin + Meal Insulin if > 3 hrs since last rapid insulin AND BG > Target";

