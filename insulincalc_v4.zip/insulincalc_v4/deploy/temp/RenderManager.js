/**
 * @author rpeltz
 */
Ext.ns('Child');
Ext.define('Child.RenderManagerClass', {
    extend: 'Ext.util.Observable',
	constructor : function(config) {
				this.renderQ = [];
				this.renderInProcess = false;
				this.startTime = 0;
				this.addToQ = function(rm, renderInfo) {
					var item = renderInfo;
					this.renderQ.push(item);
					this.listQ();
					rm.fireEvent('iteminq', this, 'item in q');
				};
				this.processQ = function() {
					if (this.renderQ.length > 0
							&& this.renderInProcess === false) {
						var item = this.renderQ.shift();
						var renderFn = item.renderFn;
						
						Child.Framework.debugLog(item.cclProgram, 'warn');
						this.startTime = new Date();
						
						var renderData = item.data;
						this.renderInProcess = true;
						renderFn(renderData);
					}
				};
				this.listQ = function() {
					var qString = '';
					for (var i = 0; i < this.renderQ.length; i++) {
						qString += i + ': ' + this.renderQ[i].cclProgram + ';';
					}
					if (qString.length === 0) {
						qString = 'empty q';
					}

					// alert(qString);
					// if (console){
					// console.log(qString);
					// }
					
					Child.Framework.debugLog(qString, 'info');
					
				};
				this.addEvents('rendercompleted', 'iteminq');
				this.listeners = config.listerners;
				this.callParent(arguments);
//				Child.RenderManagerClass.callParent.constructor.call(config);
//				Child.RenderManagerClass.superclass.constructor.call(this.config);
			}
		});

//Child.RenderManager = new Child.RenderManagerClass({});
Child.RenderManager = Ext.create(Child.RenderManagerClass,{});

Child.RenderManager.on('iteminq', function(pnl, aVar) {
			// alert('iteminq: ' + aVar);
			Child.RenderManager.processQ();
		});
Child.RenderManager.on('rendercompleted', function(pnl, aVar) {
			// alert('rendercompleted: ' + aVar);
			// Ext.Msg.alert('Render completed', aVar);
			
			var elapsedTime = 0;
			if(this.startTime !== 0) {
				var now = new Date();
				elapsedTime = now - this.startTime;
			}
			Child.Framework.debugLog('Render completed: ' + aVar + ' Elapsed Time : ' + elapsedTime, 'warn');
			
			Child.RenderManager.renderInProcess = false;
			this.listQ();
			
			
//			var delayProcessingNextItem = new Ext.util.DelayedTask(function() {
				Child.RenderManager.processQ();
//			});
			
//			delayProcessingNextItem.delay(20);
			
		});
