/**
 * @author rpeltz
 */
Ext.ns('Child');
Child.AboutPopup =  function () {
	var popup;
	var getIdInfo = '';
	var getIdInfoAlt = '';
	var linkToTestCode = '';
	var imgPath = '';
//	var userId = jsonInfo['PT_SUMMARY_INFO']['USER_ID'];
//	var patientId = jsonInfo['PT_SUMMARY_INFO']['PERSON_ID'];
//	var encounterId = jsonInfo['PT_SUMMARY_INFO']['ENCNTR_ID'];
	var orderIdQuery = 'QueryString OrderId : ' + Child.Framework.ORDERID;
//	var orderIdJSON = 'JSON OrderId : ' + 

	var browserDisplay = 'Browser: ' + navigator.appName + ' '
			+ navigator.userAgent + ' ';
	if (document.all) {
		var version = /MSIE \d+.\d+/;
		browserDisplay += navigator.appVersion.match(version);
	}

	var loc = 'WEB Server DNS: ' + window.location.hostname;

//	var isUserDBA = (jsonInfo['PT_SUMMARY_INFO']['USER_DBA'] == 'YES');
//	var isUserDev = (jsonInfo['PT_SUMMARY_INFO']['USER_DEVELOPER'] == 'YES');
//	if (isUserDBA || isUserDev) {
//		getIdInfo = String
//				.format(
//						'<br />Person Id: {0}<br />Encounter Id: {1}<br />User Id: {2}<br />',
//						patientId, encounterId, userId);
//		getIdInfoAlt = Ext.String.format(
//				'<br />Patient,Encounter,User: {0},{1},{2}<br />', patientId,
//				encounterId, userId);
//		imgPath = Ext.String.format('<br />Web Asset Folder Path: {0}<br />',
//				Child.Framework.WEB_ASSET_FILE_LOCATION);
//	}
//	if (isUserDev) {
//		linkToTestCode = '<br /><a href="javascript:CCLNEWSESSIONWINDOW(%22CCLLINK(\'ccl_readfile\',  \'^MINE^,^1mp_ptsum_test.html^\', 1)%22,\'_blank\',\'height=500,width=800,resizable=yes\',0,0);"> Link to Test</a><br />';
//	}

	if (popup === undefined) {
		popup = new Ext.Window({
			layout : 'fit',
			width : 300,
			height : 400,
			closeAction : 'hide',
			stateful : false,
			plain : true,
			modal : false,
			title : 'Seattle Childrens MPages',
			items : new Ext.Panel({
						id : 'pnlAbout',
						labelWidth : 75,
						frame : false,
						html : '<div style="padding:15px;text-align:left;">vers.'
								+ Child.Framework.VERSION
								+ '<br />Env: '
//								+ jsonInfo['PT_SUMMARY_INFO']['DOMAIN_NAME']
								+ '<br />HTML Env: '
								+ DOMAIN_NAME
								+ '<br />'
								+ loc
								+ '<br />'
								+ getIdInfo
								+ getIdInfoAlt
								+ imgPath
								+ orderIdQuery
								+ linkToTestCode
								+ '<br />'
								+ browserDisplay + '</div>'
					})
		});
	}
	popup.show();
};
Child.CCLValues_Popup = function (uji) {

	var ccl_popup;

	if (ccl_popup === undefined) {
		ccl_popup = new Ext.Window({
			layout : 'fit',
			width : 400,
			height : 450,
			closeAction : 'hide',
			stateful : false,
			plain : true,
			modal : false,
			title : 'Seattle Childrens MPages',
			items : new Ext.Panel({
						id : 'pnlcclValues',
//						labelWidth : 75,
						frame : false,
						html : '<table width="100%" border="1" cellspacing="0px"><tr width="100%"><th class="const-table-header" >LABEL</th><th class="const-table-header" >VALUE</th></tr>'
								+ Ext.String.format('<tr><td>PatientAgeYears : </td><td>{0}</td></tr>', 
									uji.PatientAgeYears)
								+ Ext.String.format('<tr><td>IsU100StandardInsulin</td><td>{0}</td></tr>', 
									uji.IsU100StandardInsulin)
								+ Ext.String.format('<tr><td>DisplayLine</td><td>{0}</td></tr>', 
									uji.DisplayLine)
								+ Ext.String.format('<tr><td>AdminTime</td><td>{0}</td></tr>', 
									uji.AdminTime)
								+ Ext.String.format('<tr><td>CarbInsulinRatio</td><td>{0}</td></tr>', 
									uji.CarbInsulinRatio)
								+ Ext.String.format('<tr><td>CorrectionFactor</td><td>{0}</td></tr>', 
									uji.CorrectionFactor)
								+ Ext.String.format('<tr><td>TargetBloodGlucose</td><td>{0}</td></tr>', 
									uji.TargetBloodGlucose)
								+ Ext.String.format('<tr><td>Increment</td><td>{0}</td></tr>', 
									uji.Increment)
								+ Ext.String.format('<tr><td>GramsOfCarbsEaten</td><td>{0}</td></tr>', 
									uji.GramsOfCarbsEaten)
								+ Ext.String.format('<tr><td>CurrentBloodGlucose</td><td>{0}</td></tr>', 
									uji.CurrentBloodGlucose)
								+ Ext.String.format('<tr><td>IsMoreThan3HoursSinceLastInsulin</td><td>{0}</td></tr>', 
									uji.IsMoreThan3HoursSinceLastInsulin)
								+ '</table>'
					})
		});
	}
	ccl_popup.show();

};

Child.ConstantsPopup =  function () {
//	alert('constants go here');

	var constants_popup;

	if (constants_popup === undefined) {
		constants_popup = new Ext.Window({
			layout : 'fit',
			width : 600,
			height : 450,
			closeAction : 'hide',
			stateful : false,
			plain : true,
			modal : false,
			title : 'Seattle Childrens MPages',
			items : new Ext.Panel({
						id : 'pnlConstants',
//						labelWidth : 75,
						frame : false,
						html : '<table width="100%" border="1" cellspacing="0px"><tr width="100%"><th class="const-table-header" >CONSTANT</th><th class="const-table-header" >VALUE</th><th class="const-table-header" >UNIT</th><th class="const-table-header" >ACTION TAKEN</th></tr>'
								+ Ext.String.format('<tr><td>Carbs Eaten Limit for Calc : </td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.value,
									CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.units,
									CHILD.InsulinCalcConstants.CarbsEatenLimitForCalc.calculatorAction)
								+ Ext.String.format('<tr><td>Carbs Eaten Min</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CarbsEatenMin.value,
									CHILD.InsulinCalcConstants.CarbsEatenMin.units,
									CHILD.InsulinCalcConstants.CarbsEatenMin.calculatorAction)
								+ Ext.String.format('<tr><td>Carbs Eaten Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CarbsEatenMax.value,
									CHILD.InsulinCalcConstants.CarbsEatenMax.units,
									CHILD.InsulinCalcConstants.CarbsEatenMax.calculatorAction)
								+ Ext.String.format('<tr><td>Carbs Eaten Min - DILUTE</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CarbsEatenDiluteMin.value,
									CHILD.InsulinCalcConstants.CarbsEatenDiluteMin.units,
									CHILD.InsulinCalcConstants.CarbsEatenDiluteMin.calculatorAction)
								+ Ext.String.format('<tr><td>Carbs Eaten Max - DILUTE</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CarbsEatenDiluteMax.value,
									CHILD.InsulinCalcConstants.CarbsEatenDiluteMax.units,
									CHILD.InsulinCalcConstants.CarbsEatenDiluteMax.calculatorAction)
								+ Ext.String.format('<tr><td>Blood Glucose Limit for calc</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.BGLimtForCalc.value,
									CHILD.InsulinCalcConstants.BGLimtForCalc.units,
									CHILD.InsulinCalcConstants.BGLimtForCalc.calculatorAction)
//								+ Ext.String.format('<tr><td>Blood Glucose Hyper Threshold Bedtime Correction</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
//									CHILD.InsulinCalcConstants.BGHyperThresholdBedtimeCorrection.value,
//									CHILD.InsulinCalcConstants.BGHyperThresholdBedtimeCorrection.units,
//									CHILD.InsulinCalcConstants.BGHyperThresholdBedtimeCorrection.calculatorAction)
								+ Ext.String.format('<tr><td>Blood Glucose Min</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.BGMinimum.value,
									CHILD.InsulinCalcConstants.BGMinimum.units,
									CHILD.InsulinCalcConstants.BGMinimum.calculatorAction)
								+ Ext.String.format('<tr><td>Blood Glucose Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.BGMaximum.value,
									CHILD.InsulinCalcConstants.BGMaximum.units,
									CHILD.InsulinCalcConstants.BGMaximum.calculatorAction)
								+ Ext.String.format('<tr><td>Blood Glucose Critical Hypo Threshold</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.BGCriticalHypoThreshold.value,
									CHILD.InsulinCalcConstants.BGCriticalHypoThreshold.units,
									CHILD.InsulinCalcConstants.BGCriticalHypoThreshold.calculatorAction)
								+ Ext.String.format('<tr><td>Blood Glucose Hypo Threshold</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.BGHypoThreshold.value,
									CHILD.InsulinCalcConstants.BGHypoThreshold.units,
									CHILD.InsulinCalcConstants.BGHypoThreshold.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMax.value,
									CHILD.InsulinCalcConstants.TargetBGMax.units,
									CHILD.InsulinCalcConstants.TargetBGMax.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Min</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMin.value,
									CHILD.InsulinCalcConstants.TargetBGMin.units,
									CHILD.InsulinCalcConstants.TargetBGMin.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Max < 5 yo</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo.value,
									CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo.units,
									CHILD.InsulinCalcConstants.TargetBGMaxLessThan5yo.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Min < 5 yo</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMinLessThan5yo.value,
									CHILD.InsulinCalcConstants.TargetBGMinLessThan5yo.units,
									CHILD.InsulinCalcConstants.TargetBGMinLessThan5yo.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Max 5-12 yo</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMax5to12yo.value,
									CHILD.InsulinCalcConstants.TargetBGMax5to12yo.units,
									CHILD.InsulinCalcConstants.TargetBGMax5to12yo.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Min 5-12 yo</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMin5to12yo.value,
									CHILD.InsulinCalcConstants.TargetBGMin5to12yo.units,
									CHILD.InsulinCalcConstants.TargetBGMin5to12yo.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Max >= 12 yo</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo.value,
									CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo.units,
									CHILD.InsulinCalcConstants.TargetBGMaxGreaterThan12yo.calculatorAction)
								+ Ext.String.format('<tr><td>Target Blood Glucose Min >= 12 yo</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.TargetBGMinGreaterThan12yo.value,
									CHILD.InsulinCalcConstants.TargetBGMinGreaterThan12yo.units,
									CHILD.InsulinCalcConstants.TargetBGMinGreaterThan12yo.calculatorAction)
								+ Ext.String.format('<tr><td>Insulin Carb Ratio Min</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.InsulinCarbRatioMin.value,
									CHILD.InsulinCalcConstants.InsulinCarbRatioMin.units,
									CHILD.InsulinCalcConstants.InsulinCarbRatioMin.calculatorAction)
								+ Ext.String.format('<tr><td>Insulin Carb Ration Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.InsulinCarbRatioMax.value,
									CHILD.InsulinCalcConstants.InsulinCarbRatioMax.units,
									CHILD.InsulinCalcConstants.InsulinCarbRatioMax.calculatorAction)
								+ Ext.String.format('<tr><td>Correction Factor Min</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CorrectionFactorMin.value,
									CHILD.InsulinCalcConstants.CorrectionFactorMin.units,
									CHILD.InsulinCalcConstants.CorrectionFactorMin.calculatorAction)
								+ Ext.String.format('<tr><td>Correction Factor Warning Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CorrectionFactorWarnMax.value,
									CHILD.InsulinCalcConstants.CorrectionFactorWarnMax.units,
									CHILD.InsulinCalcConstants.CorrectionFactorWarnMax.calculatorAction)
								+ Ext.String.format('<tr><td>Correction Factor Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.CorrectionFactorMax.value,
									CHILD.InsulinCalcConstants.CorrectionFactorMax.units,
									CHILD.InsulinCalcConstants.CorrectionFactorMax.calculatorAction)
								+ Ext.String.format('<tr><td>U10 Dilute Correction Factor Max</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax.value,
									CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax.units,
									CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMax.calculatorAction)
								+ Ext.String.format('<tr><td>U10 Dilute Correction Factor Min</td><td>{0}</td><td>{1}</td><td>{2}</td></tr>', 
									CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin.value,
									CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin.units,
									CHILD.InsulinCalcConstants.U10DiluteCorrectionFactorMin.calculatorAction)
								+ '</table>'
					})
		});
	}
	constants_popup.show();
	
};