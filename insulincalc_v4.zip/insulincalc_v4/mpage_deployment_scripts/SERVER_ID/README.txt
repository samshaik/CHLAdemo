Deployment of HTML across servers

The contents of Server ID files are appended to the end of the html.  The contents consist of a 
javascript tag with commented out name of the server from which the contents of the HMTL are 
served.  This is in order to help developers troubleshoot problems by enabling them to know
the source of the files in a load balanced environment.
SERVER_ID_P<P|T>WMPIxx.txt contains
<script type="text/javascript">//P<T|P>WMPIxx</script>

Deployment scripts append the contents of the server id files to the end of the html during
deployment.