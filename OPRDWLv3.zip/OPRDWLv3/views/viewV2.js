chla.OPRADWL.View.ClearAll = function (evt) {
    var appObj = chla.OPRADWL;
    $('select#SelOrderNum').val('0');
    $('select#selHoldBy').val('0');
    $('select#selProtocol').val('0');
    $('select#selModality').val('0');
    $('select#selPatient').val('0');
    $('select#selTimeRange').val('0');
    $('select#selHoldType').val('0');
    appObj.Data.selFltrsVal.Patient    = '0';
    appObj.Data.selFltrsVal.OrderId    = '0';
    appObj.Data.selFltrsVal.HoldBy     = '0';
    appObj.Data.selFltrsVal.Protocol   = '0';
    appObj.Data.selFltrsVal.Modality   = '0';
    appObj.Data.selFltrsVal.TimeRng    = '0';
    appObj.Data.selFltrsVal.HoldType   = '0';
    appObj.ResetDom(appObj);
    appObj.processCtlClearFilters(appObj, appObj.Data.getOrdersViewDto_strUI(appObj),appObj.Data.getOrdersViewDto(appObj).fltrs);
    evt.stopPropagation();
};
/**
 *
 * @param aAppObj  {*}
 * @param aFilterType {string}
 * @param aExpand {boolean}
 * @param aDtoData {*}
 * @param aDtoUI {string}
 * @param aFilters {*}
 */
chla.OPRADWL.View.processApplyFilters = function(aAppObj,aFilterType,aExpand,aDtoData,aDtoUI,aFilters){
    var selectedFiltersVal = chla.OPRADWL.Data.selFltrsVal,
        vExpand = false,
        vDtoUI = aDtoUI,
        arrSelectVal = aAppObj.Data.selFltrsVal,
        arrSelect = Object.keys(aAppObj.Data.selFltrsVal),
        isFiltersCleared = true,
        objWrk;
    arrSelect.forEach(
        function (value) {
            if(arrSelectVal[value] !== '0'){
                isFiltersCleared = false;
            }
        }
    );

    aAppObj.ResetDom(aAppObj);
    if(aFilterType !== 'NONE') {
        objWrk = aAppObj.crTrSt.nP(aDtoData, aAppObj, true);
        aFilters = objWrk.fltrs;
        vDtoUI = aAppObj.processUI(aAppObj, objWrk.tblData);
        vExpand = true;
    }
    if (isFiltersCleared){
        vExpand = false;
    }
    aAppObj.processInstance(aAppObj,vDtoUI);
    aAppObj.processPostInstance(aAppObj,aDtoUI,vExpand,aFilters);

    $('select#selPatient').val(selectedFiltersVal.Patient);
    $('select#SelOrderNum').val(selectedFiltersVal.OrderId);
    $('select#selHoldBy').val(selectedFiltersVal.HoldBy);
    $('select#selProtocol').val(selectedFiltersVal.Protocol);
    $('select#selModality').val(selectedFiltersVal.Modality);
    $('select#selTimeRange').val(selectedFiltersVal.TimeRng);
    $('select#selHoldType').val(selectedFiltersVal.HoldType);
};
chla.OPRADWL.View.selectPatientFilter = function () {
    var combo = $(this),
        appObj = chla.OPRADWL,
        selectedFilters = chla.OPRADWL.Data.selFltrs,
        selectedFiltersVal = chla.OPRADWL.Data.selFltrsVal;
    selectedFilters.Patient = combo.text();
    selectedFiltersVal.Patient = combo.val();

    appObj.View.processSelectFilters(appObj,'Patient');
} ;

chla.OPRADWL.View.selectHoldByFilter = function () {
    var combo = $(this),
        appObj = chla.OPRADWL,
        selectedFilters = chla.OPRADWL.Data.selFltrs,
        selectedFiltersVal = chla.OPRADWL.Data.selFltrsVal;
    selectedFilters.HoldBy = combo.text();
    selectedFiltersVal.HoldBy = combo.val();

    appObj.View.processSelectFilters(appObj,'HoldBy');
};

chla.OPRADWL.View.selectOrderIdFilter = function () {
    var combo = $(this),
        appObj = chla.OPRADWL,
        selectedFilters = chla.OPRADWL.Data.selFltrs,
        selectedFiltersVal = chla.OPRADWL.Data.selFltrsVal;
    selectedFilters.OrderId = combo.text();
    selectedFiltersVal.OrderId = combo.val();

    appObj.View.processSelectFilters(appObj,'OrderId');
};

chla.OPRADWL.View.selectModalityFilter = function () {
    var combo = $(this),
        appObj = chla.OPRADWL,
        selectedFilters = chla.OPRADWL.Data.selFltrs,
        selectedFiltersVal = chla.OPRADWL.Data.selFltrsVal;
    selectedFilters.Modality = combo.text();
    selectedFiltersVal.Modality = combo.val();

    appObj.View.processSelectFilters(appObj,'Modality');
};


chla.OPRADWL.View.selectProtocolFilter = function () {
    var combo = $(this),
        appObj = chla.OPRADWL,
        selectedFilters = chla.OPRADWL.Data.selFltrs,
        selectedFiltersVal = chla.OPRADWL.Data.selFltrsVal;
    selectedFilters.Protocol = combo.text();
    selectedFiltersVal.Protocol = combo.val();

    appObj.View.processSelectFilters(appObj,'Protocol');
};

chla.OPRADWL.View.selectHoldTypeFilter = function () {
    var combo = $(this),
        appObj = chla.OPRADWL,
        selectedFilters = chla.OPRADWL.Data.selFltrs,
        selectedFiltersVal = chla.OPRADWL.Data.selFltrsVal;
    selectedFilters.HoldType = combo.text();
    selectedFiltersVal.HoldType = combo.val();

    appObj.View.processSelectFilters(appObj,'HoldType');
};

// chla.OPRADWL.View.selectTimeRangeFilter = function (combo) {
//     chla.OPRADWL.OrdersView.selFltrs.TimeRng = combo.value;
//     chla.OPRADWL.View.SelectTimeRange(combo.value);
// };

