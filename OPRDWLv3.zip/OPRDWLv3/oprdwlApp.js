'use strict';
// noinspection JSUnusedAssignment
/**
 * CHLA eApps Namespace - cleanup global space
 * @type Object
 */
var chla = chla || {};
chla.eAppsUtil = chla.eAppsUtil || {};
chla.eApps=  {
    Version             : '02.08.00',
    eComments           : 'QA Testing PRODQA Update Research section ',
    eBuildDate          : '07/29/2019 14:38:57',
    eLocation           : 'I:/WININTEL/static_content/custom_mpage_content/Chla_eApps_Static_mPages/QA/OPRDWLv3',
    appName             : 'OP Radiology WorkList',
    cclProgram          : 'chla_ca_mp_rw_fo_jsn4',
    ccLNewOrders        : 'chla_ca_mp_rw_fo_jsn4',
    inpatientURL        : 'http://159.140.229.9/mpage-content/p1345.chla_ca.cernerasp.com/custom_mpage_content/Chla_eApps_Static_mPages/IPRADWL/rad_mpage.htm',
     baseHtml            : 'opdwlMainTest.html',  // local:opdwlMainTest.html, prod(USERS/QA):opdwlMain.html
    testEnvironment     : false,
    filterZzKids        : true,//'test',  //true, false, 'test'
    gFuncs              : {},
    gTmplts             : {},
    loggingControl      : {
        'LogInfo':{
            'LG0'     : {
                'notifyLevel': 0,
                'logLevel'   : 0
            }
        },
        'LogAlert':{
            'LG0'     : {
                'notifyLevel': 0,
                'logLevel'   : 0
            }
        },
        'LogError':{
            'LG0'     : {
                'notifyLevel': 0,
                'logLevel'   : 0
            }
        },
        'LogWarn':{
            'LG0'     : {
                'notifyLevel': 0,
                'logLevel'   : 0
            }
        },
        logLevel:0,
        notifyLevel:0,
        showBlackbird: true,
        showOrderData: true,
        showTreeStructure: false
    },
    blackbirdControl    :  '',
    indicatorSetImgHover: 1
};
chla.ReqType = {
    funcOper     : 'New,Future,Hold,Modify,Wait,Hist1,Hist2,OrderSpec',
        funcType     : 'UNFMTRPTDATA,RPTDATA,UNFMTPFID,PFID',
        recordType   : 'PFID/RPTDATA',
        recordMarker : 'SCHORDERS/XORDERS',
        formatType   : 'Unformatted/formatted',
        linkValue    : 0, // encounterid,personid,orderid
        params       : [],
        cclProg      : ''
};
chla.OPRADWL =  {
    crTrSt: {
        nP   : function(){}
        // ,Future_Processor: function(){}
        // ,Modify_Processor: function(){}
        // ,Wait_Processor  : function(){}
        // ,Active_Processor: function(){}
    },
    View:{

        /**
         *
         * @param viewMod
         * @param aAppObj
         * @returns {string}
         */
        processOprdwlToolBar: function (viewMod,aAppObj) {
            var toolbar = [];
            toolbar.push(
                '<div style="width: 100px;margin:0;display: inline-block"><span style="font-size: larger; font-weight: 700;" onclick="chla.about2();"> OutPatient</span></div>',
                '<div style="margin:0; display: inline-block;height: 14px;width: 0;border-left: 1px solid #98c8ff;border-right: 1px solid white;"></div>',
                '<div style="width: 50px; margin:0; left: 121px; top: 3px;display: inline-block;line-height: 1em;text-align:center;',
                (viewMod === 'NEW'? '"><span class="currTab">New<br>Orders</span>':'font-size: smaller;font-weight: normal;" onclick="chla.OPRADWL.View.processMenuLink(\'NEW\');"><u>New<br>Orders</u>'),
                '</div>',
                '<div style="margin:0; display: inline-block;height: 14px;width: 0;border-left: 1px solid #98c8ff;border-right: 1px solid white;"></div>',
                '<div style="width: 50px; margin:0; left: 121px; top: 3px;display: inline-block;line-height: 1em;text-align:center;',
                (viewMod === 'FUTURE'? '"><span class="currTab">Future<br>Orders</span>':'font-size: smaller;font-weight: normal;" onclick="chla.OPRADWL.View.processMenuLink(\'FUTURE\');"><u>Future<br>Orders</u>'),
                '</div>',
                '<div style="margin:0; display: inline-block;height: 14px;width: 0;border-left: 1px solid #98c8ff;border-right: 1px solid white;"></div>',
                '<div style="width: 50px; margin:0; left: 121px; top: 3px;display: inline-block;line-height: 1em;text-align:center;',
                (viewMod === 'MODIFY'? '"><span class="currTab">Orders<br>to Modify</span>': 'font-size: smaller;font-weight: normal;" onclick="chla.OPRADWL.View.processMenuLink(\'MODIFY\');"><u>Orders<br>to Modify</u>'),
                '</div>',
                '<div style="margin:0; display: inline-block;height: 14px;width: 0;border-left: 1px solid #98c8ff;border-right: 1px solid white;"></div>',
                '<div style="width: 50px; margin:0; left: 121px; top: 3px;display: inline-block;line-height: 1em;text-align:center;',
                (viewMod === 'HOLD'? '"><span class="currTab">Orders<br>on Hold</span>': 'font-size: smaller;font-weight: normal;" onclick="chla.OPRADWL.View.processMenuLink(\'HOLD\');"><u>Orders<br>on Hold</u>'),
                '</div>',
                //'<div style="margin:0; display: inline-block;height: 14px;width: 0;border-left: 1px solid #98c8ff;border-right: 1px solid white;"></div>',
                //'<div style="width: 50px; margin:0; left: 121px; top: 3px;display: inline-block;line-height: 1em;text-align:center;',
                //(viewMod === 'WAIT'? '"><span class="currTab">Waiting<br/>Orders</span>': 'font-size: smaller;font-weight: normal;" onclick="chla.OPRADWL.View.processMenuLink(\'WAIT\');"><u>Waiting<br/>Orders</u>'),
                //'</div>',
                '<div style="margin:0; display: inline-block;height: 14px;width: 0;border-left: 1px solid #98c8ff;border-right: 1px solid white;"></div>',
                '<div style="width: 50px; margin:0; left: 121px; top: 3px;display: inline-block;line-height: 1em;text-align:center;',
                //(viewMod === 'ACTIVE'? '"><span class="currTab">Active<br>Orders</span>': 'font-size: smaller;"><a href="http://159.140.229.9/mpage-content/p1345.chla_ca.cernerasp.com/custom_mpage_content/Chla_eApps_Static_mPages/OPRADWLv1/opradao_mpage.htm"><u><span style="font-weight: normal;">Active<br>Orders</span></u></a>'),
                 (viewMod === 'ACTIVE'? '"><span class="currTab">Active<br>Orders</span>': 'font-size: smaller;font-weight: normal;" onclick="chla.OPRADWL.View.processMenuLink(\'ACTIVE\');"><u>Active<br>Orders</u>'),
                '</div>',
                '<div style="margin:0; display: inline-block;height: 14px;width: 0;border-left: 1px solid #98c8ff;border-right: 1px solid white;"></div>',
                '<div style="display: inline-block;margin:0; left: 388px; top: 7px;" onclick="chla.OPRADWL.View.processMenuLink(\'INPATIENT\');">',
                '&nbsp;&nbsp;<u>INPATIENT</u></div>'
            );
            aAppObj.View.processMenuLink = function (aViewMod) {
                var pURL = ['opdwlMain.html?view='];
                if (aViewMod === 'INPATIENT'){
                    pURL.pop();
                    pURL.push(chla.eApps.inpatientURL);
                }else {
                    pURL.push(aViewMod);
                }
                aAppObj.ResetDom(chla.OPRADWL);
                window.location.href= pURL.join('');
            };
            return toolbar.join('');
        },
        HtmlViewMain:[
            '<div class="section green" id="DivSection" style="<#=viewportHeight#>" ><h2 class="sec-hd h2a-marker" style="height: 28px;">',
            '<div style="display: block;">',
            '<div class="sec-title " style="margin-right: 0;width:650px;padding-top: 0;"><div id="oprdwlToolbar" style="font-size: 11px;"></div></div>',
            '<div style="float:right;">&nbsp;</div><div style="display: inline-block;float:right;vertical-align: middle;">',
            '<#=MbarBtnClrFilter#>',
            '<div style="display: inline-block;vertical-align: middle">',
            '<#=SpacerBar0#>',
            '<#=MbarSelPosition1#>',
            '<#=SpacerBar1#>',
            '<#=MbarSelPosition2#>',
            '<#=SpacerBar2#>',
            '<#=MbarSelPosition3#>',
            '<#=SpacerBar3#>',
            '<#=MbarSelPosition4#>',
            '<div style="padding-top: 5px;display: inline-block;height: 18px;">&nbsp;</div></div></div></div></h2>',
            '<div class="sec-content" id="DivSecContent"><div class="content-body" id="SecR1C1" style="<#=viewportHeight2#>"><div id="chla_opradwl" class="eapps_CC" style="text-align:left;"><div id="prog3">',
            '<div id="startup_label" style="position: absolute;top: 0;left: 0;width: 100%;height: 100%; z-index: 10;background-color: rgba(0,0,0,0.2);">',
            '<h3  style="z-index:12;color:white;text-align: center;font-family:  Tahoma,Verdana,Segoe,sans-serif ;font-size:24px;font-weight: 900;padding-top:280px">Loading<br/>',
            '<img class="center" alt="Working" src="eAppsResources/images/large-loading.gif" /></h3></div>',
            '</div></div></div></div></div>',
            '<div id="shadowdiv" style="display:none;position: absolute;top: 0;left: 0;width: 100%;height: 100%; z-index: 10;background-color: rgba(0,0,0,0.2);">',
            '<h3  style="z-index:12;color:white;text-align: center;font-family:  Tahoma,Verdana,Segoe,sans-serif ;font-size:16px;padding-top:280px">Working<br/>',
            '<img class="center" alt="Working" src="eAppsResources/images/large-loading.gif" /></h3></div>'
        ],
        HtmlDivShadow: [
            '<div id="shadowdiv" style="color:white;position: absolute;top: 0;left: 0;width: 100%;height: 100%; z-index: 10;background-color: rgba(0,0,0,0.2);">',
            '<h3  style="z-index:12;color:white;text-align: center;font-family:  Tahoma,Verdana,Segoe,sans-serif ;font-size:16px;padding-top:280px">Working<br/>',
            '<img class="center" alt="Working" src="eAppsResources/images/large-loading.gif" /></h3></div>'
        ],
        HtmlBtnClearFilter: [
            '<div style="width: 75px; display: inline-block;padding-top:3px;">',
            '<button id="btnClrAll" type="button" style="width: 75px;font-size: smaller;font-weight: normal"><span style="line-height: normal; "><u>Clear All</u></span>',
            '</button></div>'
        ],
        HtmlSpacer: [
            '<div style="display: inline-block;height: 14px;width: 0;border-left: 1px solid #98c8ff;border-right: 1px solid white;"></div>'
        ],
        HtmlSeltimeRange: [
            '<div style="display: inline-block;width: 170px; margin:0;">',
            '<select id="selTimeRange" style="width:170px;font-size: smaller;"><option value="0">-Time Range-</option></select></div>'
        ],
        HtmlSelPatient: [
            '<div style="display: inline-block;width: 170px; margin:0;">',
            '<select id="selPatient" style="width:170px;font-size: smaller;"><option value="0">-Patient-</option><option >Patient1</option><option >Patient2</option></select></div>'
        ],
        HtmlSelHoldType: [
            '<div style="display: inline-block;width: 170px; margin:0;">',
            '<select id="selHoldType" style="width:170px;font-size: smaller;"><option value="0">-Hold Types-</option><option value="Awake Attempt">Awake Attempt</option></select></div>'
        ],

        HtmlSelModality: [
            '<div style="display: inline-block;width: 75px; margin:0;">',
            '<select id="selModality" style="width:75px;font-size: smaller;"><option>-Modality-</option></select></div>'
        ],
        HtmlSelProtocol: [
            '<div style="display: inline-block;width: 135px; margin:0;">',
            '<select id="selProtocol" style="width:135px;font-size: smaller;display: inline-block"><option value="0">-Protocol-</option></select></div>'
        ],
        HtmlSelHoldBy: [
            '<div style="display: inline-block;width: 170px; margin:0;">',
            '<select id="selHoldBy" style="width:170px;font-size: smaller;"><option value="0">-Hold By-</option></select></div>'
        ],
        HtmlSelNeuroBody: [
            '<div style="display: inline-block;width: 170px; margin:0;">',
            '<select id="selBodyNeuro" style="width:170px;font-size: smaller;"><option value="0">-Neuro/Body-</option><option ><option >Neuro</option><option >Body</option><option >Neuro and/or Body</option></select></div>'
        ],
        HtmlSelOrderNum: [
            '<div style="display: inline-block;width: 170px; margin:0;">',
            '<select id="SelOrderNum" style="width:170px;font-size: smaller;"><option value="0">-Order Id-</option><option ></select></div>'
        ],
        H5H6BuilderList:
            {
                'NEW': {
                    'H6List':{
                        "New Order":''
                    }
                },
                'FUTURE': {
                    'H6List':{
                        "Exam Protocol":'',
                        "Cardio Exam Protocol": '',
                        "Nurse Practitioner":"NP Triage"
                    }
                },
                'MODIFY': {
                    'H6List':{
                        "Exam Protocol":'',
                        "Cardio Exam Protocol": '',
                        "Scheduling" : ''
                    }
                 },
                'HOLD': {
                    'H6List':{
                        "Exam Protocol":'',
                        "Cardio Exam Protocol": '',
                        "Nurse Practitioner":"NP Triage",
                        "HOLD":'RESCHEDULE '
                    }
                },
                'WAIT': {
                    'H6List': {
                        "New Order"           : '',
                        "Exam Protocol"       : '',
                        "Cardio Exam Protocol": '',
                        "Nurse Practitioner"  : "NP Triage",
                        "Waiting"             : '',
                        "Nurse Tech"          : "Nurse / Technologist",
                        "Completed"           : ''
                    }
                },
                'HIST': {
                    'H6List':{
                        "New Order":'',
                        "Exam Protocol":'',
                        "Cardio Exam Protocol": '',
                        "Nurse Practitioner":"NP Triage",
                        "Waiting":'',
                        "Nurse Tech":"Nurse / Technologist",
                        "Completed":''
                    }
                },

                'ACTIVE':{
                    'H6List':{
                        "Nurse Tech":"Nurse / Technologist"
                    }
                }
            },
        /**
         *
         * SPECIFIC: to View type
         *  @param aAppObj
         *  @param aLblMod
         *  @param aLblProt
         * @param aData
         * @returns {{H5id: string, H5SecId: string, H6id: string, H6SecId: string, H6Body: {}}}
         */
        H5H6Builder: function (aAppObj, aLblMod, aLblProt, aData){
            var retObj = {
                H5id    : aLblMod,
                H5SecId : aLblMod + '1',
                H6id    : aLblProt,
                H6SecId : aLblMod + 'NO1',
                LEVEL   : 2,
                    H6Body:{
                        NAME          : aData.NAME_FULL_FORMATTED,
                        MOD           : aLblMod,
                        Protocol      : aLblProt,
                        CTLPROTOCAL_STATUS2: aData.CTLPROTOCAL_STATUS2,
                        LEVEL         : 3,
                        vProtocolID   : aData.ProtocolID,
                        vPersonID     : aData.PERSONID,
                        vEncounterID  : aData.ENCNTRID,
                        vGROUP_PF_ID  : aData.GROUP_PF_ID,
                        vActiveFormId : aData.FORM_ACTIVITY_ID,
                        vName         : nameToLink(aData.NAME_FULL_FORMATTED, aData),
                        vNamelbl      : aData.NAME_FULL_FORMATTED,
                        vHoldID       : aData.HoldByID,
                        vNameID       : aData.NameID,
                        vAge          : ageCss(aData.AGE, aData),
                        vAgelbl       : agelbl(aData.AGE),
                        vHW           : heightAndWeight(aData.HEIGHT, aData),
                        vLoc          : formatPatLoc(aData.ORDER_LOC, aData),
                        vPrior        : retrieveOrderPriority(aData.PRIORITY, aData),
                        vPriorlbl     : aData.PRIORITY,
                        vaData        : '',
                        vHoldType     : aData.NP_CLR,
                        vClipData     : '',
                        vOrdId        : orderIdBtn(aData.ORDERID, aData),
                        vOrdIdlbl     : aData.ORDERID,
                        vHoverText    : '',
                        vOrder        : retrieveOrderDetail(aData.ORDER_DESC, aData),
                        vOrderlbl     : aData.ORDER_DESC,
                        vCmt          : convertToIcon4(aData.RAD_COMMENTS, aData),
                        vSedation     : aData.SEDATION,
                        vRadDisc      : aData.RAD_DISCRETION,
                        vProtStat     : protoStatToLink(aData.CTLPROTOCAL_STATUS, aData),
                        vProtBy       : aData.RADIOLOGISTID,
                        vOrdDtlbl     : ConvertSortDateTime(aData.DATE_ORDERED),
                        vOrdDt        : aData.DATE_ORDERED,
                        vReqExmDt     : aData.DATE_REQUESTED,
                        vUptDtlbl     : ConvertSortDateTime(aData.PROTOCOL_DATE_MODIFIED),
                        vUptDt        : retrieveNormalData(aData.PROTOCOL_DATE_MODIFIED, aData),
                        vHldSts       : '',
                        vACCESSIONID  : '',
                        vDOB          : aData.DOB,
                        vISOLATION    : '',
                        vDATE_REQUESTED: '',
                        vCSA_SIGNED   : '',
                        vCSA_SIGNED_DT:  '',
                        vCSA_CONTRIND : '',
                        vALERT_FLAG   : aData.ALERT_FLAG,
                        vCSA_FORM_ACTIVITY_ID:'',
                        vCSA_EXAM_FORM_ID: '',
                        vMRN: aData.MRN,
                        vMRNlbl: (aData.MRN === ''? '0':aData.MRN )
                    }
                };
            if (aAppObj.Data.getOrdState(aAppObj) === 'ACTIVE') {
                retObj.H6Body.vACCESSIONID           =retrieveAccessionID(aData.ACCESSIONID,aData);
                retObj.H6Body.vISOLATION             =convertToIcon3(aData.ISOLATION,aData);
                retObj.H6Body.vCSA_SIGNED            =aData.CSA_SIGNED;
                retObj.H6Body.vOrder_Status          =aData.ORDER_STATUS;
                retObj.H6Body.vCSA_SIGNED_DT         =convertToIcon(aData.CSA_SIGNED_DT,aData);
                retObj.H6Body.vCSA_CONTRIND          =convertToIcon2(aData.CSA_CONTRIND,aData);
                retObj.H6Body.vCSA_FORM_ACTIVITY_ID  = aData.CSA_FORM_ACTIVITY_ID;
                retObj.H6Body.vCSA_EXAM_FORM_ID      = aData.CSA_EXAM_FORM_ID;
            } else {
                retObj.H6Body.vMrn          = aData.MRN;
                retObj.H6Body.vHldStslbl    = ConvertHoldDate(aData);
                retObj.H6Body.vHldSts       = HLDconvertToStatus(aData.EP_HOLD_STATUS, aData);
            }
            return retObj;
        },
        dataTable           : {
            'lNAME':     {id:'',sortVector: 0},
            'lMRN':      {id:'',sortVector: 0},
            'lORDLOC':   {id:'',sortVector: 0},
            'lORDSTAT':  {id:'',sortVector: 0},
            'lORDERID':  {id:'',sortVector: 0},
            'lORDDESC':  {id:'',sortVector: 0},
            'lRADCMTS':  {id:'',sortVector: 0},
            'lSEDATION': {id:'',sortVector: 0},
            'lRADDISCR': {id:'',sortVector: 0},
            'lPROTSTAT': {id:'',sortVector: 0},
            'lDTORD':    {id:'',sortVector: 0},
            'lBEGDT':    {id:'',sortVector: 0},
            'lPROTDTMOD':{id:'',sortVector: 0}
        },
        OrdState:'',
        tblliststr:'',
        tbllst: [],
        SortFuncs: {
            ActiveCol:'',
            PrevCol: '',
            Direction: 'ASC'
        },
        PROTOSTAT:{},
        GROUP_PF_ID:{}
    },
    Data:{
        jsonData:'',
        DtoData:'',
        UIDtoData:'',
        getOrdState: function (objApp) {
            return objApp.View.OrdState;
        },
        setOrdState: function (objApp,objData) {
            objApp.View.OrdState = objData;
        },
        getJsonDataDto: function (objApp) {
            return objApp.Data.jsonData;
        },
        setJsonDataDto: function (objApp,objData) {
            objApp.Data.jsonData = objData;
        },
        getDataDto: function (objApp) {
            return objApp.Data.DtoData;
        },
        setDataDto: function (objApp,objData) {
            objApp.Data.DtoData = objData;
        },
        getUiDto: function (objApp) {
            return objApp.Data.UIDtoData;
        },
        setUiDto: function (objApp,objData) {
            objApp.Data.UIDtoData = objData;
        },
        // getOrdersFilteredDto: function (objApp) {
        //     return objApp.Data.OrdersFiltered;
        // },
        // setOrdersFilteredDto: function (objApp,objData) {
        //     objApp.Data.OrdersFiltered = objData;
        // },
        getOrdersViewDto: function (objApp) {
            return objApp.Data.OrdersView;
        },
        setOrdersViewDto: function (objApp,objData) {
            objApp.Data.OrdersView = objData;
        },
        getOrdersViewDto_strUI: function (objApp) {
            return objApp.Data.OrdersView.strUI;
        },
        setOrdersViewDto_strUI: function (objApp,objData) {
            objApp.Data.OrdersView.strUI = objData;
        },
        setBaseViewOrders: function(objApp,objData){
            objApp.Data.BaseViewOrders = objData;
        },
        getBaseViewOrders: function(objApp){
            return objApp.Data.BaseViewOrders;
        },
        setOrdersCopy: function(objApp,objData){
            objApp.Data.OrdersCopy = objData;
        },
        Orders              : [],
        OrdersCopy          : [],
        BaseViewOrders      : [],
        selFltrs     : {
            'HoldBy'   : '',
            'OrderId'  : '',
            'Patient'  : '',
            'Modality' : '',
            'Protocol' : '',
            'TimeRng'  : '',
            'HoldType' : ''
        },
        selFltrsVal     : {
            'HoldBy'   : '0',
            'OrderId'  : '0',
            'Patient'  : '0',
            'Modality' : '0',
            'Protocol' : '0',
            'TimeRng'  : '0',
            'HoldType' : '0'
        },
        OrdersView          :{
            viewId:'',
            LdDate:'',
            strUI:'',
            tblData: {},
            fltrs             : {
                'cbHldBy'   : [],
                'cbOrdId'  : [],
                'cbPat'  : [],
                'cbMod' : [],
                'cbProt' : [],
                'comboTimeRng'  : [],
                'comboHoldType' : []
            }
        },
        OrdersFiltered      :{filterId:'',tblData: {}},
        researchOrders:{
            'R143022402': true, //MRI Radiology Research Study-250
            'R143022467': true, //MRI Radiology Research Study-300
            'R143022497': true, //MRI Radiology Research Study-600
            'R143022536': true //MRI Radiology Research Study-900
        },
	    cardioOrders:{
	            'R815362':     true ,	//MRI Cardiac morph & Func w/wo Cont
	            'R815364':     true ,	//MRI Cardiac morph & Func w/o Cont + Stress
	            'R815366':     true ,	//MRI Cardiac morph & Func w/o Cont
	            'R978359':     true ,	//MRI Cardiac morph & Func w/wo Cont + Stress
	            'R69219888':   true ,	//MRI Cardiac Velocity Flow Mapping
	            'R1549149865': true ,	//MRI Iron Overload Cardiac
	            'R1582585223': true ,	//MRI Congenital Heart Disease w/+ w/o Contrast
	            'R1582585687': true  	//MRI Heart Muscle w/ + w/o Contrast
        },
        autoRouteVals: {
	            //CATALOG_CD           //ORDER_NAME
	            'R632645303': true,     //X CT 3D Image Recon - Independent Workstation
	            'R814652': true,        //X CT Bone Densitometry Study
	            'R211949507': true,    //CT 3D Image Reconstruction
	            'R814662': true,       //CT Cervical Spine w/ + w/o Contrast
	            'R392359879': true,    //CT Cervical Spine w/ + w/o Contrast LIMITED
	            'R814664': true,       //CT Cervical Spine w/ Contrast
	            'R814666': true,       //CT Cervical Spine w/o Contrast
	            'R392359937': true,     //X CT Cervical Spine w/o Contrast LIMITED
	            'R814814': true,       //CT Lumbar Spine w/ + w/o Contrast
	            'R392360525': true,    //CT Lumbar Spine w/ + w/o Contrast LIMITED
	            'R814816': true,       //CT Lumbar Spine w/ Contrast
	            'R814818': true,       //CT Lumbar Spine w/o Contrast
	            'R392360543': true,     //X CT Lumbar Spine w/o Contrast LIMITED
	            'R198701997': true,    //CT Spondylolysis w/ + w/o Contrast
	            'R198702134': true,    //CT Spondylolysis w/ Contrast
	            'R198702384': true,     //X CT Spondylolysis w/o Contrast
	            'R814900': true,       //CT Temporal Bone w/ Contrast Bilateral
	            'R814902': true,        //X CT Temporal Bone w/o Contrast Bilateral
	            'R814898': true,       //CT Temporal Bone w/ + w/o Contrast Bilateral
	            'R392360367': true,    //CT Thoracic Spine w/ + w/o Contrast LIMITED
	            'R814910': true,       //CT Thoracic Spine w/ + w/o Contrast
	            'R814912': true,       //CT Thoracic Spine w/ Contrast
	            'R814914': true,       //CT Thoracic Spine w/o Contrast
	            'R392360457': true,    //X CT Thoracic Spine w/o Contrast LIMITED
	            'R1549149585': true,   //MRI Abdomen Iron/Overload
	            'R1618441103': true,    //X MRI Elastography/Liver
	            'R69219890': true,      //X MRI Fetal / Pelvic
	            'R1618438833': true,    //X MRI Limited Spine Screening w/o Contrast
	            'R1549149497': true,    //X MRI Pituitary Iron/Overload
	            'R2185854': true        //X MRI Spectroscopy
        }
    },
    cclFuncOperators: {
        'NEW': {
            'funcId': 0,
            'OrdState':'NEW',
            'H5H6Builder':'NEW',
            'view': 'neworder'
        },
        'FUTURE': {
            'funcId': 1,
            'OrdState':'FUTURE',
            'H5H6Builder':'FUTURE',
            'view': 'futureorder'
        },
        'MODIFY': {
            'funcId': 1,
            'OrdState':'MODIFY',
            'H5H6Builder':'MODIFY',
            'view': 'modorder'
        },
        'HOLD': {
            'funcId': 1,
            'OrdState':'HOLD',
            'H5H6Builder':'HOLD',
            'view': 'holdorder'
        },
        'WAIT': {
            'funcId': 5,
            'OrdState':'WAIT',
            'H5H6Builder':'WAIT',
            'view': 'waitorder'
        },
        'HIST': {
            'funcId': 10,
            'OrdState':'WAIT',
            'H5H6Builder':'WAIT',
            'view': 'historder'
        },
        'STATUS': {
            'funcId': 9,
            'OrdState':'STATUS',
            'H5H6Builder':'STATUS',
            'view': 'statusorder'
        },
        'ACTIVE':{
            'funcId': 3,
            'OrdState':'ACTIVE',
            'H5H6Builder':'ACTIVE',
            'view': 'activeorder'
        }
    },
    funcOper            :  0,
    refresh:false,
    MPAGESOVERRIDEREFRESH: {"IMPLEMENTED":false},
    UserInterface: {},
    NewOrderPfDto: {
        btnId       : '',
        funcOperCall: 0,
        response    : false,
        orderId     : 0,
        encounterId : 0,
        personId    : 0,
        FormId      : 0,
        ActivityId  : 0,
        ProcessStep : 0,
        grpId       : '',
        MpOperation : false,
        arrPatOrders: []
    },
    NewOrderPf            : {},
    FeatureCtl: {
            F00001_0: {
                Available:true,
                Description:'Code associated with Column Sorting',
                VersionRel: '02_04_00'
            },
            F00002_0: {
                Available:false,
                Description:'Code associated with Nuclear Med Orders Sedation related to Backlog Item# ',
                VersionRel: '00_01_00'
            },
            F00003_0: {
                Available:true,
                Description:'Code associated with Mass Protocol related to Backlog Item# ',
                VersionRel: '00_01_00'
            },
            F00004_0: {
                Available:false,
                Description:'Code associated with IR Orders related to Backlog Item# ',
                VersionRel: '00_01_00'
            },
            F00005_0: {
                Available:false,
                Description:'Code associated with Fluoroscopy Orders related to Backlog Item# ',
                VersionRel: '00_01_00'
            },
            F00006_0: {
                Available:true,
                Description:'Code associated with NP By-Pass Orders related to Backlog Item#11714 ',
                VersionRel: '02_05_00'
            },
            F00007_0: {
                Available:true,
                Description:'Code associated with NM-PET ',
                VersionRel: '02_05_00'
            },
            F00008_0: {
                Available:true,
                Description:'Code associated with new Research section',
                VersionRel: '02_07_00'
            },
            F00009_0: {
                Available:true,
                Description:'Code associated with refactored MRCardio determination',
                VersionRel: '02_07_00'
            },
    		F00010_0: {
                Available:true,
                Description:'Code associated with refactored AUTO ROUTING determination',
                VersionRel: '02_07_00'
            },
            B00001: {
                Available:false,
                Description:'Code associated with Bug Item#',
                VersionRel: '00_00_00'
            }
        }
};
chla.OPRADWL.View.objCfgViewMain = {
    'NEW': {
        'MbarBtnClrFilter':chla.OPRADWL.View.HtmlBtnClearFilter.join(''),
        'SpacerBar0'      :'',
        'MbarSelPosition1':'',
        'SpacerBar1'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition2':chla.OPRADWL.View.HtmlSelPatient.join(''),
        'SpacerBar2'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition3':chla.OPRADWL.View.HtmlSelModality.join(''),
        'SpacerBar3'      :'',
        'MbarSelPosition4':''
    },
    'FUTURE': {
        'MbarBtnClrFilter':chla.OPRADWL.View.HtmlBtnClearFilter.join(''),
         'SpacerBar0'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition1':chla.OPRADWL.View.HtmlSelPatient.join(''),
        'SpacerBar1'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition2':chla.OPRADWL.View.HtmlSelModality.join(''),
        'SpacerBar2'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition3':chla.OPRADWL.View.HtmlSelProtocol.join(''),
        'SpacerBar3'      :'',
        'MbarSelPosition4':''
    },
    'WAIT': {
        'MbarBtnClrFilter':chla.OPRADWL.View.HtmlBtnClearFilter.join(''),
        'SpacerBar0'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition1':chla.OPRADWL.View.HtmlSeltimeRange.join(''),
        'SpacerBar1'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition2':chla.OPRADWL.View.HtmlSelPatient.join(''),
        'SpacerBar2'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition3':chla.OPRADWL.View.HtmlSelOrderNum.join(''),
        'SpacerBar3'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition4':chla.OPRADWL.View.HtmlSelModality.join('')
    },
    'MODIFY': {
        'MbarBtnClrFilter':chla.OPRADWL.View.HtmlBtnClearFilter.join(''),
        'SpacerBar0'      :'',
        'MbarSelPosition1':'',
        'SpacerBar1'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition2':chla.OPRADWL.View.HtmlSelOrderNum.join(''),
        'SpacerBar2'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition3':chla.OPRADWL.View.HtmlSelPatient.join(''),
        'SpacerBar3'      :'',
        'MbarSelPosition4':''
    },
    'HOLD': {
        'MbarBtnClrFilter':chla.OPRADWL.View.HtmlBtnClearFilter.join(''),
        'SpacerBar0'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition1':chla.OPRADWL.View.HtmlSelHoldBy.join(''),
        'SpacerBar1'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition2':chla.OPRADWL.View.HtmlSelHoldType.join(''),
        'SpacerBar2'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition3':chla.OPRADWL.View.HtmlSelPatient.join(''),
        'SpacerBar3'      :chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition4':chla.OPRADWL.View.HtmlSelModality.join('')
    },
    'ACTIVE': {
        'MbarBtnClrFilter': chla.OPRADWL.View.HtmlBtnClearFilter.join(''),
        'SpacerBar0'      : chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition1': chla.OPRADWL.View.HtmlSelPatient.join(''),
        'SpacerBar1'      : chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition2': chla.OPRADWL.View.HtmlSelModality.join(''),
        'SpacerBar2'      : chla.OPRADWL.View.HtmlSpacer.join(''),
        'MbarSelPosition3': chla.OPRADWL.View.HtmlSelProtocol.join(''),
        'SpacerBar3'      : '',
        'MbarSelPosition4': ''
    },
    'STATUS': {
        'MbarBtnClrFilter': chla.OPRADWL.View.HtmlBtnClearFilter.join(''),
        'SpacerBar0'      : '',
            'MbarSelPosition1': '',//'SelPatient'
            'SpacerBar1'      : '',
            'MbarSelPosition2': '',//'SelModality'
            'SpacerBar2'      : '',
            'MbarSelPosition3': '',//'SelProtocol'
            'SpacerBar3'      : '',
            'MbarSelPosition4': '' //''
    },
    'HISTORY': {
        'MbarBtnClrFilter': chla.OPRADWL.View.HtmlBtnClearFilter.join(''),
        'SpacerBar0'      : '',
            'MbarSelPosition1': '',//'SelPatient'
            'SpacerBar1'      : '',
            'MbarSelPosition2': '',//'SelModality'
            'SpacerBar2'      : '',
            'MbarSelPosition3': '',//'SelProtocol'
            'SpacerBar3'      : '',
            'MbarSelPosition4': '' //''
    }
};

chla.about = function (){
    var aboutVal = [];
    aboutVal.push('<table>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">Application:</td><td>');
    aboutVal.push(chla.eApps.appName);
    aboutVal.push('</td></tr>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">Version:</td><td>');
    aboutVal.push(chla.eApps.Version);
    aboutVal.push('</td></tr>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">Comments:</td><td>');
    aboutVal.push(chla.eApps.eComments);
    aboutVal.push('</td></tr>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">Build Date:</td><td>');
    aboutVal.push(chla.eApps.eBuildDate);
    aboutVal.push('</td></tr>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">Folder:</td><td>');
    aboutVal.push(chla.eApps.eLocation.replace(/\//g,'-'));
    aboutVal.push('</td></tr>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">CCL Program:</td><td>');
    aboutVal.push(chla.eApps.cclProgram);
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">IPRADWL Program:</td><td>');
    aboutVal.push(chla.eApps.inpatientURL);
    aboutVal.push('</td></tr>');
    aboutVal.push('</td></tr>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">Test Environment:</td><td>');
    aboutVal.push(chla.eApps.testEnvironment.replace(/\//g,'-'));
    aboutVal.push('</td></tr></table>');
    CommentsWindow(aboutVal.join(''),'Radiology OP WorkList - about');
};
chla.about2 = function (){
    var aboutVal = [];
    aboutVal.push('<table style="width: 725px;">');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">Application:</td><td>');
    aboutVal.push(chla.eApps.appName);
    aboutVal.push('</td></tr>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">Version:</td><td>');
    aboutVal.push(chla.eApps.Version);
    aboutVal.push('</td></tr>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">Build Date:</td><td>');
    aboutVal.push(chla.eApps.eBuildDate);
    aboutVal.push('</td></tr>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">Comments:</td><td>');
    aboutVal.push(chla.eApps.eComments);
    aboutVal.push('</td></tr>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">Folder:</td><td>');
    aboutVal.push(chla.eApps.eLocation.replace(/\//g,'-'));
    aboutVal.push('</td></tr>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">CCL Program:</td><td>');
    aboutVal.push(chla.eApps.cclProgram);
    aboutVal.push('</td></tr>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">IPRADWL Program:</td><td>');
    aboutVal.push(chla.eApps.inpatientURL.replace(/\//g,'-'));
    aboutVal.push('</td></tr>');
    aboutVal.push('<tr><td style="font-weight:800;padding-right:10px;">Test Environment:</td><td>');
    aboutVal.push(chla.eApps.testEnvironment);
    aboutVal.push('</td></tr></table>');
    CommentsWindow2(aboutVal.join(''),'Radiology OP WorkList - about');
};

chla.OPRADWL.View.tblLdSort = function () {
    var  SortFuncs = chla.OPRADWL.View.SortFuncs;
    chla.OPRADWL.View.tbllst.forEach(function (item) {
        if (chla.OPRADWL.View.tbllststr.indexOf(item) > -1) {
            document.querySelector("#" + item + " > thead > tr > th:nth-child(" + SortFuncs.ColId + ")").click();
        }
    });
    $('div#shadowdiv').css('display','none');
};
chla.OPRADWL.View.tblLd = function() {
    chla.OPRADWL.View.SortFuncs.Direction = '';
    chla.OPRADWL.View.tbllst.forEach(function (item) {

        if (chla.OPRADWL.View.tbllststr.indexOf(item) > -1)  {
            // noinspection JSUnusedGlobalSymbols
            tsorter.create(item, 0,
                {
                    tag_name: function (row) {
                        return this.getCell(row).getAttribute("data-lbl");
                    },
                    orderid: function (row) {
                        return parseFloat(this.getCell(row).getAttribute("data-lbl"));
                    }
                }
            )
        }
    });
};
(function () {
    var blackbirdHtml = [
        '<div style="width:100%; float:left;">',
        '&nbsp;Blackbird:&nbsp;',
        '<a href="javascript:eAppBlkBrd.toggle();">toggle</a>&nbsp;&nbsp;',
        '<a href="javascript:eAppBlkBrd.move();">move</a>&nbsp;&nbsp;',
        '<a href="javascript:eAppBlkBrd.resize();">resize</a>&nbsp;&nbsp;',
        '<a href="javascript:eAppBlkBrd.clear();">clear</a>',
        '</div>'
    ];
    if (chla.eApps.loggingControl.showBlackbird){
        chla.eApps.blackbirdControl = blackbirdHtml.join('');
        if (typeof chla.eAppsUtil !== 'undefined'){
            if (typeof chla.eAppsUtil.Blackbird !== 'undefined'){
            chla.eAppsUtil.Logger = window[ chla.eAppsUtil.Blackbird.NAMESPACE ];//eAppBlkBrd
            }
        }
    }
}());
