'use strict';
/**
 *
 */
chla.OPRADWL.overrideMpagesRefresh = function()     {
    chla.OPRADWL.ResetDom(chla.OPRADWL);
    chla.OPRADWL.GetOrdersData(chla.OPRADWL.Data.getOrdState(chla.OPRADWL), chla.OPRADWL);
};
/**
 *
 * @param aParam
 */
chla.OPRADWL.appInit = function(aParam){
    if (typeof chla.eAppsUtil !== 'undefined'){
        if (typeof chla.eAppsUtil.Blackbird !== 'undefined'){
            if(chla.eApps.loggingControl.showBlackbird) {
                $('div#BB1').html(chla.eApps.blackbirdControl);
                chla.eAppsUtil.Logger = window[chla.eAppsUtil.Blackbird.NAMESPACE];//eAppBlkBrd
                chla.eAppsUtil.Blackbird.initializeBB();
            }
        }
    }
    if (chla.eApps.testEnvironment=== false) {
        $('div#CernerBaseContainer').remove();
    }
    chla.OPRADWL.render(aParam,chla.OPRADWL);
};
/**
 *
 * @param aParam
 * @param aAppObj
 */
chla.OPRADWL.render = function (aParam,aAppObj) {
    /**
     *
     * @param aParam
     * @param aAppObj
     */
    aAppObj.processInit =  function(aParam,aAppObj) {
        window["RefreshOverRide"] = chla.OPRADWL.overrideMpagesRefresh;
        if (window.external && ('MPAGESOVERRIDEREFRESH' in window.external)){
            window.external.MPAGESOVERRIDEREFRESH("RefreshOverRide()");
        }
        aAppObj.Data.setOrdState(aAppObj,aParam);
        aAppObj.ResetDom = function (aAppObj) {
            var viewMod = aAppObj.Data.getOrdState(aAppObj),
                cfgObj = aAppObj.View.objCfgViewMain[viewMod],
                vHeight;
            aAppObj.View.Height = $('div#BaseContainer').height();
            vHeight = aAppObj.View.Height;
            cfgObj.viewportHeight = [
                'height: ',
                (vHeight - 99),  //67
                'px;'
            ].join('');
            cfgObj.viewportHeight2 = [
                'height: ',
                (vHeight - 110),  //70
                'px;'
            ].join('');
            cfgObj.viewportHeight3 = [
                'height: ',
                (vHeight - 102),  //102
                'px;'
            ].join('');
            LogIt({
                logType:'LogInfo',
                arrParams: [
                    'vHeight',
                    aAppObj.View.Height,
                    ' : ',
                    cfgObj.viewportHeight,
                    ' : ',
                    cfgObj.viewportHeight2,
                    ' : ',
                    cfgObj.viewportHeight3
                ]
            });
            $("div#CCmPageContainer_A").height((vHeight - 55));//25
            document.getElementById("CCmPageContainer_A").innerHTML = chla.eApps.gFuncs.parseTemplate(
                aAppObj.View.HtmlViewMain.join(''),cfgObj
            );
            document.getElementById("oprdwlToolbar").innerHTML      = aAppObj.View.processOprdwlToolBar(viewMod,aAppObj);
        };
        chla.OPRADWL.onreadystatechange  = function () {
            var msgData,
                patID = this,
                arrWrk=[],
                jsonData,
                appObj;

            if (chla.eApps.loggingControl.showOrderData ){
                arrWrk.push(
                    'readyState: ' ,
                    patID.readyState,
                    ' <br/>',
                    'status <br/>',
                    patID.status
                )  ;
                LogIt({
                    logType:'LogInfo',
                    arrParams: arrWrk
                });
            }
            if (patID.readyState === 4 && patID.status === 200) {
                appObj = patID.appObj;
                LogIt({
                    logType:'Profile',
                    arrParams: ['RequestingData']
                });
                LogIt({
                    logType:'Profile',
                    arrParams: ['RenderTreeStructure']
                });
                msgData = patID.responseText;
                if (msgData !== null) {
                    jsonData = eval('(' + msgData + ')');
                    if (chla.eApps.loggingControl.showOrderData ){
                        LogIt({
                            logType:'LogInfo',
                            arrParams: ['GetOrderData <br/>' , msgData]
                        });
                    }
                }
                if (jsonData) {
                    appObj.Data.setJsonDataDto(appObj,getRootObj(jsonData));
                    if ( aAppObj.Data.getOrdState(aAppObj) === 'INPATIENT'){
                        appObj.processCtlIP(appObj);
                    } else {
                        appObj.processCtl(appObj);
                    }
                    LogIt({
                        logType:'Profile',
                        arrParams: ['RenderTreeStructure']
                    });
                }
            } else  if ( patID.status  > 200) {
                arrWrk.length = 0;
                LogIt({
                    logType:'Profile',
                    arrParams: ['RequestingData']
                });
                arrWrk.push('<span style="color:red;font-size:16px;"> Http/CCL:<br/>ReadyState: ');
                arrWrk.push(patID.readyState);
                arrWrk.push('<br/>Status: ');
                arrWrk.push(patID.status);
                arrWrk.push( "</span>");
                LogIt({
                    logType:'LogInfo',
                    arrParams: arrWrk
                });
                $('div#prog3').html(arrWrk.join('') );
            }
        };

        /**
         *
         * @param viewMod {string}
         * @param objApp
         */
        chla.OPRADWL.GetOrdersData =function(viewMod,objApp) {
            var patID,
                arrWrk = [];

            LogIt({
                logType:'Profile',
                arrParams: ['RequestingData']
            });
            patID = new chlaMpageApi.getXMLHttpRequest();
            patID.appObj = objApp;
            patID.open('GET', chla.eApps.cclProgram);
            patID.onreadystatechange = objApp.onreadystatechange;
            if (viewMod === 'INPATIENT'){
                arrWrk.push(
                    '^MINE^,',
                    objApp.cclFuncOperators[viewMod].funcId,
                    ',^^,^^,^^,^^,^',
                    objApp.cclFuncOperators[viewMod].OrdState,
                    '^,0,^^,^^,0,0,0,0,value($USR_PersonID$)'
                )
            } else {

                arrWrk.push(
                    '^MINE^,',
                    objApp.cclFuncOperators[viewMod].funcId,
                    ',^^,^^,^^,^^,^',
                    objApp.cclFuncOperators[viewMod].OrdState,
                    '^,0,^^,^^,0,0,0,0,value($USR_PersonID$)'
                );
            }
            LogIt({
                logType:'LogInfo',
                arrParams: [
                    'CCL: ',
                    chla.eApps.cclProgram,
                    ' Params: ',
                    arrWrk.join('')]
            });
            patID.send(arrWrk.join(''));


        };
        aAppObj.ResetDom(aAppObj);
        aAppObj.GetOrdersData(aAppObj.Data.getOrdState(aAppObj), aAppObj);
    };
    /**
     *
     * @param aAppObj
     */
    aAppObj.processData =  function(aAppObj) {
        var objJsonData = aAppObj.Data.getJsonDataDto(aAppObj),
            Orders = (aAppObj.Data.getOrdState(aAppObj) === 'ACTIVE'? objJsonData.ORDERS:objJsonData.SCHORDERS );
        return aAppObj.crTrSt.nP(Orders,aAppObj,false);
    };
    /**
     *
     * @param aAppObj
     */
    aAppObj.processDataIP =  function(aAppObj) {
        var objJsonData = aAppObj.Data.getJsonDataDto(aAppObj),
            Orders =  objJsonData.ORDERS;
        return aAppObj.crTrSt.nP(Orders,aAppObj,false);
    };
    /**
     *
     * @param aAppObj {*} application base object
     * @param aDataDto {*} type Dto.tblData element
     * @returns {string}
     */
    aAppObj.processUI  = function (aAppObj,aDataDto) {
        var arrTreeTbl = [],
            strOrdState = aAppObj.Data.getOrdState(aAppObj),
            baseTblHdr = [
                '<div id="tblHeader">',
                ' <table style="font-size: 10px;">',
                ' <tr>'
            ],
            baseTblAll = [
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width:{0};padding:0;">',
                '<!--suppress HtmlUnknownAttribute --><div class="eapps-x-col-header" style="margin: 0; position: relative; "  {4} data-id="{5}">',
                '<!--suppress HtmlUnknownAttribute --><div class="eapps-x-col-header-inner"  style="padding:0;text-align: center;{1}" {2}>',
                '<div class="eapps-x-col-header-text" style="white-space: nowrap;background-color: transparent;font-size: 10px;color:#999999;{6}" >{3}</div></div>',

                //'<div class="eapps-x-col-header-trigger"  style="height: 25px;" {4} data-id="{5}"></div>',
                '</div></th>'
            ],
            baseTblFtr = [
                ' </tr></table></div><div id="tblBodyDiv" style="height:',
                aAppObj.View.Height - 134,
                'px;overflow-y: scroll;border: 1px solid #5d744b;">'
            ],
            hdrs = {
                newview:[{
                    colwdth: '138px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Name',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'MRN',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '130px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Location',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Priority',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '93px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Order ID',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '225px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Order',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '90px;',
                    colLnHt: ' ',
                    colcss1: ' ',
                    colname: 'Protocol Status',
                    colbehv: ' ',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '80px;',
                    colLnHt: 'line-height: 1.2em;',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Radiologist\'s<br/>Discretion',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:1em;'
                }, {
                    colwdth: '115px;',
                    colLnHt: 'line-height: 1.2em;',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Anesthesia<br/>Sedation',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:1em;'
                }, {
                    colwdth: '125px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Date Ordered',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'

                // }, {
                //     colwdth: '125px;',
                //     colLnHt: ' ',
                //     colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                //     colname: 'Req Exam Date',
                //     colbehv: 'onclick="doSortAction(this);"',
                //     collblh: ' line-height:2em;'
                }],
                inpatientview: [{
                    colwdth: '138px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Name',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'MRN',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Age',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: ' ',
                    colname: 'Ht/Wt',
                    colbehv: ' '
                }, {
                    colwdth: '130px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Location',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '25px;',
                    colLnHt: 'line-height: .5em;',
                    colcss1: ' ',
                    colname: '<img src="images/isolation2.png" title="Isolation" alt="Isolation" width=16, height=18 />',
                    colbehv: ' ',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '65px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'AccessionID',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Priority',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '93px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Order ID',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '225px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Order',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '25px;',
                    colLnHt: 'line-height: .5em;',
                    colcss1: ' ',
                    colname: '<img src="images/comments4.png" title="Exam Protocol Comments" alt="Comments" width=16, height=18 />',
                    colbehv: ' ',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '90px;',
                    colLnHt: ' ',
                    colcss1: ' ',
                    colname: 'Protocol Status',
                    colbehv: ' ',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '25px;',
                    colLnHt: 'line-height: .5em;',
                    colcss1: ' ',
                    colname: '<img src="images/pageIcon.png" title="Contrast Screening and Administration PowerForm Signed" alt="Signed" width=16, height=18 />',
                    colbehv: ' '
                }, {                    colwdth: '25px;',
                    colLnHt: 'line-height: .5em;',
                    colcss1: ' ',
                    colname: '<img src="images/ContraINDyellow11x13.png" title="Contrast Contraindication" alt="Contraindication" width=16, height=18 />',
                    colbehv: ' ',
                    collblh: ' line-height:2em;'
                }, {
                    //     colwdth: '80px;',
                    //     colLnHt: 'line-height: 1.2em;',
                    //     colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    //     colname: 'Radiologist\'s<br/>Discretion',
                    //     colbehv: 'onclick="doSortAction(this)"'
                    // }, {
                    colwdth: '115px;',
                    colLnHt: 'line-height: 1.2em;',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Anesthesia<br/>Sedation',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:1em;'
                }, {
                    //     colwdth: '125px;',
                    //     colLnHt: ' ',
                    //     colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    //     colname: 'Protocolled By',
                    //     colbehv: 'onclick="doSortAction(this)"'
                    // }, {
                    colwdth: '125px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Date Ordered',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '125px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Last Updated',
                    colbehv: 'onclick="doSortAction(this);"',
                    collblh: ' line-height:2em;'
                    // }, {
                    //     colwdth: '125px;',
                    //     colLnHt: ' ',
                    //     colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    //     colname: 'Hold / Status',
                    //     colbehv: 'onclick="doSortAction(this);"'
                }],
                futureview: [{
                    colwdth: '138px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Name',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'MRN',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Age',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: ' ',
                    colname: 'Ht/Wt',
                    colbehv: ' ',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '130px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Location',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Priority',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '93px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Order ID',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '25px;',
                    colLnHt: 'line-height: .5em;',
                    colcss1: ' ',
                    colname: '<img src="images/ok15px.png" title="Exam Protocol Complete" alt="PF section Completed" width=16, height=18 />',
                    colbehv: ' ',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '225px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Order',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '25px;',
                    colLnHt: 'line-height: .5em;',
                    colcss1: ' ',
                    colname: '<img src="images/comments4.png" title="Exam Protocol Comments" alt="Comments" width=16, height=18 />',
                    colbehv: ' ',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '90px;',
                    colLnHt: ' ',
                    colcss1: ' ',
                    colname: 'Protocol Status',
                    colbehv: ' ',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '80px;',
                    colLnHt: 'line-height: 1.2em;',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Radiologist\'s<br/>Discretion',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:1em;'
                }, {
                    colwdth: '115px;',
                    colLnHt: 'line-height: 1.2em;',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Anesthesia<br/>Sedation',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:1em;'
                }, {
                    colwdth: '125px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Protocolled By',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '125px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Date Ordered',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '125px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Last Updated',
                    colbehv: 'onclick="doSortAction(this);"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '125px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Hold / Status',
                    colbehv: 'onclick="doSortAction(this);"',
                    collblh: ' line-height:2em;'
                }],
                holdview: [{
                    colwdth: '138px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Name',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'MRN',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Age',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: ' ',
                    colname: 'Ht/Wt',
                    colbehv: ' ',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '130px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Location',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '55px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Priority',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '93px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Order ID',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '225px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Order',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '25px;',
                    colLnHt: 'line-height: .5em;',
                    colcss1: ' ',
                    colname: '<img src="images/comments4.png" title="Exam Protocol Comments" alt="Comments" width=16, height=18 />',
                    colbehv: ' ',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '90px;',
                    colLnHt: ' ',
                    colcss1: ' ',
                    colname: 'Protocol Status',
                    colbehv: ' ',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '80px;',
                    colLnHt: 'line-height: 1.2em;',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Radiologist\'s<br/>Discretion',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:1em;'
                }, {
                    colwdth: '115px;',
                    colLnHt: 'line-height: 1.2em;',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Anesthesia<br/>Sedation',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:1em;'
                }, {
                    colwdth: '125px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Protocolled By',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '125px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Date Ordered',
                    colbehv: 'onclick="doSortAction(this)"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '125px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Last Updated',
                    colbehv: 'onclick="doSortAction(this);"',
                    collblh: ' line-height:2em;'
                }, {
                    colwdth: '125px;',
                    colLnHt: ' ',
                    colcss1: 'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                    colname: 'Hold / Status',
                    colbehv: 'onclick="doSortAction(this);"',
                    collblh: ' line-height:2em;'
                }],
                modifyview:
                    [{
                        colwdth:'138px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Name',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'125px;',
                        colLnHt:' ',
                        colcss1:' ',
                        colname:'Hold / Status',
                        colbehv:' ',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'55px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'MRN',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'55px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Age',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'55px;',
                        colLnHt:' ',
                        colcss1:' ',
                        colname:'Ht/Wt',
                        colbehv:' ',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'130px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Location',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'55px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Priority',
                        colbehv:'onclick="doSortAction(this)"'
                    },{
                        colwdth:'93px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Order ID',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'225px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Order',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'25px;',
                        colLnHt:'line-height: .5em;',
                        colcss1:' ',
                        colname:'<img src="images/comments4.png" title="Exam Protocol Comments" alt="Comments" width=16, height=18 />',
                        colbehv:' ',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'90px;',
                        colLnHt:' ',
                        colcss1:' ',
                        colname:'Protocol Status',
                        colbehv:' ',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'80px;',
                        colLnHt:'line-height: 1.2em;',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Radiologist\'s<br/>Discretion',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:1em;'
                    },{
                        colwdth:'115px;',
                        colLnHt:'line-height: 1.2em;',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Anesthesia<br/>Sedation',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:1em;'
                    },{
                        colwdth:'125px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Date Ordered',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'125px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Last Updated',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    }],
                activeview:
                    [{
                        colwdth:'138px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Name',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'55px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Age',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'55px;',
                        colLnHt:' ',
                        colcss1:' ',
                        colname:'Ht/Wt',
                        colbehv:' ',
                        collblh: ' line-height:2em;'
                    },{
//                         colwdth:'130px;',
//                         colLnHt:' ',
//                         colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
//                         colname:'Location',
//                         colbehv:'onclick="doSortAction(this)"',
//                         collblh: ' line-height:2em;'
//                     },{
                        colwdth:'55px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Priority',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'93px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'AccessionID',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'93px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Order ID',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'93px;',
                        colLnHt:' ',
                        colcss1:' ',
                        colname:'Order Status',
                        colbehv:' ',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'225px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Order',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'25px;',
                        colLnHt:'line-height: .5em;',
                        colcss1:' ',
                        colname:'<img src="images/comments4.png" title="Exam Protocol Comments" alt="Comments" style="width:15px;height:18px" />',
                        colbehv:' ',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'90px;',
                        colLnHt:' ',
                        colcss1:' ',
                        colname:'Protocol Status',
                        colbehv:' ',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'115px;',
                        colLnHt:'line-height: 1.2em;',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Anesthesia<br/>Sedation',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:1em;'
                    },{
                        colwdth:'80px;',
                        colLnHt:'line-height: 1.2em;',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Radiologist\'s<br/>Discretion',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:1em;'
                    },{
                        colwdth:'25px;',
                        colLnHt:'line-height: .5em;',
                        colcss1:' ',
                        colname:'<img src="images/pageIcon.png" title="Contrast Screening and Administration PowerForm Signed" alt="Sig" width=11, height=13 />',
                        colbehv:' ',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'25px;',
                        colLnHt:'line-height: .5em;',
                        colcss1:' ',
                        colname:'<img src="images/ContraINDyellow11x13.png" title="Contrast Contraindication" alt="Contraindication" width=11, height=13 />',
                        colbehv:' ',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'125px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Date Ordered',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'125px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Req Exam Date',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    },{
                        colwdth:'125px;',
                        colLnHt:' ',
                        colcss1:'onmouseover="classAdd1(this)" onmouseout="classRemove1(this)"',
                        colname:'Last Updated',
                        colbehv:'onclick="doSortAction(this)"',
                        collblh: ' line-height:2em;'
                    }]
            },
            baseTbl3 = [
                '<div id="tblHeader">',
                ' <table style="font-size: 10px;">',
                ' <tr>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 138px;">Name</th>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 55px;">MRN</th>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 55px;">Age</th>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 55px;">Ht/Wt</th>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 130px;">Location</th>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 55px;">Priority</th>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 93px;">Order ID</th>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 225px;">Order</th>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 25px;"><img src="images/comments4.png" title="Exam Protocol Comments" alt="Comments" width=16, height=18 /></th>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 90px;">Protocol Status</th>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 115px;">Anesthesia<br/>Sedation</th>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 80px;">Radiologist\'s<br/>Discretion</th>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 125px;">Date Ordered</th>',
                ' <th style="border-right:1px solid lightgrey;text-align: center;vertical-align: middle;width: 125px;">Hold / Status</th>',
                ' <th style="text-align: center;vertical-align: middle;width: 125px;">Last Updated</th>',
                ' </tr></table></div><div id="tblBodyDiv" style="height:',
                aAppObj.View.Height - 102,
                'px;overflow-y: scroll;border: 1px solid #5d744b;">'
            ],
            arrSections,
            arSecW,
            sWk;
        arrSections = Object.keys(aDataDto);
        arSecW = arrSections.slice();
        arSecW.push('xx');
        arSecW.unshift('xx');
        sWk = arSecW.join(':');
        if (sWk.indexOf(':AR3:') > -1 ){
            sWk = sWk.replace(':AR3','').replace('xx:','').replace(':xx','');
            arrSections = sWk.split(':');
            arrSections.push('AR3');
        }
        /**
         *
         * @param aLbl
         * @param aSectId
         * @param abdCont
         * @param aCount
         * @returns {string}
         */
        function formatModRow (aLbl,aSectId,abdCont,aCount) {
            var retVal,
                tmplCfg = {
                    idLabel             :  aSectId,
                    TLabel1             :  aLbl,
                    SectionCnt          : 'auto',
                    SectionID           :  '',
                    SectionDivID        :  '',
                    SectionCntVal       :  aCount,
                    SectionClosed       : 'auto',
                    Disabled_Lbl        : 'auto',
                    CustIcon            : 'auto',
                    CustMargin          : '',
                    HideIfEmpty         : 'false',
                    ContentBody         : abdCont,
                    UnformatBodyVal     : '',
                    HdrCss              : '',
                    fo_cat_type         : '',
                    OvrrdHdrCss         : '',
                    OvrrdHdrStyle       : '',
                    hovertip            : '',
                    HdrLayout           : '',
                    SubSecContentStyle  : '',
                    OvrrdContentBodyCss : '',
                    defaultHeightHdr    : '',
                    defaultHeightFtr    : '',
                    TemplateType        : 'H5',
                    SectionTheme        : '',
                    toggleSwitch        : ''
                };
            retVal = chla.eApps.gFuncs.SectionCtl.generateHTML(tmplCfg);
            return retVal;
        }
        /**
         *
         * @param aLbl
         * @param aSectId
         * @param abdCont
         * @param aCount
         * @returns {string}
         */
        function formatProtRow (aLbl,aSectId,abdCont,aCount) {
            var retVal,
                tmplCfg = {
                    idLabel             :  aSectId,
                    TLabel1             :  aLbl,
                    SectionCnt          : 'auto',
                    SectionID           :  '',
                    SectionDivID        :  '',
                    SectionCntVal       :  aCount,
                    SectionClosed       : 'closed',
                    Disabled_Lbl        : 'auto',
                    CustIcon            : 'auto',
                    CustMargin          : 'margin-left:15px;', //Used on a H6 header
                    HideIfEmpty         : 'false',
                    ContentBody         : abdCont,
                    UnformatBodyVal     : '',
                    HdrCss              : '',
                    fo_cat_type         : '',
                    OvrrdHdrCss         : '',
                    OvrrdHdrStyle       : '',
                    hovertip            : '',
                    HdrLayout           : '',
                    SubSecContentStyle  : '',
                    OvrrdContentBodyCss : '',
                    defaultHeightHdr    : '',
                    defaultHeightFtr    : '',
                    TemplateType        : 'H6',
                    SectionTheme        : '',
                    toggleSwitch        : ''
                };
            retVal = chla.eApps.gFuncs.SectionCtl.generateHTML(tmplCfg);
            return retVal;
        }
        /**
         *
         * @param abdCont {Array} type RowDTO
         * @param aStrOrdState {string}
         * @param tblId
         * @returns {string}
         */
        function  formatOrdRow (abdCont,aStrOrdState,tblId) {
            var retVal = ['<table '] ;
            if( aStrOrdState === 'FUTURE' ||
                aStrOrdState === 'WAIT' ||
                aStrOrdState === 'HOLD' ) {
                chla.OPRADWL.View.tbllststr += ('tbl'+ tblId);
                chla.OPRADWL.View.tbllst.push('tbl' + tblId);
                retVal.push( 'ID="tbl', tblId,'"  class="sortable">');
                retVal.push(
                    '<THEAD><tr style="line-height: 11px;display: none;" >',
                    '<th id="C1"  data-tsorter="tag_name">C1</th>',
                    '<th id="C2" style="width:55px;"  data-tsorter="orderid">C2',
                    '</th><th id="C3" style="width:55px;" data-tsorter="orderid">C3',
                    '</th><th id="C4" style="width:55px;">C4',
                    '</th><th id="C5" style="width:130px;">C5',
                    '</th><th id="C6" style="width:55px;" data-tsorter="tag_name">C6');
                if (aStrOrdState === 'FUTURE') {
                    retVal.push('</th><th id="C6a" style="width:25px;">C6a');
                }
                retVal.push('</th><th id="C7" style="width:93px;" data-tsorter="orderid">C7',
                    '</th><th id="C8" style="width:225px;" data-tsorter="tag_name" >C8',
                    '</th><th id="C9" style="width:25px;">C9',
                    '</th><th id="C10" style="width:90px;">C10',
                    '</th><th id="C11" style="width:80px;">C11',
                    '</th><th id="C12" style="width:115px;">C12',
                    '</th><th id="C13" style="width:125px;">C13',
                    '</th><th id="C14" style="width:125px;" data-tsorter="tag_name" >C14',
                    '</th><th id="C15" style="width:125px;" data-tsorter="tag_name" >C15',
                    '</th><th id="C16" style="width:115px;" data-tsorter="tag_name" >C16',
                    '</th></tr></THEAD><TBODY>');
                abdCont.forEach(
                    function (value) {
                        retVal.push(
                            '<tr style="line-height: 11px;" ><td style="text-align: left;border-bottom:1px solid lightgrey;width:138px;font-size:11px;"',
                            ' data-lbl="',
                            value.vNamelbl,
                            '">&nbsp;',
                            value.vName,
                            '</td><td style="width:55px;"',
                            ' data-lbl="',
                            value.vMRNlbl,
                            '">',
                            value.vMrn,
                            '</td><td style="width:55px;" ',
                            ' data-lbl="',
                            value.vAgelbl,
                            '">',
                            value.vAge,
                            '</td><td style="width:55px;">',
                            value.vHW,
                            '</td><td style="width:130px;">',
                            value.vLoc,
                            '</td><td style="width:55px;"',
                            ' data-lbl="',
                            value.vPriorlbl,
                            '">',
                            value.vPrior,
                            '</td><td style="width:93px;"',
                            ' data-lbl="',
                            value.vOrdIdlbl,
                            '">',
                            value.vOrdId);
                        if (aStrOrdState === 'FUTURE') {
                            retVal.push(
                                '</td><td id="SC',
                                value.vOrdIdlbl,
                                '" style="width:25px;">',
                                '&nbsp;');
                        }
                        retVal.push(
                            '</td><td style="width:225px;"',
                            ' data-lbl="',
                            value.vOrderlbl,
                            '">',
                            value.vOrder,
                            '</td><td style="width:25px;">',
                            value.vCmt, //icon img html or &nbsp;
                            '</td><td style="width:90px;">',
                            value.vProtStat,
                            '</td><td style="width:80px;">',
                            value.vRadDisc,
                            '</td><td style="width:115px;font-size: 11px;">',
                            value.vSedation,
                            '</td><td style="width:125px;font-size: 11px;">',
                            value.vProtBy.replace(/\(.*\)/g,''),
                            '</td><td style="width:125px;" ',
                            ' data-lbl="',
                            value.vOrdDtlbl,
                            '">',
                            (value.vOrdDt === '--' ? value.vOrdDt: value.vOrdDt.replace(/-/g,'/')),
                            '</td><td style="width:125px;" ',
                            ' data-lbl="',
                            value.vUptDtlbl,
                            '">',
                            (value.vUptDt === '--'? value.vUptDt: value.vUptDt.replace(/-/g,"/")),
                            '</td><td style="width:115px;" ',
                            ' data-lbl="',
                            value.vHldStslbl,
                            '">',
                            value.vHldSts,
                            '</td></tr>'
                        );
                    }
                );
                // }else if (
                //     aStrOrdState === 'WAIT' ||
                //     aStrOrdState === 'HOLD' ) {
                //     abdCont.forEach(
                //         function (value) {
                //             retVal.push(
                //                 '<tr style="line-height: 11px;" ><td style="text-align: left;border-bottom:1px solid lightgrey;width:138px;font-size:11px;">&nbsp;',
                //                 value.vName,
                //                 '</td><td style="width:55px;">',
                //                 value.vMrn,
                //                 '</td><td style="width:55px;">',
                //                 value.vAge,
                //                 '</td><td style="width:55px;">',
                //                 value.vHW,
                //                 '</td><td style="width:130px;">',
                //                 value.vLoc,
                //                 '</td><td style="width:55px;">',
                //                 value.vPrior,
                //                 '</td><td style="width:93px;">',
                //                 value.vOrdId,
                //                 '</td><td style="width:225px;">',
                //                 value.vOrder,
                //                 '</td><td style="width:25px;">',
                //                 value.vCmt, //icon img html or &nbsp;
                //                 '</td><td style="width:90px;">',
                //                 value.vProtStat,
                //                 '</td><td style="width:115px;font-size: 11px;">',
                //                 value.vSedation,
                //                 '</td><td style="width:80px;font-size: 11px;">',
                //                 value.vRadDisc,
                //                 '</td><td style="width:125px;">',
                //                 (value.vOrdDt === '--' ? value.vOrdDt: value.vOrdDt.replace(/-/g,'/')),
                //                 // '</td><td style="width:125px;">',
                //                 // value.vReqExmDt,
                //                 '</td><td style="width:125px;">',
                //                 (value.vUptDt === '--'? value.vUptDt: value.vUptDt.replace(/-/g,"/")),
                //                 '</td><td style="width:115px;">',
                //                 value.vHldSts,
                //                 '</td></tr>'
                //             );
                //         }
                //     );
            }else if( aStrOrdState === 'ACTIVE') {
                chla.OPRADWL.View.tbllststr += ('tbl'+ tblId);
                chla.OPRADWL.View.tbllst.push('tbl' + tblId);
                retVal.push( 'ID="tbl', tblId,'"  class="sortable">');
                retVal.push(
                    '<THEAD><tr style="line-height: 11px;display: none;" >',
                    '<th id="C1"  style="width:138px;" data-tsorter="tag_name">C1 </th>',   //Name
                    '<th id="C2"  style="width:55px;"  data-tsorter="orderid" >C2 </th>',   //Age
                    '<th id="C3"  style="width:55px;"  >C3</th>',                           //Ht/Wt
                    '<th id="C4"  style="width:55px;"  data-tsorter="tag_name">C4  </th>',  //Priority
                    '<th id="C5"  style="width:93px;"  >C5</th>',                           //AccessionID
                    '<th id="C6"  style="width:93px;"  data-tsorter="tag_name">C6  </th>',  //OrderID
                    '<th id="C7"  style="width:93px;"  >C7</th>',                           //Order Status
                    '<th id="C8"  style="width:225px;" data-tsorter="tag_name">C8 </th>',   //ORDER
                    '<th id="C9"  style="width:25px;"  >C9</th>',                           //Comments
                    '<th id="C10" style="width:90px;"  >C10</th>',                          //Protocol Status
                    '<th id="C11" style="width:115px;" >C11</th>',                          //Anesthesia
                    '<th id="C12" style="width:80px;"  data-tsorter="tag_name" >C12</th>',  //Discretion
                    '<th id="C13" style="width:25px;"  >C13</th>',                          //Contrast Screening
                    '<th id="C14" style="width:115px;" data-tsorter="tag_name">C14</th>',   //Req exam Date
                    '<th id="C15" style="width:115px;" data-tsorter="tag_name">C15</th>',   //Date Ordered
                    '<th id="C16" style="width:115px;" data-tsorter="tag_name">C16</th>',   //Date Updated
                    '</tr></THEAD><TBODY>');
                abdCont.forEach(
                    function (value) {
                        retVal.push(
                            '<tr style="line-height: 11px;" ><td style="text-align: left;border-bottom:1px solid lightgrey;width:138px;font-size:11px;"',
                            ' data-lbl="',
                            value.vNamelbl,
                            '">&nbsp;',
                            value.vName,
                            // '</td><td style="width:55px;">',
                            // value.vMrn,
                            '</td><td style="width:55px;" ',
                            ' data-lbl="',
                            value.vAgelbl,
                            '">',
                            value.vAge,
                            '</td><td style="width:55px;"><span style="font-size: 8px;">',
                            value.vHW,
                            '</td><td style="width:55px;"',
                            ' data-lbl="',
                            value.vPriorlbl,
                            '>',
                            value.vPrior,
                            '</td><td style="width:93px;">',
                            value.vACCESSIONID,
                            '</td><td style="width:93px;"',
                            ' data-lbl="',
                            value.vOrdIdlbl,
                            '">',
                            value.vOrdId,
                            '</td><td style="text-align: left;  font-size: 10px;border-bottom:1px solid lightgrey;width:93px;">',
                            value.vOrder_Status,
                            '</td><td style="text-align: center;  font-size: 10px;border-bottom:1px solid lightgrey;width:225px;"',
                            ' data-lbl="',
                            value.vOrderlbl,
                            '">',
                            value.vOrder,
                            '</td><td style="width:25px;">',
                            value.vCmt, //icon img html or &nbsp;
                            '</td><td style="width:90px;">',
                            value.vProtStat,
                            '</td><td style="width:115px;font-size: 11px;">',
                            value.vSedation,
                            '</td><td style="width:80px;">',
                            value.vRadDisc,
                            '</td><td style="width:25px;">',
                            value.vCSA_SIGNED_DT, //icon img html or &nbsp;
                            '</td><td style="width:25px;">',
                            value.vCSA_CONTRIND, //icon img html or &nbsp;
                            '</td><td style="width:115px;"',
                            ' data-lbl="',
                            value.vReqExmDtlbl,
                            '">',
                            (value.vReqExmDt === '--' ? value.vReqExmDt: value.vReqExmDt.replace(/-/g,'/')),
                            '</td><td style="width:115px;"',
                            ' data-lbl="',
                            value.vOrdDtlbl,
                            '">',
                            (value.vOrdDt === '--' ? value.vOrdDt: value.vOrdDt.replace(/-/g,'/')),
                            '</td><td style="width:115px;"',
                            ' data-lbl="',
                            value.vUptDtlbl,
                            '">',
                            (value.vUptDt === '--'? value.vUptDt: value.vUptDt.replace(/-/g,"/")),
                            '</td></tr>'
                        );
                    }
                );

            }else if( aStrOrdState === 'MODIFY') {
                chla.OPRADWL.View.tbllststr += ('tbl'+ tblId);
                chla.OPRADWL.View.tbllst.push('tbl' + tblId);
                retVal.push( 'ID="tbl', tblId,'"  class="sortable">');
                retVal.push(
                    '<THEAD><tr style="line-height: 11px;display: none;" >',
                    '<th id="C1"  data-tsorter="tag_name">C1</th>',
                    '<th id="C2" style="width:115px;">C2</th>',
                    '<th id="C3" style="width:55px;"  data-tsorter="orderid">C3',
                    '</th><th id="C4" style="width:55px;" data-tsorter="orderid">C4',
                    '</th><th id="C5" style="width:55px;">C5',
                    '</th><th id="C6" style="width:130px;">C6',
                    '</th><th id="C7" style="width:55px;" data-tsorter="tag_name">C7',
                    '</th><th id="C8" style="width:93px;" data-tsorter="orderid">C8',
                    '</th><th id="C9" style="width:225px;" data-tsorter="tag_name" >C9',
                    '</th><th id="C10" style="width:25px;">C10',
                    '</th><th id="C11" style="width:90px;">C11',
                    '</th><th id="C12" style="width:80px;">C12',
                    '</th><th id="C13" style="width:115px;">C13',
                    '</th><th id="C14" style="width:125px;">C14',
                    '</th><th id="C15" style="width:125px;" data-tsorter="tag_name">C15',
                    '</th><th id="C16" style="width:125px;" data-tsorter="tag_name">C16',
                    '</th></tr></THEAD><TBODY>');
                abdCont.forEach(
                    function (value) {
                        retVal.push(
                            '<tr style="line-height: 11px;" ><td style="text-align: left;border-bottom:1px solid lightgrey;width:138px;font-size:11px;"',
                            ' data-lbl="',
                            value.vNamelbl,
                            '">&nbsp;',
                            value.vName,
                            '</td><td style="width:125px;">',
                            value.vHldSts,
                            '</td><td style="width:55px;"',
                            ' data-lbl="',
                            value.vMRNlbl,
                            '">',
                            value.vMrn,
                            '</td><td style="width:55px;" ',
                            ' data-lbl="',
                            value.vAgelbl,
                            '">',
                            value.vAge,
                            '</td><td style="width:55px;">',
                            value.vHW,
                            '</td><td style="width:130px;">',
                            value.vLoc,
                            '</td><td style="width:55px;"',
                            ' data-lbl="',
                            value.vPriorlbl,
                            '">',
                            value.vPrior,
                            '</td><td style="width:93px;"',
                            ' data-lbl="',
                            value.vOrdIdlbl,
                            '">',
                            value.vOrdId,
                            '</td><td style="width:225px;"',
                            ' data-lbl="',
                            value.vOrderlbl,
                            '">',
                            value.vOrder,
                            '</td><td style="width:25px;">',
                            value.vCmt, //icon img html or &nbsp;
                            '</td><td style="width:90px;">',
                            value.vProtStat,
                            '</td><td style="width:115px;font-size: 11px;">',
                            value.vSedation,
                            '</td><td style="width:80px;">',
                            value.vRadDisc,
                            '</td><td style="width:125px;"',
                            ' data-lbl="',
                            value.vOrdDtlbl,
                            '">',
                            (value.vOrdDt === '--' ? value.vOrdDt: value.vOrdDt.replace(/-/g,'/')),
                            '</td><td style="width:115px;"',
                            ' data-lbl="',
                            value.vUptDtlbl,
                            '">',
                            (value.vUptDt === '--'? value.vUptDt: value.vUptDt.replace(/-/g,"/")),
                            '</td></tr>'
                        );
                    }
                );
            }else if( aStrOrdState === 'INPATIENT') {
                chla.OPRADWL.View.tbllst.push('tbl' + tblId);
                retVal.push( 'ID="tbl', tblId,'"  class="sortable">');
                retVal.push(
                    '<THEAD><tr style="line-height: 11px;display: none;" >',
                    '<th id="C1"  data-tsorter="tag_name">C1</th>',                         //NAME
                    '<th id="C2" style="width:55px;"  data-tsorter="orderid">C2</th>',      //MRN
                    '<th id="C3" style="width:55px;" data-tsorter="orderid">C3</th>',       //AGE
                    '<th id="C4" style="width:55px;">C4</th>',                              //HT/WT
                    '<th id="C5" style="width:130px;">C5</th>',                             //LOCATION
                    '<th id="C6" style="width:55px;" data-tsorter="tag_name">C6</th>',      //PRIORITY
                    '<th id="C7" style="width:93px;" data-tsorter="orderid">C7</th>',       //ORDER ID
                    '<th id="C8" style="width:225px;" data-tsorter="tag_name" >C8</th>',    //ORDER
                    '<th id="C9" style="width:25px;">C9</th>',                              //RAD COMMENT ICON
                    '<th id="C10" style="width:90px;">C10</th>',                            //PROTOCOL STATUS
                    '<th id="C11" style="width:80px;">C11</th>',                            //RADIOLOGIST DISCRETION
                    '<th id="C12" style="width:115px;">C12</th>',                           //ANESTHESIA SEDATION
                    '<th id="C13" style="width:125px;">C13</th>',                           //PROTOCOL BY
                    '<th id="C14" style="width:125px;" data-tsorter="tag_name" >C14</th>',  //DATE ORDERED
                    '<th id="C15" style="width:125px;" data-tsorter="tag_name" >C15</th>',  //LAST UPDATE
                    '<th id="C16" style="width:115px;" data-tsorter="tag_name" >C16</th>',  //HOLD/STATUS
                    '</tr></THEAD><TBODY>');
                abdCont.forEach(
                    function (value) {
                        retVal.push(
                            '<tr style="line-height: 11px;" ><td style="text-align: left;border-bottom:1px solid lightgrey;width:138px;font-size:11px;"',

                            '">&nbsp;',
                            value.vName,
                            // '</td><td style="width:55px;">',
                            // value.vMrn,
                            '</td><td style="width:55px;" ',
                            ' data-lbl="',
                            value.vAgelbl,
                            '">',
                            value.vAge,
                            '</td><td style="width:55px;"><span style="font-size: 8px;">',
                            value.vHW,
                            '</span></td><td style="width:130px;">',
                            value.vLoc,
                            '</td><td style="width:55px;">',
                            value.vPrior,
                            '</td><td style="width:93px;">',
                            value.vACCESSIONID,
                            '</td><td style="width:93px;">',
                            value.vOrdId,
                            '</td><td style="text-align: left;  font-size: 10px;border-bottom:1px solid lightgrey;width:93px;">',
                            value.vOrder_Status,
                            '</td><td style="text-align: center;  font-size: 10px;border-bottom:1px solid lightgrey;width:225px;">',
                            value.vOrder,
                            '</td><td style="width:25px;">',
                            value.vCmt, //icon img html or &nbsp;
                            '</td><td style="width:90px;">',
                            value.vProtStat,
                            '</td><td style="width:115px;font-size: 11px;">',
                            value.vSedation,
                            '</td><td style="width:80px;">',
                            value.vRadDisc,
                            '</td><td style="width:25px;">',
                            value.vCSA_SIGNED_DT, //icon img html or &nbsp;
                            '</td><td style="width:25px;">',
                            value.vCSA_CONTRIND, //icon img html or &nbsp;
                            '</td><td style="width:125px;">',
                            (value.vOrdDt === '--' ? value.vOrdDt: value.vOrdDt.replace(/-/g,'/')),
                            '</td><td style="width:115px;">',
                            (value.vUptDt === '--'? value.vUptDt: value.vUptDt.replace(/-/g,"/")),
                            '</td></tr>'
                        );
                    }
                );
            }else {//'NEW'
                chla.OPRADWL.View.tbllst.push('tbl' + tblId);
                chla.OPRADWL.View.tbllststr += ('tbl'+ tblId);
                retVal.push( 'ID="tbl', tblId,'"  class="sortable">');
                retVal.push(
                    '<THEAD>',
                    '<tr style="line-height: 11px;display: none;" >',
                    '<th      id="C1"  style="width:138px;" data-tsorter="tag_name" >C1',
                    '</th><th id="C2"  style="width:55px;"  data-tsorter="orderid"  >C2',
                    '</th><th id="C3"  style="width:130px;" >C3',
                    '</th><th id="C4"  style="width:55px;"  data-tsorter="tag_name" >C4',
                    '</th><th id="C5"  style="width:93px;"  data-tsorter="orderid"  >C5',
                    '</th><th id="C6"  style="width:225px;" data-tsorter="tag_name" >C6',
                    '</th><th id="C7"  style="width:80px;"  >C7',
                    '</th><th id="C8"  style="width:115px;" >C8',
                    '</th><th id="C9"  style="width:80px;"  >C9',
                    '</th><th id="C10" style="width:130px;" data-tsorter="tag_name" >C10',
                    '</th>',
                    // '<th id="C11" style="width:115px;" data-tsorter="tag_name" >C11</th>',
                    '</tr>',
                    '</THEAD><TBODY>');
                abdCont.forEach(
                    function (value) {
                        retVal.push(
                            '<tr style="line-height: 11px;" ><td style="text-align: left;border-bottom:1px solid lightgrey;width:138px;font-size:11px;"',
                            ' data-lbl="',
                            value.vNamelbl,
                            '">',
                            value.vName,
                            '</td><td style="width:55px;"',
                            ' data-lbl="',
                            value.vMRNlbl,
                            '">',
                            value.vMrn,
                            '</td><td style="width:130px;">',
                            value.vLoc,
                            '</td><td style="width:55px;"',
                            ' data-lbl="',
                            value.vPriorlbl,
                            '">',
                            value.vPrior,
                            '</td><td style="width:93px;"',
                            ' data-lbl="',
                            value.vOrdIdlbl,
                            '">',
                            value.vOrdId,
                            '</td><td style="width:225px;"',
                            ' data-lbl="',
                            value.vOrderlbl,
                            '">',
                            value.vOrder,
                            '</td><td style="width:80px;">',
                            value.vProtStat,
                            '</td><td style="width:115px;font-size: 11px;">',
                            value.vSedation,
                            '</td><td style="width:80px;">',
                            value.vRadDisc,
                            '</td><td style="width:130px;"',
                            ' data-lbl="',
                            value.vOrdDtlbl,
                            '">',
                            (value.vOrdDt === '--' ? value.vOrdDt: value.vOrdDt.replace(/-/g,'/')),
                            // '</td><td style="width:115px;">',
                            // (value.vReqExmDt === '--' ? value.vReqExmDt: value.vReqExmDt.replace(/-/,"/")),
                            '</td></tr>'
                        );
                    }
                );
            }
            retVal.push('</TBODY></table>');
            return retVal.join('');
        }
        if( strOrdState === 'NEW'){
            arrTreeTbl.push(baseTblHdr.join(''));
            hdrs.newview.forEach(
                function (cfgValue, index) {
                    arrTreeTbl.push(
                        chla.eApps.gFuncs.sFormatter(
                            baseTblAll.join(''),
                            cfgValue.colwdth,
                            cfgValue.colLnHt,
                            cfgValue.colcss1,
                            cfgValue.colname,
                            cfgValue.colbehv,
                            (index + 1),
                            cfgValue.collblh
                        )

                    )
                }
            );
            arrTreeTbl.push(baseTblFtr.join(''));
            // arrTreeTbl.push(baseTbl1.join(''));
        } else if( strOrdState === 'INPATIENT'  ){
            arrTreeTbl.push(baseTblHdr.join(''));
            hdrs.inpatientview.forEach(
                function (cfgValue,index) {
                    arrTreeTbl.push(
                        chla.eApps.gFuncs.sFormatter(
                            baseTblAll.join(''),
                            cfgValue.colwdth,
                            cfgValue.colLnHt,
                            cfgValue.colcss1,
                            cfgValue.colname,
                            cfgValue.colbehv,
                            (index + 1),
                            cfgValue.collblh
                        )

                    )
                }
            );
        } else if( strOrdState === 'FUTURE' ) {
            arrTreeTbl.push(baseTblHdr.join(''));
            hdrs.futureview.forEach(
                function (cfgValue, index) {
                    arrTreeTbl.push(
                        chla.eApps.gFuncs.sFormatter(
                            baseTblAll.join(''),
                            cfgValue.colwdth,
                            cfgValue.colLnHt,
                            cfgValue.colcss1,
                            cfgValue.colname,
                            cfgValue.colbehv,
                            (index + 1),
                            cfgValue.collblh
                        )
                    )
                }
            );
            arrTreeTbl.push(baseTblFtr.join(''));
            // arrTreeTbl.push(baseTbl2.join(''));
        } else if(strOrdState === 'WAIT' ||
                strOrdState === 'HOLD' ){
                arrTreeTbl.push(baseTblHdr.join(''));
                hdrs.holdview.forEach(
                    function (cfgValue,index) {
                        arrTreeTbl.push(
                            chla.eApps.gFuncs.sFormatter(
                                baseTblAll.join(''),
                                cfgValue.colwdth,
                                cfgValue.colLnHt,
                                cfgValue.colcss1,
                                cfgValue.colname,
                                cfgValue.colbehv,
                                (index + 1),
                                cfgValue.collblh
                            )

                        )
                    }
                );
                arrTreeTbl.push(baseTblFtr.join(''));
                // arrTreeTbl.push(baseTbl2.join(''));
        } else if( strOrdState === 'MODIFY'){
            arrTreeTbl.push(baseTblHdr.join(''));
            hdrs.modifyview.forEach(
                function (cfgValue,index) {
                    arrTreeTbl.push(
                        chla.eApps.gFuncs.sFormatter(
                            baseTblAll.join(''),
                            cfgValue.colwdth,
                            cfgValue.colLnHt,
                            cfgValue.colcss1,
                            cfgValue.colname,
                            cfgValue.colbehv,
                            (index + 1),
                            cfgValue.collblh
                        )

                    )
                }
            );
            arrTreeTbl.push(baseTblFtr.join(''));
            // arrTreeTbl.push(baseTbl2a.join(''));
        } else if( strOrdState === 'ACTIVE'){
            arrTreeTbl.push(baseTblHdr.join(''));
            hdrs.activeview.forEach(
                function (cfgValue,index) {
                    arrTreeTbl.push(
                        chla.eApps.gFuncs.sFormatter(
                            baseTblAll.join(''),
                            cfgValue.colwdth,
                            cfgValue.colLnHt,
                            cfgValue.colcss1,
                            cfgValue.colname,
                            cfgValue.colbehv,
                            (index + 1),
                            cfgValue.collblh
                        )

                    )
                }
            );
            arrTreeTbl.push(baseTblFtr.join(''));
            // arrTreeTbl.push(baseTbl4.join(''));
        }else {
            arrTreeTbl.push(baseTbl3.join(''));
        }
        chla.OPRADWL.View.tbllststr = '';
        arrSections.forEach(
            function (value) {
                var arrH6 = [],
                    sWk,
                    objH5 = aDataDto[value],
                    arKH6;
               if (typeof objH5 !== 'undefined') {
                   if (typeof objH5.bdCont !== 'undefined') {
                        arKH6 = Object.keys(objH5.bdCont);
                        arKH6.forEach(
                            function (value1) {
                                var objH6 = objH5.bdCont[value1],
                                    strWrk;
                                strWrk = formatOrdRow(objH6.bdCont,strOrdState,objH6.SectId);
                                arrH6.push(formatProtRow(objH6.Lbl,objH6.SectId,strWrk,objH6.Count));
                            }
                        );
                        sWk = formatModRow(objH5.Lbl,objH5.SectId,arrH6.join(''),objH5.Count);
                        sWk = sWk.replace('">AR3','">Reschedule' );
                        arrTreeTbl.push(sWk);
                        }else {
                               LogIt( {
                                logType: 'LogError',
                                sepChar: ',',
                                logLevel: 100,
                                arrParams: [
                                  'Error arrSection 1 undefined ',
                                  value
                              ]
                            });
                     }
                } else {
                         LogIt( {
                          logType: 'LogError',
                          sepChar: ',',
                          logLevel: 100,
                          arrParams: [
                            'Error arrSection 2 undefined ',
                            value
                        ]
                      });
                }

            }
        );
        arrTreeTbl.push('</div>');
        return arrTreeTbl.join('');
    };
    /**
     *
     * @param aAppObj
     * @param aDataObj
     */
    aAppObj.processInstance =  function(aAppObj,aDataObj) {
        document.getElementById("chla_opradwl").innerHTML = aDataObj;
    };
    /**
     *
     * @param aAppObj {*}
     * @param aDtoUI {*}
     * @param aExpand {boolean} expand all sections T/F
     * @param aFilters {*}
     */
    aAppObj.processPostInstance =  function(aAppObj,aDtoUI,aExpand,aFilters) {
        var selTmpltOp = '<option value="<#=selValue#>"><#=lbl#></option>',
            arrWrk = [],
            objArr = aFilters;

        $("H2.h5a-marker").on( "click",
            function( event ) {
                $(this).find('span.h5b-marker').toggleClass('closed');
                $(this).next().toggleClass('closed');
            });

        $("H2.h6a-marker").on( "click",
            function( event ) {
                $(this).find('span.h6b-marker').toggleClass('closed');
                $(this).next().toggleClass('closed');
            });

        $("tr").on( "click",
            function( event ) {
                $('tr.highlight').toggleClass('highlight');
                $(this).toggleClass('highlight');
            });
        if ( objArr.cbPat.length > 0) {
            arrWrk.push('<option value="0">-Patient-</option>');
            objArr.cbPat.forEach(
                function (value) {
                    arrWrk.push(chla.eApps.gFuncs.parseTemplate(selTmpltOp, {
                        selValue: value.replace(/ /g,'').replace(/[\(\)\.\,]/g,''),
                        lbl     : value
                    }))
                }
            );
            $('select#selPatient').html(arrWrk.join(''));
        }
        arrWrk.length = 0;
        if ( objArr.cbMod.length > 0) {
            arrWrk.push('<option value="0">-Modality-</option>');
            objArr.cbMod.forEach(
                function (value) {
                    arrWrk.push(chla.eApps.gFuncs.parseTemplate(selTmpltOp, {
                        selValue: value, //(index + 1),
                        lbl     : value
                    }))
                }
            );
            $('select#selModality').html(arrWrk.join(''));
        }
        arrWrk.length = 0;
        if ( objArr.cbProt.length > 0) {
            arrWrk.push('<option value="0">-Protocol-</option>');
            objArr.cbProt.forEach(
                function (value) {
                    arrWrk.push(chla.eApps.gFuncs.parseTemplate(selTmpltOp, {
                        selValue: value.replace(/ /g,'').replace(/[\(\)\.\,]/g,''),//(index + 1),
                        lbl     : value
                    }))
                }
            );
            $('select#selProtocol').html(arrWrk.join(''));
        }
        arrWrk.length = 0;
        if ( objArr.cbHldBy.length > 0) {
            arrWrk.push('<option value="0">-Hold By-</option>');
            objArr.cbHldBy.forEach(
                function (value) {
                    arrWrk.push(chla.eApps.gFuncs.parseTemplate(selTmpltOp, {
                        selValue: value.replace(/ /g,'').replace(/[\(\)\.\,]/g,''),
                        lbl     : value
                    }))
                }
            );
            $('select#selHoldBy').html(arrWrk.join(''));
        }
        arrWrk.length = 0;
        if ( objArr.cbOrdId.length > 0) {
            arrWrk.push('<option value="0">-Order Id-</option>');
            objArr.cbOrdId.forEach(
                function (value, index) {
                    arrWrk.push(chla.eApps.gFuncs.parseTemplate(selTmpltOp, {
                        selValue: (index + 1),
                        lbl     : value
                    }))
                }
            );
            $('select#SelOrderNum').html(arrWrk.join(''));
        }

        $('button#btnClrAll').on('click',chla.OPRADWL.View.ClearAll);
        $('select#selPatient').on('change',chla.OPRADWL.View.selectPatientFilter);
        $('select#selHoldBy').on('change',chla.OPRADWL.View.selectHoldByFilter);
        $('select#selModality').on('change',chla.OPRADWL.View.selectModalityFilter);
        $('select#selProtocol').on('change',chla.OPRADWL.View.selectProtocolFilter);
        $('select#selHoldType').on('change',chla.OPRADWL.View.selectHoldTypeFilter);

        if (aExpand){
            $('.closed').each( function(index){
                $(this).toggleClass('closed');
            });
        }
        chla.OPRADWL.View.tblLd();
    };
    /**
     *
     * @param aAppObj
     */
    aAppObj.processCtl =  function(aAppObj) {
        var objWrk,strWrk,objData;
        objData = aAppObj.processData(aAppObj);
        aAppObj.Data.setDataDto(aAppObj,objData);
        objData = aAppObj.processUI(aAppObj,objData.tblData);
        aAppObj.Data.setUiDto(aAppObj,objData);
        objWrk = aAppObj.Data.getDataDto(aAppObj);

        aAppObj.Data.setOrdersViewDto(aAppObj,objWrk);
        strWrk = aAppObj.Data.getUiDto(aAppObj);
        aAppObj.Data.setOrdersViewDto_strUI(aAppObj,strWrk);

        aAppObj.processInstance(aAppObj,strWrk);
        aAppObj.processPostInstance(aAppObj,{},false,aAppObj.Data.getOrdersViewDto(aAppObj).fltrs);
    };
    /**
     *
     * @param aAppObj
     */
    aAppObj.processCtlIP =  function(aAppObj) {
        var objWrk,strWrk,objData;
        objData = aAppObj.processDataIP(aAppObj);
        aAppObj.Data.setDataDto(aAppObj,objData);
        objData = aAppObj.processUI(aAppObj,objData.tblData);
        aAppObj.Data.setUiDto(aAppObj,objData);
        objWrk = aAppObj.Data.getDataDto(aAppObj);

        aAppObj.Data.setOrdersViewDto(aAppObj,objWrk);
        strWrk = aAppObj.Data.getUiDto(aAppObj);
        aAppObj.Data.setOrdersViewDto_strUI(aAppObj,strWrk);

        aAppObj.processInstance(aAppObj,strWrk);
        aAppObj.processPostInstance(aAppObj,{},false,aAppObj.Data.getOrdersViewDto(aAppObj).fltrs);
    };
    /**
     *
     * @param aAppObj {*}
     * @param aFilterType {string}
     */
    aAppObj.View.processSelectFilters =  function(aAppObj, aFilterType) {
        var FilterType,
            dtoFilters ={},
            isExpanded,
            dtoTemp,
            dtoUI;
        function processFilters(orderItem){
            var retValue = true,
                arrFiltersList,
                selectedFiltersVal = aAppObj.Data.selFltrsVal;
            arrFiltersList = Object.keys(selectedFiltersVal);
            arrFiltersList.forEach(
                function (value) {
                    if (retValue) {
                        if (value === 'Patient' && selectedFiltersVal.Patient !== '0') {
                            retValue = (orderItem.NameID === selectedFiltersVal.Patient);
                        } else if (value === 'TimeRng') {
                            //TODO: calc range
                            //retValue = (orderItem.vOrdDt === selFltrs.TimeRng);
                        } else if (value === 'OrderId' && selectedFiltersVal.OrderId !== '0') {
                            retValue = (orderItem.ORDERID === selectedFiltersVal.OrderId);
                        } else if (value === 'HoldBy' && selectedFiltersVal.HoldBy !== '0') {
                            retValue = (orderItem.HoldID.indexOf(selectedFiltersVal.HoldBy)> -1);
                        } else if (value === 'Modality' && selectedFiltersVal.Modality !== '0') {
                            retValue = (orderItem.MODTYPELBL === selectedFiltersVal.Modality);
                        } else if (value === 'Protocol' && selectedFiltersVal.Protocol !== '0') {
                            retValue = (orderItem.ProtocolID === selectedFiltersVal.Protocol);
                        } else if (value === 'HoldType' && selectedFiltersVal.HoldType !== '0') {
                            retValue = (orderItem.NP_HOLD_STATUS.indexOf(selectedFiltersVal.HoldType) > -1);
                        }
                    }
                }
            );
            return retValue;
        }
        if (aFilterType !== ''){
            dtoTemp = aAppObj.Data.getBaseViewOrders(aAppObj).filter(processFilters);
            aAppObj.Data.setOrdersCopy(aAppObj,dtoTemp);
            dtoFilters.Filters = {
                'cbHldBy'  : [],
                'cbOrdId' : [],
                'cbPat' : [],
                'cbMod': [],
                'cbProt': [],
                'comboTimeRng' : [],
                'comboHoldType': []
            };
            FilterType = 'Filtered';
            isExpanded = true;
            dtoUI = '';
            // objWrk = aAppObj.crTrSt.nP(dtoTemp,aAppObj,true);
            // objWrk = aAppObj.processUI(aAppObj,objWrk.tblData);

        } else {
            dtoTemp = aAppObj.Data.getDataDto(aAppObj);
            dtoFilters = dtoTemp.fltrs;
            dtoUI =  aAppObj.Data.getOrdersViewDto_strUI(aAppObj);
            FilterType = (aFilterType === ''?'NONE': 'NONE');
            isExpanded = false;

        }
        // aAppObj.processInstance(aAppObj,objWrk);
        // aAppObj.processPostInstance(aAppObj,{},true,dtoTemp.fltrs);
        aAppObj.View.processApplyFilters(aAppObj,FilterType,isExpanded,dtoTemp,dtoUI,dtoFilters);
    };
    /**
     *
     * @param aAppObj {*}
     * @param aDtoUI  {*}
     * @param aFilters {*}
     */
    aAppObj.processCtlClearFilters =  function(aAppObj,aDtoUI,aFilters) {
        aAppObj.processInstance(aAppObj,aDtoUI);
        aAppObj.processPostInstance(aAppObj,aDtoUI,false,aFilters);
        aAppObj.Data.setOrdersCopy(aAppObj,[]);
    };

    aAppObj.processInit(aParam,aAppObj);
};
