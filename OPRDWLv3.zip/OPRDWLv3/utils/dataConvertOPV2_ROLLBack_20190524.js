'use strict';
/**
 * @file This file is used for converting data.
 *
 * @author mburling
 * @version 2.0
 */
function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
}
/**
 * Get the root of a json object.
 * @param {object} jsonObject The json object
 * @return {object} The root of a json object
 * @type object
 */
function getRootObj(jsonObject)
{
    if (jsonObject['d']) {
        return jsonObject['d'];
    }
    if (jsonObject['RPTDATA']) {
        return jsonObject['RPTDATA'];
    }
    else {
        return jsonObject;
    }
}

//noinspection JSUnusedGlobalSymbols
/**
 * Convert a date to a fixed format with detail time.
 * @param {String} data The date will be converted
 * @return {string} The result of the fixed format
 * @type String
 */
//noinspection JSUnusedLocalSymbols
function convertDate(data)
{
    if (data === undefined ) return '--';
    if (data === '') return '--';
    var year = data.substring(6, 10);
    if (year === '0000') {
        return '--';
    }
    var month = data.substring(11, 13);
    var date = data.substring(14, 16);
    var time = data.substring(17, 22);
    return month+"/"+date+"/"+year+" "+time;
}
/**
 * Convert a date to a fixed format with detail time.
 * @param {String} data The date will be converted  mm/dd/yy
 * @return {string} The result of the fixed format  mm/dd/yyyy
 * @type String
 */
function convertToDate3(data) {
    return data.substr(0, 6) + '20' + data.substr(6);
}
// /**
//  *
//  * @param data
//  * @returns {*}
//  */
// function convertToDate4(data) {//1:2013061200000000:0.000000:0:0
//     if (data === undefined || data === '') return '';
//     var year = data.substring(4, 6);
//     var month = data.substring(6, 8);
//     var date = data.substring(8, 10);
//     return month + "/" + date + "/" + year
// }

//noinspection JSUnusedLocalSymbols
/**
 * Get the value of the element.
 * @type String
 * @param {String} type The type of the element
 * @see #setFormElement
 */
function getFormElement(type)
{
    return document.getElementById(type).value;
}

/**
 * Set the element value.
 * @param {String} type The type of the element
 * @param {String} value The element value to be set
 * @see #getFormElement
 */
function setFormElement(type, value) {
    document.getElementById(type).value = value;
}
/**
 * Formats the patient's  weight.
 * Retrieve a data and convert it to a fixed format.
 * @param {String} data The date will be retrieved
 * @return {string}  The  weight of the patient
 * @type String
 */
function retrieveWeight(data) {
    if (data === '') {
        return '--';
    } else {
        var WTvalue;
        WTvalue = data;
        return (parseFloat(WTvalue).toFixed(2) + '<span class="Units"> kg </span>');
    }
}

/**
 * Calculate the patient's height.
 * Retrieve a data and convert it to a fixed format.
 * @param {String} data The date will be retrieved
 * @return {string} The height of the patient
 * @type String
 */
function retrieveHeight(data) {
    if (data === '') {
        return '--';
    } else {
        var HTvalue = data || 0;
        return (parseFloat(HTvalue).toFixed(2) + ' <span class="Units"> cm </span>');
    }
}
//noinspection JSUnusedLocalSymbols
/**
 *
 * @param v
 * @param record
 * @returns {string}
 */
function heightAndWeight(v, record) {
    if (record.LEVEL === 3)
        return retrieveHeight(record.HEIGHT) + ' / ' + retrieveWeight(record.WEIGHT);
    else
        return '';
}
/**
 *
 * @param v
 * @param record
 * @returns {string}
 */
function retrieveAccessionID(v, record) {
    if (record.LEVEL === 3) {
        if (v === '') {
            return '--';
        } else {
            var AIDvalue = v.replace(/^0+/g, '');
            return (AIDvalue);
        }
    } else
        return '';
}
// /**
//  *
//  * @param v
//  * @param record
//  * @returns {string}
//  */
// function retrieveOrder(v, record) {
//     if (record.LEVEL === 3) {
//         var alertFlag = (record.ALERT_FLAG === ''? 'No':record.ALERT_FLAG),
//             arrWrk =[];
//         arrWrk.push('<div style="color: ' );
//         arrWrk.push((alertFlag !== 'No' ? 'red' : 'black'));
//         arrWrk.push( '" onclick="MouseOverData3.call(this,&quot;Order&nbsp;Clinical&nbsp;Display&nbsp;Line&quot;);" ');
//         arrWrk.push(' title="' );
//         arrWrk.push( record.ORDER_CLIN_DISP_LINE.replace(/,/g,"\n"));
//         arrWrk.push( '">');
//         arrWrk.push( retrieveNormalData(v, record) );
//         arrWrk.push( '</div>');
//         return arrWrk.join('');
//     } else
//         return '';
// }
function retrieveOrderDetail(v, record) {
    var strRetVal = '',
        strAlert_Flag =  (record.ALERT_FLAG === '' ? 'No' : record.ALERT_FLAG);
    /**
     *
     * @param aFldVal
     * @param aRecord
     * @returns {string}
     */
    function OrderDetHover(aFldVal,aRecord) {
       var arrResult=[],
            arrStatWindow = [
                '<div class="dropt" style="padding-left:6px;background:transparent;font-size:12px;color:',
                '<#=AlertFlag#>;"  ',
                'onclick="MouseOverData3.call(this,&quot;Order Detail/Comments&quot;);">',
                '<div class="bodytext" style="width:600px;white-space: normal;color:black;">',
                '<#=OrderDetail#>',
                '</div>',
                retrieveNormalData(v, record),
                '</div>'
            ];

//         /**
//          *
//          * @param aInputStr {string}
//          * @param aParseChar {string}
//          * @returns {Array}
//          */
//         function lenParser(aInputStr,aParseChar) {
//             var arrLenParser,
//                 arrTotal=[];
//             arrLenParser = aInputStr.split(aParseChar);
//             arrLenParser.forEach(
//                 function (item) {
//                     var strWrk = arrTotal.join(' ');
//                     if ((strWrk.length + item.length) > 56){
//                         arrResult.push(strWrk);
//                         arrTotal.length = 0;
//                         arrTotal.push('<br/>&nbsp;&nbsp;');
//                     }
//                     arrTotal.push(item);
//                 }
//             );
//             return arrTotal;
//         }
        /**
         *
         * @param aRecord2
         * @returns {string}
         */
        function OrderDet(aRecord2){
            var arrOrderDetail =  [
                '<span style="font-weight: 800;font-size:larger;text-decoration: underline;">Order&nbsp;Information</span><br/>',
                '<span style="font-weight: 800;"><#=orderDesc#></span><br/>',
                '<span style="font-weight: 800;">Ordering MD: <#=ordermd#></span><br/>',
                '<span style="font-weight: 800;font-size:larger;text-decoration: underline"><br/>Order Details:</span><br/>',
                '<span style="font-weight: 800;">Clinical Information: </span><#=clinInfo#><br/>',
                '<span style="font-weight: 800;">Priority: </span><#=priorvalue#><br/>',
                '<span style="font-weight: 800;">Anesthesia/Sedation: </span><#=sedvalue#><br/>',
                '<span style="font-weight: 800;">Contrast per Radiologists Discretion: </span><#=RadDiscrValue#><br/>',
                '<span style="font-weight: 800;">Requested Exam Date: </span><#=reqexamdt#><br/>',
                '<span style="font-weight: 800;">Future Order: </span><#=futord#><br/>',
                '<span style="font-weight: 800;">Pregnant: </span><#=preg#><br/>',
                '<span style="font-weight: 800;">Diagnosis: </span><#=diagvalue#><br/>',
                '<span style="font-weight: 800;">Order Location: </span><#=ordloc#><br/>',
                '<span style="font-weight: 800;">Stop Date/Time: </span><#=stopdttm#><br/>',
                '<span style="font-weight: 800;">Original Order Date: </span><#=orgorddt#><br/>',
                '<span style="font-weight: 800;">Order Comment: </span><#=ordcomment#><br/>'
            ];
            if (chla.OPRADWL.Data.getOrdState(chla.OPRADWL) !== 'ACTIVE') {
                return chla.eApps.gFuncs.parseTemplate(arrOrderDetail.join(''), {
                    orderID: aRecord2.ORDERID,
                    ordermd: aRecord2.ORDER_PROVIDER,           // not ActiveView
                    mrn: aRecord2.MRN,                          // not ActiveView
                    orderDesc: aFldVal,                         //aRecord2.ORDLBLINFO,
                    clinInfo: aRecord2.CLININFO,                // not ActiveView
                    priorvalue: aRecord2.PRIORITY,
                    sedvalue: (aRecord2.SEDATION === '' ? '---' : aRecord2.SEDATION),
                    RadDiscrValue: (aRecord2.RAD_DISCRETION === '' ? 'No' : aRecord2.RAD_DISCRETION),
                    reqexamdt: aRecord2.BEGIN_DT,               // not ActiveView
                    futord: aRecord2.FUTUREORD,                 // not ActiveView
                    preg: aRecord2.PREGNANT,                    // not ActiveView
                    diagvalue: aRecord2.ODDIAGNOSIS.replace(/\|$/, '').replace(/\|/g, '<br/> '),// not ActiveView
                    ordloc: aRecord2.ORDER_LOC.replace('~PATIENTLOCATION', ' '),
                    stopdttm: aRecord2.END_DT,                 // not ActiveView
                    orgorddt: aRecord2.ORIGORDDT,
                    ordcomment: (typeof aRecord2.ORDERCMTS === 'undefined' ? '' : aRecord2.ORDERCMTS.replace(/\r\n/g, '<br/>'))  // not ActiveView

                });
            } else {
                return chla.eApps.gFuncs.parseTemplate(arrOrderDetail.join(''), {
                    orderID: aRecord2.ORDERID,
                    ordermd: '',           // not ActiveView
                    mrn: '',                      // not ActiveView
                    orderDesc: aFldVal,                          //aRecord2.ORDLBLINFO,
                    clinInfo: '',                // not ActiveView
                    priorvalue: aRecord2.PRIORITY,
                    sedvalue: (aRecord2.SEDATION === '' ? '---' : aRecord2.SEDATION),
                    RadDiscrValue: (aRecord2.RAD_DISCRETION === '' ? 'No' : aRecord2.RAD_DISCRETION),
                    reqexamdt: '',               // not ActiveView
                    futord: '',              // not ActiveView
                    preg: '',                // not ActiveView
                    diagvalue: '',// not ActiveView
                    ordloc: aRecord2.ORDER_LOC.replace('~PATIENTLOCATION', ' '),
                    stopdttm: '',                 // not ActiveView
                    orgorddt: aRecord2.ORIGORDDT,
                    ordcomment:''  // not ActiveView

                });
            }
        }
        return chla.eApps.gFuncs.parseTemplate( arrStatWindow.join(''), {
            OrderDetail: OrderDet(aRecord),
            AlertFlag:  (strAlert_Flag !== 'No' ? 'red' : 'black')
        });
    }
    if (record.LEVEL === 3 ){
        strRetVal = OrderDetHover(v,record);
    }
    return strRetVal;
}
/**
 *
 * @param v
 * @param record
 * @returns {string}
 */
function retrieveOrderPriority(v, record) {
    var arrWrk = [],
        priority = retrieveNormalData(record.PRIORITY, record) ;
    if (record.LEVEL === 3) {
        arrWrk.push('<span style="color: ');
        arrWrk.push((priority === 'Stat' ? 'red' : 'black'));
        arrWrk.push('">');
        arrWrk.push(priority);
        arrWrk.push('</span>');
        return arrWrk.join('');
    } else
        return '';
}
/**
 * Retrieve a data to be normal.
 * @param v {string} The data will be retrieved
 * @param record {object}
 * @returns {string} The normal data
 */
function retrieveNormalData(v, record) {
    if (record && record.LEVEL === 3) {
        if (v === '' || v === '0.0') {
            return '--';
        } else {
            return v;
        }
    } else
        return '';
}
// /**
//  * Retrieve a data to be concatenated to string with slash.
//  * @param v
//  * @returns {string} The slash data or empty string
//  */
// function retrieveSlashData(v) {
//     if (v === '' || v === '0.0') {
//         return '';
//     } else {
//         return ('/' + v);
//     }
// }
// /**
//  *
//  * @param v
//  * @param record
//  * @returns {string}
//  */
// function toLocation(v, record) {
//     var arrWrk=[];
//     if (record.LEVEL === 3)
//         arrWrk.push('<span title="' ,
//             record.NURSING_UNIT ,
//             retrieveSlashData(record.ROOM) ,
//             retrieveSlashData(record.BED) ,
//             '">' ,
//             record.NURSING_UNIT ,
//             retrieveSlashData(record.ROOM) ,
//             retrieveSlashData(record.BED) ,
//             '</span>');
//     else
//         return '';
// }
/**
 * This function is used to converting a data to a fixed format.
 * i.e.  "AGE":"22 Years 11 Months",
 * @param v {string} The data to be converted
 * @param record {object} all the data of the record
 * @returns {string}
 */
function ageCss(v, record) {
    var a ,
        b ,
        w ,
        d ,
        f ,
        data,
        year,
        month,
        week,
        days,
        age;
    if (record.LEVEL === 3) {
        data = v.trim();
        age = '';
        if (data === "" || data === undefined) {
            age = "--";
        } else {
            a = data.indexOf('Y');
            b = data.indexOf('M');
            w = data.indexOf('W');
            d = data.indexOf('D');
            f = data.indexOf(' ');
            // e = data.lastIndexOf(' ');
            if (a > 0) {
                year = data.substring(0, f);
                // c = data.substring(a, a + 5);
                age = year + ' ' + '<span class="Units" style="color:#7C7C7C;font-size:9px;">' + (year > 1 ? 'yrs' : 'yr') + '</span>' + ' ';
            }
            if (b > 0 && a === -1) {
                month = data.substring(0, b - 1);
                age += month + ' ' + '<span class="Units" style="color:#7C7C7C;font-size:9px;">m</span>' + ' ';
            }
            if (d > 0) {
                days = data.substring(f + 1, d - 2);
                age += days + ' ' + '<span class="Units" style="color:#7C7C7C;font-size:9px;">' + (days > 1 ? 'days' : 'day') + '</span>' + ' ';
            }
            if (w > 0) {
                week = data.substring(f + 1, w - 2);
                age += week + ' ' + '<span class="Units" style="color:#7C7C7C;font-size:9px;">' + (week > 1 ? 'wks' : 'wk') + '</span>';
            }
        }
        return age;
    } else
        return '';
}
function agelbl(v) {
    var a ,
        b ,
        w ,
        d ,
        f ,
        data,
        year,
        month,
        week,
        days,
        age;
    data = v.trim();
    age = 0;
    if (data === "" || data === undefined) {
        age = "--";
    } else {
        a = data.indexOf('Y');
        b = data.indexOf('M');
        w = data.indexOf('W');
        d = data.indexOf('D');
        f = data.indexOf(' ');
        if (a > 0) {
            year = data.substring(0, f);
            age = (year * 356);
        }
        if (b > 0 && a === -1) {
            month = data.substring(0, b - 1);
            age += (month * 30);
        }
        if (d > 0) {
            days = data.substring(f + 1, d - 2);
            age += days;
        }
        if (w > 0) {
            week = data.substring(f + 1, w - 2);
            age += (week * 7);
        }
    }
    return age;

}
/**
 *
 * @param v
 * @param record
 * @returns {string}
 */
function nameToLink(v, record) {
    var arrWrk = [],
        retVal = v;
    if (record.LEVEL === 3) {
        if(record.ENCNTRID > 0){
            arrWrk.push( '<span style="color:blue; cursor:pointer;',
                (record.ORDERSEQERROR === 'YES'? 'background-color: pink;': ''),
                '" onclick="return launch(' ,
                "'CHART'" ,
                ',' ,
                "'" ,
                record.PERSONID ,
                "'" ,
                ',' ,
                "'" ,
                record.ENCNTRID ,
                "'" ,
                ',' ,
                "'" ,
                record.EXAM_FORM_ID ,
                "'" ,
                ',' ,
                "'" ,
                record.FORM_ACTIVITY_ID ,
                "'" ,
                ');"> ' ,
                v ,
                '</span>');
            retVal =  arrWrk.join('');
        }
    }
    return retVal;
}
/**
 *
 * @param v
 * @param record
 * @returns {string}
 */
function protoStatToLink(v, record) {
    var arrWrk = [],
        arrWrk2 = [],
        arrWrk3 = [],
        Group_PF_id ,
        strProtStat;
    if (record.LEVEL === 3){
        strProtStat = v;
        strProtStat = (strProtStat === 'Nurse Tech'? 'Active Form': strProtStat);
        if (record.FORM_ACTIVITY_ID > 0 && record.ENCNTRID > 10 ) {
            arrWrk2.push('<span style="color:blue; cursor:pointer; font-size:11px;" onclick="return launch(',
                "'",
                record.MODIFY_FLAG,
                "'",
                ',',
                "'",
                record.PERSONID,
                "'",
                ',',
                "'",
                record.ENCNTRID,
                "'",
                ',',
                "'",
                record.EXAM_FORM_ID,
                "'",
                ',',
                "'",
                record.FORM_ACTIVITY_ID
                );
            if(chla.OPRADWL.FeatureCtl.F00003_0.Available) {
                arrWrk2.pop();
                arrWrk2.push((record.GROUP_PF_ID === 0 ? record.FORM_ACTIVITY_ID : record.GROUP_PF_ID));
            }
            arrWrk2.push(
                "'",
                ',',
                "'",
                record.ORDERID,
                "'",');">');
            arrWrk2.push(
                strProtStat,
                '</span>');
            if(chla.OPRADWL.FeatureCtl.F00003_0.Available) {
                if (record.GROUP_PF_ID > 0 ) {
                    arrWrk.push(
                        '<div class="dropt" style="text-align: center;background-color: transparent;font-size:12px;"> ',
                        '<div class="bodytext" style="width:500px;overflow-x: hidden;word-wrap: break-word; ">',
                        '<span style="font-weight: 800;">Mass Protocolled Group:</span><br/>');
                    Group_PF_id = "G" + record.GROUP_PF_ID;
                    if (typeof chla.OPRADWL.View.GROUP_PF_ID[Group_PF_id] !== 'undefined') {
                        chla.OPRADWL.View.GROUP_PF_ID[Group_PF_id].forEach(function (item) {
                            arrWrk3 = item.split('@');
                            arrWrk3.pop();
                            arrWrk.push(arrWrk3.join(' '),'<br/>');
                        });

                    }
                    arrWrk.push('<br/>','</div>');
                    arrWrk.push(arrWrk2.join(''));
                    arrWrk.push( '</div>' );
                }else {
                    arrWrk.push(arrWrk2.join(''));
                }
            } else {
                arrWrk.push(arrWrk2.join(''));
            }
        } else {
            arrWrk.push('<span style="color:gray;font-size:11px;">');
            arrWrk.push((record.PROTOCAL_STATUS.toUpperCase() === 'NEW'?'New Order' : 'No Form'));
            arrWrk.push('</span>');
        }
    }
    return arrWrk.join('');
}
/**
 *
 * @param v
 * @param record
 * @returns {string}
 */
function convertToIcon(v, record) {
    var arrWrk = [],
        objDtCurrent,
        objDate;
    if (record.LEVEL === 3 && v !== '') {
        if(record.CSA_SIGNED === 2) {
            objDate = new Date(convertToDate3(v));
            objDate.setDate(objDate.getDate()+ 1);
            objDtCurrent = new Date();
            arrWrk.push( '<div style="background: transparent;"><img alt="" src="' );
            arrWrk.push( );
            arrWrk.push((objDate > objDtCurrent ?'images/ok15px.png' : 'images/ok15px_orange.png' ));
            arrWrk.push( '" title="Form signed on ');
            arrWrk.push( v );
            arrWrk.push('" width="15" height="15" onclick="return launch(' + "'POWERFORM'" + ',' + "'");
            arrWrk.push( record.PERSONID);
            arrWrk.push( "'" + ',' + "'"  );
            arrWrk.push( record.ENCNTRID );
            arrWrk.push( "'" + ',' + "'");
            arrWrk.push( record.CSA_EXAM_FORM_ID);
            arrWrk.push( "'" + ',' + "'" );
            arrWrk.push( record.CSA_FORM_ACTIVITY_ID);
            arrWrk.push("'" + ');" style="cursor:pointer; margin-top:0;"/></div>');
        } else {
            arrWrk.push('--');
        }
        return arrWrk.join('');
    } else
        return '';
}
/**
 *
 * @param v
 * @param record
 * @returns {string}
 */
function convertToIcon2(v, record) {   //Contrast Contraindication Noted
    var resultStr = [];
    if (record.LEVEL === 3 && v !== '') {
        if (v === 1) {
            resultStr.push('<div style="background: transparent;"><img alt="" style="vertical-align:middle;" src="images/stop_icon.png"');
            resultStr.push(' title="Contrast Contraindication Noted" ');
            resultStr.push(' width="20" height="20" onclick="return launch(');
            resultStr.push( "'POWERFORM'");
            resultStr.push(',' + "'" );
            resultStr.push( record.PERSONID );
            resultStr.push( "'" + ',' + "'");
            resultStr.push(record.ENCNTRID);
            resultStr.push( "'" + ',' + "'" );
            resultStr.push(record.CSA_CTRIND_FORM_ID);
            resultStr.push("'" + ',' + "'" );
            resultStr.push(record.CSA_CTRIND_FORM_ACT_ID);
            resultStr.push( "'" + ');" style="cursor:pointer; margin-top:0;"/></div>');
        } else {
            // resultStr.push('[2]');
            if(record.CSA_CTRIND_FORM_ID > 0 && record.CSA_CTRIND_FORM_ID > 0 ) {
                resultStr.push('<div style="background: transparent;"><span ');
                resultStr.push(' width="20" height="20" onclick="return launch(');
                resultStr.push("'POWERFORM'");
                resultStr.push(',' + "'");
                resultStr.push(record.PERSONID);
                resultStr.push("'" + ',' + "'");
                resultStr.push(record.ENCNTRID);
                resultStr.push("'" + ',' + "'");
                resultStr.push(record.CSA_CTRIND_FORM_ID);
                resultStr.push("'" + ',' + "'");
                resultStr.push(record.CSA_CTRIND_FORM_ACT_ID);
                resultStr.push("'" + ');" style="cursor:pointer; margin-top:0;font-size:9px;">[2]</span></div>');
            }else {
                resultStr.push( '<div style="background: transparent;"><span style=" margin-top:0;font-size:9px;">');
                resultStr.push('&nbsp;');
                resultStr.push('</span></div>');
            }
        }
        return resultStr.join('');
    } else {
        return '';
    }
}
/**
 *
 * @param v
 * @param record
 * @returns {string}
 */
function convertToIcon3(v, record) {    //ISOLATION
    var resultStr = '';
    if (record.LEVEL === 3 && v !== '') {
        if (v.indexOf('Standard') < 0){
            resultStr =  '<div style="padding-left:6px;"><img alt="" src="images/isolation2.png" title="' + v + '" ' +
                ' width="16" height="16" ' +
                ' style="cursor:pointer; margin-top:0;"/></div>' ;
        }
        return resultStr;
    } else {
        return '';
    }
}
function ConvertHoldDate(aRecord) {
    var strWrk,
        arrWrk,
        arrWrk1,
        arrWrk2=[];

    strWrk = '';

    if (aRecord.PROTOCAL_STAT_LVL === 1) {
        arrWrk = aRecord.EP_HOLD_STATUS.split('|');                       //EP_HOLD_STATUS  (" Date| ????")

        if (arrWrk.length === 2){
            strWrk = arrWrk[0];


        }
        if (aRecord.EP_HOLD_STATUS2 !== ''){
            arrWrk = aRecord.EP_HOLD_STATUS2.split('|');                       //EP_HOLD_STATUS  (" Date| ????")

            if (arrWrk.length === 2){
                strWrk = arrWrk[0];

            }
        }
    }
    if (aRecord.PROTOCAL_STAT_LVL === 2) {
        arrWrk = aRecord.NP_HOLD_STATUS.split('|');                       //EP_HOLD_STATUS  (" Date| ????")
        if(arrWrk.length === 2){
            strWrk = arrWrk[0];
        }
    }
    if(strWrk !== ''){
        arrWrk = strWrk.split(' ');
        arrWrk1 = arrWrk[0].split('/');
        arrWrk2.push(arrWrk1[2]);
        arrWrk2.push('/');
        arrWrk2.push(arrWrk1[0]);
        arrWrk2.push('/');
        arrWrk2.push(arrWrk1[1]);
        arrWrk2.push(' ');
        arrWrk2.push(arrWrk[1]);
    }
    return arrWrk2.join('');
}

function ConvertSortDateTime (aDtTm) {
    var strWrk = aDtTm.replace(/-/g,'/'),
        arrWrk,
        arrWrk1,
        arrWrk2=[];
    if(strWrk !== ''){
        arrWrk = strWrk.split(' ');
        arrWrk1 = arrWrk[0].split('/');
        arrWrk2.push(arrWrk1[2]);
        arrWrk2.push('/');
        arrWrk2.push(arrWrk1[0]);
        arrWrk2.push('/');
        arrWrk2.push(arrWrk1[1]);
        arrWrk2.push(' ');
        arrWrk2.push(arrWrk[1]);
    }
    return arrWrk2.join('');

}
/**
 *
 * @param v
 * @param record
 * @returns {string}
 */
function convertToIcon4(v, record) {   //COMMENTS_FLD
    var resultStr = [];
    if (record.LEVEL === 3 && v !== '') {
        resultStr.push(
            '<div class="dropt" style="padding-left:6px;background-color: transparent;font-size:12px;" ',
            'onclick="MouseOverData3.call(this,&quot;Radiology&nbsp;Comments&quot;);"',
            '><div class="bodytext" style="width:500px;overflow-x: hidden;word-wrap: break-word; ">',
            '<br/>',
            v,
            '<br/>',
            '</div>',
            '<img alt="" src="images/comments4.png" width="16" height="18" style="margin-top:0;"/>',
            '</div>'
        );
    }
    return resultStr.join('');
}
/**
 *
 * @param v
 * @param record
 * @returns {string}
 */
function HLDconvertToStatus(v,record) {
    var strReturn;
    /**
     *
     * @param aRecord
     * @returns {string}
     */
    function OrderModifyDone(aRecord) {
        var arrResult=[],
            arrWrk2;
        arrResult.push(
            '<div class="droptro" style="padding-left:6px;background-color: transparent;font-size:12px;" ',
            'onclick="MouseOverData3.call(this,&quot;Reorder Detail&quot;);"',
            '><div class="bodytext" style="padding-left:6px;width:500px;overflow-x: hidden;word-wrap: break-word; ">'
            //,'<br/>'
        );
        arrResult.push('<span style="text-decoration: underline;font-weight:800;">Change:</span></br>');
        if (aRecord.EP_REORDER_CHGS !== ''){
            arrWrk2 = aRecord.EP_REORDER_CHGS.replace('DEFAULT_VALUE|','').split('|');
            if(arrWrk2.length > 0){
                arrResult.push(arrWrk2.join('<br/>'));
            }else {
                arrResult.push("No Selection Made");
            }
        } else {
            arrResult.push("No Selection Made");
        }
        arrResult.push(
            '<br/>',
            '</div>',
            '<span style="padding-left:6px;font-weight:800;background-color: lightblue;;">REORDERED</span>',
            '</div>'
        );
        return arrResult.join('');
    }
    /**
     *
     * @param aRecord
     * @returns {string}
     */
    function OrderModifyRequest(aRecord) {
        var arrResult=[],
            arrWrk2;
        arrResult.push(
            '<div class="droptro" style="padding-left:6px;background-color: transparent;font-size:12px;" ',
            'onclick="MouseOverData3.call(this,&quot;Reorder Detail&quot;);"',
            '><div class="bodytext" style="padding-left:6px;width:500px;overflow-x: hidden;word-wrap: break-word; ">'
            //,'<br/>'
        );
        arrResult.push('<span style="text-decoration: underline;font-weight:800;">Change:</span></br>');
        if (aRecord.EP_REORDER_CHGS !== ''){
            arrWrk2 = aRecord.EP_REORDER_CHGS.replace('DEFAULT_VALUE|','').split('|');
            if(arrWrk2.length > 0){
                arrResult.push(arrWrk2.join('<br/>'));
            }else {
                arrResult.push("No Selection Made");
            }
        } else {
            arrResult.push("No Selection Made");
        }
        arrResult.push(
            '<br/>',
            '</div>',
            '<span style="padding-left:6px;color:white;font-weight:800;color: red;">REORDER needed</span>',
            '</div>'
        );
        return arrResult.join('');
    }

    /**
     *
     * @param aFldVal
     * @param aRecord
     * @returns {string}
     */
    function HoldStatus(aFldVal,aRecord) {
        var //arrResult=[],
            strWrk,
            strWrk1,
            arrWrk,
            arrWrk2 = [],
            arrStatWindow = [
                '<div class="dropt" style="padding-left:6px;background-color: yellow;font-size:12px;"  onclick="',
                'MouseOverData3.call(this,&quot;Hold/Status Detail&quot;);">',
                '<div class="bodytext" style="width:500px;overflow-x: hidden;word-wrap: break-word; ">',
                '<b>Hold Date: </b><#=HoldDate#>',
                '<br/><b>Reason:</b><br/>&nbsp;&nbsp;&nbsp;<#=HoldReason#>',
                '<br/><b>Hold By:</b>  <#=HoldByID#>',
                '<#=HldSpecProtocolVal#>',
                '<#=EPModifyCmts#>',
                '<#=NPonHoldCmts#>',
                '<#=NPModifyCmts#>',
                '<#=NPCLR#>',
                '<#=OrderDetail#>',
                '</div>',
                '<span><#=HoldDate#></span></div>'
            ];

        /**
         *
         * @param aInputStr {string}
         * @param aParseChar {string}
         * @returns {Array}
         */
        function lenParser(aInputStr,aParseChar) {
            var arrLenParser,
                arrTotal=[];
            arrLenParser = aInputStr.split(aParseChar);
            arrLenParser.forEach(
                function (item) {
                    var strWrk = arrTotal.join(' ');
                    if ((strWrk.length + item.length) > 56){
                       // arrResult.push(strWrk);
                        arrTotal.length = 0;
                        arrTotal.push('<br/>&nbsp;&nbsp;');
                    }
                    arrTotal.push(item);
                }
            );
            return arrTotal;
        }
        /**
         * Format the Hold Special Protocol Instructions
         * @param aRecord2
         * @returns {string}
         */
        function HldSpecProtocolVal(aRecord2) {
            var arrResult=[];

            if ( aRecord2.EP_HOLD_SPEC_PROTOCOL !== '' ) {
                arrResult.push('<br/><b>Special Protocol Instructions:</b> <br/>&nbsp;&nbsp;');
                arrResult.push(lenParser(aRecord2.EP_HOLD_SPEC_PROTOCOL,' ').join(' '));
            }
            arrResult.push('<br/>');
            return arrResult.join('');
        }
        /**
         *
         * @param aRecord2
         * @returns {string}
         */
        function NPCLR(aRecord2){
            var arrResult=[],
                arrWrk;
            if ( aRecord2.NP_CLR !== '' ) {
                arrWrk = aRecord2.NP_CLR.split('|');
                arrResult.push('<br/><b>NP CLR:</b> <br/>&nbsp;&nbsp;');
                arrResult.push(arrWrk.shift());
                arrResult.push('<br/>&nbsp;&nbsp;');
                arrResult.push(lenParser(arrWrk.join(''),' ').join(' '));
            }
            arrResult.push('<br/>');
            return arrResult.join('');
        }
        /**
         *
         * @param aRecord2
         * @returns {string}
         */
        function EPModifyComments(aRecord2){
            var arrResult=[],
                arrWrk;
            if ( aRecord2.EP_MODIFY_CMT !== '' ) {
                arrWrk = aRecord2.EP_MODIFY_CMT.split('|');
                arrResult.push('<br/><b>EP Modify Comments:</b> <br/>&nbsp;&nbsp;');
                arrResult.push(arrWrk.shift());
                arrResult.push('<br/>&nbsp;&nbsp;');
                arrResult.push(lenParser(arrWrk.join(''),' ').join(' '));
            }
            arrResult.push('<br/>');
            return arrResult.join('');
        }
        /**
         *
         * @param aRecord2
         * @returns {string}
         */
        function NPonHoldComments(aRecord2){
            var arrResult=[],
                arrWrk;
            if ( aRecord2.NP_HOLD_CMT !== '' ) {
                arrWrk = aRecord2.NP_HOLD_CMT.split('|');
                arrResult.push('<br/><b>NP on Hold Comments:</b>&nbsp;&nbsp;');
                arrResult.push(arrWrk.shift());
                arrResult.push('<br/>&nbsp;&nbsp;');
                arrResult.push(lenParser(arrWrk.join(''),' ').join(' '));
            }
            arrResult.push('<br/>');
            return arrResult.join('');
        }
        /**
         *
         * @param aRecord2
         * @returns {string}
         */
        function NPModifyComments(aRecord2){
            var arrResult=[],
                arrWrk;
            if ( aRecord2.NP_MODIFY_CMT !== '' ) {
                arrWrk = aRecord2.NP_MODIFY_CMT.split('|');
                arrResult.push('<br/><b>NP Modify Comments:</b>&nbsp;&nbsp;');
                arrResult.push(arrWrk.shift());
                arrResult.push('<br/>&nbsp;&nbsp;');
                arrResult.push(lenParser(arrWrk.join(''),' ').join(' '));
            }
            arrResult.push('<br/>');
            return arrResult.join('');
        }
        /**
         *
         * @param aRecord2
         * @returns {string}
         */
        function OrderDet(aRecord2){
            var arrOrderDetail =  [
                '<br/><span style="font-weight: 800;font-size:larger;text-decoration: underline;">Order&nbsp;Information</span><br/>',
                '<span style="font-weight: 800;">Ordering MD: <#=ordermd#></span><br/>',
                '<#=orderDesc#></span<br/>',
                '<span style="font-weight: 800;font-size:larger;"><br/>Order Details:</span><br/>',
                '<span style="font-weight: 800;">Clinical Information: </span><#=clinInfo#><br/>',
                '<span style="font-weight: 800;">Priority: </span><#=priorvalue#><br/>',
                '<span style="font-weight: 800;">Anesthesia/Sedation: </span><#=sedvalue#><br/>',
                '<span style="font-weight: 800;">Contrast per Radiologists Discretion: </span><#=RadDiscrValue#><br/>',
                '<span style="font-weight: 800;">Requested Exam Date: </span><#=reqexamdt#><br/>',
                '<span style="font-weight: 800;">Future Order: </span><#=futord#><br/>',
                '<span style="font-weight: 800;">Pregnant: </span><#=preg#><br/>',
                '<span style="font-weight: 800;">Diagnosis: </span><#=diagvalue#><br/>',
                '<span style="font-weight: 800;">Order Location: </span><#=ordloc#><br/>',
                '<span style="font-weight: 800;">Stop Date/Time: </span><#=stopdttm#><br/>',
                '<span style="font-weight: 800;">Original Order Date: </span><#=orgorddt#><br/>'
            ];
            return chla.eApps.gFuncs.parseTemplate(arrOrderDetail.join(''),{
                orderID:        aRecord2.ORDERID,
                ordermd:        aRecord2.ORDER_PROVIDER,
                mrn:            aRecord2.MRN,
                orderDesc:      aRecord2.ORDLBLINFO,
                clinInfo:       aRecord2.CLININFO,
                priorvalue:     aRecord2.PRIORITY,
                sedvalue:       (aRecord2.SEDATION === ''? '---':aRecord2.SEDATION),
                RadDiscrValue:  (aRecord2.RAD_DISCRETION === ''? 'No':aRecord2.RAD_DISCRETION),
                reqexamdt:      aRecord2.BEGIN_DT,
                futord:         aRecord2.FUTUREORD,
                preg:           aRecord2.PREGNANT,
                diagvalue:      aRecord2.ODDIAGNOSIS.replace(/\|$/,'').replace(/\|/g,'<br/> '),
                ordloc:         aRecord2.ORDER_LOC.replace('~PATIENTLOCATION',' '),
                stopdttm:       aRecord2.END_DT ,
                orgorddt:       aRecord2.ORIGORDDT
            });
        }
        strWrk = '';
        strWrk1= '';
        if (aRecord.PROTOCAL_STAT_LVL === 1) {
            arrWrk = aFldVal.split('|');                       //EP_HOLD_STATUS  (" Date| ????")
            arrWrk2 = aRecord.EP_HOLD_STATUSID.split('|'); // (" NAME| Date")
            if (arrWrk.length === 2){
                strWrk = arrWrk[0];
                strWrk1 = arrWrk[1].replace(/,/g,'<br/>&nbsp;&nbsp;');

            }
            if (aRecord.EP_HOLD_STATUS2 !== ''){
                arrWrk = aRecord.EP_HOLD_STATUS2.split('|');                       //EP_HOLD_STATUS  (" Date| ????")
                arrWrk2 = aRecord.EP_HOLD_STATUSID2.split('|'); // (" NAME| Date")
                if (arrWrk.length === 2){
                    strWrk = arrWrk[0];
                    strWrk1 = arrWrk[1].replace(/,/g,'<br/>&nbsp;&nbsp;');

                }
            }
        }
        if (aRecord.PROTOCAL_STAT_LVL > 1) {
            arrWrk = aRecord.NP_HOLD_STATUS.split('|');                       //EP_HOLD_STATUS  (" Date| ????")
            if(arrWrk.length === 2){
                strWrk = arrWrk[0];
                strWrk1 = arrWrk[1].replace(/,/g,'<br/>&nbsp;&nbsp;');
            }
            arrWrk2 = aRecord.NP_HOLD_STATUSID.split('|'); // (" NAME| Date")
        }
        aRecord.HOLDBY = arrWrk2[0];
        return chla.eApps.gFuncs.parseTemplate( arrStatWindow.join(''), {
            HoldDate:strWrk,
            HoldReason:strWrk1,
            HoldByID: arrWrk2[0],
            HldSpecProtocolVal:(aRecord.PROTOCAL_STAT_LVL === 1? HldSpecProtocolVal(aRecord): ''),
            EPModifyCmts: (aRecord.PROTOCAL_STAT_LVL === 1? EPModifyComments(aRecord): ''),
            NPonHoldCmts: (aRecord.PROTOCAL_STAT_LVL === 2? NPonHoldComments(aRecord): ''),
            NPModifyCmts: (aRecord.PROTOCAL_STAT_LVL === 2? NPModifyComments(aRecord): ''),
            NPCLR: (aRecord.EP_HOLD_STATUS2 !== ""? NPCLR(aRecord): ''),
            OrderDetail: OrderDet(aRecord)
        });

    }

    if (record.LEVEL === 3 && record.EP_REORDER_FLAG.toUpperCase() === 'DONE' && record.ARIND === 0) {
        if (record.CTLPROTOCAL_STATUS === 'Nurse Practitioner') {
            strReturn = OrderModifyDone(record) ;
        }
    } else if (record.LEVEL === 3 && record.EP_REORDER_FLAG.toUpperCase() === 'YES') {
        strReturn = OrderModifyRequest(record);
    }else if (chla.OPRADWL.Data.getOrdState(chla.OPRADWL).toUpperCase() === 'HOLD') {
        /* v = EP_HOLD_STATUS*/
        if(record.LEVEL === 3 && ( v !== '' || record.NP_HOLD_STATUS  !== '' || record.EP_HOLD_STATUS2 !== '')) {
            strReturn = HoldStatus(v,record) ;
        }
    }
    return strReturn;
}
function myFormShow() {
    var windig = [];

    windig.push(
        '<div id="eAppsPFlinker"  style="position: absolute; width: 800px; height: 460px; left: 490px; top: 214px; z-index: 19010;overflow: hidden;">',
        '<div id="Linker_DivSecContent"><div id="eAppsPFlinker-body">',
        '</div></div></div>');
    document.getElementById("WindDialog").innerHTML =windig.join('');
}
function CommentsWindow2(data,wTitle) {
    var windig = [],
        dataMod = data.replace('color: black;','color:transparent;');
    windig.push(
        '<div id="radcmtbox" class="section green" style="position: absolute; width: 725px; height: 500px; left: 520px; top: 214px; z-index: 19010;"><h2 class="sec-hd h2a-marker">',
        '<span class="sec-hd-tgl h2b-marker" title="icon toggle close" style="background-image: none;width:22px; height:22px;"><img alt="" src="images/Close_1.png"',
        'onclick=\'document.getElementById("WindOrdCmt").innerHTML =""\';/> </span>',
        '<span class="sec-title " style="margin-right:0;padding-top:10px;padding-bottom:5px;"><span>',
        wTitle,
        '</span></span></h2><div id="OrdCmt_DivSecContent" class="sec-content"><div id="radcmtbox_body" class="content-body" style="padding:5px;">',
        dataMod,
        '</div></div></div>');
    document.getElementById("WindOrdCmt").innerHTML =windig.join('');
}
/**
 *
 * @param wTitle
 * @returns {boolean}
 */
function MouseOverData3(wTitle){
    var popupFrame = [
            '<div class="bodytext" style="width: 500px; -ms-overflow-x: hidden; -ms-word-wrap: break-word;">',
            '',
            '</div>'
        ],
        strInnerDiv;
    strInnerDiv = $(this).find('div.bodytext');
    popupFrame[1] = strInnerDiv.html();
    CommentsWindow2(popupFrame.join(''),wTitle) ;
    return false;
}
/**
 *
 * @param HtmlStr
 * @returns {string}
 */
chla.eApps.gFuncs.HtmlLogFormatter = function (HtmlStr) {
    return HtmlStr.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
};
var _tmplCache = {};
/**
 *
 * @param str
 * @param obj
 * @returns {*}
 */
chla.eApps.gFuncs.parseTemplate = function(str, obj) {
    var arrWrk =[],
        err = "",
        strFunc,
        func;
    try {
        func =  _tmplCache[str];
        if (!func) {
            strFunc =
                "var p=[],print=function(){p.push.apply(p,arguments);};" +
                "with(obj){p.push('" +
                str.replace(/[\r\t\n]/g, " ")
                .replace(/'(?=[^#]*#>)/g, "\t")
                .split("'").join("\\'")
                .split("\t").join("'")
                .replace(/<#=(.+?)#>/g, "',$1,'")
                .split("<#").join("');")
                .split("#>").join("p.push('")
                + "');}return p.join('');";
            //alert('strFunc <br/> ' + strFunc);
            //chla.LogInfo( 'strFunc' + strFunc.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'));
            func = new Function("obj", strFunc);
            _tmplCache[str] = func;
        }
        return func(obj);
    } catch (e) {
        err = e.message;
        chla.eAppsUtil.Logger.LogError('err - parseTemplate: ' + err);
        alert('err - parseTemplate: ' + err);
        arrWrk.push('<textarea rows="4" style="width:99%;">',
            'parseTemple Error <br/><pre>',
            chla.eApps.gFuncs.HtmlLogFormatter(str),
            ' ',
            JSON.stringify(obj),
            '</pre></textarea>');
        chla.eAppsUtil.Logger.LogError(arrWrk.join(''));
    }
    return "< # ERROR: " + chla.eApps.gFuncs.HtmlLogFormatter(err) + " # >";
};
function newPowerFormMP() {
    var funcoper,
        arrOrderId,
        strOrderId,
        arrWrk = [],
        arrValues,
        log = [];
    arrValues = $('#BtnExitOrderIdMP').val().split('|');
    /*
     arrValues[0], ;'MRN'
     arrValues[1], ;'NAME_FULL_FORMATTED'
     arrValues[2], ; PERSONID
     arrValues[3], ; ENCOUNTERID
     arrValues[4], ; FORM_ID
     arrValues[5], ; FORM_ACTIVITY
     arrValues[6]) ; ORDERID:OrderDescription
     */
    arrWrk.push("Orderid:");
    arrWrk.push(arrValues[6]);
    arrWrk.push("PersonID:");
    arrWrk.push(arrValues[2]);
    arrWrk.push("EncounterID:");
    arrWrk.push(arrValues[3]);
    arrWrk.push("FORM_ID:");
    arrWrk.push(arrValues[4]);
    LogIt( {
        logType: 'LogInfo',
        sepChar:',',
        logLevel: 100, arrParams: arrWrk
    });
    arrWrk.length = 0;
    funcoper = 99;
    if ( arrValues[3] < 10 ){
        funcoper = 6;
    }
    if (typeof  chla.objXmlCcl === 'undefined') {
        chla.objXmlCcl = new chlaMpageApi.XMLCclRequest();
    }
    arrOrderId = arrValues[6].split(':');
    if (arrOrderId.length === 2){
        strOrderId = arrOrderId[0];
    }else {
        strOrderId = arrWrk[6];
    }
    arrWrk.push('^MINE^');                   /* "Output to File/Printer/MINE" = "MINE"*/
    arrWrk.push(funcoper);                   /* , "Function Operation Selector" =3*/
    arrWrk.push('^^');                       /* , "Start Date Range" = ""*/
    arrWrk.push('^^');                       /* , "End Date Range" = ""*/
    arrWrk.push('^^');                       /* , "Start Date Range2" = ""*/
    arrWrk.push('^^');                       /* , "End Date Range2" = ""*/
    arrWrk.push('^REQUEST^');                /* , "Future Order State" = ""*/
    arrWrk.push('0');                        /* , "Specific Order ID" = New OrderID*/
    arrWrk.push('^Link:EncounterIdOperation^'); /* , "Linkage Pair" = ""*/
    arrWrk.push('^^');                       /* , "Order in Protocol State" = ""*/
    arrWrk.push(0);                          /* , "Encounter ID" = 0*/
    arrWrk.push(strOrderId + '.0');          /* , "ORDER ID" = 0*/
    arrWrk.push(arrValues[4] + '.0');        /* , "PowerForm ID" = 0*/
    arrWrk.push(arrValues[2] + '.0');        /* , "Person ID" = 0*/
    arrWrk.push('value($USR_PersonID$)');    /* , "User ID" = 0*/

    chla.OPRADWL.NewOrderPfDto.orderId      = strOrderId;
    chla.OPRADWL.NewOrderPfDto.response     = false;
    chla.OPRADWL.NewOrderPfDto.funcOperCall = funcoper;
    chla.OPRADWL.NewOrderPfDto.FormId       = arrValues[4];
    chla.OPRADWL.NewOrderPfDto.encounterId  = arrValues[3];
    chla.OPRADWL.NewOrderPfDto.personId     = arrValues[2];
        chla.OPRADWL.NewOrderPfDto.ProcessStep  = 1;

    chla.objXmlCcl.open('GET', chla.eApps.cclProgram);
    /**
     * objXmlCcl.onreadystatechange function
     */
    chla.objXmlCcl.onreadystatechange = function () {
        var msgData,
            vEncounterID,
            vPersonID,
            vEX_FORM_ID,
            vOrderID,
            jsonData,
            errorFlag = false,
            log = [];
        if (chla.objXmlCcl.readyState === 4 && chla.objXmlCcl.status === 200) {
            msgData  = chla.objXmlCcl.responseText;
            jsonData = msgData;
            if (msgData !== null) {
                jsonData = eval('(' + msgData + ')');
                log.push("EncounterList: ");
                log.push(msgData);
                LogIt( {
                    logType: 'LogInfo',
                    sepChar: '',
                    logLevel: 100, arrParams: log
                });
            }
            if (jsonData.RPTDATA.ERR_STAT.toUpperCase() === 'TRUE') {
                alert('Error in Creation of PF Link information to custom table');
            } else {
                if(jsonData.RPTDATA.FNOPER !== 6) {
                    vOrderID     = chla.OPRADWL.NewOrderPfDto.orderId;
                    vEncounterID = chla.OPRADWL.NewOrderPfDto.encounterId;
                    vPersonID    = chla.OPRADWL.NewOrderPfDto.personId;
                    chla.OPRADWL.NewOrderPfDto.ProcessStep = 1;
                } else {
                    if (jsonData.RPTDATA.ENCTRLIST_CNT > 0) {
                        vEX_FORM_ID  = jsonData.RPTDATA.ENCTR_EXAM_FORM_ID;
                        vPersonID    = jsonData.RPTDATA.ENCTRLIST[0].PERSONID;
                        vEncounterID = jsonData.RPTDATA.ENCTRLIST[0].ENCTRID;
                        vOrderID     = jsonData.RPTDATA.ENCTRZEROORDERID;
                        chla.OPRADWL.NewOrderPfDto.orderId      = vOrderID;
                        chla.OPRADWL.NewOrderPfDto.funcOperCall = jsonData.RPTDATA.FNOPER;
                        chla.OPRADWL.NewOrderPfDto.encounterId  = vEncounterID;
                        chla.OPRADWL.NewOrderPfDto.personId     = vPersonID;
                        chla.OPRADWL.NewOrderPfDto.FormId       = vEX_FORM_ID;
                        chla.OPRADWL.NewOrderPfDto.ProcessStep  = 1;
                    } else {
                        LogIt({
                            logType : 'LogError',
                            logLevel: 100, arrParams: ['No valid encounter id found']
                        });
                    }
                }
                log.length   = 0;
                log.push('vEX_FORM_ID');
                log.push(vEX_FORM_ID);
                log.push('vPersonID');
                log.push(vPersonID);
                log.push('vEncounterID');
                log.push(vEncounterID);
                log.push('vOrderID');
                log.push(vOrderID);
                LogIt({
                    logType : 'LogInfo',
                    sepChar : ',',
                    logLevel: 100, arrParams: log
                });
                //todo: add error notification
                if (errorFlag === false) {
                    nextStep('#BtnCpyOrderIdMP','curstepone','cursteptwo','next','#btnPfMP');
                }
            }
        }
    };
    log.push("Send:");
    log.push(chla.eApps.cclProgram);
    log.push("   data:");
    log.push(arrWrk.join());
    LogIt( {
        logType: 'LogInfo',
        sepChar:',',
        logLevel: 100, arrParams: log
    });
    chla.objXmlCcl.send( arrWrk.join() );
}
function newPowerForm() {
    var funcoper,
        arrOrderId,
        strOrderId,
        arrWrk = [],
        arrValues,
        log = [];
    arrValues = $('#BtnExitOrderId').val().split('|');
    //arrValues = comp.value.split('|');
    /*
     arrValues[0], ;'MRN'
     arrValues[1], ;'NAME_FULL_FORMATTED'
     arrValues[2], ; PERSONID
     arrValues[3], ; ENCOUNTERID
     arrValues[4], ; FORM_ID
     arrValues[5], ; FORM_ACTIVITY
     arrValues[6]) ; ORDERID:OrderDescription
     */
    arrWrk.push("Orderid:");
    arrWrk.push(arrValues[6]);
    arrWrk.push("PersonID:");
    arrWrk.push(arrValues[2]);
    arrWrk.push("EncounterID:");
    arrWrk.push(arrValues[3]);
    arrWrk.push("FORM_ID:");
    arrWrk.push(arrValues[4]);
    LogIt( {
        logType: 'LogInfo',
        sepChar:',',
        logLevel: 100, arrParams: arrWrk
    });
    arrWrk.length = 0;
    funcoper = 99;
    if ( arrValues[3] < 10 ){
        funcoper = 6;
    }
    if (typeof  chla.objXmlCcl === 'undefined') {
        chla.objXmlCcl = new chlaMpageApi.XMLCclRequest();
    }
    arrOrderId = arrValues[6].split(':');
    if (arrOrderId.length === 2){
        strOrderId = arrOrderId[0];
    }else {
        strOrderId = arrWrk[6];
    }
    arrWrk.push('^MINE^');                   /* "Output to File/Printer/MINE" = "MINE"*/
    arrWrk.push(funcoper);                   /* , "Function Operation Selector" =3*/
    arrWrk.push('^^');                       /* , "Start Date Range" = ""*/
    arrWrk.push('^^');                       /* , "End Date Range" = ""*/
    arrWrk.push('^^');                       /* , "Start Date Range2" = ""*/
    arrWrk.push('^^');                       /* , "End Date Range2" = ""*/
    arrWrk.push('^REQUEST^');                /* , "Future Order State" = ""*/
    arrWrk.push('0');                        /* , "Specific Order ID" = New OrderID*/
    arrWrk.push('^Link:EncounterIdOperation^'); /* , "Linkage Pair" = ""*/
    arrWrk.push('^^');                       /* , "Order in Protocol State" = ""*/
    arrWrk.push(0);                          /* , "Encounter ID" = 0*/
    arrWrk.push(strOrderId + '.0');        /* , "ORDER ID" = 0*/
    arrWrk.push(arrValues[4] + '.0');        /* , "PowerForm ID" = 0*/
    arrWrk.push(arrValues[2] + '.0');        /* , "Person ID" = 0*/
    arrWrk.push('value($USR_PersonID$)');    /* , "User ID" = 0*/

    chla.OPRADWL.NewOrderPfDto.orderId      = strOrderId;
    chla.OPRADWL.NewOrderPfDto.response     = false;
    chla.OPRADWL.NewOrderPfDto.funcOperCall = funcoper;
    chla.OPRADWL.NewOrderPfDto.FormId       = arrValues[4];
    chla.OPRADWL.NewOrderPfDto.encounterId  = arrValues[3];
    chla.OPRADWL.NewOrderPfDto.personId     = arrValues[2];
    chla.OPRADWL.NewOrderPfDto.ProcessStep  = 1;

    chla.objXmlCcl.open('GET', chla.eApps.cclProgram);
    /**
     * objXmlCcl.onreadystatechange function
     */
    chla.objXmlCcl.onreadystatechange = function () {
        var msgData,
            vEncounterID,
            vPersonID,
            vEX_FORM_ID,
            vOrderID,
            jsonData,
            errorflag = false,
            log = [];
        if (chla.objXmlCcl.readyState === 4 && chla.objXmlCcl.status === 200) {
            msgData  = chla.objXmlCcl.responseText;
            jsonData = msgData;
            if (msgData !== null) {
                jsonData = eval('(' + msgData + ')');
                log.push("EncounterList: ");
                log.push(msgData);
                LogIt( {
                    logType: 'LogInfo',
                    sepChar: '',
                    logLevel: 100, arrParams: log
                });
            }
            if (jsonData.RPTDATA.ERR_STAT.toUpperCase() === 'TRUE') {
                alert('Error in Creation of PF Link information to custom table');
            } else {
                if(jsonData.RPTDATA.FNOPER !== 6) {
                    vOrderID = chla.OPRADWL.NewOrderPfDto.orderId;
                    vEncounterID = chla.OPRADWL.NewOrderPfDto.encounterId;
                    vPersonID = chla.OPRADWL.NewOrderPfDto.personId;
                    chla.OPRADWL.NewOrderPfDto.ProcessStep = 1;
                } else {
                    if (jsonData.RPTDATA.ENCTRLIST_CNT > 0) {
                        vEX_FORM_ID  = jsonData.RPTDATA.ENCTR_EXAM_FORM_ID;
                        vPersonID    = jsonData.RPTDATA.ENCTRLIST[0].PERSONID;
                        vEncounterID = jsonData.RPTDATA.ENCTRLIST[0].ENCTRID;
                        vOrderID     = jsonData.RPTDATA.ENCTRZEROORDERID;
                        chla.OPRADWL.NewOrderPfDto.orderId      = vOrderID;
                        chla.OPRADWL.NewOrderPfDto.funcOperCall = jsonData.RPTDATA.FNOPER;
                        chla.OPRADWL.NewOrderPfDto.encounterId  = vEncounterID;
                        chla.OPRADWL.NewOrderPfDto.personId     = vPersonID;
                        chla.OPRADWL.NewOrderPfDto.FormId       = vEX_FORM_ID;
                        chla.OPRADWL.NewOrderPfDto.ProcessStep  = 1;
                    } else {
                        LogIt({
                            logType : 'LogError',
                            logLevel: 100, arrParams: ['No valid encounter id found']
                        });
                    }
                }
                        log.length   = 0;
                        log.push('vEX_FORM_ID');
                        log.push(vEX_FORM_ID);
                        log.push('vPersonID');
                        log.push(vPersonID);
                        log.push('vEncounterID');
                        log.push(vEncounterID);
                        log.push('vOrderID');
                        log.push(vOrderID);
                        LogIt({
                            logType : 'LogInfo',
                            sepChar : ',',
                            logLevel: 100, arrParams: log
                        });
                //todo: add error notification
                if (errorflag === false) {
                    nextStep('#BtnCpyOrderId',"curstepone","cursteptwo","next","#btnPf")

                }
            }
        }
    };
    log.push("Send:");
    log.push(chla.eApps.cclProgram);
    log.push("   data:");
    log.push(arrWrk.join());
    LogIt( {
        logType: 'LogInfo',
        sepChar:',',
        logLevel: 100, arrParams: log
    });
    chla.objXmlCcl.send( arrWrk.join() );
}
function loadNewPowerform() {
    chla.OPRADWL.NewOrderPfDto.ProcessStep = 2;
    $('button#BtnExitOrderId').text('Exit');
       launch('NEW',
           chla.OPRADWL.NewOrderPfDto.personId,          //vPersonID,
           chla.OPRADWL.NewOrderPfDto.encounterId,       // vEncounterID,
           chla.OPRADWL.NewOrderPfDto.FormId,            // vEX_FORM_ID,
           chla.OPRADWL.NewOrderPfDto.ActivityId,         // 0
           chla.OPRADWL.NewOrderPfDto.orderId
       );
}
//----------------------------------
/**
 *
 * @param cBtn
 * @param curStep
 * @param nextStep
 * @param lbl
 * @param nBtn
 */
function nextStep (cBtn,curStep,nextStep,lbl,nBtn){
    var comp = $(cBtn),textDsp;
    textDsp = (lbl.toLowerCase() === 'next'? '<span style="color:green;"><==</span> Current Step':'&nbsp;');
    comp.css('backgroundColor','gray');
    comp.css('color','gray');
    comp.prop("disabled",true);
    $('div#' + curStep).html('&nbsp;');
    if (nextStep !== '') {
        $('div#' + nextStep).html(textDsp);
    }
    if (typeof nBtn !== 'undefined' ){
        if (nBtn !== '') {
            $(nBtn).prop("disabled", false);
        }
    }
}
/**
 *
 */
function exitMyform() {
    document.getElementById("WindDialog").innerHTML = '';
    if(typeof chla.clippy !== 'undefined')
        chla.clippy.destroy();
}

function launchMassProto() {
    var comp = this,
        arrOrderId,
        arrWrk,
        arrMode = [],
        c8Link1,
        c8Link1a,
        c8Link2,
        c8Link3,
        c8Link4,
        c8Link1Params,
        c8Link2Params,
        arrHtml0 = [
            '<div id="PatRelOrders" style="background-color:whitesmoke;font-size:16px;font-family:Tahoma, Geneva, sans-serif;height:800px;">',
            '<div  style="display:table;margin-left: 20px;">',
            '<div style="display:table-caption;margin:5px;font-size:x-large;font-weight: 800;text-align: center;width:1200px">Create New Powerform&nbsp;for&nbsp;Radiology&nbsp;Order&nbsp;</div>',
            '<div style="display:table-caption;text-align: center;margin:5px;font-size:larger;color:lightblue;font-weight: 800;width:1200px">Mass Protocolling Mode</div>'
        ],
        arrHtml1 = [
            '<div id="PatRelOrders" style="background-color:whitesmoke;font-size:16px;font-family:Tahoma, Geneva, sans-serif;height:800px;">',
            '<div  style="display:table;margin-left: 20px;">',
            '<div style="display:table-caption;margin:5px;font-size:x-large;font-weight: 800;text-align: center;width:1200px">Edit&nbsp;Radiology&nbsp;Order&nbsp;Group</div>',
            '<div style="display:table-caption;text-align: center;margin:5px;font-size:larger;color:lightblue;font-weight: 800;width:1200px">Mass Protocolling Mode</div>'
        ],
        arrHtml = [
            '<div style="display:table">',
            '<div style="display:table-row;">',
            '<div style="display:table-cell;width:1200px;padding-top:25px;padding-bottom: 10px;font-weight: 700">Patient Patient Information:</div></div>',
            '<div style="display:table">',
            '<div style="display:table-row">',
            '<div style="display:table-cell;width:150px;">Patient Name:</div>',
            '<div style="display:table-cell"><input style="width: 400px;" id="txtPtInfo" type="text" disabled value=" <#=ptName#>"/></div></div>',
            '<div style="display:table-row"><div style="display:table-cell">MRN:</div>',
            '<div style="display:table-cell"><input style="width: 400px;" id="txtPtMRN"  type="text" disabled value=" <#=ptMRN#>"/></div></div>',
            //'<div style="display:table-row;"><div style="display:table-cell">Order ID:</div>',
            //'<div style="display:table-cell"><input style="width: 400px;" id="txtOrderId" type="text" disabled value="<#=ptOrderId#>"/></div></div></div>',
            '</div>',
            '<div style="display:table;" >',
            '<div style="display:table-row;"><div style="display:table-cell;width:300px;padding-top:35px;padding-bottom: 25px;font-weight: 700">Patient Related Orders:</div></div></div>',
            '<div style="width:1200px;border:1px solid blue;height:300px; overflow-y: auto;font-size: 12px;" >',
            '<div style="display:table">',
            '<div style="display:table-row;font-size: 9px;color grey;">',
            '<div style="display:table-cell;border-bottom:1px solid blue;width:100px;text-align: center;background-color: lightgrey;">Order Id</div>',
            '<div style="display:table-cell;border-bottom:1px solid blue;width:300px;text-align: center;background-color: lightgrey;">Description</div>',
            '<div style="display:table-cell;border-bottom:1px solid blue;width:100px;text-align: center;background-color: lightgrey;">Order Dt</div>',
            '<div style="display:table-cell;border-bottom:1px solid blue;border-left: 1px solid blue;width:100px;text-align: center;background-color: lightgrey;">Order Id</div>',
            '<div style="display:table-cell;border-bottom:1px solid blue;width:300px;text-align: center;background-color: lightgrey;">Description</div>',
            '<div style="display:table-cell;border-bottom:1px solid blue;width:100px;text-align: center;background-color: lightgrey;">Order Dt</div>',
            '<div style="display:table-cell;border-bottom:1px solid blue;border-left: 1px solid blue;width:100px;text-align: center;background-color: lightgrey;">Order Id</div>',
            '<div style="display:table-cell;border-bottom:1px solid blue;width:300px;text-align: center;background-color: lightgrey;">Description</div>',
            '<div style="display:table-cell;border-bottom:1px solid blue;width:100px;text-align: center;background-color: lightgrey;">Order Dt</div>',
            '</div>',
            '<#=PatientRelatedOrders#>',
            '</div></div>'
        ],
        steps1 = [
            '<div style="display:table">',
            '<div style="display:table-row;"><div style="display:table-cell;width:300px;padding-top: 10px;padding-bottom: 25px;font-weight: 700">Process Steps:</div></div></div>',
            '<div style="display:table;width:750px;" >',
            '<div style="display:table-row;">',
            '<div style="display:table-cell;width:185px;">',
            '<button id="BtnCpyOrderIdMP" class="orderidcss" style="width:180px;"  onclick="',
            '<#=createLink1#>"  data-clipboard-text="<#=ptOrderId#>">Step 1</button></div>',
            '<div id="curstepone" style="display:table-cell;color:blue;font-weight:800;font-size:11px;width: 90px;"><span style="color:green;"><==</span> Current Step</div>',
            '<div style="display: table-cell;vertical-align: middle; width:350px;">',
            '<span style="color: gray; line-height: 18px;">&nbsp;&nbsp;Copy Order ID to Clipboard</span></div></div>',
            '<div style="display:table-row;">',
            '<div style="display:table-cell;width:185px;">&nbsp;</div>',
            '<div style="display:table-cell;">&nbsp;</div>',
            '<div style="display:table-cell;width:350px;">&nbsp;</div></div>',
            '<div style="display:table-row;padding-top:15px;">',
            '<div style="display:table-cell;width:185px;">',
            '<button id="btnPfMP" style="width: 180px;" disabled="disabled" onclick="',
            '<#=createLink2#>" value="">Step 2</button></div>',
            '<div id="cursteptwo" style="display:table-cell;color:blue;font-weight:800;font-size:11px;">&nbsp;</div>',
            '<div style="display:table-cell;vertical-align: middle;">',
            '<span style="color: gray; line-height: 18px;">&nbsp;&nbsp;Open New Radiology Exam Protocol PowerForm </span></div></div></div>',
            '</div><button id="BtnExitOrderIdMP" style="float: right;margin-right: 80px;width: 90px;" onclick="',
            '<#=createLink3#>" value="<#=ptPFinfo2#>" >Exit</button><br/><br/></div>'
        ],
        steps2 = [
            '</div>',
            '<div style="display:table;width:750px;" >',
            '<div style="display:table-row;">',
            '<div style="display:table-cell;width:185px;">&nbsp;</div>',
            '<div style="display:table-cell;">&nbsp;</div>',
            '<div style="display:table-cell;width:350px;">&nbsp;</div></div>',
            '<div style="display:table-row;padding-top:15px;">',
            '<div style="display:table-cell;width:185px;">',
            '<button id="btnPfMP" style="width: 180px;" onclick="',
            '<#=createLink1#>" value="">Update</button></div>',
            //'<div id="cursteptwo" style="display:table-cell;color:blue;font-weight:800;font-size:11px;"><==</div>',
            '<div style="display:table-cell;vertical-align: middle;width: 400px;">',
            '<span style="color: gray; line-height: 18px;">&nbsp;&nbsp; Mass Protocolled Grouping</span></div></div>',
            '</div><button id="BtnExitOrderIdMP" style="float: right;margin-right: 80px;width: 90px;" onclick="',
            '<#=createLink2#>" value="<#=ptPFinfo2#>" >Cancel</button><br/><br/></div>'
        ],
        cellTplt = [
            '<div id="chkbk<#=OrderID1#>" style="display:table-cell;border-bottom-color: blue; border-bottom-width: 1px; border-bottom-style: solid; ',
            '<#=css1#>"><input name="PatRelOrder" type="checkbox" <#=checked#> <#=disabled#>  value="<#=OrderID1#>"><#=OrderID1#></div>',
            '<div id="txtlbl<#=OrderID1#>" style="display:table-cell;border-bottom:1px solid blue;"><#=OrderDesc1#></div>',
            '<div id="dtlbl<#=OrderID1#>" style="display:table-cell;border-bottom:1px solid blue;"><#=OrderDTTM1#></div>'
        ],
        cellTplt2 = [
            '<div style="display:table-cell;<#=css1#>;border-bottom:1px solid blue;"><#=OrderID1#></div>',
            '<div style="display:table-cell;border-bottom:1px solid blue;"><#=OrderDesc1#></div>',
            '<div style="display:table-cell;border-bottom:1px solid blue;"><#=OrderDTTM1#></div>'
        ],
        dtoTemp,
        grp_id = [],
        relatedOrders = [],
        appObj = chla.OPRADWL,
        $eAppsPFlinker_body,
        strWrk;
    arrWrk = comp.value.split('|');
    /*
     arrWrk[0], ;'MRN'
     arrWrk[1], ;'NAME_FULL_FORMATTED'
     arrWrk[2], ; PERSONID
     arrWrk[3], ; ENCOUNTERID
     arrWrk[4], ; FORM_ID
     arrWrk[5], ; FORM_ACTIVITY
     arrWrk[6]) ; ORDERID:ORDER DESC ===> ORDERID:MP
     arrWrk[7]) ; MODALITY
     arrWrk[8]) ; GROUP_PF_ID
     */
    chla.OPRADWL.NewOrderPfDto.personId     = arrWrk[2];
    chla.OPRADWL.NewOrderPfDto.encounterId  = arrWrk[3];
    chla.OPRADWL.NewOrderPfDto.FormId       = arrWrk[4];
    chla.OPRADWL.NewOrderPfDto.ActivityId   = arrWrk[5];
    chla.OPRADWL.NewOrderPfDto.btnId        = $(this).attr('ID');
    chla.OPRADWL.NewOrderPfDto.ProcessStep  = 0;
    chla.OPRADWL.NewOrderPfDto.MpOperation  = true;

    arrOrderId = arrWrk[6].split(':');
    chla.OPRADWL.NewOrderPfDto.grpId        = arrOrderId[0] + ":MP";
    chla.OPRADWL.NewOrderPfDto.grpOrderId   = arrOrderId[0] + ":MP*";
    chla.OPRADWL.NewOrderPfDto.orderId      = arrOrderId[0];
    c8Link1Params = arrWrk.join('|');
    c8Link1  =  "ldClipbrdMP(2);createLinkTblEntry2();nextStep('#btnPfMP','cursteptwo','','','');";
    c8Link4  = 'updateLinkTblEntryMP();';

    c8Link1a = "ldClipbrdMP(1);";
    c8Link2  = "loadNewPowerform();createLinkTblEntry();";
    c8Link3  = 'createLinkTblEntry2();';

    c8Link2Params = '';
    if ( comp.id.indexOf('BTNUPTMP') > -1) {
        strWrk = $(this).attr('data-groupd');
        if (strWrk !== '') {
            dtoTemp = strWrk.split('|');

            dtoTemp.forEach(
                function (item, index) {
                    var strWrk1,
                        arrWrk;
                    arrWrk = item.split('@');
                    if (index === 0) {
                        relatedOrders.push('<div style="display:table-row;border-bottom:1px solid blue;">');
                        relatedOrders.push(chla.eApps.gFuncs.parseTemplate(cellTplt.join(''), {
                            css1: 'border-left:1px solid blue;',
                            OrderID1: arrWrk[0],
                            OrderDesc1: arrWrk[1],
                            OrderDTTM1: arrWrk[2].replace(/... P.T/,''),
                            checked: 'checked',
                            disabled:  ''
                        }));

                    } else if (index % 3 === 0) {
                        relatedOrders.push('</div><div style="display:table-row;border-bottom:1px solid blue;">');
                        relatedOrders.push(chla.eApps.gFuncs.parseTemplate(cellTplt.join(''), {
                            css1: 'border-left:1px solid blue;',
                            OrderID1: arrWrk[0],
                            OrderDesc1: arrWrk[1],
                            OrderDTTM1: arrWrk[2].replace(/... P.T/,''),
                            checked: 'checked',
                            disabled:  ''
                        }));

                    } else {
                        relatedOrders.push(chla.eApps.gFuncs.parseTemplate(cellTplt.join(''), {
                            css1: 'border-left:1px solid blue;',
                            OrderID1: arrWrk[0],
                            OrderDesc1: arrWrk[1],
                            OrderDTTM1: arrWrk[2].replace(/... P.T/,''),
                            checked: 'checked',
                            disabled:  ''
                        }));

                    }
                }
            );
            if (relatedOrders.length % 4 > 0) {
                relatedOrders.push(chla.eApps.gFuncs.parseTemplate(cellTplt2.join(''), {
                    css1: 'border-left:1px solid blue;',
                    OrderID1: '&nbsp;',
                    OrderDesc1: '&nbsp;',
                    OrderDTTM1: '&nbsp;'
                }));
            }
            if (relatedOrders.length % 4 > 0) {
                relatedOrders.push(chla.eApps.gFuncs.parseTemplate(cellTplt2.join(''), {
                    css1: 'border-left:1px solid blue;',
                    OrderID1: '&nbsp;',
                    OrderDesc1: '&nbsp;',
                    OrderDTTM1: '&nbsp;'
                }));
            }

            relatedOrders.push('</div>');

            arrMode.push(arrHtml1.join(''));
            arrMode.push(arrHtml.join(''));
            arrMode.push(steps2.join(''));

            myFormShow();
            $eAppsPFlinker_body = $('div#eAppsPFlinker-body');
            $eAppsPFlinker_body.html(chla.eApps.gFuncs.parseTemplate(arrMode.join(''), {
                ptName: arrWrk[1],
                ptMRN: arrWrk[0],
                ptOrderId: chla.OPRADWL.NewOrderPfDto.grpId,
                ptPFinfo1: c8Link2Params,
                ptPFinfo2: c8Link1Params,
                createLink1: c8Link1,
                createLink2: c8Link4,
                PatientRelatedOrders: relatedOrders.join('')
            }));
            chla.OPRADWL.NewOrderPfDto.grpId = 'EDIT';
            $('div#eAppsPFlinker').css({'height': '800px', 'top': '0', 'width': '1260px', 'left': '20px'});
            $eAppsPFlinker_body.css({'height': '800px'});
            chla.OPRADWL.NewOrderPfDto.MpGrpList    = grp_id.slice();
        }
    }else {
        dtoTemp = appObj.Data.getBaseViewOrders(appObj).filter(
            function (orderItem) {
                var retVal;
                if(chla.OPRADWL.FeatureCtl.F00003_0.Available) {
                    retVal = ( orderItem.PERSONID.toString() === arrWrk[2] && orderItem.GROUP_PF_ID === 0 && orderItem.arrTreeStructureP2 === arrWrk[7]);
                } else{
                    retVal = ( orderItem.PERSONID.toString() === arrWrk[2] && orderItem.arrTreeStructureP2 === arrWrk[7]);
                }
                return retVal;
            });

        if (dtoTemp.length > 1) {

            dtoTemp.forEach(
                function (item, index) {

                    if (index === 0) {
                        relatedOrders.push('<div style="display:table-row;border-bottom:1px solid blue;">');
                        relatedOrders.push(chla.eApps.gFuncs.parseTemplate(cellTplt.join(''), {
                            css1:       'border-left:1px solid blue;',
                            OrderID1:   item.ORDERID,
                            OrderDesc1: item.ORDER_LBL,
                            OrderDTTM1: item.ORIGORDDT.replace(/... P.T/,''),
                            checked:    (parseInt(arrOrderId[0]) === item.ORDERID ? 'checked' : ''),
                            disabled:   (parseInt(arrOrderId[0]) === item.ORDERID ? 'disabled' : '')
                        }));
                        grp_id.push(item.ORDERID, ':', item.ORDER_LBL, ' ');
                    } else if (index % 3 === 0) {
                        relatedOrders.push('</div><div style="display:table-row;border-bottom:1px solid blue;">');
                        relatedOrders.push(chla.eApps.gFuncs.parseTemplate(cellTplt.join(''), {
                            css1: 'border-left:1px solid blue;',
                            OrderID1: item.ORDERID,
                            OrderDesc1: item.ORDER_LBL,
                            OrderDTTM1: item.ORIGORDDT.replace(/... P.T/,''),
                            checked: (parseInt(arrOrderId[0]) === item.ORDERID ? 'checked' : ''),
                            disabled: (parseInt(arrOrderId[0]) === item.ORDERID ? 'disabled' : '')
                        }));
                        grp_id.push(item.ORDERID, ':', item.ORDER_LBL, ' ');
                    } else {
                        relatedOrders.push(chla.eApps.gFuncs.parseTemplate(cellTplt.join(''), {
                            css1: 'border-left:1px solid blue;',
                            OrderID1: item.ORDERID,
                            OrderDesc1: item.ORDER_LBL,
                            OrderDTTM1: item.ORIGORDDT.replace(/... P.T/,''),
                            checked: (parseInt(arrOrderId[0]) === item.ORDERID ? 'checked' : ''),
                            disabled: (parseInt(arrOrderId[0]) === item.ORDERID ? 'disabled' : '')
                        }));
                        grp_id.push(item.ORDERID, ':', item.ORDER_LBL, ' ');
                    }
                }
            );

            if (relatedOrders.length % 4 > 0) {
                relatedOrders.push(chla.eApps.gFuncs.parseTemplate(cellTplt2.join(''), {
                    css1: 'border-left:1px solid blue;',
                    OrderID1: '&nbsp;',
                    OrderDesc1: '&nbsp;',
                    OrderDTTM1: '&nbsp;'
                }));
            }
            if (relatedOrders.length % 4 > 0) {
                relatedOrders.push(chla.eApps.gFuncs.parseTemplate(cellTplt2.join(''), {
                    css1: 'border-left:1px solid blue;',
                    OrderID1: '&nbsp;',
                    OrderDesc1: '&nbsp;',
                    OrderDTTM1: '&nbsp;'
                }));
            }

            relatedOrders.push('</div>');

            arrMode.push(arrHtml0.join(''));
            arrMode.push(arrHtml.join(''));
            arrMode.push(steps1.join(''));

            myFormShow();
            $eAppsPFlinker_body = $('div#eAppsPFlinker-body');
            $eAppsPFlinker_body.html(chla.eApps.gFuncs.parseTemplate(arrMode.join(''), {
                ptName:                 arrWrk[1],
                ptMRN:                  arrWrk[0],
                ptOrderId:              chla.OPRADWL.NewOrderPfDto.grpId,
                ptPFinfo1:              c8Link2Params,
                ptPFinfo2:              c8Link1Params,
                createLink1:            c8Link1a,
                createLink2:            c8Link2,
                createLink3:            c8Link3,
                PatientRelatedOrders:   relatedOrders.join('')
            }));
            $('div#eAppsPFlinker').css({'height': '800px', 'top': '0', 'width': '1260px', 'left': '20px'});
            $eAppsPFlinker_body.css({'height': '800px'});
            chla.OPRADWL.NewOrderPfDto.grpId = 'LINK';
        } else {
            alert('Mass Protocolling not available for the Person: Only 1 order found');
        }
    }
}
/**
 *
 */
function launchNewPF() {
    var comp    = this,
        arrWrk,
         c8Link1,
        c8Link2,
        c8Link3,
        c8Link1Params,
        c8Link2Params,
        arrHtml = [
            '<div style="background-color:whitesmoke;font-size:16px;font-family:Tahoma, Geneva, sans-serif;height: 460px;">',
            '<div  style="display:table;margin-left: 20px;">',
            '<div style="display:table-caption;margin:5px;font-size:x-large;font-weight: 800;text-align: center;width:750px">',
            'Create New Powerform&nbsp;for&nbsp;Radiology&nbsp;Order&nbsp;</div>',
            '<div style="display:table">',
            '<div style="display:table-row;">',
            '<div style="display:table-cell;width:600px;padding-top:25px;padding-bottom: 10px;font-weight: 700">Patient Patient Information:</div></div>',
            '<div style="display:table">',
            '<div style="display:table-row">',
            '<div style="display:table-cell;width:150px;">Patient Name:</div>',
            '<div style="display:table-cell"><input style="width: 400px;" id="txtPtInfo" type="text" disabled value=" <#=ptName#>"/></div></div>',
            '<div style="display:table-row"><div style="display:table-cell">MRN:</div>',
            '<div style="display:table-cell"><input style="width: 400px;" id="txtPtMRN"  type="text" disabled value=" <#=ptMRN#>"/></div></div>',
            '<div style="display:table-row;"><div style="display:table-cell">Order ID:</div>',
            '<div style="display:table-cell"><input style="width: 400px;" id="txtOrderId" type="text" disabled value="<#=ptOrderId#>"/></div></div></div></div>',
            '<div style="display:table">',
            '<div style="display:table-row;"><div style="display:table-cell;width:300px;padding-top:35px;padding-bottom: 25px;font-weight: 700">',
            'Process Steps:</div></div></div>',
            '<div style="display:table;width:750px;" >',
            '<div style="display:table-row;">',
            '<div style="display:table-cell;width:185px;">',
            '<button id="BtnCpyOrderId" class="orderidcss" style="width:180px;"  onclick="',
            '<#=createLink1#>"  data-clipboard-text="<#=ptOrderId#>">Step 1</button></div>',
            '<div id="curstepone" style="display:table-cell;color:blue;font-weight:800;font-size:11px;width: 90px;"><span style="color:green;">',
            '<==</span> Current Step</div>',
            '<div style="display: table-cell;vertical-align: middle; width:350px;">',
            '<span style="color: gray; line-height: 18px;">&nbsp;&nbsp;Copy Order ID to Clipboard</span></div></div>',
            '<div style="display:table-row;">',
            '<div style="display:table-cell;width:185px;">&nbsp;</div>',
            '<div style="display:table-cell;">&nbsp;</div>',
            '<div style="display:table-cell;width:350px;">&nbsp;</div></div>',
            '<div style="display:table-row;padding-top:15px;">',
            '<div style="display:table-cell;width:185px;">',
            '<button id="btnPf" style="width: 180px;" disabled="disabled" onclick="',
            '<#=createLink2#>" value="">Step 2</button></div>',
            '<div id="cursteptwo" style="display:table-cell;color:blue;font-weight:800;font-size:11px;">&nbsp;</div>',
            '<div style="display:table-cell;vertical-align: middle;">',
            '<span style="color: gray; line-height: 18px;">&nbsp;&nbsp;Open New Radiology Exam Protocol PowerForm </span></div></div></div>',
            '</div><br/><br/>'
        ];
    if(chla.OPRADWL.FeatureCtl.F00003_0.Available){
        arrHtml.push(
            '<button id="BtnNewViewMP" style="margin-right: 90px; float: right;" onclick="launchMassProto.call(this);"  value="<#=ptPFinfo2#>">Mass Protocol</button>'
        );
    }
    arrHtml.push(
        '<button id="BtnExitOrderId" style="float: right;margin-right: 50px;" onclick="',
        '<#=createLink3#>"  value="<#=ptPFinfo2#>" ><#=btnLbl#></button><br/><br/></div>'
    );
    myFormShow();
    arrWrk                = comp.value.split('|');
    /*
     arrValues[0], ;'MRN'
     arrValues[1], ;'NAME_FULL_FORMATTED'
     arrValues[2], ; PERSONID
     arrValues[3], ; ENCOUNTERID
     arrValues[4], ; FORM_ID
     arrValues[5], ; FORM_ACTIVITY
     arrValues[6]) ; ORDERID:order desc
     */
    chla.OPRADWL.NewOrderPfDto.encounterId = arrWrk[3];
    chla.OPRADWL.NewOrderPfDto.personId = arrWrk[2];
    chla.OPRADWL.NewOrderPfDto.FormId = arrWrk[4];
    chla.OPRADWL.NewOrderPfDto.ActivityId = arrWrk[5];
    chla.OPRADWL.NewOrderPfDto.btnId = $(this).attr('ID');
    chla.OPRADWL.NewOrderPfDto.MpOperation = false;
    c8Link1 = 'ldClipbrd();newPowerForm(1)';
    c8Link2 = 'loadNewPowerform();createLinkTblEntry();';
    c8Link3 = 'exitMyform();newOrderProcessed();';

    c8Link1Params = arrWrk.join('|');
    c8Link2Params = '';
        $('div#eAppsPFlinker-body').html( chla.eApps.gFuncs.parseTemplate(arrHtml.join(''), {
        ptName   : arrWrk[1],
        ptMRN    : arrWrk[0],
        ptOrderId: arrWrk[6].trim(),
        ptPFinfo1 : c8Link2Params,
        ptPFinfo2 : c8Link1Params,
        createLink1: c8Link1,
        createLink2: c8Link2,
        createLink3: c8Link3,
        btnLbl: 'Cancel'
    }));
}
/**
 * This will copy a specific associate value to the clipboard
 */
function ldClipbrd(){
    // noinspection JSCheckFunctionSignatures
    chla.clippy = new Clipboard('.orderidcss');
    $('button#BtnNewViewMP').hide();
}

// noinspection JSUnusedGlobalSymbols
/**
 *
 * @param aOperType
 */
function ldClipbrdMP(aOperType) {
    var arrOrders = [],
        $BtnCpyOrderIdMP = $('button#BtnCpyOrderIdMP');
    arrOrders.push($BtnCpyOrderIdMP.attr('data-clipboard-text'));
    arrOrders.push('  ');
    $('input[name="PatRelOrder"]:checked').each(
        function (index, item) {
            var orderId = item.value;
            arrOrders.push(', ');
            arrOrders.push($('div#txtlbl' + orderId).text());
        }
    );
    if (aOperType === 1) {
        if (arrOrders.length < 6) {
            alert('For Grouping a minimum of 2 orders must be selected');
        } else {
            $BtnCpyOrderIdMP.attr('data-clipboard-text', arrOrders.join(''));
            // noinspection JSCheckFunctionSignatures
            chla.clippy = new Clipboard('.orderidcss');
            chla.OPRADWL.NewOrderPfDto.ProcessStep = 1;
            newPowerFormMP();
        }
    } else if(aOperType === 2){
        chla.OPRADWL.NewOrderPfDto.ProcessStep = 2;
        $('button#BtnExitOrderIdMP').text('Exit');
    }
}
/**
 *
 * @param v
 * @param record
 */
function orderIdBtn(v,record) {
    var arrWrk=[],
        Group_PF_id;
    if (record.LEVEL === 3 ) {
        if (record.FORM_ACTIVITY_ID === 0 &&
            record.PROTOCAL_STATUS.toUpperCase() === 'NEW') {
            arrWrk.push(
                '<button  class="orderidcss" ',
                ' id="BTN',
                v,
                '" ',
                'style="width:90px;line-height:11px;font-size:10px;background-color:lightgrey;" ',
                'data-clipboard-text="',
                v + '|' + record.ORDER_LBL,
                '"',
                'onclick="launchNewPF.call(this);"',
                ' value="',
                record.MRN,
                '|',
                record.NAME_FULL_FORMATTED,
                '|',
                record.PERSONID,
                "|",
                record.ENCNTRID,
                "|",
                //287650320.00,  //
                record.EXAM_FORM_ID ,
                "|",
                0.00,
                "|",
                v + ':' + record.ORDER_LBL,
                "|",
                record.arrTreeStructureP2,
                '"> ',
                v,
                '</button>');


        } else if (chla.OPRADWL.Data.getOrdState(chla.OPRADWL).toUpperCase()=== 'FUTURE' ) {
            if (chla.OPRADWL.FeatureCtl.F00003_0.Available) {
                if (record.GROUP_PF_ID > 0) {
                    if (record.arrTreeStructureP2.indexOf('NURSEPRACTITIONER') === -1) {
                        arrWrk.push(
                            '<button  class="orderidcss" ',
                            ' id="BTNUPTMP',
                            v,
                            '" ',
                            'style="width:90px;line-height:11px;font-size:10px;background-color:orange;" ',
                            'onclick="launchMassProto.call(this);" ',
                            ' value="',
                            record.MRN,
                            '|',
                            record.NAME_FULL_FORMATTED,
                            '|',
                            record.PERSONID,
                            "|",
                            record.ENCNTRID,
                            "|",
                            //287650320.00,  //
                            record.EXAM_FORM_ID,
                            "|",
                            0.00,
                            "|",
                            v + ':MP ',
                            "|",
                            record.arrTreeStructureP2,
                            '" '
                        );
                        Group_PF_id = "G" + record.GROUP_PF_ID;
                        if (typeof chla.OPRADWL.View.GROUP_PF_ID[Group_PF_id] !== 'undefined') {
                            arrWrk.push('data-groupd="');
                            arrWrk.push(chla.OPRADWL.View.GROUP_PF_ID[Group_PF_id].join('|'));
                            arrWrk.push('"');
                        }
                        arrWrk.push(
                            '> ',
                            v,
                            '</button>');

                    } else {
                        arrWrk.push(
                            '<span ',
                            ' style="width:90px;line-height:11px;padding:1px 13px;',
                            'border: 3px solid orange;font-weight:normal;font-size:10px;',
                            'background-color:orange;" ',
                            'data-clipboard-text="',
                            v,
                            '"',
                            ' value="',
                            v,
                            ':',
                            record.ORDER_LBL,   //order_id
                            '"> ',
                            v,
                            '</span>'
                        );
                    }

                } else {
                    if (record.arrTreeStructureP2.indexOf('NURSEPRACTITIONER') === -1) {
                        arrWrk.push(
                            '<button  class="orderidcss" ',
                            ' id="BTN',
                            v,
                            '" ',
                            'style="width:90px;line-height:11px;font-size:10px;background-color:lightblue;" ',
                            'data-clipboard-text="',
                            v + '|' + record.ORDER_LBL,
                            '"',
                            'onclick="launchMassProto.call(this);"',
                            ' value="',
                            record.MRN,
                            '|',
                            record.NAME_FULL_FORMATTED,
                            '|',
                            record.PERSONID,
                            '|',
                            record.ENCNTRID,
                            '|',
                            //287650320.00,
                            record.EXAM_FORM_ID,
                            '|',
                            0.00,
                            '|',
                            v + ':MP',
                            '|',
                            record.arrTreeStructureP2,
                            '|0"> ',
                            v,
                            '</button>');
                    } else {
                        arrWrk.push(
                            '<span ',
                            ' style="width:90px;padding:1px 13px;border: 3px solid lightblue;font-weight:normal;font-size:10px;background-color:lightblue;" ',
                            'data-clipboard-text="',
                            v,
                            '"',
                            ' value="',
                            v,
                            ':',
                            record.ORDER_LBL,   //order_id
                            '"> ',
                            v,
                            '</button>'
                        );
                    }
                }
            } else {
                arrWrk.push(v);
            }
        } else if (chla.OPRADWL.Data.getOrdState(chla.OPRADWL).toUpperCase() === 'MODIFY' &&
                          record.EP_REORDER_FLAG.toUpperCase() === 'YES') {
            arrWrk.push(
                '<button  class="orderidcss"',
                ' style="width:90px;line-height:11px;color:white;font-weight:800;font-size:10px;background-color:red;" ',
                'data-clipboard-text="',
                v,
                '"',
                ' value="',
                v  + ':' + record.ORDER_LBL ,   //order_id
                '"> ',
                v,
                '</button>'
            );
        } else {
            arrWrk.push(v);
        }
        return arrWrk.join('');
    } else {
        return '';
    }
}
/**
 *
 */
function createLinkTblEntry (){
    var arrValues = ['createLinkTblEntry Function called'],
        funcoper = 2;
    LogIt( {
        logType: 'LogInfo',
        logLevel: 100, arrParams: arrValues
    });
    chla.OPRADWL.NewOrderPfDto.response =  false;
    chla.OPRADWL.NewOrderPfDto.funcOperCall = funcoper;

    if (funcoper > 0 && chla.OPRADWL.NewOrderPfDto.ProcessStep === 2){
        sendCreateLinkTblEntry(
            funcoper,
            chla.OPRADWL.NewOrderPfDto.orderId,
            chla.OPRADWL.NewOrderPfDto.encounterId,
            chla.OPRADWL.NewOrderPfDto.personId);
    }
}
function sendCreateLinkTblEntry(aFuncOper,aOrderId,aEncounterId,aPersonId) {
    var arrWrk = [],
        strFutureOrderState =(chla.OPRADWL.NewOrderPfDto.MpOperation ? '^MPCREATE^':'^UPDATE^'),
        strMPorderId;
    strMPorderId = (strFutureOrderState=== '^MPCREATE^'? '^'+ chla.OPRADWL.NewOrderPfDto.grpOrderId +'^':'^^');

    arrWrk.push('^MINE^');                  // "Output to File/Printer/MINE" = "MINE"
    arrWrk.push(aFuncOper);                 //     , "Function Operation Selector" = 2
    arrWrk.push(strMPorderId);              //     , "Start Date Range" = ""
    arrWrk.push('^^');                      //     , "End Date Range" = ""
    arrWrk.push('^^');                      //     , "Start Date Range2" = ""
    arrWrk.push('^^');                      //     , "End Date Range2" = ""
    arrWrk.push(strFutureOrderState);       //     , "Future Order State" = ""
    arrWrk.push(aOrderId + '.0');           //     , "Specific Order ID" = New OrderID
    arrWrk.push('^initial:linkOperation^'); //     , "Linkage Pair" = ""
    arrWrk.push('^^');                      //     , "Order in Protocol State" = ""
    arrWrk.push(aEncounterId + '.0');       //     , "Encounter ID" = 0
    arrWrk.push(aOrderId + '.0');           //     , "ORDER ID" = 0
    arrWrk.push(0);                         //     , "PowerForm ID" = 0
    arrWrk.push(aPersonId + '.0');          //     , "Person ID" = 0
    arrWrk.push('value($USR_PersonID$)');   //     , "User ID" = 0
    LogIt( {
        logType: 'LogInfo',
        sepChar:',',
        logLevel: 100, arrParams: arrWrk
    });
    if (typeof  chla.objXmlCcl2 === 'undefined') {
        chla.objXmlCcl2 = new chlaMpageApi.XMLCclRequest();
    }
    chla.objXmlCcl2.open('GET', chla.eApps.cclProgram);
    chla.objXmlCcl2.onreadystatechange = function () {
        var msgData,
            jsonData,
            log=[];
        if (chla.objXmlCcl2.readyState === 4 && chla.objXmlCcl2.status === 200) {
            msgData  = chla.objXmlCcl2.responseText;
            jsonData = msgData;
            if (msgData !== null) {
                jsonData = eval('(' + msgData + ')');
            }
            log.push('sendCreateLinkTblEntry response: ');
            log.push( msgData);
            LogIt( {
                logType: 'LogInfo',
                sepChar: '',
                logLevel: 100, arrParams: log
            });
            if (jsonData.RPTDATA.ERR_STAT.toUpperCase() === 'TRUE' ) {
                alert ('Error in Creation of PF Link information to custom table');
            }else {
                chla.OPRADWL.NewOrderPfDto.response =  true;
                if (chla.OPRADWL.NewOrderPfDto.MpOperation){
                    nextStep('#btnPfMP','cursteptwo','','','');
                } else {
                    nextStep('#btnPf', "cursteptwo", "", "", "")
                }
            }
        }
    };
    chla.objXmlCcl2.send(arrWrk.join());

}
function MP_OrderProcessed(arrPatOrders) {
    if (chla.OPRADWL.NewOrderPfDto.response) {
        /* remove new PF button */
        arrPatOrders.forEach(
            function (item) {
                var arrWrk = ['#'];
                if (chla.OPRADWL.NewOrderPfDto.grpId === 'EDIT'){
                    arrWrk.push('BTNUPTMP' + item);
                } else {
                    arrWrk.push('BTN' + item);
                }
                $(arrWrk.join('')).replaceWith(item );
            }
        );
        chla.OPRADWL.NewOrderPfDto.orderId = 0;
        chla.OPRADWL.NewOrderPfDto.response = false
    }
}
// noinspection JSUnusedGlobalSymbols
function createLinkTblEntry2 (){
    var arrValues = ['createLinkTblEntry2 Function called - Grouped Orders: '],
        NewOrderPfDto = chla.OPRADWL.NewOrderPfDto,
        funcoper,
        MP_BaseOrderID;
    NewOrderPfDto.arrPatOrders = [];
    NewOrderPfDto.response =  false;
    $('button#BtnExitOrderIdMP').text('Exit');
    if (NewOrderPfDto.ProcessStep === 2){
        MP_BaseOrderID = $('input[name="PatRelOrder"]:disabled').val();
        if (typeof MP_BaseOrderID !== 'undefined') {
            NewOrderPfDto.arrPatOrders.push(MP_BaseOrderID);
        } else {
            MP_BaseOrderID = 0;
        }
        /*$('input[name="PatRelOrder"]:checked').each(*/
        if (chla.OPRADWL.NewOrderPfDto.grpId === 'EDIT') {
            $('input[name="PatRelOrder"]:not(:checked)').each(
                function (index, item) {
                    var orderId = item.value;
                    if (MP_BaseOrderID !== orderId) {
                        NewOrderPfDto.arrPatOrders.push(orderId);
                    }
                }
            );
        } else {
            $('input[name="PatRelOrder"]:checked').each(
                function (index, item) {
                    var orderId = item.value;
                    if (MP_BaseOrderID !== orderId) {
                        NewOrderPfDto.arrPatOrders.push(orderId);
                    }
                }
            );
        }
        funcoper = 12;
        NewOrderPfDto.funcOperCall = funcoper;
        arrValues.push(NewOrderPfDto.arrPatOrders.join(','));
        sendCreateLinkTblEntry2(
            funcoper,
            NewOrderPfDto.arrPatOrders,
            NewOrderPfDto.encounterId,
            NewOrderPfDto.personId,
            NewOrderPfDto.grpId
        );
    }
    if (NewOrderPfDto.arrPatOrders.length === 0) {
        exitMyform()
    }
    LogIt( {
        logType: 'LogInfo',
        logLevel: 100, arrParams: arrValues
    });
}
// noinspection JSUnusedGlobalSymbols
function updateLinkTblEntryMP (){
    var arrValues = ['updateLinkTblEntry2 Function called - Grouped Orders: '],
        NewOrderPfDto = chla.OPRADWL.NewOrderPfDto,
        funcoper = 13;
    NewOrderPfDto.arrPatOrders  = [];
    NewOrderPfDto.response      =  false;
    NewOrderPfDto.funcOperCall  = funcoper;
    if (funcoper > 0 && NewOrderPfDto.ProcessStep === 2){
        $('input[name="PatRelOrder"]:checked').each(
            function (index,item) {
                var orderId = item.value;
                NewOrderPfDto.arrPatOrders.push(orderId);
            }
        );
        arrValues.push(NewOrderPfDto.arrPatOrders.join(','));
        sendCreateLinkTblEntry2(
            funcoper,
            NewOrderPfDto.arrPatOrders,
            NewOrderPfDto.encounterId,
            NewOrderPfDto.personId,
            NewOrderPfDto.grpId
        );
    }
    if (NewOrderPfDto.arrPatOrders.length === 0) {
        exitMyform()
    }

    LogIt( {
        logType: 'LogInfo',
        logLevel: 100, arrParams: arrValues
    });
}

/**
 *
 * @param aFuncOper
 * @param aArrPatOrders
 * @param aEncounterId
 * @param aPersonId
 * @param aGrpID
 */
function sendCreateLinkTblEntry2(aFuncOper,aArrPatOrders,aEncounterId,aPersonId,aGrpID) {
    var arrWrk = [],
    strFutureOrderState= (aGrpID === "EDIT"?'^MPUPDATE^':'^MPLINK^'),
    funcOper = (aGrpID === "EDIT"?13:12) ;
    arrWrk.push('^MINE^');                              // "Output to File/Printer/MINE" = "MINE"
    arrWrk.push(funcOper);                              //     , "Function Operation Selector" =3
    arrWrk.push('^^');                                  //     , "Start Date Range" = ""
    arrWrk.push('^^');                                  //     , "End Date Range" = ""
    arrWrk.push('^^');                                  //     , "Start Date Range2" = ""
    arrWrk.push('^^');                                  //     , "End Date Range2" = ""
    arrWrk.push(strFutureOrderState);                   //     , "Future Order State" = ""
    arrWrk.push(0);                                     //     ,
    arrWrk.push('^^');                                  //     ,   Specific Link ID
    arrWrk.push('^'+ aArrPatOrders.join(',') + '^');    // "Linkage Pair" = ""  Linkage Group ID for MP Powerform
    arrWrk.push(aEncounterId + '.0');                   //     , "Encounter ID" = 0
    arrWrk.push(0);                                     //     , "ORDER ID" = 0
    arrWrk.push(aArrPatOrders.length + '.0' );          //     , "PowerForm ID" = 0
    arrWrk.push(aPersonId + '.0');                      //     , "Person ID" = 0
    arrWrk.push('value($USR_PersonID$)');               //     , "User ID" = 0
    LogIt( {
        logType: 'LogInfo',
        sepChar:',',
        logLevel: 100, arrParams: arrWrk
    });
    if (typeof  chla.objXmlCcl2 === 'undefined') {
        chla.objXmlCcl2 = new chlaMpageApi.XMLCclRequest();
    }
    chla.objXmlCcl2.open('GET', chla.eApps.cclProgram);
    /**
     * objXmlCcl.onreadystatechange function
     */
    chla.objXmlCcl2.onreadystatechange = function () {
        var msgData,
            jsonData,
            log=[];
        if (chla.objXmlCcl2.readyState === 4 && chla.objXmlCcl2.status === 200) {
            msgData  = chla.objXmlCcl2.responseText;

            jsonData = eval('(' + msgData + ')');
            log.push('sendCreateLinkTblEntry2 response: ');
            log.push( msgData);
            LogIt( {
                logType: 'LogInfo',
                sepChar: '',
                logLevel: 100, arrParams: log
            });
            if (jsonData.RPTDATA.ERR_STAT.toUpperCase() === 'TRUE' ) {
                alert ('Error in MP linkage of PF Link information to custom table');
                chla.OPRADWL.NewOrderPfDto.response =  false;
            }else {
                chla.OPRADWL.NewOrderPfDto.response =  true;
                if (chla.OPRADWL.NewOrderPfDto.grpId === 'LINK') {
                    MP_OrderProcessed(chla.OPRADWL.NewOrderPfDto.arrPatOrders);
                } else if (chla.OPRADWL.NewOrderPfDto.grpId === 'EDIT') {
                    MP_OrderProcessed(chla.OPRADWL.NewOrderPfDto.MpGrpList);
                }
                exitMyform();
            }
        }
    };
    chla.objXmlCcl2.send(arrWrk.join());

}
function newOrderProcessed() {
    var arrWrk = [];

    if (chla.OPRADWL.NewOrderPfDto.response) {
        /* remove new PF button */
        arrWrk.push('#');
        arrWrk.push(chla.OPRADWL.NewOrderPfDto.btnId);
        $(arrWrk.join('')).replaceWith(chla.OPRADWL.NewOrderPfDto.orderId.toString() );
        chla.OPRADWL.NewOrderPfDto.orderId = 0;
        chla.OPRADWL.NewOrderPfDto.response = false;
    }
}
/**
 * Execute mPage api calls to Applink, MPages_Event
 * @param p_modified {string}
 * @param p_personId {string}
 * @param p_enctrId {string}
 * @param p_formId {string}
 * @param p_activityId {string}
 * @param p_orderId {string}
 */
function launch(p_modified, p_personId, p_enctrId, p_formId, p_activityId,p_orderId) {
    var arrWrk = [];
    if (p_modified === "NEW") {
        arrWrk.push ('Launch:New MPages_Event("POWERFORM",');
        arrWrk.push(p_personId ,
            '|' ,
            p_enctrId ,
            '|' ,
            p_formId ,
            '.00|0|0');
        LogIt( {
            logType: 'LogInfo',
            sepChar:'',
            logLevel: 100, arrParams: arrWrk
        });
        arrWrk.shift();
        MPAGES_EVENT("POWERFORM", arrWrk.join(''));

        LogIt( {
            logType: 'LogInfo',
            sepChar:'',
            logLevel: 100, arrParams: ['RETURN FROM :New MPages_Event POWERFORM"']
        });
    } else if (p_modified === "CHART") {
        arrWrk.length = 0;
        arrWrk.push('Launch: Applink( 0, "POWERFORM",' );
        arrWrk.push('/PERSONID=' );
        arrWrk.push(p_personId );
        arrWrk.push('/ENCNTRID=');
        arrWrk.push( p_enctrId );
        arrWrk.push(')');
        LogIt( {
            logType: 'LogInfo',
            logLevel: 100, arrParams: arrWrk
        });
        arrWrk.shift();
        arrWrk.pop();
        APPLINK(0, "Powerchart.exe",arrWrk.join(''));
    } else {
        arrWrk.length = 0;
        arrWrk.push('Launch:Modify MPages_Event("POWERFORM",');
        arrWrk.push(p_personId );
        arrWrk.push('|' );
        arrWrk.push( p_enctrId );
        arrWrk.push('|' );
        arrWrk.push( p_formId );
        arrWrk.push('.00|' );
        arrWrk.push( p_activityId );
        arrWrk.push('.00|0');
        arrWrk.push(')');
        LogIt( {
            logType: 'LogInfo',
            sepChar: '',
            logLevel: 100, arrParams: arrWrk
        });
        arrWrk.shift();
        arrWrk.pop();
        MPAGES_EVENT("POWERFORM",arrWrk.join(''));
        //new call to CCL to do ProcessModOrd
        if (p_activityId > 0 ) {
            chkPf_ProtStat(p_orderId,parseFloat(p_enctrId))
        }
    }
}

// /**
//  *
//  * @param v
//  * @param record
//  * @returns {string | void}
//  */
// function formatName(v,record) {
//     return v.replace(/\(.*\)/,'');
// }

/**
 *
 * @param v
 * @param record
 * @returns {string | void}
 */
function formatPatLoc(v,record){
//ORDER_LOC":"~PATIENTLOCATION"
    return v.replace('~PATIENTLOCATION',' ');
}

/**
 *
 * @type {{eApps_panel_Tmpl: string[], eApps_GenSection_Tmpl: string[], H2_Tmpl: string[], H5_Tmpl: string[], H6_Tmpl: string[], gCcMainDiv: string[]}}
 */
chla.eApps.gTmplts = {
    eApps_panel_Tmpl: [
        '<div id="',
        '<#=idLabel#>',
        '_Div_eApps_panel" class="',
        '<#=HdrCss#>">',
        '<h2 class="fo-sub-sec-hd ',
        '<#=fo_cat_type#>',
        ' hxa-marker ',
        '<#=OvrrdHdrCss#>',
        '" <#=OvrrdHdrStyle#>',
        ' <#=hovertip#>>',
        '<span class="sub-sec-hd-tgl hxb-marker ',
        '<#=SectionClosed#>',
        '"  style="',
        '<#=CustIcon#>',
        ' <#=CustMargin#>',
        '">-</span>',
        '<#=HdrLayout#></h2>',
        '<div id="',
        '<#=idLabel#>',
        '_DivSubSecContent" class="sub-sec-content ',
        '<#=SectionClosed#>',
        '" <#=SubSecContentStyle#>>',
        '<div id="',
        '<#=idLabel#>',
        '" class="content-body  ',
        '<#=OvrrdContentBodyCss#>">',
        '<#=defaultHeightHdr#>',
        '<#=ContentBody#>',
        '<#=defaultHeightFtr#>',
        '</div></div></div>'
    ],
    eApps_GenSection_Tmpl: [
        '<div id="<#=div1_idLabel#>" class="<#=HdrCss#> <#=SectionTheme#>">',
        '<h2 class="',
        '<#=HdrH2Css#> ',
        '<#=fo_cat_type#> hxa-marker ',
        '<#=OvrrdHdrCss#>" ',
        '<#=OvrrdHdrStyle#> ',
        '<#=hovertip#>>',
        '<span class="',
        '<#=hd_tglCls#> hxb-marker ',
        '<#=SectionClosed#>" style="',
        '<#=hd_tglStyle#> ',
        '<#=CustIcon#> ',
        '<#=CustMargin#>">&nbsp;',
        '</span>',
        '<#=HdrLayout#>',
        '</h2>',
        '<div id="',
        '<#=div2_idLabel#>" class="',
        '<#=DivSubSecContentCss#> ',
        '<#=SectionClosed#>" ',
        '<#=SubSecContentStyle#>>',
        '<div id="',
        '<#=div3_idLabel#>" class="content-body ',
        '<#=OvrrdContentBodyCss#>"> ',
        '<#=defaultHeightHdr#> ',
        '<#=ContentBody#>',
        '<#=defaultHeightFtr#></div>',
        '</div>',
        '</div>'
     ],
    H2_Tmpl : [
        '<div id="<#=idLabel#>_DivSection" class="section <#=SectionTheme#>"><h2 class="sec-hd h2a-marker">',
        '<span class="sec-hd-tgl h2b-marker" title="icon toggle open">-</span>',
        '<span id="mainCompMenu_<#=idLabel#>" class="opts-menu menu-hide">&nbsp;</span>',
        '<span class="sec-title " style="margin-right:0;"><span><#=TLabel1#></span>',
        '<span class="sec-total" style="padding-left: 3px; margin-top: 5px;">&nbsp;<#=SectionCnt#></span>',
        '</span></h2><div id="<#=idLabel#>_DivSecContent" class="sec-content">',
        '<div id="<#=idLabel#>" class="content-body"><#=ContentBody#></div></div></div>'
    ],
    H5_Tmpl : [
        '<div id="',
        '<#=idLabel#>',
        '_DivSubSec" class="sub-sec" ><h2 class="fo-sub-sec-hd fo-cat-type h5a-marker" <#=toggleSwitch#>>',
        '<span class="sub-sec-hd-tgl h5b-marker ',
        '<#=SectionClosed#>',
        '" style="',
        '<#=CustIcon#>"',
        ' title="icon toggle open">-</span><span class="sub-sec-title  ',
        '<#=Disabled_Lbl#>',
        ' " style="background-image: none;">',
        '<#=TLabel1#>',
        '<#=SectionCnt#>',
        '</span></h2><div id="',
        '<#=idLabel#>',
        '_DivSubSecContent"',
        ' class="sub-sec-content ',
        '<#=SectionClosed#>',
        '"><div id="',
        '<#=idLabel#>',
        '" class="content-body">',
        '<#=ContentBody#>',
        '</div></div></div>'
    ],
    H6_Tmpl : [
        '<div id="',
        '<#=idLabel#>',
        '_DivSubSec1" class="sub-sec" ><h2 class="fo-sub-sec-hd h6a-marker" <#=toggleSwitch#>>',
        '<span class="sub-sec-hd-tgl h6b-marker ',
        '<#=SectionClosed#>',
        '" style="',
        '<#=CustIcon#>',
        ' <#=CustMargin#>" title="icon toggle open">-</span><span class="sub-sec-title',
        ' <#=Disabled_Lbl#>" style="background-image: none;">',
        '<#=TLabel1#>',
        '<#=SectionCnt#>',
        '</span></h2><div id="',
        '<#=idLabel#>',
        '_DivSubSecContent" class="sub-sec-content ',
        '<#=SectionClosed#>',
        '"><div id="',
        '<#=idLabel#>',
        '" class="content-body">',
        '<#=ContentBody#>',
        '</div></div></div>'
    ],
    gCcMainDiv: [
        '<div id="<#=cc_id#>" class="eapps_CC">',
        '<#=mainSection#>',
        '</div>'
    ]
};
// /**
//  *
//  * @type {{vPersonID: string, vEncounterID: string, vActiveFormId: string, vName: string, vMrn: string, vLoc: string, vPrior: string, vValue: string, vClipData: string, vOrdId: string, vHoverText: string, vOrder: string, vCmt: string, vSedation: string, vRadDisc: string, vProtStat: string, vOrdDt: string, vReqExmDt: string, vUptDt: string}}
//  */
// var RowDTO = {
//     vPersonID: '',
//     vEncounterID: '',
//     vActiveFormId: '',
//     vName: '',
//     vMrn: '',
//     vLoc: '',
//     vPrior: '',
//     vValue: '',
//     vClipData: '',
//     vOrdId: '',
//     vHoverText: '',
//     vOrder: '',
//     vCmt: '', //icon img html or &nbsp;
//     vSedation: '',
//     vRadDisc: '',
//     vProtStat: '',
//     vOrdDt: '',
//     vReqExmDt: '',
//     vUptDt: ''
// };
/**
 *
 * @type {{generateHTML: function(*=): (*|string), initValues: chla.eApps.gFuncs.SectionCtl.initValues, resetValues: chla.eApps.gFuncs.SectionCtl.resetValues, initToggle: chla.eApps.gFuncs.SectionCtl.initToggle}}
 */
chla.eApps.gFuncs.SectionCtl = {
    generateHTML: function (secObj){
        var //secObj = this,
            resultVal = 'Section creation error! ',
            arrWrk = [],
            sectCfgId,
            tmplType,
            sectionTemplate,
            tmplList =
                {
                    /**
                     *
                     * @param secObj
                     * @returns {{tagType: string, sectionId: string, headerId: string}}
                     */
                    H2: function (secObj) {
                        return {
                            tagType:'div#',
                            sectionId:secObj.idLabel + '_DivSection',
                            headerId:' H2.h2a-marker'
                        };
                    },
                    /**
                     *
                     * @param secObj
                     * @returns {{tagType: string, sectionId: string, headerId: string}}
                     */
                    H5: function (secObj) {
                        return {
                            tagType:'div#',
                            sectionId:secObj.idLabel + '_DivSubSec',
                            headerId:' H2.h5a-marker'
                        };
                    },
                    /**
                     *
                     * @param secObj
                     * @returns {{tagType: string, sectionId: string, headerId: string}}
                     */
                    H6: function (secObj) {
                        return {
                            tagType:'div#',
                            sectionId:secObj.idLabel + '_DivSubSec',//_DivSubSec1
                            headerId:' H2.h6a-marker'
                        };
                    }
//                     /**
//                      *
//                      * @param secObj
//                      * @returns {{tagType: string, sectionId: string, headerId: string}}
//                      */
//                     EAPPS_PANEL: function (secObj) {
//                         return {
//                             tagType:'div#',
//                             sectionId:secObj.idLabel + '_Div_' + secObj.TemplateType,
//                             headerId:' H2.hxa-marker'
//                         };
//                     },
//                     /**
//                      *
//                      * @param secObj
//                      * @returns {{tagType: string, sectionId: string, headerId: string}}
//                      */
//                     EAPPS_GENSECTION: function (secObj) {
//                         return {
//                             tagType:'div#',
//                             sectionId:secObj.idLabel + '_Div_' + secObj.TemplateType,
//                             headerId:' H2.hxa-marker'
//                         };
//                     }
                };
        sectCfgId = tmplList[secObj.TemplateType.toUpperCase()](secObj);
        secObj.SectionID = sectCfgId.sectionId;
        arrWrk.push(sectCfgId.tagType);
        arrWrk.push(sectCfgId.sectionId);
        arrWrk.push(sectCfgId.headerId);
        secObj.SectionDivID = arrWrk.join('');
        tmplType =
            secObj.TemplateType +
            '_Tmpl';
        sectionTemplate = chla.eApps.gTmplts[tmplType].join('');
        /* Rules for processing Section Data into template
         *  Value will be used as is unless condition met or defaulted base on rule
         * */
        /* if auto will apply parenthesis */
        if (secObj.SectionCnt.toLowerCase() === 'auto'  ){
            arrWrk.length =0;
            arrWrk.push(' (' );
            arrWrk.push(secObj.SectionCntVal );
            arrWrk.push(')');
            secObj.SectionCnt = arrWrk.join('');
        }
        /*if not auto or closed --> value = '' for open  */
        if (secObj.SectionClosed.toLowerCase() === 'auto' ){
            secObj.SectionClosed = (secObj.SectionCntVal === 0 )? 'closed' : '';
        } else if (secObj.SectionClosed.toLowerCase() !== 'closed') {
            secObj.SectionClosed = ''
        }

        if (secObj.Disabled_Lbl.toLowerCase() === 'auto'){
            secObj.Disabled_Lbl = (secObj.SectionCntVal === 0 ) ? 'grey': '';
        } else {
            secObj.Disabled_Lbl = '';
        }

        secObj.defaultHeight = (typeof secObj.defaultHeight === 'undefined' ? '': secObj.defaultHeight);
        if (secObj.defaultHeight !== ''){
            secObj.defaultHeightHdr = '<div style="height:' + secObj.defaultHeight +';overflow-y:auto;overflow-x:hidden">';
            secObj.defaultHeightFtr= '</div>'
        } else {
            secObj.defaultHeightHdr= '';
            secObj.defaultHeightFtr= '';
        }

        if (secObj.CustIcon.toLowerCase() === 'none'){
            secObj.CustIcon = 'background-image:none;'
        } else {
            secObj.CustIcon = (secObj.SectionCntVal === 0 ) ? 'background-image:none;': '';
        }
        if (secObj.HideIfEmpty.toLowerCase() !== 'false'){
            resultVal = '';
        } else {
            resultVal = chla.eApps.gFuncs.parseTemplate(sectionTemplate,secObj);
        }
        return  resultVal ;
    },
    initValues: function (o){
        this.idLabel             =  '';
        this.SectionDivID        =  '';
        this.SectionCntVal       =  0;
        this.HideIfEmpty         = 'false';
        this.ContentBody         = '';
        this.TemplateType        = 'H5';
        // this.TLabel1             =  '';
        // this.SectionCnt          = 'auto';
        // this.SectionID           =  '';
        // this.SectionClosed       = 'auto';
        // this.Disabled_Lbl        = 'auto';
        // this.CustIcon            = 'auto';
        // this.CustMargin          = 'margin-left:15px;';
        // this.UnformatBodyVal     = '';
        // this.HdrCss              = '';
        // this.fo_cat_type         = '';
        // this.OvrrdHdrCss         = '';
        // this.OvrrdHdrStyle       = '';
        // this.hovertip            = '';
        // this.HdrLayout           = '';
        // this.SubSecContentStyle  = '';
        // this.OvrrdContentBodyCss = '';
        // this.defaultHeightHdr    = '';
        // this.defaultHeightFtr    = '';
        // this.SectionTheme        = '';
        // this.toggleSwitch        = '';
        // this.SectionData         = {};
        for (var item in o){
            if (o.hasOwnProperty(item)) {
                if (item === 'Count'){
                    this['SectionCntVal'] = o[item];
                } else if(item === 'Body'){
                    this['ContentBody'] = o[item];
                } else {
                    this[item] = o[item];
                }
            }
        }
    },
    resetValues: function (sectionObj){
        sectionObj.idLabel          =  '';
        sectionObj.SectionID        =  '';
        sectionObj.TLabel1          =  '';
        sectionObj.SectionCnt       = 'auto';
        sectionObj.SectionID        =  '';
        sectionObj.SectionDivID     =  '';
        sectionObj.SectionCntVal    =  0;
        sectionObj.SectionClosed    = 'auto';
        sectionObj.Disabled_Lbl     = 'auto';
        sectionObj.CustIcon         = 'auto';
        sectionObj.CustMargin       = 'margin-left:15px;';
        sectionObj.HideIfEmpty      = 'false';
        sectionObj.ContentBody      = '';
        sectionObj.UnformatBodyVal  = '';
        sectionObj.TemplateType     = 'H5';
    },
    initToggle: function (CSSBehaviors,SectionData){
        var sectionCnt = 0 ,
            sectionType = '' ,
            sectionDivID = '',
            sectionToggle = 'auto';
        if ( typeof SectionData === 'undefined' ){
            sectionCnt = this.SectionCntVal;
            sectionType = this.TemplateType;
            sectionDivID = this.SectionDivID;
        } else {
            sectionCnt = SectionData.Count;
            sectionType = SectionData.TemplateType;
            sectionDivID = SectionData.SectionDivID;
            sectionToggle = SectionData.Toggle || 'auto';
        }
        if (typeof chla.eApps.gCSSBehavior === 'undefined'){
            sectionToggle = 'auto';
        }
        if(sectionCnt !== '0' && ( sectionToggle === 'auto' ||sectionToggle === 'true' ) ) {
            if (sectionType === 'H2') {
                $(sectionDivID).on( "click",CSSBehaviors.SingleH2SectionToggle) ;
            }
            else if (sectionType === 'H5') {
                $(sectionDivID).on( "click",CSSBehaviors.SingleH5SectionToggle) ;
            }
            else if (sectionType === 'H6') {
                $(sectionDivID).on( "click",CSSBehaviors.SingleH6SectionToggle) ;
            }
            else if (sectionType === 'eApps_panel') {
                $(sectionDivID).on( "click",CSSBehaviors.SingleEappsPanelSectionToggle) ;
            }
        }
    }
};

chla.eApps.gFuncs.onlyUnique = function (value, index, self) {
    return self.indexOf(value) === index;
};
/**
 *
 * @param strFormat
 * @returns {string}
 */
chla.eApps.gFuncs.sFormatter = function(strFormat) {
    var args,
        formatRe = /{(\d+)}/g;
    function toArray(iterable, start, end){
        var array = [],
            i;
        if (!iterable || !iterable.length) {
            return [];
        }

        if (typeof iterable === 'string') {
            iterable = iterable.split('');
        }

        start = start || 0;
        end = end ? ((end < 0) ? iterable.length + end : end) : iterable.length;

        for (i = start; i < end; i++) {
            array.push(iterable[i]);
        }

        return array;
    }
    args = toArray(arguments, 1);
    return strFormat.replace(formatRe, function(m, i) {
        return args[i];
    });

};
chla.eApps.gFuncs.forEach = function (array, callback, scope) {
    for (var i = 0; i < array.length; i++) {
        callback.call(scope, i, array[i]); // passes back stuff we need
    }
};

/**
 *  After close of powerform we check for dta changes in:
 *  contrast modification
 *  protocol changes�. Need to wait unitl  message comes back to close ui form
 * @param aSpecOrdId
 * @param aEncntrId
 */
function chkPf_ProtStat(aSpecOrdId,aEncntrId) {
    var arrWrk = [];

    if (typeof  chla.objXmlCcl4 === 'undefined') {
        chla.objXmlCcl4 = new chlaMpageApi.XMLCclRequest();
    }
    arrWrk.push('^MINE^');                   /* "Output to File/Printer/MINE" = "MINE"*/
    arrWrk.push(9);                          /* , "Function Operation Selector" =10*/
    arrWrk.push('^^');                       /* , "Start Date Range" = ""*/
    arrWrk.push('^^');                       /* , "End Date Range" = ""*/
    arrWrk.push('^^');                       /* , "Start Date Range2" = ""*/
    arrWrk.push('^^');                       /* , "End Date Range2" = ""*/
    arrWrk.push('^PROTSTAT^');               /* , "Future Order State" = ""*/
    arrWrk.push(aSpecOrdId );                /* , "Specific Order ID" = current associated OrderID*/
    arrWrk.push('^^');                       /* , "Linkage Pair" = ""*/
    arrWrk.push('^^');                       /* , "Order in Protocol State" = ""*/
    arrWrk.push(aEncntrId);                  /* , "Encounter ID" = 0*/
    arrWrk.push(0);                          /* , "ORDER ID" = 0*/
    arrWrk.push(0);                          /* , "PowerFomr ID" = 0*/
    arrWrk.push(0);                          /* , "Person ID" = 0*/
    arrWrk.push('value($USR_PersonID$)');    /* , "User ID" = 0*/
    chla.objXmlCcl4.open('GET', chla.eApps.cclProgram);
    /**
     * objXmlCcl.onreadystatechange function
     */
    chla.objXmlCcl4.onreadystatechange = function () {
        var msgData,
            jsonData;
        if (chla.objXmlCcl4.readyState === 4 && chla.objXmlCcl4.status === 200) {
            msgData  = chla.objXmlCcl4.responseText;
            jsonData = msgData.RPTDATA;
            if (msgData !== '') {
                jsonData = eval('(' + msgData + ')');
                if (chla.eApps.loggingControl.showOrderData ){
                    LogIt({
                        logType:'LogInfo',
                        arrParams: ['protocol status check<br/>' , msgData]
                    });
                }

            }
            if (jsonData.RPTDATA.ERR_STAT.toUpperCase() === 'TRUE') {
                alert('Error in processing protocol status update - CCL');
            }
        }
    };

    LogIt( {
        logType: 'LogInfo',
        sepChar: ',',
        logLevel: 100,
        arrParams: arrWrk
    });
    chla.objXmlCcl4.send( arrWrk.join() );
}



