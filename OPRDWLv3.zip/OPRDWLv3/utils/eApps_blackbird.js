//::---------------------------------------------------------------------------
//:: Module Name:  eApps_blackbird.js
//:: Version    :  1.9.0
//:: Author     :  CHLA eApps Group
//:: Copyright  :  2014
//:: Description:
//::
//::   Blackbird - Open Source JavaScript Logging Utility
//::   Author: G Scott Olson
//::   Web: http://blackbirdjs.googlecode.com/
//::      http://www.gscottolson.com/blackbirdjs/
//::        Version: 1.0
//::
//::   The MIT License - Copyright (c) 2008 Blackbird Project
//::
//:: Dependencies:
//::               eAppsClass.js
//:: Revision History
//:: Date:               Modified by:      Version: Description:
//:: 8/12/2014 15:41:25  mburling          1.0.0     Initial create
//:: 9/12/2014 15:23:53  mburling          1.9.0     refactor to Namespace isolation
//::---------------------------------------------------------------------------

//::===========================================================================
//:: Chla eApps blackbird logging - Functionality  library   ---------------
//::---------------------------------------------------------------------------
// -- eApps NameSpaces Initialization --
    var chla = chla || {};
    chla.eAppsUtil = chla.eAppsUtil || {};
    chla.eAppsUtil.c8LogObj = function (cfgObj) {
        var cfgList = Object.keys(cfgObj),
            objCfg,
            newLogObj = {
                logType:'',
                logGroup:'',
                logLevel: 0,
                notifyLevel: 0,
                sepChar:'',
                arrParams:[]
            };
        cfgList.forEach(
            function(item){
                newLogObj[item]= cfgObj[item];
            }
        );
        newLogObj.logType = (typeof cfgObj.logType !== 'undefined'? cfgObj.logType:'UndefinedType');
        newLogObj.logGroup = (typeof cfgObj.logGroup !== 'undefined'? cfgObj.logGroup:'LG0');
        if( typeof chla.eAppsUtil.loggingControl[newLogObj.logType]  !== 'undefined') {
            objCfg = chla.eAppsUtil.loggingControl[newLogObj.logType];
            if( typeof objCfg[newLogObj.logGroup]  !== 'undefined') {
                newLogObj.logLevel    = (typeof cfgObj.logLevel !== 'undefined' ? cfgObj.logLevel :objCfg[newLogObj.logGroup].logLevel);
                newLogObj.notifyLevel = (typeof cfgObj.notifyLevel !== 'undefined' ? cfgObj.notifyLevel :objCfg[newLogObj.logGroup].notifyLevel);
                newLogObj.arrParams   = (typeof cfgObj.arrParams !== 'undefined' ? cfgObj.arrParams.slice() : ['LOGIT:ERROR - found no data to log']);
            }
        }
        return newLogObj;
    };
/**
 * Object type for passing the control and item information to the BlackBird Logging Object
 * objLog.logType      : Logging type "LogInfo,LogAlert,LogError,LogWarn,Profile
 * objLog.logGroup     : Control value 0 - ###    Default:0
 * objLog.notifyLevel  : Control value 100 - 0   Default:50
 * objLog.logLevel     : Control value 100 - 0   Default:50
 * arrParams[#]        : individual values
 * @type {{logType: string, logGroup: number, logLevel: number, notifyLevel: number, sepChar: string, arrParams: Array}}
 */
chla.eAppsUtil.LogObj = {
        logType:'',
        logGroup:0,
        logLevel:0,
        notifyLevel:0,
        sepChar:'',
        arrParams:[]
    };
chla.eAppsUtil.loggingControl= {
    'LogInfo' : {
        'LG0': {
            'notifyLevel': 0,
            'logLevel'   : 0
        }
    },
    'LogAlert': {
        'LG0': {
            'notifyLevel': 0,
            'logLevel'   : 0
        }
    },
    'LogError': {
        'LG0': {
            'notifyLevel': 0,
            'logLevel'   : 0
        }
    },
    'LogWarn' : {
        'LG0': {
            'notifyLevel': 0,
            'logLevel'   : 0
        }
    },
    'Profile' : {
        'LG0': {
            'notifyLevel': 0,
            'logLevel'   : 0
        }
    }
};
/**
 * Test for logging available and call logging
 * objLog.logType      : Logging type "LogInfo,LogAlert,LogError,LogWarn
 * objLog.logGroup     : Control value 0 - ###    Default:0
 * objLog.notifyLevel  : Control value 100 - 0   Default:0
 * objLog.logLevel     : Control value 100 - 0   Default:0
 * arrParams[#]        : individual values
 *
 * @param {object} objInput
 */
function LogIt(objInput) {
    var objLog = chla.eAppsUtil.c8LogObj(objInput);
    if (chla.eApps.loggingControl.showBlackbird) {
        if (objLog.logLevel >= chla.eApps.loggingControl.logLevel) {
            switch (objLog.logType) {
                case 'LogInfo':
                    chla.eAppsUtil.Logger.LogInfo(objLog.arrParams.join(objLog.sepChar));
                    break;
                case 'LogError':
                    chla.eAppsUtil.Logger.LogError(objLog.arrParams.join(objLog.sepChar));
                    break;
                case 'LogWarn':
                    chla.eAppsUtil.Logger.LogWarn(objLog.arrParams.join(objLog.sepChar));
                    break;
                case 'LogDebug':
                    chla.eAppsUtil.Logger.LogDebug(objLog.arrParams.join(objLog.sepChar));
                    break;
                case 'Profile':
                    chla.eAppsUtil.Logger.profile(objLog.arrParams.join(objLog.sepChar));
                    break;
                case 'EventInfo':
                    chla.eAppsUtil.Logger.LogInfo('EventInfo: ' +
                        objLog.logGroup + ' : '  +
                        objLog.logLevel + ' : ' +
                        objLog.notifyLevel  + ' : ' +
                        objLog.arrParams.join(objLog.sepChar));
                    break;
                case 'EventError':
                    chla.eAppsUtil.Logger.LogError('EventError: ' +
                        objLog.logGroup + ' : '  +
                        objLog.logLevel + ' : ' +
                        objLog.notifyLevel  + ' : ' +
                        objLog.arrParams.join(objLog.sepChar));
                    break;
                case 'EventAlert':
                    chla.eAppsUtil.Logger.LogError('EventAlert: ' +
                        objLog.logGroup + ' : '  +
                        objLog.logLevel + ' : ' +
                        objLog.notifyLevel  + ' : ' +
                        objLog.arrParams.join(''));
                    break;
                case 'EventWarn':
                    chla.eAppsUtil.Logger.LogWarn('EventWarn: ' +
                        objLog.logGroup + ' : '  +
                        objLog.logLevel + ' : ' +
                        objLog.notifyLevel  + ' : ' +
                        objLog.arrParams.join(objLog.sepChar));
                    break;
                case 'EventDebug':
                    chla.eAppsUtil.Logger.LogDebug('EventDebug: ' +
                        objLog.logGroup + ' : '  +
                        objLog.logLevel + ' : ' +
                        objLog.notifyLevel  + ' : ' +
                        objLog.arrParams.join(objLog.sepChar));
                    break;
                default:
                    chla.eAppsUtil.Logger.LogError("Undefined Logging type:" +
                        objLog.logType + ' : ' +
                        objLog.logGroup + ' : '  +
                        objLog.logLevel + ' : ' +
                        objLog.notifyLevel  + ' : ' +
                        objLog.arrParams.join(objLog.sepChar));
                    break;
            }
        }
    }
}

    chla.eAppsUtil.Blackbird = {
        isOn: true,
        NAMESPACE: 'eAppBlkBrd',
        IE6_POSITION_FIXED: true, // enable IE6 {position:fixed}
        bbird: null,
        outputList: null,
        cache: [],
        state: {
            size: 1,
            pos: 1
        },
        classes: {},
        profiler: {},
        IDs: {
            blackbird: 'blackbird',
            checkbox: 'bbVis',
            filters: 'bbFilters',
            controls: 'bbControls',
            size: 'bbSize'
        },
        messageTypes: { //order of these properties imply render order of filter controls
            debug: true,
            info: true,
            warn: true,
            error: true,
            profile: true
        },

        generateMarkup: function () { //build markup
            var spans = [];
            var vType;
            for (vType in chla.eAppsUtil.Blackbird.messageTypes) {
                spans.push([ '<span class="', vType, '" type="', vType, '"></span>'].join(''));
            }

            var newNode = document.createElement('DIV');
            newNode.id = chla.eAppsUtil.Blackbird.IDs.blackbird;
            newNode.style.display = 'none';
            newNode.style.zIndex = "20";
            newNode.innerHTML = [
                '<div class="header">',
                '<div class="left">',
                '<div id="', chla.eAppsUtil.Blackbird.IDs.filters, '" class="filters" title="click to filter by message type">', spans.join(''), '</div>',
                '</div>',
                '<div class="right">',
                '<div id="', chla.eAppsUtil.Blackbird.IDs.controls, '" class="controls">',
                '<span class="move" title="move" op="move"></span>',
                '<span id="', chla.eAppsUtil.Blackbird.IDs.size , '" title="contract" op="resize"></span>',
                '<span class="clear1" title="clear" op="clear"></span>',
                '<span class="close" title="close" op="close"></span>',
                '</div>',
                '</div>',
                '</div>',
                '<div class="main">',
                '<div class="left"></div><div class="mainBody">',
                '<ol>', chla.eAppsUtil.Blackbird.cache.join(''), '</ol>',
                '</div><div class="right"></div>',
                '</div>',
                '<div class="footer">',
                '<div class="left"><label for="', chla.eAppsUtil.Blackbird.IDs.checkbox, '"><input type="checkbox" id="', chla.eAppsUtil.Blackbird.IDs.checkbox, '" />Visible on page load</label></div>',
                '<div class="right"></div>',
                '</div>'
            ].join('');
            return newNode;
        },

        backgroundImage: function () { //(IE6 only) change <BODY> tag's background to resolve {position:fixed} support
            var bodyTag = document.getElementsByTagName('BODY')[ 0 ];

            if (bodyTag.currentStyle && chla.eAppsUtil.Blackbird.IE6_POSITION_FIXED) {
                if (bodyTag.currentStyle.backgroundImage == 'none') {
                    bodyTag.style.backgroundImage = 'url(about:blank)';
                }
                if (bodyTag.currentStyle.backgroundAttachment == 'scroll') {
                    bodyTag.style.backgroundAttachment = 'fixed';
                }
            }
        },

        addMessage: function (type, content) { //adds a message to the output list
            content = ( content.constructor == Array ) ? content.join('') : content;
            if (chla.eAppsUtil.Blackbird.isOn == true) {
                if (chla.eAppsUtil.Blackbird.outputList) {
                    var newMsg = document.createElement('LI');
                    newMsg.className = type;
                    newMsg.innerHTML = [ '<span class="icon"></span>', content ].join('');
                    chla.eAppsUtil.Blackbird.outputList.appendChild(newMsg);
                    chla.eAppsUtil.Blackbird.scrollToBottom();
                } else {
                    chla.eAppsUtil.Blackbird.cache.push([ '<li class="', type, '"><span class="icon"></span>', content, '</li>' ].join(''));
                }
            }
        },

        clear: function () { //clear list output
            chla.eAppsUtil.Blackbird.outputList.innerHTML = '';
        },

        clickControl: function (evt) {
            if (!evt) evt = window.event;
            var el = ( evt.target ) ? evt.target : evt.srcElement;

            if (el.tagName == 'SPAN') {
                switch (el.getAttributeNode('op').nodeValue) {
                    case 'resize':
                        chla.eAppsUtil.Blackbird.resize();
                        break;
                    case 'clear':
                        chla.eAppsUtil.Blackbird.clear();
                        break;
                    case 'close':
                        chla.eAppsUtil.Blackbird.hide();
                        break;
                    case 'move':
                        chla.eAppsUtil.Blackbird.reposition();
                        break;

                }
            }
        },

        clickFilter: function (evt) { //show/hide a specific message type
            if (!evt) evt = window.event;
            var span = ( evt.target ) ? evt.target : evt.srcElement;

            if (span && span.tagName == 'SPAN') {

                var type = span.getAttributeNode('type').nodeValue;

                if (evt.altKey) {
                    var filters = document.getElementById(chla.eAppsUtil.Blackbird.IDs.filters).getElementsByTagName('SPAN');

                    var active = 0;
                    var vEntry;
                    for (vEntry in chla.eAppsUtil.Blackbird.messageTypes) {
                        if (chla.eAppsUtil.Blackbird.messageTypes[ vEntry ]) active++;
                    }
                    var oneActiveFilter = ( active == 1 && chla.eAppsUtil.Blackbird.messageTypes[ type ] );

                    for (var i = 0; filters[ i ]; i++) {
                        var spanType = filters[ i ].getAttributeNode('type').nodeValue;

                        filters[ i ].className = ( oneActiveFilter || ( spanType == type ) ) ? spanType : spanType + 'Disabled';
                        chla.eAppsUtil.Blackbird.messageTypes[ spanType ] = oneActiveFilter || ( spanType == type );
                    }
                }
                else {
                    chla.eAppsUtil.Blackbird.messageTypes[ type ] = !chla.eAppsUtil.Blackbird.messageTypes[ type ];
                    span.className = ( chla.eAppsUtil.Blackbird.messageTypes[ type ] ) ? type : type + 'Disabled';
                }

                //build outputList's class from messageTypes object
                var disabledTypes = [];
                for (type in chla.eAppsUtil.Blackbird.messageTypes) {
                    if (!chla.eAppsUtil.Blackbird.messageTypes[ type ]) disabledTypes.push(type);
                }
                disabledTypes.push('');
                chla.eAppsUtil.Blackbird.outputList.className = disabledTypes.join('Hidden ');

                chla.eAppsUtil.Blackbird.scrollToBottom();
            }
        },

        clickVis: function (evt) {
            if (!evt) evt = window.event;
            var el = ( evt.target ) ? evt.target : evt.srcElement;

            chla.eAppsUtil.Blackbird.state.load = el.checked;
            chla.eAppsUtil.Blackbird.setState();
        },

        scrollToBottom: function () { //scroll list output to the bottom
            chla.eAppsUtil.Blackbird.outputList.scrollTop = chla.eAppsUtil.Blackbird.outputList.scrollHeight;
        },

        isVisible: function () { //determine the visibility
            return ( chla.eAppsUtil.Blackbird.bbird.style.display == 'block' );
        },

        hide: function () {
            chla.eAppsUtil.Blackbird.bbird.style.display = 'none';
        },

        show: function () {
            var body = document.getElementsByTagName('BODY')[ 0 ];
            body.removeChild(chla.eAppsUtil.Blackbird.bbird);
            body.appendChild(chla.eAppsUtil.Blackbird.bbird);
            chla.eAppsUtil.Blackbird.bbird.style.display = 'block';
        },

        //sets the position
        reposition: function (position) {
            if (position === undefined || position == null) {
                position = ( chla.eAppsUtil.Blackbird.state && chla.eAppsUtil.Blackbird.state.pos === null ) ? 1 : ( chla.eAppsUtil.Blackbird.state.pos + 1 ) % 4; //set to initial position ('topRight') or move to next position
            }

            switch (position) {
                case 0:
                    chla.eAppsUtil.Blackbird.classes[ 0 ] = 'bbTopLeft';
                    break;
                case 1:
                    chla.eAppsUtil.Blackbird.classes[ 0 ] = 'bbTopRight';
                    break;
                case 2:
                    chla.eAppsUtil.Blackbird.classes[ 0 ] = 'bbBottomLeft';
                    break;
                case 3:
                    chla.eAppsUtil.Blackbird.classes[ 0 ] = 'bbBottomRight';
                    break;
            }
            chla.eAppsUtil.Blackbird.state.pos = position;
            chla.eAppsUtil.Blackbird.setState();
        },

        resize: function (size) {
            if (size === undefined || size === null) {
                size = ( chla.eAppsUtil.Blackbird.state && chla.eAppsUtil.Blackbird.state.size == null ) ? 0 : ( chla.eAppsUtil.Blackbird.state.size + 1 ) % 2;

            }
            chla.eAppsUtil.Blackbird.classes[ 1 ] = ( size === 0 ) ? 'bbSmall' : 'bbLarge';

            var span = document.getElementById(chla.eAppsUtil.Blackbird.IDs.size);
            span.title = ( size === 1 ) ? 'small' : 'large';
            span.className = span.title;

            chla.eAppsUtil.Blackbird.state.size = size;
            chla.eAppsUtil.Blackbird.setState();
            chla.eAppsUtil.Blackbird.scrollToBottom();
        },

        setState: function () {
            var props = [];
            var vEntry;
            for (vEntry in chla.eAppsUtil.Blackbird.state) {
                var value = ( chla.eAppsUtil.Blackbird.state[ vEntry ] && chla.eAppsUtil.Blackbird.state[ vEntry ].constructor === String ) ? '"' + chla.eAppsUtil.Blackbird.state[ vEntry ] + '"' : chla.eAppsUtil.Blackbird.state[ vEntry ];
                props.push(vEntry + ':' + value);
            }
            props = props.join(',');

            var expiration = new Date();
            expiration.setDate(expiration.getDate() + 14);
            document.cookie = [ 'blackbird={', props, '}; expires=', expiration.toUTCString() , ';' ].join('');

            var newClass = [];
            var vWord;
            for (vWord in chla.eAppsUtil.Blackbird.classes) {
                newClass.push(chla.eAppsUtil.Blackbird.classes[ vWord ]);
            }
            chla.eAppsUtil.Blackbird.bbird.className = newClass.join(' ');
        },

        getState: function () {
            var re = new RegExp(/blackbird=({[^;]+})(;|\b|$)/);
            var match = re.exec(document.cookie);
            return ( match && match[ 1 ] ) ? eval('(' + match[ 1 ] + ')') : { pos: null, size: null, load: null };
        },

        //event handler for 'keyup' event for window
        readKey: function (evt) {
            if (!evt) evt = window.event;
            var code = 113; //F2 key

            if (evt && evt.keyCode == code) {

                var visible = chla.eAppsUtil.Blackbird.isVisible();

                if (visible && evt.shiftKey && evt.altKey) chla.eAppsUtil.Blackbird.clear();
                else if (visible && evt.shiftKey) chla.eAppsUtil.Blackbird.reposition();
                else if (!evt.shiftKey && !evt.altKey) {
                    ( visible ) ? chla.eAppsUtil.Blackbird.hide() : chla.eAppsUtil.Blackbird.show();
                }
            }
        },

        //event management ( thanks John Resig )
        addEvent: function (obj, type, fn) {
            var obj1 = ( obj.constructor === String ) ? document.getElementById(obj) : obj;
            if (obj1.attachEvent) {
                obj1[ 'e' + type + fn ] = fn;
                obj1[ type + fn ] = function () {
                    obj1[ 'e' + type + fn ](window.event)
                };
                obj1.attachEvent('on' + type, obj1[ type + fn ]);
            } else obj1.addEventListener(type, fn, false);
        },

        removeEvent: function (obj, type, fn) {
            var obj2 = ( obj.constructor === String ) ? document.getElementById(obj) : obj;
            if (obj2.detachEvent) {
                obj2.detachEvent('on' + type, obj2[ type + fn ]);
                obj2[ type + fn ] = null;
            } else obj2.removeEventListener(type, fn, false);
        },
        initializeBB: function () {
            var body = document.getElementsByTagName('BODY')[ 0 ];
            chla.eAppsUtil.Blackbird.bbird = body.appendChild(chla.eAppsUtil.Blackbird.generateMarkup());
            chla.eAppsUtil.Blackbird.outputList = chla.eAppsUtil.Blackbird.bbird.getElementsByTagName('OL')[ 0 ];

            chla.eAppsUtil.Blackbird.backgroundImage();

            //add events
            chla.eAppsUtil.Blackbird.addEvent(chla.eAppsUtil.Blackbird.IDs.checkbox, 'click', chla.eAppsUtil.Blackbird.clickVis);
            chla.eAppsUtil.Blackbird.addEvent(chla.eAppsUtil.Blackbird.IDs.filters, 'click', chla.eAppsUtil.Blackbird.clickFilter);
            chla.eAppsUtil.Blackbird.addEvent(chla.eAppsUtil.Blackbird.IDs.controls, 'click', chla.eAppsUtil.Blackbird.clickControl);
            chla.eAppsUtil.Blackbird.addEvent(document, 'keyup', chla.eAppsUtil.Blackbird.readKey);
            chla.eAppsUtil.Blackbird.size = 0;      // 0 = small  ; 1 = large
            chla.eAppsUtil.Blackbird.resize(chla.eAppsUtil.Blackbird.state.size);
            chla.eAppsUtil.Blackbird.reposition(chla.eAppsUtil.Blackbird.state.pos);
            if (chla.eAppsUtil.Blackbird.state.load) {
                chla.eAppsUtil.Blackbird.show();
                document.getElementById(chla.eAppsUtil.Blackbird.IDs.checkbox).checked = true;
            }

            chla.eAppsUtil.Blackbird.scrollToBottom();

            window[ chla.eAppsUtil.Blackbird.NAMESPACE ].init = function () {
                chla.eAppsUtil.Blackbird.show();
                window[ chla.eAppsUtil.Blackbird.NAMESPACE ].error([ '<b>', chla.eAppsUtil.Blackbird.NAMESPACE, '</b> can only be initialized once' ]);
            };

            chla.eAppsUtil.Blackbird.addEvent(window, 'unload', function () {
                chla.eAppsUtil.Blackbird.removeEvent(chla.eAppsUtil.Blackbird.IDs.checkbox, 'click', chla.eAppsUtil.Blackbird.clickVis);
                chla.eAppsUtil.Blackbird.removeEvent(chla.eAppsUtil.Blackbird.IDs.filters, 'click', chla.eAppsUtil.Blackbird.clickFilter);
                chla.eAppsUtil.Blackbird.removeEvent(chla.eAppsUtil.Blackbird.IDs.controls, 'click', chla.eAppsUtil.Blackbird.clickControl);
                chla.eAppsUtil.Blackbird.removeEvent(document, 'keyup', chla.eAppsUtil.Blackbird.readKey);
            });
        }

    };
    window[ chla.eAppsUtil.Blackbird.NAMESPACE ] = {
        toggle: function () {
            ( chla.eAppsUtil.Blackbird.isVisible() ) ? chla.eAppsUtil.Blackbird.hide() : chla.eAppsUtil.Blackbird.show();
        },
        resize: function () {
            chla.eAppsUtil.Blackbird.resize();
        },
        clear: function () {
            chla.eAppsUtil.Blackbird.clear();
        },
        move: function () {
            chla.eAppsUtil.Blackbird.reposition();
        },
        debug: function (msg) {
            chla.eAppsUtil.Blackbird.addMessage('debug', msg);
        },
        warn: function (msg) {
            chla.eAppsUtil.Blackbird.addMessage('warn', msg);
        },
        info: function (msg) {
            chla.eAppsUtil.Blackbird.addMessage('info', msg);
        },
        error: function (msg) {
            chla.eAppsUtil.Blackbird.addMessage('error', msg);
        },
        LogDebug: function (msg) {
            chla.eAppsUtil.Blackbird.addMessage('debug', msg);
        },
        LogWarn: function (msg) {
            chla.eAppsUtil.Blackbird.addMessage('warn', msg);
        },
        LogInfo: function (msg) {
            chla.eAppsUtil.Blackbird.addMessage('info', msg);
        },
        LogError: function (msg) {
            chla.eAppsUtil.Blackbird.addMessage('error', msg);
        },
        profile: function (label) {
            var currentTime = new Date(); //record the current time when profile() is executed

            if (label == undefined || label == '') {
                chla.eAppsUtil.Blackbird.addMessage('error', '<b>ERROR:</b> Please specify a label for your profile statement');
            }
            else if (chla.eAppsUtil.Blackbird.profiler[ label ]) {
                chla.eAppsUtil.Blackbird.addMessage('profile', [ label, ': ', currentTime - chla.eAppsUtil.Blackbird.profiler[ label ], 'ms' ].join(''));
                delete chla.eAppsUtil.Blackbird.profiler[ label ];
            }
            else {
                chla.eAppsUtil.Blackbird.profiler[ label ] = currentTime;
                chla.eAppsUtil.Blackbird.addMessage('profile', label);
            }
            return currentTime;
        }
    };

    chla.eAppsUtil.Blackbird.state = chla.eAppsUtil.Blackbird.getState();
    chla.eAppsUtil.Blackbird.size = 1;
//     chla.eAppsUtil.Blackbird.addEvent( window, 'load',
// 		/* initialize Blackbird when the page loads */
// 		function() {
// 			var body = document.getElementsByTagName( 'BODY' )[ 0 ];
// 			chla.eAppsUtil.Blackbird.bbird = body.appendChild( chla.eAppsUtil.Blackbird.generateMarkup() );
// 			chla.eAppsUtil.Blackbird.outputList = chla.eAppsUtil.Blackbird.bbird.getElementsByTagName( 'OL' )[ 0 ];
//
// 			chla.eAppsUtil.Blackbird.backgroundImage();
//
// 			//add events
// 			chla.eAppsUtil.Blackbird.addEvent( chla.eAppsUtil.Blackbird.IDs.checkbox, 'click', chla.eAppsUtil.Blackbird.clickVis );
// 			chla.eAppsUtil.Blackbird.addEvent( chla.eAppsUtil.Blackbird.IDs.filters, 'click', chla.eAppsUtil.Blackbird.clickFilter );
// 			chla.eAppsUtil.Blackbird.addEvent( chla.eAppsUtil.Blackbird.IDs.controls, 'click', chla.eAppsUtil.Blackbird.clickControl );
// 			chla.eAppsUtil.Blackbird.addEvent( document, 'keyup', chla.eAppsUtil.Blackbird.readKey);
//
// 			chla.eAppsUtil.Blackbird.resize( chla.eAppsUtil.Blackbird.state.size );
// 			chla.eAppsUtil.Blackbird.reposition( chla.eAppsUtil.Blackbird.state.pos );
// 			if ( chla.eAppsUtil.Blackbird.state.load ) {
// 				chla.eAppsUtil.Blackbird.show();
// 				document.getElementById( chla.eAppsUtil.Blackbird.IDs.checkbox ).checked = true;
// 			}
//
// 			chla.eAppsUtil.Blackbird.scrollToBottom();
//
// 			window[ chla.eAppsUtil.Blackbird.NAMESPACE ].init = function() {
// 				chla.eAppsUtil.Blackbird.show();
// 				window[ chla.eAppsUtil.Blackbird.NAMESPACE ].error( [ '<b>', chla.eAppsUtil.Blackbird.NAMESPACE, '</b> can only be initialized once' ] );
// 			}
//
// 			chla.eAppsUtil.Blackbird.addEvent( window, 'unload', function() {
// 				chla.eAppsUtil.Blackbird.removeEvent( chla.eAppsUtil.Blackbird.IDs.checkbox, 'click', chla.eAppsUtil.Blackbird.clickVis );
// 				chla.eAppsUtil.Blackbird.removeEvent( chla.eAppsUtil.Blackbird.IDs.filters, 'click', chla.eAppsUtil.Blackbird.clickFilter );
// 				chla.eAppsUtil.Blackbird.removeEvent( chla.eAppsUtil.Blackbird.IDs.controls, 'click', chla.eAppsUtil.Blackbird.clickControl );
// 				chla.eAppsUtil.Blackbird.removeEvent( document, 'keyup', chla.eAppsUtil.Blackbird.readKey );
// 			});
// 		});
