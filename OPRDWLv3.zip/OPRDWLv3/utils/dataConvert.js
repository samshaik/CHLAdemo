/**
 * @fileoverview This file is used for converting data.
 *
 * @author
 * @version 1.0
 */

/**
 * The webservice address.
 * @type String
 */
/**
 * Get the root of a json object.
 * @param {object} jsonObject The json object
 * @return The root of a json object
 * @type object
 */
function getRootObj(jsonObject)
{
    if (jsonObject['d']) {
        return jsonObject['d'];
    }
    if (jsonObject['RPTDATA']) {
        return jsonObject['RPTDATA'];
    }
    else {
        return jsonObject;
    }
}

/**
 * Convert a date to a fixed format with detail time.
 * @param {String} data The date will be converted
 * @return The result of the fixed format
 * @type String
 */
function convertDate(data)
{
  if (data == undefined ) return '--';
	if (data == '') return '--';
    var year = data.substring(6, 10);
    if (year == '0000') {
        return '--';
    }
    var month = data.substring(11, 13);
    var date = data.substring(14, 16);
    var time = data.substring(17, 22);
    return month+"/"+date+"/"+year+" "+time;
}
/**
 * Convert a date to a fixed format with detail time.
 * @param {String} data The date will be converted
 * @return The result of the fixed format
 * @type String
 */
function convertDateTime2(data)
{
	if (data == '') return '--';
    var year = data.substring(6, 10);
    if (year == '0000') {
        return '--';
    }
    var month = data.substring(11, 13);
    var date = data.substring(14, 16);
    var time = data.substring(17, 22);
    var time2 = data.substring(30, 36);
    return month+"/"+date+"/"+year+" "+time+ " "+ time2;
}

function convertToDate3(data) {
    return data.substr(0, 6) + '20' + data.substr(6);
}

function convertToDate4(data) {//1:2013061200000000:0.000000:0:0
    if (data == undefined || data == '') return '';
    var year = data.substring(4, 6);
    var month = data.substring(6, 8);
    var date = data.substring(8, 10);
    return month + "/" + date + "/" + year
}

/**
 * Convert a date to a fixed format.
 * @param {String} data The date will be converted
 * @return The result of the fixed format
 * @type String
 */
function convertShiftDate(data)
{
	if (data == '') return '--';
    var time = data.substring(11, 21);
    return time;
}

/**
 * Convert a date to a fixed format -- "MM/DD/YYYY".
 * @param {String} data The date will be converted
 * @return The result of the fixed format
 * @type String
 */
function convertDate2(data)
{
	if (data == '') return '';
    var year = data.substring(6, 10);
    if (year == '0000') {
        return '';
    }
    var month = data.substring(11, 13);
    var date = data.substring(14, 16);

    return month+"/"+date+"/"+year;
}

/**
 * Calculate days.
 * @param {String} data The date will be calculate
 * @return The days
 * @type int
 */
function calculateDays(data)
{
    today=new Date();
    var oldDate=new Date(data);
    var one_day=1000*60*60*24;

    return Math.ceil((today.getTime()-oldDate.getTime())/(one_day));
}

/**
 * Retrieve a data present indicator.
 * @param {String} data The date will be retrieved
 * @return The data
 * @type String
 */
function retrieveresult(data)
{
    if (data == '' || data == null || data == undefined) {
        return '--';
    } else {
        return data;
    }
}

/**
 * Calculate the patient's weight.
 * Retrieve a data and convert it to a fixed format.
 * @param {String} data The date will be retrieved
 * @return The weight of the patient
 * @type String
 */
function retrieveMedCalcWt(data)
{
    if (data['MEDCALC_WT'] == '') {
        return '--';
    } else {
        return (data['MEDCALC_WT'] + '<span class="Units">  kg </span>');
    }
}

/**
 * Retrieve care team
 * @param {String} data The date will be retrieved
 * @return The care team of the patient
 * @type String
 */
function retrieveCareTeam(data)
{
    if (data['CARETEAM'] == '') {
        return '--';
    } else {
        return data['CARETEAM'];
    }
}

/**
 * Retrieve allergies
 * @param {String} data The date will be retrieved
 * @return The allergies of the patient
 * @type String
 */
function retrieveAllergies(data)
{
    var result = '--';
    if (data['ALLERGY_CNT'] > 0 ) {
        var data2 = data['ALLERGY'];
        for (i = 0; i < data['ALLERGY_CNT']; i++) {
            if (i == 0) {
                result = data2[i]['DESC'];
            } else {
                result += ' ,' + data2[i]['DESC'];
            }
        }
    }
    return result;
}


/**
 * Retrieve the patient's ICU.
 * Retrieve a data and convert it to a fixed format.
 * @param {String} data The date will be retrieved
 * @return The ICU of the patient
 * @type String
 */
function retrieveICU(data)
{
    var result = '--';
    if (data['ICU_CNT'] > 0 ) {
        var data2 = data['ICU'];
        for (i = 0; i < data['ICU_CNT']; i++) {
            var depart_text = convertDate(data2[i]['DEPART_DT_TM']);
            if (depart_text == '12/31/2100 00:00') {
                depart_text = 'present';
            }
            if (i == 0) {
                result = data2[i]['UNIT']+': <span class="Units">'+convertDate(data2[i]['ARRIVE_DT_TM'])+' to '+depart_text + "</span>";
            } else {
                result += '<span class="Units"> ,</span></BR>' + data2[i]['UNIT']+':  <span class="Units">'+convertDate(data2[i]['ARRIVE_DT_TM'])+' to '+depart_text+ "</span>";
            }
        }
    }
    return result;
}

/**
 * Retrieve the patient's guardian.
 * Retrieve a data and convert it to a fixed format.
 * @param {String} data The date will be retrieved
 * @return The guardian of the patient
 * @type String
 */
function retrieveGuardian(data)
{
    var result = '--';
    if (data['GUARDIAN_CNT'] > 0 ) {
        var data2 = data['GUARDIAN'];
        for (i = 0; i < data['GUARDIAN_CNT']; i++) {
            if (i == 0) {
                result = data2[i]['NAME_FULL_FORMATTED']+' ('+data2[i]['PERSON_RELTN']+')';
            } else {
                result += ',' + data2[i]['NAME_FULL_FORMATTED']+' ('+data2[i]['PERSON_RELTN']+')';
            }
        }
    }
    return result;
}

/**
 * Retrieve the patient's phone number.
 * @param {String} data The date will be retrieved
 * @return The phone number of the patient
 * @type String
 */
function retrievePhone(data)
{
    var result = '--';
    if (data['PHONE_CNT'] > 0 ) {
        var data2 = data['PHONE'];
        for (i = 0; i < data['PHONE_CNT']; i++) {
            if (i == 0) {
                result = data2[i]['PHONE_NUM'];
            } else {
                result += ' ,' + data2[i]['PHONE_NUM'];
            }
        }
    }
    return result;
}

/**
 * Retrieve the patient's phone number.
 * @param {String} data The date will be retrieved
 * @return The phone number of the patient
 * @type String
 */
function retrieveDoc(count, docs)
{
    var result = '--';
    if (count > 0 ) {
        for (i = 0; i < count; i++) {
            if (i == 0) {
                result = docs['NAME_FULL_FORMATTED'];
            } else {
                result += ' ,' + docs['NAME_FULL_FORMATTED'];
            }
        }
    }
    return (/undefined/.test(result ))? '--':result ;
}

/**
 * A function used to retrieve the medical devices.
 * @param {String} date1 A date
 * @param {String} date2 A date
 * @param {String} type The type
 * @param {String} value A value
 * @param {String} value2 A value
 */
function retrieveMedicalDevices1(date1, date2, type, value, value2)
{
    if (convertDate(date1) == '')
        return '--';

    var typeDate=new Date(convertDate(date1));
    var removalDate=new Date(convertDate(date2));
    today=new Date();

    if ( (typeDate > removalDate) && (today - typeDate < 1000*60*60*0.5))
    {
        if (type != '')
        {
            result = value + ' ('+type+'),';
        } else {
            result = value + ' (type not specified),';
        }
    }
}

/**
 * A function used to retrieve the medical devices.
 * @param {String} date1 A date
 * @param {String} date2 A date
 * @param {String} type The type
 * @param {String} location The location
 * @param {String} value A value
 */
function retrieveMedicalDevices2(date1, date2, type, location, value)
{
    if (convertDate(date1) == '')
        return '';

    var typeDate=new Date(convertDate(date1));
    var removalDate=new Date(convertDate(date2));
    today=new Date();

    if ( (typeDate > removalDate) && (today - typeDate < 1000*60*60*0.5))
    {
        if (type != '' && location != '')
        {
            result = value + ' ('+type+')/,'+location+'),';
        } else if (type != '') {
            result = value + ' ('+type+'),';
        } else if (location != '') {
            result = value + ' ('+location+'),';
        } else {
            result = value + ' (type/location not specified),';
        }
    }
}

/**
 * Retrieve the medical devices.
 * @param {String} data The date will be retrieved
 * @return The medical devices
 * @type String
 */
function retrieveMedicalDevices(data)
{
    var result = 'undefined';
    var result1 = '';
    result1 = ' ' + retrieveMedicalDevices1(data['CVCIVLINE1TYPE_DT_TM'], data['CVCIVLINE1REMOVAL_DT_TM'], data['CVCIVLINE1TYPE'],' CVC #1', ' (type not specified),');
    result +=(/undefined/.test(result1))? '':result1;
    result1 = ' ' + retrieveMedicalDevices1(data['CVCIVLINE2TYPE_DT_TM'], data['CVCIVLINE2REMOVAL_DT_TM'], data['CVCIVLINE2TYPE'],' CVC #2', ' (type not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
    	result1 = ' ' + retrieveMedicalDevices1(data['CVCIVLINE3TYPE_DT_TM'], data['CVCIVLINE3REMOVAL_DT_TM'], data['CVCIVLINE3TYPE'],' CVC #3', ' (type not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices1(data['CVCIVLINE4TYPE_DT_TM'], data['CVCIVLINE4REMOVAL_DT_TM'], data['CVCIVLINE4TYPE'],' CVC #4', ' (type not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
		result1 = ' ' + retrieveMedicalDevices2(data['DRAIN1_DT_TM'], data['DRAIN1REMOVAL_DT_TM'], data['DRAIN1TYPESIZE'],data['DRAIN1LOCATION'],' DRAIN #1',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['DRAIN2_DT_TM'], data['DRAIN2REMOVAL_DT_TM'], data['DRAIN2TYPESIZE'],data['DRAIN2LOCATION'],' DRAIN #2',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['DRAIN3_DT_TM'], data['DRAIN3REMOVAL_DT_TM'], data['DRAIN3TYPESIZE'],data['DRAIN3LOCATION'],' DRAIN #3',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['DRAIN4_DT_TM'], data['DRAIN4REMOVAL_DT_TM'], data['DRAIN4TYPESIZE'],data['DRAIN4LOCATION'],' DRAIN #4',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['DRAIN5_DT_TM'], data['DRAIN5REMOVAL_DT_TM'], data['DRAIN5TYPESIZE'],data['DRAIN5LOCATION'],' DRAIN #5',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['DRAIN6_DT_TM'], data['DRAIN6REMOVAL_DT_TM'], data['DRAIN6TYPESIZE'],data['DRAIN6LOCATION'],' DRAIN #6',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['DRAIN7_DT_TM'], data['DRAIN7REMOVAL_DT_TM'], data['DRAIN7TYPESIZE'],data['DRAIN7LOCATION'],' DRAIN #7',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['DRAIN8_DT_TM'], data['DRAIN8REMOVAL_DT_TM'], data['DRAIN8TYPESIZE'],data['DRAIN8LOCATION'],' DRAIN #8',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices1(data['NEURODRAIN1_DT_TM'], data['NEURODRAIN1_DT_TM'], data['NEURODRAIN1LOCATION'],' Neuro Drain #1', ' (location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices1(data['NEURODRAIN2_DT_TM'], data['NEURODRAIN2_DT_TM'], data['NEURODRAIN2LOCATION'],' Neuro Drain #2', ' (location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices1(data['NEURODRAIN3_DT_TM'], data['NEURODRAIN3_DT_TM'], data['NEURODRAIN2LOCATION'],' Neuro Drain #3', ' (location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices1(data['OSTOMY1_DT_TM'], data['OSTOMY1REMOVAL_DT_TM'], data['OSTOMY1TYPELOCATION'],' Ostomy #1', ' (type not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices1(data['OSTOMY2_DT_TM'], data['OSTOMY2REMOVAL_DT_TM'], data['OSTOMY2TYPELOCATION'],' Ostomy #2', ' (type not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices1(data['OSTOMY3_DT_TM'], data['OSTOMY3REMOVAL_DT_TM'], data['OSTOMY3TYPELOCATION'],' Ostomy #3', ' (type not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['GITUBE1_DT_TM'], data['GITUBE1REMOVAL_DT_TM'], data['GITUBE1TYPESIZE'],data['GITUBE1LOCATION'],' GI Tube #1',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['GITUBE2_DT_TM'], data['GITUBE2REMOVAL_DT_TM'], data['GITUBE2TYPESIZE'],data['GITUBE2LOCATION'],' GI Tube #2',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['GITUBE3_DT_TM'], data['GITUBE3REMOVAL_DT_TM'], data['GITUBE3TYPESIZE'],data['GITUBE3LOCATION'],' GI Tube #3',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['GITUBE4_DT_TM'], data['GITUBE4REMOVAL_DT_TM'], data['GITUBE4TYPESIZE'],data['GITUBE4LOCATION'],' GI Tube #4',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['GUTUBE1_DT_TM'], data['GUTUBE1REMOVAL_DT_TM'], data['GUTUBE1TYPESIZE'],data['GUTUBE1LOCATION'],' GU Tube #1',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['GUTUBE2_DT_TM'], data['GUTUBE2REMOVAL_DT_TM'], data['GUTUBE2TYPESIZE'],data['GUTUBE2LOCATION'],' GU Tube #2',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['GUTUBE3_DT_TM'], data['GUTUBE3REMOVAL_DT_TM'], data['GUTUBE3TYPESIZE'],data['GUTUBE3LOCATION'],' GU Tube #3',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['GUTUBE4_DT_TM'], data['GUTUBE4REMOVAL_DT_TM'], data['GUTUBE4TYPESIZE'],data['GUTUBE4LOCATION'],' GU Tube #4',' (type/location not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices2(data['TRACHTUBE_DT_TM'], data['TRACHTUBEREMOVAL_DT_TM'], data['TRACHTUBETYPE'],data['TRACHTUBESIZE'],' Trach Tube',' (type/size not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices1(data['CHESTTUBE1_DT_TM'], data['CHESTTUBE1REMOVAL_DT_TM'], data['CHESTTUBE1LOCATIONSIZE'],' Chest Tube #1',' (location/size not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices1(data['CHESTTUBE2_DT_TM'], data['CHESTTUBE2REMOVAL_DT_TM'], data['CHESTTUBE2LOCATIONSIZE'],' Chest Tube #2',' (location/size not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices1(data['CHESTTUBE3_DT_TM'], data['CHESTTUBE3REMOVAL_DT_TM'], data['CHESTTUBE3LOCATIONSIZE'],' Chest Tube #3',' (location/size not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices1(data['CHESTTUBE4_DT_TM'], data['CHESTTUBE4REMOVAL_DT_TM'], data['CHESTTUBE4LOCATIONSIZE'],' Chest Tube #4',' (location/size not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices1(data['CHESTTUBE5_DT_TM'], data['CHESTTUBE5REMOVAL_DT_TM'], data['CHESTTUBE5LOCATIONSIZE'],' Chest Tube #5',' (location/size not specified),');
    result +=(/undefined/.test(result1 ))? '' :result1;
			result1 = ' ' + retrieveMedicalDevices1(data['CHESTTUBE6_DT_TM'], data['CHESTTUBE6REMOVAL_DT_TM'], data['CHESTTUBE6LOCATIONSIZE'],' Chest Tube #6',' (location/size not specified),');
    result +=(/undefined/.test(result1 ))? '':result1;
			result1 = ' ' + retrieveMedicalDevices1(data['CHESTTUBE7_DT_TM'], data['CHESTTUBE7REMOVAL_DT_TM'], data['CHESTTUBE7LOCATIONSIZE'],' Chest Tube #7',' (location/size not specified),');
    result =(/undefined/.test(result1 ))? '--':result1;
    return result;
}

/**
 * Get the value of the element.
 * @type String
 * @param {String} type The type of the element
 * @see #setFormElement
 */
function getFormElement(type)
{
    var value = document.getElementById(type).value;
    return value;
}

/**
 * Set the element value.
 * @param {String} type The type of the element
 * @param {String} value The element value to be set
 * @see #getFormElement
 */
function setFormElement(type, value) {
    document.getElementById(type).value = value;
}
/**
 * Pad a string with leading characters
 * @param number
 * @param length
 * @param padchar
 */
function lpad(number, length, padchar) {

    var str = '' + number;
    while (str.length < length) {
        str = padchar + str;
    }

    return str;

}
/**
* Formats the patient's  weight.
* Retrieve a data and convert it to a fixed format.
* @param {String} data The date will be retrieved
* @return The  weight of the patient
* @type String
*/
function retrieveWeight(data) {
    if (data == '') {
        return '--';
    } else {
        var WTvalue = 0;
        WTvalue = data;
        return (Ext.util.Format.number(WTvalue, '0.00') + '<span class="Units"> kg </span>');
    }
}

/**
* Calculate the patient's height.
* Retrieve a data and convert it to a fixed format.
* @param {String} data The date will be retrieved
* @return The height of the patient
* @type String
*/
function retrieveHeight(data) {
    if (data == '') {
        return '--';
    } else {
        var HTvalue = 0;
        HTvalue = data;
        return (Ext.util.Format.number(HTvalue, '0.00') + ' <span class="Units"> cm </span>');
    }
}

function heightAndWeight(v, record) {
    if (record.data.LEVEL == 3)
        return retrieveHeight(record.data.HEIGHT) + ' / ' + retrieveWeight(record.data.WEIGHT);
    else
        return '';
}

function retrieveAccessionID(v, record) {
    if (record.data.LEVEL == 3) {
        if (v == '') {
            return '--';
        } else {
            var AIDvalue = v.replace(/^0+/g, '');
            return (AIDvalue);
        }
    } else
        return '';
}

function retrieveOrder(v, record) {
    var arrWrk = []
    if (record.data.LEVEL === 3) {
        arrWrk.push( '<span style="color: ' );
            arrWrk.push( (record.data.ALERT_FLAG !== 'No' ? 'red' : 'black') );
            arrWrk.push( '"');
            arrWrk.push(' onclick="MouseOverData.call(this,' );
            arrWrk.push( "'Order Details'" );
            arrWrk.push( ');"' );
            arrWrk.push( ' title="' );
            arrWrk.push( record.data.ORDER_CLIN_DISP_LINE );
            arrWrk.push( '">' );
            arrWrk.push( retrieveNormalData(v, record) );
            arrWrk.push( '</span>');
    }

    return arrWrk.join('');
}

function retrieveOrderStat(v, record) {
    var arrWrk = [],
        priority;
    if (record.data.LEVEL === 3) {
        priority = retrieveNormalData(v, record) ;
        arrWrk.push('<span style="color: ');
        arrWrk.push((priority === 'Stat' ? 'red' : 'black'));
        arrWrk.push('">');
        arrWrk.push(priority);
        arrWrk.push('</span>');
        return arrWrk.join('');
    } else
        return '';
}
/**
* Retrieve a data to be normal.
* @param {String} data The date will be retrieved
* @return The normal data
* @type String
*/
function retrieveNormalData(v, record) {
    if (record && record.data.LEVEL == 3) {
        if (v == '' || v == '0.0') {
            return '--';
        } else {
            return v;
        }
    } else
        return '';
}
/**
* Retrieve a data to be concatenated to string with slash.
* @param {String} data The date will be retrieved
* @return The slash data or empty string
* @type String
*/
function retrieveSlashData(v, record) {
    if (v == '' || v == '0.0') {
        return '';
    } else {
        return ('/' + v);
    }
}

function toLocation(v, record) {
    if (record.data.LEVEL == 3)
        return '<span title="' + record.data.NURSING_UNIT + retrieveSlashData(record.data.ROOM) + retrieveSlashData(record.data.BED) + '">' + record.data.NURSING_UNIT + retrieveSlashData(record.data.ROOM) + retrieveSlashData(record.data.BED) + '</span>';
    else
        return '';
}
/**
 * This function is used to coverting a data to a fixed format.
 * @param {String} data The data to be converted
 * i.e.  "AGE":"22 Years 11 Months",
 */
function ageCss(v, record) {
    if (record.data.LEVEL == 3) {
        var data = Ext.String.trim(v);
        var month;
        var week;
        var age = '';
        if (data == "" || data == undefined) {
            age = "--";
        } else {
            var a = data.indexOf('Y');
            var b = data.indexOf('M');
            var w = data.indexOf('W');
            var d = data.indexOf('D');

            var f = data.indexOf(' ');
            var e = data.lastIndexOf(' ')


            if (a > 0) {
                var year = data.substring(0, f);
                var c = data.substring(a, a + 5);
                age = year + ' ' + '<span class="Units" style="color:#7C7C7C; font-size:9px;">' + (year > 1 ? 'yrs' : 'yr') + '</span>' + ' ';
            }
            if (b > 0 && a == -1) {
                month = data.substring(0, b - 1);
                age += month + ' ' + '<span class="Units" style="color:#7C7C7C; font-size:9px;">m</span>' + ' ';
            }
            if (d > 0) {
                var days = data.substring(f + 1, d - 2);
                age += days + ' ' + '<span class="Units" style="color:#7C7C7C; font-size:9px;">' + (days > 1 ? 'days' : 'day') + '</span>' + ' ';
            }
            if (w > 0) {
                //var idx_weeks = data.indexOf('Weeks');
                week = data.substring(f + 1, w - 2);
                //var g = data.substring(e + 1)
                age += week + ' ' + '<span class="Units" style="color:#7C7C7C; font-size:9px;">' + (week > 1 ? 'wks' : 'wk') + '</span>';
            }
        }
        return age;
    } else
        return '';
}

function nameToLink(v, record) {
    if (record.data.LEVEL == 3)
        return '<span style="color:blue; cursor:pointer;" onclick="return launch(' + "'CHART'" + ',' + "'" + record.data.PERSONID + "'" + ',' + "'" + record.data.ENCNTRID + "'" + ',' + "'" + record.data.EXAM_FORM_ID + "'" + ',' + "'" + record.data.FORM_ACTIVITY_ID + "'" + ');"> ' + v + '</span>';
    else
        return v;
}

function protStatToLink(v, record) {
    var arrWrk = [];
    if (record.data.LEVEL == 3) {
               if (record.data.FORM_ACTIVITY_ID > 0) {
            arrWrk.push('<span style="color:blue; cursor:pointer;" onclick="return launch(',
                "'",
                record.data.MODIFY_FLAG,
                "'",
                ',',
                "'",
                record.data.PERSONID,
                "'",
                ',',
                "'",
                record.data.ENCNTRID,
                "'",
                ',',
                "'",
                record.data.EXAM_FORM_ID,
                "'",
                ',',
                "'",
                record.data.FORM_ACTIVITY_ID,
                "'",
                ');"> ',
                retrieveNormalData(v, record),
                '</span>');
        } else {
            arrWrk.push('<span style="color:gray;">');
            arrWrk.push('Active Order');
            arrWrk.push('</span>');
        }
    }
        return arrWrk.join('');
}

function convertToIcon(v, record) {
    if (record.data.LEVEL == 3 && v != '') {
        if (Ext.Date.add(new Date(convertToDate3(v)), Ext.Date.DAY, 1) > new Date()) {
            return (record.data.CSA_SIGNED == 2) ? '<div><img src="images/ok15px.png" title="Form signed on ' + v + '" width="15" height="15" onclick="return launch(' + "'POWERFORM'" + ',' + "'" + record.data.PERSONID + "'" + ',' + "'" + record.data.ENCNTRID + "'" + ',' + "'" + record.data.CSA_EXAM_FORM_ID + "'" + ',' + "'" + record.data.CSA_FORM_ACTIVITY_ID + "'" + ');" style="cursor:pointer; margin-top:0px;"/></div>' : '--';
        } else {
            return (record.data.CSA_SIGNED == 2) ? '<div><img src="images/ok15px_orange.png" title="Form signed on ' + v + '" width="15" height="15" onclick="return launch(' + "'POWERFORM'" + ',' + "'" + record.data.PERSONID + "'" + ',' + "'" + record.data.ENCNTRID + "'" + ',' + "'" + record.data.CSA_EXAM_FORM_ID + "'" + ',' + "'" + record.data.CSA_FORM_ACTIVITY_ID + "'" + ');" style="cursor:pointer; margin-top:0px;"/></div>' : '--';
        }
    } else
        return '';
}

function convertToIcon2(v, record) {   //Contrast Contraindication Noted
    var resultStr;
    if (record.data.LEVEL == 3 && v != '') {
         resultStr = (v == 1) ? '<div><img style="vertical-align:middle;"src="images/stop_icon.png" title="Contrast Contraindication Noted" ' +
                                ' width="20" height="20" onclick="return launch(' + "'POWERFORM'" +
                                ',' + "'" + record.data.PERSONID + "'" + ',' + "'" +
                                record.data.ENCNTRID + "'" + ',' + "'" + record.data.CSA_CTRIND_FORM_ID +
                                "'" + ',' + "'" + record.data.CSA_CTRIND_FORM_ACT_ID + "'" +
                                ');" style="cursor:pointer; margin-top:0px;"/></div>' : '[2]';
         CHLA.LogInfo('resultStr: <br/>' + resultStr.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') );
         return resultStr;
    } else {
        return '';
        }
}
function convertToIcon3(v, record) {    //ISOLATION
    var resultStr = '';
    if (record.data.LEVEL == 3 && v != '') {
         if (v.indexOf('Standard') < 0){
             resultStr =  '<div style="padding-left:6px;"><img src="images/isolation2.png" title="' + v + '" ' +
                                    ' width="16" height="16" ' +
                                    ' style="cursor:pointer; margin-top:0px;"/></div>' ;
             //CHLA.LogInfo('resultStr: <br/>' +resultStr.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') );
         }
         return resultStr;
    } else {
        return '';
        }
}

function convertToIcon4(v, record) {   //COMMENTS_FLD
    var resultStr = '';
    if (record.data.LEVEL == 3 && v != '') {
         resultStr =  '<div style="padding-left:6px;" ><img class="imgHover"  title="'
                                + v + '&nbsp; ' +
                                '" onclick="MouseOverData.call(this,' + "'Radiology Comments'" + ');"' + ' src="images/COMMENTS4.png" ' +
                                ' width="16" height="18" ' +
                                'style=" margin-top:0px;"/></div>';
         //CHLA.LogInfo('resultStr: <br/>' +resultStr.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') );
         return resultStr;
    } else {
        return '';
        }
}
function CommentsWindow(data,title) {
    var datamod = data.replace( /\n/g,'<br>');
    var window = new Ext.Window({
        title: title,
        id:'CMTBX',
        width: 725,
        height: 500,
        autoScroll: true,
        shadow:false,
        componentCls: 'commentborder',
        border:2,
        bodyStyle: 'background:#FFF; padding:5px;',
        style: {
            borderColor: 'white',
            borderStyle: 'solid'
        },
        items: [{
            html: datamod //Ext.encode(datamod)
        }]
    });
    window.show();
    window.on('beforeclose', function(panel,eOpts){
        	window.un('beforeclose');
          chla.eApps.indicatorSetImgHover = 1;
    });
}


function MouseOverData(stitle){
    if (chla.eApps.indicatorSetImgHover == 1) {
        var data;
        if (typeof this.title === 'string'){
            data = this.attributes['title'].value;
            CommentsWindow(data,stitle) ;
            chla.eApps.indicatorSetImgHover = 0;
            return false;
        }
    }
}
function InitPopUpsDiv (dataResponse,  argHoverelement, alignPos) {
         var Parent = this ;
         var alignPostion = 0 ;
         var alignPostion2 = 0 ;
         argHoverelement.hoverContent = dataResponse;
         if (typeof alignPos != 'undefined' && alignPos != null){
            if (alignPos == "L") alignPostion = -320;
            }
         if (typeof alignPos != 'undefined' && alignPos != null){
            if (alignPos == "T") alignPostion2 = -50;
            }
         $(argHoverelement).hover( function (args) {
                  $('<div class="eapps-tooltip"></div>')
                  .html(Parent.hoverContent)
                  .appendTo('body')
                  .fadeIn('slow');
          }, function() {
                  $('.eapps-tooltip').remove();
          }).mousemove(function(e) {
                  var mousex = e.pageX + (20  + alignPostion);
                  var mousey = e.pageY + (10  + alignPostion2);
                  $('.eapps-tooltip')
                  .css({ top: mousey, left: mousex })
             }) ;
    }

function launch(p_modified, p_personId, p_enctrId, p_formId, p_activityId) {
    var arrWrk = [];

    if (p_modified == "NEW") {
        //APPLINK(0, "Powerchart.exe", '/PERSONID=' + p_personId + ' /ENCNTRID=' + p_enctrId + ' /FIRSTTAB=^Task List^');
        arrWrk.push(p_personId ,
            '|' ,
            p_enctrId ,
            '|' ,
            p_formId ,
            '.00|' ,
            "0|0");
        MPAGES_EVENT("POWERFORM", arrWrk.join(''));

    } else if (p_modified == "CHART") {
        APPLINK(0, "Powerchart.exe", '/PERSONID=' + p_personId + ' /ENCNTRID=' + p_enctrId);
    } else {
        MPAGES_EVENT("POWERFORM", p_personId + '|' + p_enctrId + '|' + p_formId + '.00|' + p_activityId + ".00|0");
    }
}
