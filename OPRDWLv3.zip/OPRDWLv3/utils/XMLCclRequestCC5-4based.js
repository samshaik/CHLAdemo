//::---------------------------------------------------------------------------
//:: Module Name:  XMLCclRequest
//:: Version    :  1.0.2
//:: Author     :  CHLA eApps Group
//:: Copyright  :  2014,2015,2016
//:: Description:
//:: Topic: MPage Core
//::        This file will declare a global "chlaMpageApi.inMpage" boolean variable that will be true
//::        if running inside of PowerChart. This is indicated by passing "mpage=false"
//::        in the URl. If running on an MPage then the following PowerChart functions
//::        are defined:
//::
//::                * XMLCclRequest
//::                * APPLINK
//::                * MPAGES_EVENT
//::                * CCLLINK
//::                * CCLLINKPOPUP
//::                * CCLNEWPOPUPWINDOW
//::                * MPAGES_SVC_EVENT
//:: JavaScript Library
//:: based on contributions from Joshua Faulkenberry
//::Lucile Packard Children's Hospital at Stanford
//::
//:: Dependencies:    Discern Native Function
//::
//:: Revision History
//:: CR:              Description:
//:: 1-5091604711  Use window.location to invoke XMLCCLRequest
//:: 1-5609585291  Add blobIn variable and setBlobIn function to allow a parameter string larger than 32,000 characters

//::---------------------------------------------------------------------------
var chlaMpageApi = {
    inMpage: true ,
    XMLCclRequest: null,
    getXMLHttpRequest: function () {
        var retValue;
        if ( chlaMpageApi.XMLCclRequest != null){
            retValue = new chlaMpageApi.XMLCclRequest();
        } else {
            retValue = null;
        }
    return retValue;
    },
//     APPLINK: function (mode, appname, param ){ return false; },
//     CCLLINK: function (program, param, nViewerType ){return false;},
//     MPAGES_EVENT: function (eventType, eventParams ){return false;},
//     old CCLLINKPOPUP: function (eventType, eventParams ){return false;},
//     CCLLINKPOPUP: function ( program, param, sName, sFeatures, bReplace )
//     old CCLNEWPOPUPWINDOW: function (eventType, eventParams ){return false;},
//     CCLNEWPOPUPWINDOW: function (sUrl,sName,sFeatures,bReplace)
//     CCLNEWSESSIONWINDOW: function(sUrl,sName,sFeatures,bReplace,bModal)
//     MPAGES_SVC_EVENT: function( uri, params ){return false;}
    evaluate: function (x) {
        return eval(x);
    }
};

if (/[\?|&]mpage=false/i.test(location.search)){
        chlaMpageApi.inMpage = false;
}
if (chlaMpageApi.inMpage) {
    var MpageXMLCcl = {
        XMLCclRequest: function (options) {
            /************ Attributes *************/

            this.onreadystatechange = function () {
                return null;
            };
            this.options = options || {};
            this.readyState = 0;
            this.responseText = "";
            this.status = 0;
            this.statusText = "";
            this.sendFlag = false;
            this.errorFlag = false;
            this.responseBody =
                this.responseXML =
                    this.async = true;
            this.requestBinding = null;
            this.requestText = null;
            this.blobIn = null;

            /************** Events ***************/

                //Raised when there is an error.
            this.onerror =

            /************** Methods **************/

            //Cancels the current CCL request.
            this.abort =

            //Returns the complete list of response headers.
            this.getAllResponseHeaders =

            //Returns the specified response header.
            this.getResponseHeader = function () {
                return null;
            };

            //Assigns method, destination URL, and other optional attributes of a pending request.
            this.open = function (method, url, async) {
                if (method.toLowerCase() != "get" && method.toLowerCase() != "post") {
                    this.errorFlag = true;
                    this.status = 405;
                    this.statusText = "Method not Allowed";
                    return false;
                }
                this.method = method.toUpperCase();
                this.url = url;
                this.async = async != null ? (async ? true : false) : true;
                this.requestHeaders = null;
                this.responseText = "";
                this.responseBody = this.responseXML = null;
                this.readyState = 1;
                this.sendFlag = false;
                this.requestText = "";
                this.onreadystatechange();
            };

            //Sends a CCL request to the server and receives a response.
            this.send = function (param) {
                if (this.readyState != 1) {
                    this.errorFlag = true;
                    this.status = 409;
                    this.statusText = "Invalid State";
                    return false;
                }
                if (this.sendFlag) {
                    this.errorFlag = true;
                    this.status = 409;
                    this.statusText = "Invalid State";
                    return false;
                }
                this.sendFlag = true;
                this.requestLen = param.length;
                this.requestText = param;
                var uniqueId = this.url + "-" + (new Date()).getTime() + "-" + Math.floor(Math.random() * 99999);
                XMLCCLREQUESTOBJECTPOINTER[uniqueId] = this;
                window.location = "javascript:XMLCCLREQUEST_Send(\"" + uniqueId + "\"" + ")";

            };

            //Adds custom HTTP headers to the request.
            this.setRequestHeader = function (name, value) {
                if (this.readyState != 1) {
                    this.errorFlag = true;
                    this.status = 409;
                    this.statusText = "Invalid State";
                    return false;
                }
                if (this.sendFlag) {
                    this.errorFlag = true;
                    this.status = 409;
                    this.statusText = "Invalid State";
                    return false;
                }
                if (!value) {
                    return false;
                }
                if (!this.requestHeaders) {
                    this.requestHeaders = [];
                }
                this.requestHeaders[name] = value;
            };

            // Sets blob input.
            this.setBlobIn = function (blob) {
                this.blobIn = blob;
            };
        }
    };
    chlaMpageApi.XMLCclRequest = MpageXMLCcl.XMLCclRequest;
}

function  APPLINK( mode, appname, param ){
     var paramLength = param.length;
     if (paramLength > 2000){
/**************** new*/
    if (!document.getElementById("__ID_CCLPostParams_28717__")) {
        el = document.createElement("a");
        el.id = "__ID_CCLPostParams_28717__";
        document.body.appendChild(el);
    }
/******************/
         document.getElementById("__ID_CCLPostParams_28717__").value = '"' + param + '"';
         param = param.substring(0, 2000);
     }
     var el = document.getElementById("__ID_CCLLINKHref_15353__");
     el.href = "javascript:APPLINK__(" + mode + ",\"" + appname + "\",\"" + param + "\"," + paramLength +")";
     el.click();
}
function  CCLLINK( program, param, nViewerType ){
     var paramLength = param.length;
     if (paramLength > 2000){
/**************** new*/
    if (!document.getElementById("__ID_CCLPostParams_28717__")) {
        el = document.createElement("a");
        el.id = "__ID_CCLPostParams_28717__";
        document.body.appendChild(el);
    }
/******************/
         document.getElementById("__ID_CCLPostParams_28717__").value = '"' + param + '"';
         param = param.substring(0, 2000);
     }
     var el = document.getElementById("__ID_CCLLINKHref_15353__");
     el.href = "javascript:CCLLINK__(\"" + program + "\",\"" + param + "\"," + nViewerType + "," + paramLength +")";
     el.click();
}
function  MPAGES_EVENT( eventType, eventParams ){
     var paramLength = eventParams.length;
     if (paramLength > 2000){
/**************** new*/
    if (!document.getElementById("__ID_CCLPostParams_28717__")) {
        el = document.createElement("a");
        el.id = "__ID_CCLPostParams_28717__";
        document.body.appendChild(el);
    }
/******************/
         document.getElementById("__ID_CCLPostParams_28717__").value = '"' + eventParams + '"';
         eventParams = eventParams.substring(0, 2000);
     }
     var el = document.getElementById("__ID_CCLLINKHref_15353__");
     el.href = "javascript:MPAGES_EVENT__(\"" + eventType + "\",\"" + eventParams + "\"," + paramLength +")";
     el.click();
}

function CCLLINKPOPUP( program, param, sName, sFeatures, bReplace ){
    var paramLength = param.length;
    if (paramLength > 2000){
        document.getElementById("__ID_CCLPostParams_3981__").value = '"' + param + '"';
        param = param.substring(0, 2000);
    }
    var el = document.getElementById("__ID_CCLLINKHref_30441__");
    el.href = "javascript:CCLLINKPOPUP__(\"" + program + "\",\"" + param + "\",\"" + sName + "\",\"" + sFeatures + "\"," + bReplace + "," + paramLength +")";
    el.click();
}
function CCLNEWPOPUPWINDOW(sUrl,sName,sFeatures,bReplace){
    popupWindowHandle = window.open(sUrl,sName,sFeatures,bReplace);
    popupWindowHandle.focus();
}

function CCLNEWSESSIONWINDOW(sUrl,sName,sFeatures,bReplace,bModal){
    var el = document.getElementById("__ID_CCLLINKHref_30441__");
    el.href = "javascript:CCLNEWSESSIONWINDOW__(\"" + sUrl + "\",\"" + sName + "\",\"" + sFeatures + "\"," + bReplace + "," + bModal +")";
    el.click();
    if (bModal == 0) {
        popupWindowHandle = window.open(sUrl,sName,sFeatures,bReplace);
        if (popupWindowHandle) popupWindowHandle.focus();
    }
}

function MPAGES_SVC_EVENT( uri, params ){
    var paramLength = params.length;
    if (paramLength > 2000){
        document.getElementById("__ID_CCLPostParams_3981__").value = '"' + params + '"';
        params = params.substring(0, 2000);
    }
    var el = document.getElementById("__ID_CCLLINKHref_30441__");
    el.href = "javascript:MPAGES_SVC_EVENT__(\"" + uri + "\",\"" + params + "\"," + paramLength +")";
    el.click();
}

function evaluate(x)
{
    return eval(x);
}
function getXMLHttpRequest()
{
    return new MpageXMLCcl.XMLCclRequest();
}


var XMLCCLREQUESTOBJECTPOINTER = [];

function APPLINK__(mode, appname, param ){}
function CCLLINK__(program, param, nViewerType ){}
function CCLLINKPOPUP__(program, param, sName, sFeatures, bReplace){}
function MPAGES_EVENT__(eventType, eventParams ){}
function CCLNEWSESSIONWINDOW__(sUrl,sName,sFeatures,bReplace,bModal){}
function MPAGES_SVC_EVENT__(uri, params ){}

//===================================================================================
