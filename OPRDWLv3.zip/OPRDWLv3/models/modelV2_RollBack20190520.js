'use strict';
/**
 *
 * @param Orders
 * @param aAppObj
 * @param FilterOp
 */
chla.OPRADWL.createTreeStructure.New_Processor = function (Orders, aAppObj,FilterOp) {
    var arrRetDto = {
            viewId : '',
            LdDate : '',
            strUI  : '',
            tblData: {},
            Filters: {
                'comboHoldBy'  : [],
                'comboOrderId' : [],
                'comboPatient' : [],
                'comboModality': [],
                'comboProtocol': [],
                'comboTimeRng' : []
            }
        },
        arrH5Keys,
        arrH6Keys,
        objRow,
        vViewOrders,
        lblMode,
        displayTree = [
            'CTNEWORDER',
            'CTEXAMPROTOCOL',
            'CTEXAMPROTOCOLSS1101',
            'CTEXAMPROTOCOLSS1102',
            'CTEXAMPROTOCOLSS1103',
            'CTEXAMPROTOCOLSS1104',
            'CTNURSEPRACTITIONER',
            'CTWAITING',
            'CTSCHEDULING',
            'CTNURSETECH',
            'MRNEWORDER',
            'MREXAMPROTOCOL',
            'MRCARDIOEXAMPROTOCOLSS99',
            'MREXAMPROTOCOLSS1101',
            'MREXAMPROTOCOLSS1102',
            'MREXAMPROTOCOLSS1103',
            'MREXAMPROTOCOLSS1104',
            'MRNURSEPRACTITIONER',
            'MRWAITING',
            'MRSCHEDULING',
            'MRNURSETECH',
            'IRNEWORDER',
            'IREXAMPROTOCOL',
            'IRNURSEPRACTITIONER',
            'IRWAITING',
            'IRSCHEDULING',
            'IRNURSETECH',
            'PTNEWORDER',
            'PTEXAMPROTOCOL',
            'PTNURSEPRACTITIONER',
            'PTWAITING',
            'PTSCHEDULING',
            'PTNURSETECH',
            'FLNEWORDER',
            'FLEXAMPROTOCOL',
            'FLNURSEPRACTITIONER',
            'FLWAITING',
            'FLSCHEDULING',
            'FLNURSETECH',
            'USNEWORDER',
            'USEXAMPROTOCOL',
            'USNURSEPRACTITIONER',
            'USWAITING',
            'USSCHEDULING',
            'USNURSETECH'
        ],
        treeStructure = {
            'CT':false,
            'IR':false,
            'MR':false,
            'PT':false,
            'FL':false,
            'CTNEWORDER':{
                "PRESENT":false,
                'lbl':'New Order',
                'mod':'CT'
            },
            'CTEXAMPROTOCOL':{
                "PRESENT":false,
                'lbl':'Exam Protocol',
                'mod':'CT'
            },
            'CTEXAMPROTOCOLSS1101':{
                "PRESENT":false,
                'lbl':'Exam Protocol - BODY',
                'mod':'CT'
            },
            'CTEXAMPROTOCOLSS1102':{
                "PRESENT":false,
                'lbl':'Exam Protocol - NEURO',
                'mod':'CT'
            },
            'CTEXAMPROTOCOLSS1103':{
                "PRESENT":false,
                'lbl':'Exam Protocol - Body and/or Neuro',
                'mod':'CT'
            },
            'CTEXAMPROTOCOLSS1104':{
                "PRESENT":false,
                'lbl':'Exam Protocol - Not Used',
                'mod':'CT'
            },
            'CTNURSEPRACTITIONER':{
                "PRESENT":false,
                'lbl':'NP Triage',
                'mod':'CT'
            },
            'CTWAITING':{
                "PRESENT":false,
                'lbl':'Waiting',
                'id':'Waiting',
                'mod':'CT'
            },
            'CTSCHEDULING':{
                "PRESENT":false,
                'lbl':'Scheduling',
                'id':'Scheduling',
                'mod':'CT'
            },
            'CTNURSETECH':{
                "PRESENT":false,
                'lbl':'NurseTechnologist',
                'id':'NurseTechnologist',
                'mod':'CT'
            },
            'MRNEWORDER':{
                "PRESENT":false,
                'lbl':'New Order',
                'mod':'MR'
            },
            'MREXAMPROTOCOL':{
                "PRESENT":false,
                'lbl':'Exam Protocol',
                'mod':'MR'
            },
            'MREXAMPROTOCOLSS1101':{
                "PRESENT":false,
                'lbl':'Exam Protocol - BODY',
                'mod':'MR'
            },
            'MREXAMPROTOCOLSS1102':{
                "PRESENT":false,
                'lbl':'Exam Protocol - NEURO',
                'mod':'MR'
            },
            'MREXAMPROTOCOLSS1103':{
                "PRESENT":false,
                'lbl':'Exam Protocol - Body and/or Neuro',
                'mod':'MR'
            },
            'MREXAMPROTOCOLSS1104':{
                "PRESENT":false,
                'lbl':'Exam Protocol - Not Used',
                'mod':'MR'
            },
            'MRCARDIOEXAMPROTOCOLSS99':{
                "PRESENT":false,
                'lbl':'Cardio Exam Protocol',
                'id':'CardioExamProtocol',
                'mod':'MR'
            },
            'MRNURSEPRACTITIONER':{
                "PRESENT":false,
                'lbl':'NP Triage',
                'mod':'MR'
            },
            'MRWAITING':{
                "PRESENT":false,
                'lbl':'Waiting',
                'mod':'MR'
            },
            'MRSCHEDULING':{
                "PRESENT":false,
                'lbl':'Scheduling',
                'mod':'MR'
            },
            'MRNURSETECH':{
                "PRESENT":false,
                'lbl':'NurseTechnologist',
                'id':'NurseTechnologist',
                'mod':'MR'
            },
            'IRNEWORDER':{
                "PRESENT":false,
                'lbl':'New Order',
                'mod':'IR'
            },
            'IREXAMPROTOCOL':{
                "PRESENT":false,
                'lbl':'Exam Protocol',
                'mod':'IR'
            },
            'IRNURSEPRACTITIONER':{
                "PRESENT":false,
                'lbl':'NP Triage',
                'mod':'IR'
            },
            'IRWAITING':{
                "PRESENT":false,
                'lbl':'Waiting',
                'mod':'IR'
            },
            'IRSCHEDULING':{
                "PRESENT":false,
                'lbl':'Scheduling',
                'mod':'IR'
            },
            'IRNURSETECH':{
                "PRESENT":false,
                'lbl':'Nurse / Technologist',
                'id':'NurseTechnologist',
                'mod':'IR'
            },
            'PTNEWORDER':{
                "PRESENT":false,
                'lbl':'New Order',
                'mod':'PT'
            },
            'PTEXAMPROTOCOL':{
                "PRESENT":false,
                'lbl':'Exam Protocol',
                'mod':'PT'
            },
            'PTNURSEPRACTITIONER':{
                "PRESENT":false,
                'lbl':'NP Triage',
                'mod':'PT'
            },
            'PTWAITING':{
                "PRESENT":false,
                'lbl':'Waiting',
                'mod':'PT'
            },
            'PTSCHEDULING':{
                "PRESENT":false,
                'lbl':'Scheduling',
                'mod':'PT'
            },
            'PTNURSETECH':{
                "PRESENT":false,
                'lbl':'NurseTechnologist',
                'id':'NurseTechnologist',
                'mod':'PT'
            },
            'FLNEWORDER':{
                "PRESENT":false,
                'lbl':'New Order',
                'mod':'FL'
            },
            'FLEXAMPROTOCOL':{
                "PRESENT":false,
                'lbl':'Exam Protocol',
                'mod':'FL'
            },
            'FLNURSEPRACTITIONER':{
                "PRESENT":false,
                'lbl':'NP Triage',
                'mod':'FL'
            },
            'FLWAITING':{
                "PRESENT":false,
                'lbl':'Waiting',
                'mod':'FL'
            },
            'FLSCHEDULING':{
                "PRESENT":false,
                'lbl':'Scheduling',
                'mod':'FL'
            },
            'FLNURSETECH':{
                "PRESENT":false,
                'lbl':'NurseTechnologist',
                'id':'NurseTechnologist',
                'mod':'FL'
            },
            'USNEWORDER':{
                "PRESENT":false,
                'lbl':'New Order',
                'mod':'US'
            },
            'USEXAMPROTOCOL':{
                "PRESENT":false,
                'lbl':'Exam Protocol',
                'mod':'US'
            },
            'USNURSEPRACTITIONER':{
                "PRESENT":false,
                'lbl':'NP Triage',
                'mod':'US'
            },
            'USWAITING':{
                "PRESENT":false,
                'lbl':'Waiting',
                'mod':'US'
            },
            'USSCHEDULING':{
                "PRESENT":false,
                'lbl':'Scheduling',

                'mod':'US'
            },
            'USNURSETECH':{
                "PRESENT":false,
                'lbl':'NurseTechnologist',
                'id':'NurseTechnologist',
                'mod':'US'
            }
        };
        // UniqueArr = {};
    /**
     * Determine the Protocol Status and Order type source
     * SPECIFIC: to View type
     * @param orderItem
     * @param aAppObj
     */
    function OutPatOrderConvert(orderItem,aAppObj) {
        var aProtocolStatus = orderItem.PROTOCAL_STATUS,
            viewMod = aAppObj.Data.getOrdState(aAppObj),
            protocol_status,
            modval,
            /*
            ACTIVITY_SUBTYPE_CD|OC_ACTIVITY_SUBTYPE_DISP  |MNEMONIC
            110440686.00       |PET                       |PT
            61072547.00        |Fluoroscopy               |FL
            633747.00          |Computerized Tomography   |CT
            633748.00          |Interventional Radiology  |IR
            633750.00          |Magnetic Resonance Imaging|MR
            633751.00          |Nuclear Medicine          |NM
            633752.00          |General Diagnostic        |GD
            */
            modgroup        = {
                /**
                 *
                 * @returns {string}     CT
                 */
                'B633747'   : function () {
                    return 'CT';
                },
                /**
                 *
                 * @param ORDER_DESC
                 * @param CATALOG_CD
                 * @returns {string}
                 */
                'B633750': function (ORDER_DESC,CATALOG_CD) {
                    var retVal = 'MR';

                    if ( CATALOG_CD ===  69219888.0 ||
                        CATALOG_CD ===  815366.0 ||
                        CATALOG_CD ===  815364.0 ||
                        CATALOG_CD ===  815362.0 ||
                        CATALOG_CD ===  978359.0 ||
                        CATALOG_CD ===  1582585223.0 ||
                        CATALOG_CD ===  1549149865.0 ||
                        CATALOG_CD ===  1582585687.0) {
                        retVal = 'MRCARDIO';
                    }
                    return retVal;
                },
                /**
                 *
                 * @returns {string}  IR  "INTRVTN"
                 */
                'B633748'   : function () {
                    return 'IR';
                },
                /**
                 *
                 * @returns {string} "PET"
                 */
                'B110440686': function () {
                    return "PT";
                },
                /**
                 *
                 * @param ORDER_DESC {string} 'NUCMED'
                 * @returns {string}
                 */
                'B633751'   : function (ORDER_DESC) {
                    return (ORDER_DESC.indexOf('PET') > -1 ? 'PT' : 'NA');
                },
                /**
                 *
                 * @returns {string}
                 */
                'B61072547' : function () {
                    return "FL";
                },
                /**
                 *
                 * @returns {string}
                 */
                'B633753'   : function () {
                    return "US";
                }

            },
            NpByPass = [];
        modval              = 'B' + orderItem.MODTYPE.toString();
        if (typeof modgroup[modval] === 'undefined') {
            orderItem.MODTYPELBL = 'NA';
        } else {
            orderItem.MODTYPELBL = modgroup[modval](orderItem.ORDER_DESC,orderItem.CATALOG_CD);
        }

        if (aProtocolStatus.indexOf('Initalized') > -1) {
            protocol_status          = 'Exam Protocol';
        }
        if (aProtocolStatus.indexOf('|Exam Protocol') > -1) {
            protocol_status      = 'Nurse Practitioner';
        }
        if (aProtocolStatus.indexOf('|Nurse Practitioner') > -1) {
            protocol_status = 'Waiting';
        }
        if (aProtocolStatus.indexOf('|Scheduling') > -1) {
            protocol_status         = 'Nurse Tech';
        }
        if (aProtocolStatus.indexOf('|Nurse Tech') > -1) {
            protocol_status         = 'Completed';
        }
        if (viewMod === 'ACTIVE') {
            protocol_status = 'Nurse Tech';
        }else if (viewMod === 'NEW') {
            protocol_status = 'New Order';
          if ( orderItem.MODTYPELBL === 'MRCARDIO'){
                orderItem.MODTYPELBL = 'MR';
            }
        }else if (viewMod === 'HOLD') {
            if ( orderItem.MODTYPELBL === 'MRCARDIO'){
                orderItem.MODTYPELBL = 'MR';
            }
        }else if (viewMod === 'FUTURE') {
              if ( orderItem.MODTYPELBL === 'MRCARDIO'){
                  orderItem.MODTYPELBL = 'MR';
                  if (protocol_status === 'Exam Protocol') {
                      orderItem.MODTYPELBL2 = 'MRCARDIO';
                  }
              }
            if (protocol_status === 'Nurse Practitioner') {
                if (orderItem.NP_HOLD_STATUS !== '' ||
                    orderItem.EP_REORDER_FLAG.toUpperCase() === 'YES') {
                    orderItem.MODTYPELBL = 'NA';
                }
            }
            if( orderItem.EP_HOLD_STATUS2 !== ''){
                orderItem.MODTYPELBL = 'NA';
            }
            if (protocol_status === 'Exam Protocol') {
                if (orderItem.EP_HOLD_STATUS !== '') {
                    orderItem.MODTYPELBL = 'NA';
                }
            }
            if ( orderItem.ENCNTRID === 0) {
                orderItem.MODTYPELBL = 'NA';
                protocol_status = 'NA';
            }
            if (protocol_status === 'New' && orderItem.FORM_ACTIVITY_ID > 0) {
                protocol_status = 'Exam Protocol';
            }
            if (chla.OPRADWL.FeatureCtl.F00006_0.Available){
                NpByPass.push( '|' , orderItem.CATALOG_CD, '|');
                if (protocol_status !== 'Nurse Practitioner') {
                    // always route to NP triage
                    if ('|1618441103|69219890|1618438833|1549149497|2185854|632645303|392359937|392360543|198702384|814902|392360457|814652|'.indexOf(NpByPass.join('')) > -1) {
                    LogIt( {
                            logType: 'LogInfo',
                            sepChar:'',
                            logLevel: 100, arrParams:['Found Bypass', NpByPass.join('')]
                        });
                        protocol_status = 'Nurse Practitioner';
                        orderItem.PROTOCAL_STATUS = orderItem.PROTOCAL_STATUS + '|Exam Protocol';
                        orderItem.SUBTYPE_CD = 99;
                    }
                }
            }
        }else if (viewMod === 'MODIFY') {
            if (orderItem.EP_REORDER_FLAG.toUpperCase() === 'YES') {
                protocol_status = 'Scheduling';
            }
            if ( orderItem.MODTYPELBL === 'MRCARDIO'){
                orderItem.MODTYPELBL = 'MR';
            }
        }

        if(typeof aAppObj.View.H5H6BuilderList[viewMod].H6List[protocol_status] === 'undefined'){
            orderItem.MODTYPELBL = 'NA';
            protocol_status = 'NA'
        }
        if (chla.eApps.filterZzKids) {
            if ((orderItem.NAME_FULL_FORMATTED).toUpperCase().indexOf('ZZKIDS')>-1) {
                orderItem.MODTYPELBL = 'NA';
                protocol_status      = 'NA'
            }
        }
        orderItem.CTLPROTOCAL_STATUS = protocol_status;
        /* this variable was used to denote out of processing NP Triage done before Exam Protocol */
        orderItem.ORDERSEQERROR = 'No';
    }

    Orders.forEach(
        function(item) {
            var arrTreeStructure = [],
                protocol_status,
                protocol1,
                protocol2;
            OutPatOrderConvert(item,aAppObj);
            lblMode = item.MODTYPELBL;
            protocol_status = item.CTLPROTOCAL_STATUS;
            if (lblMode !== "NA" && protocol_status !== 'NA') {
                if (aAppObj.Data.getOrdState(aAppObj) !== 'ACTIVE'){
                    item.HoldID = item.EP_HOLD_STATUSID.replace(/ /g,'').replace(/[\(\)\.\,]/g,'') + item.NP_HOLD_STATUSID.replace(/ /g,'').replace(/[\(\)\.\,]/g,'');
                }
                item.NameID = item.NAME_FULL_FORMATTED.replace(/ /g,'').replace(/[\(\)\.\,]/g,'');
                arrTreeStructure.push(lblMode);
                arrTreeStructure.push(protocol_status.replace(/ /g, ''));
                protocol1 = arrTreeStructure.join('').toUpperCase();

                if (typeof item.MODTYPELBL2 !== 'undefined'){
                    arrTreeStructure[0]= item.MODTYPELBL2;
                    arrTreeStructure.push('SS99');
                    protocol2 = arrTreeStructure.join('').toUpperCase();
                    item.SUBTYPE_CD = 99;
                } else {
                    arrTreeStructure.push('SS' + item.SUBTYPE_CD);
                    protocol2 = arrTreeStructure.join('').toUpperCase();
                }

                if (treeStructure[lblMode] === false) {
                    treeStructure[lblMode] = true;
                    arrRetDto.Filters.comboModality.push(lblMode);
                    arrRetDto.tblData[lblMode] = {
                        Lbl        : lblMode,
                        SectId     : lblMode + '1',
                        BodyContent: {},
                        Count      : 0
                    };
                }
                if (item.SUBTYPE_CD === 0 && treeStructure[protocol1].PRESENT === false) {
                    treeStructure[protocol1].PRESENT = true;
                }
                if (item.SUBTYPE_CD > 0  ) {
                    if (protocol2.toUpperCase().indexOf('EXAMPROTOCOL') > -1 && aAppObj.Data.getOrdState(aAppObj) === 'FUTURE') {
                        treeStructure[protocol2].PRESENT = true;
                    } else {
                        treeStructure[protocol1].PRESENT = true;
                    }
                }
            }
        }
    );
    if (FilterOp){
        vViewOrders  = Orders.slice();
     }else {
        vViewOrders   =  Orders.filter(
            function (value) {
                return (value.MODTYPELBL !== 'NA');
            }
        );
        aAppObj.Data.setBaseViewOrders(aAppObj,vViewOrders.slice());
    }
    displayTree.forEach(
        function (item,index) {
            var lblMode,
                H6Id,
                H6SecId;
            if(treeStructure[item].PRESENT) {
                lblMode = treeStructure[item].mod;
                H6Id    = treeStructure[item].lbl;
               // H6SecId = lblMode + 'NO1';
                H6SecId = lblMode + index;
                arrRetDto.Filters.comboProtocol.push(H6Id);
                arrRetDto.tblData[lblMode].BodyContent[H6Id] = {
                    Lbl        : (H6Id === 'NurseTechnologist'? 'Nurse / Technologist':H6Id),
                    SectId     : H6SecId,
                    BodyContent: [],
                    Count      : 0
                };
            }
        });
    $('div#prog3').html( [
        '<h3 id="startup_label" ',
        'style=\"text-align: center;font-family: Tahoma ;',
        'font-size:16px;padding-top:280px\">',
        'Loading Worklist Data </h3>'].join(''));

    // aAppObj.View.SortFuncs('String',vViewOrders,'ASC');

    vViewOrders.forEach(
        /**
         * Process Modalities
         * @param value
         */
        function (value) {
            var protocol_status = value.CTLPROTOCAL_STATUS,
                subType_cd      = value.SUBTYPE_CD,
                protocol_node,
                lblMode         = value.MODTYPELBL,
                arrTreeStructure = [],
                lblProt;
            value.ORDER_LBL = value.ORDER_DESC;
            arrTreeStructure.push(lblMode);
            arrTreeStructure.push(protocol_status.replace(/ /g, '').toUpperCase());
            protocol_status= treeStructure[arrTreeStructure.join('').toUpperCase()].lbl;
            if (subType_cd> 0 && aAppObj.Data.getOrdState(aAppObj) === 'FUTURE') {
                if (arrTreeStructure[1].indexOf('EXAMPROTOCOL') > -1) {
                    if (subType_cd === 99){
                        arrTreeStructure[0]= 'MRCARDIO';
                        arrTreeStructure.push('SS99');
                    } else {
                        arrTreeStructure.push('SS' + subType_cd);
                    }
                    protocol_node = arrTreeStructure.join('').toUpperCase();
                    protocol_status= treeStructure[ protocol_node].lbl;
                }
            }
            lblProt = protocol_status;
            value.LEVEL = 3;
            value.ProtocolID = lblProt.replace(/ /g,'').replace(/[\(\)\.\,]/g,'');
            value.ModID = lblMode;
            objRow = aAppObj.View.H5H6Builder(aAppObj, lblMode, lblProt, value);
            if(typeof value.HOLDBY !== 'undefined'){
                arrRetDto.Filters.comboHoldBy.push(value.HOLDBY);
            }
            arrRetDto.Filters.comboOrderId.push(value.ORDERID);
            arrRetDto.Filters.comboPatient.push(objRow.H6Body.NAME);
            arrRetDto.tblData[objRow.H5id].BodyContent[objRow.H6id].BodyContent.push(objRow.H6Body);
        }
    );
    arrRetDto.Filters.comboOrderId  = arrRetDto.Filters.comboOrderId.filter(chla.eApps.gFuncs.onlyUnique).sort();
    arrRetDto.Filters.comboHoldBy   = arrRetDto.Filters.comboHoldBy.filter(chla.eApps.gFuncs.onlyUnique).sort();
    arrRetDto.Filters.comboProtocol = arrRetDto.Filters.comboProtocol.filter(chla.eApps.gFuncs.onlyUnique);
    arrRetDto.Filters.comboModality = arrRetDto.Filters.comboModality.filter(chla.eApps.gFuncs.onlyUnique);
    arrRetDto.Filters.comboPatient  = arrRetDto.Filters.comboPatient.filter(chla.eApps.gFuncs.onlyUnique);
    arrRetDto.Filters.comboPatient.sort();
    arrH5Keys = Object.keys(arrRetDto.tblData);
    arrH5Keys.forEach(
        function (value) {
            var objWrkH5 = arrRetDto.tblData[value];
            arrH6Keys    = Object.keys(objWrkH5.BodyContent);
            arrH6Keys.forEach(
                function (value1) {
                    var objWrkH6   = objWrkH5.BodyContent[value1];
                    objWrkH6.Count = objWrkH6.BodyContent.length;
                    objWrkH5.Count += objWrkH6.BodyContent.length;
                }
            )
        }
    );
    return arrRetDto;
};
