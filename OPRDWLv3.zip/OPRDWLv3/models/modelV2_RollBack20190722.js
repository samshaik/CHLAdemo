'use strict';
/**
 *
 * @param Orders
 * @param aAppObj
 * @param FilterOp
 */
chla.OPRADWL.crTrSt.nP = function (Orders, aAppObj, FilterOp) {
    var arrRetDto = {
            viewId : '',
            LdDate : '',
            strUI  : '',
            tblData: {},
            fltrs: {
                'cbHldBy'  : [],
                'cbOrdId' : [],
                'cbPat' : [],
                'cbMod': [],
                'cbProt': [],
                'comboTimeRng' : []
            }
        },
        arrH5Keys,
        arrH6Keys,
        objRow,
        vViewOrders,
        // lblMode,
        // protocol_status,
        displayTree = [
            'AR3HOLD',
            'AR3HOLDSS1101',
            'AR3HOLDSS1102',
            'AR3HOLDSS1103',
            'AR3HOLDSS1104',
            'CTNEWORDER',
            'CTNEWORDERSS1101',
            'CTNEWORDERSS1102',
            'CTNEWORDERSS1103',
            'CTNEWORDERSS1104',
            'CTEXAMPROTOCOL',
            'CTEXAMPROTOCOLSS1101',
            'CTEXAMPROTOCOLSS1102',
            'CTEXAMPROTOCOLSS1103',
            'CTEXAMPROTOCOLSS1104',
            'CTNURSEPRACTITIONER',
            'CTWAITING',
            'CTSCHEDULING',
            'CTNURSETECH',
            'MRNEWORDER',
            'MRNEWORDERSS1101',
            'MRNEWORDERSS1102',
            'MRNEWORDERSS1103',
            'MRNEWORDERSS1104',
            'MREXAMPROTOCOL',
            'MRCARDIOEXAMPROTOCOLSS99',
            'MREXAMPROTOCOLSS1101',
            'MREXAMPROTOCOLSS1102',
            'MREXAMPROTOCOLSS1103',
            'MREXAMPROTOCOLSS1104',
            'MRNURSEPRACTITIONER',
            'MRWAITING',
            'MRSCHEDULING',
            'MRNURSETECH',
            'IRNEWORDER',
            'IREXAMPROTOCOL',
            'IRNURSEPRACTITIONER',
            'IRWAITING',
            'IRSCHEDULING',
            'IRNURSETECH',
            'PTNEWORDER',
            'PTEXAMPROTOCOL',
            'PTNURSEPRACTITIONER',
            'PTWAITING',
            'PTSCHEDULING',
            'PTNURSETECH',
            'NMNEWORDER',
            'NMEXAMPROTOCOL',
            'NMNURSEPRACTITIONER',
            'NMNURSETECH',
            'FLNEWORDER',
            'FLEXAMPROTOCOL',
            'FLNURSEPRACTITIONER',
            'FLVCUGNURSEPRACTITIONERSS99',
            'FLWAITING',
            'FLSCHEDULING',
            'FLNURSETECH',
            'USNEWORDER',
            'USEXAMPROTOCOL',
            'USNURSEPRACTITIONER',
            'USWAITING',
            'USSCHEDULING',
            'USNURSETECH'
        ],
        trSt = {
            'CT':false,
            'IR':false,
            'MR':false,
            'PT':false,
            'FL':false,
            'NM':false,
            'AR3':false,
            'AR3HOLD':{
                "PRESENT":false,
                'lbl':'Day of Visit - NP Hold',
                'mod':'AR3'
            },
            'AR3HOLDSS1101':{
                "PRESENT":false,
                'lbl':'New Order - BODY',
                'mod':'AR3'
            },
            'AR3HOLDSS1102':{
                "PRESENT":false,
                'lbl':'New Order - NEURO',
                'mod':'AR3'
            },
            'AR3HOLDSS1103':{
                "PRESENT":false,
                'lbl':'New Order - Body and/or Neuro',
                'mod':'AR3'
            },
            'AR3HOLDSS1104':{
                "PRESENT":false,
                'lbl':'New Order - Not Used',
                'mod':'AR3'
            },
            'CTNEWORDER':{
                "PRESENT":false,
                'lbl':'New Order',
                'mod':'CT'
            },
            'CTNEWORDERSS1101':{
            "PRESENT":false,
                'lbl':'New Order - BODY',
                'mod':'CT'
            },
            'CTNEWORDERSS1102':{
                "PRESENT":false,
                    'lbl':'New Order - NEURO',
                    'mod':'CT'
            },
            'CTNEWORDERSS1103':{
                "PRESENT":false,
                    'lbl':'New Order - Body and/or Neuro',
                    'mod':'CT'
            },
            'CTNEWORDERSS1104':{
                "PRESENT":false,
                    'lbl':'New Order - Not Used',
                    'mod':'CT'
            },

            'CTEXAMPROTOCOL':{
                "PRESENT":false,
                'lbl':'Exam Protocol',
                'mod':'CT'
            },
            'CTEXAMPROTOCOLSS1101':{
                "PRESENT":false,
                'lbl':'Exam Protocol - BODY',
                'mod':'CT'
            },
            'CTEXAMPROTOCOLSS1102':{
                "PRESENT":false,
                'lbl':'Exam Protocol - NEURO',
                'mod':'CT'
            },
            'CTEXAMPROTOCOLSS1103':{
                "PRESENT":false,
                'lbl':'Exam Protocol - Body and/or Neuro',
                'mod':'CT'
            },
            'CTEXAMPROTOCOLSS1104':{
                "PRESENT":false,
                'lbl':'Exam Protocol - Not Used',
                'mod':'CT'
            },
            'CTNURSEPRACTITIONER':{
                "PRESENT":false,
                'lbl':'NP Triage',
                'mod':'CT'
            },
            'CTWAITING':{
                "PRESENT":false,
                'lbl':'Waiting',
                'id':'Waiting',
                'mod':'CT'
            },
            'CTSCHEDULING':{
                "PRESENT":false,
                'lbl':'Scheduling',
                'id':'Scheduling',
                'mod':'CT'
            },
            'CTNURSETECH':{
                "PRESENT":false,
                'lbl':'NurseTechnologist',
                'id':'NurseTechnologist',
                'mod':'CT'
            },
            'MRNEWORDER':{
                "PRESENT":false,
                'lbl':'New Order',
                'mod':'MR'
            },
            'MRNEWORDERSS1101':{
                "PRESENT":false,
                'lbl':'Exam Protocol - BODY',
                'mod':'MR'
            },
            'MRNEWORDERSS1102':{
                "PRESENT":false,
                'lbl':'Exam Protocol - NEURO',
                'mod':'MR'
            },
            'MRNEWORDERSS1103':{
                "PRESENT":false,
                'lbl':'Exam Protocol - Body and/or Neuro',
                'mod':'MR'
            },
            'MRNEWORDERSS1104':{
                "PRESENT":false,
                'lbl':'Exam Protocol - Not Used',
                'mod':'MR'
            },
            'MREXAMPROTOCOL':{
                "PRESENT":false,
                'lbl':'Exam Protocol',
                'mod':'MR'
            },
            'MREXAMPROTOCOLSS1101':{
                "PRESENT":false,
                'lbl':'Exam Protocol - BODY',
                'mod':'MR'
            },
            'MREXAMPROTOCOLSS1102':{
                "PRESENT":false,
                'lbl':'Exam Protocol - NEURO',
                'mod':'MR'
            },
            'MREXAMPROTOCOLSS1103':{
                "PRESENT":false,
                'lbl':'Exam Protocol - Body and/or Neuro',
                'mod':'MR'
            },
            'MREXAMPROTOCOLSS1104':{
                "PRESENT":false,
                'lbl':'Exam Protocol - Not Used',
                'mod':'MR'
            },
            'MRCARDIOEXAMPROTOCOLSS99':{
                "PRESENT":false,
                'lbl':'Cardio Exam Protocol',
                'id':'CardioExamProtocol',
                'mod':'MR'
            },
            'MRNURSEPRACTITIONER':{
                "PRESENT":false,
                'lbl':'NP Triage',
                'mod':'MR'
            },
            'MRWAITING':{
                "PRESENT":false,
                'lbl':'Waiting',
                'mod':'MR'
            },
            'MRSCHEDULING':{
                "PRESENT":false,
                'lbl':'Scheduling',
                'mod':'MR'
            },
            'MRNURSETECH':{
                "PRESENT":false,
                'lbl':'Nurse Technologist',
                'id':'NurseTechnologist',
                'mod':'MR'
            },
            'IRNEWORDER':{
                "PRESENT":false,
                'lbl':'New Order',
                'mod':'IR'
            },
            'IREXAMPROTOCOL':{
                "PRESENT":false,
                'lbl':'Exam Protocol',
                'mod':'IR'
            },
            'IRNURSEPRACTITIONER':{
                "PRESENT":false,
                'lbl':'NP Triage',
                'mod':'IR'
            },
            'IRWAITING':{
                "PRESENT":false,
                'lbl':'Waiting',
                'mod':'IR'
            },
            'IRSCHEDULING':{
                "PRESENT":false,
                'lbl':'Scheduling',
                'mod':'IR'
            },
            'IRNURSETECH':{
                "PRESENT":false,
                'lbl':'Nurse / Technologist',
                'id':'NurseTechnologist',
                'mod':'IR'
            },
            'PTNEWORDER':{
                "PRESENT":false,
                'lbl':'New Order',
                'mod':'PT'
            },
            'PTEXAMPROTOCOL':{
                "PRESENT":false,
                'lbl':'Exam Protocol',
                'mod':'PT'
            },
            'PTNURSEPRACTITIONER':{
                "PRESENT":false,
                'lbl':'NP Triage',
                'mod':'PT'
            },
            'PTWAITING':{
                "PRESENT":false,
                'lbl':'Waiting',
                'mod':'PT'
            },
            'PTSCHEDULING':{
                "PRESENT":false,
                'lbl':'Scheduling',
                'mod':'PT'
            },
            'PTNURSETECH':{
                "PRESENT":false,
                'lbl':'NurseTechnologist',
                'id':'NurseTechnologist',
                'mod':'PT'
            },
            'NMNEWORDER':{
                "PRESENT":false,
                'lbl':'New Order',
                'mod':'NM'
            },
            'NMEXAMPROTOCOL':{
                "PRESENT":false,
                'lbl':'Exam Protocol',
                'mod':'NM'
            },
            'NMNURSEPRACTITIONER':{
                "PRESENT":false,
                'lbl':'NP Triage',
                'mod':'NM'
            },
            'NMNURSETECH':{
                "PRESENT":false,
                'lbl':'NurseTechnologist',
                'id':'NurseTechnologist',
                'mod':'NM'
            },
            'FLNEWORDER':{
                "PRESENT":false,
                'lbl':'New Order',
                'mod':'FL'
            },
            'FLEXAMPROTOCOL':{
                "PRESENT":false,
                'lbl':'Exam Protocol',
                'mod':'FL'
            },
            'FLNURSEPRACTITIONER':{
                "PRESENT":false,
                'lbl':'NP Triage',
                'mod':'FL'
            },
            'FLVCUGNURSEPRACTITIONERSS99':{
                "PRESENT":false,
                'lbl':'NP Triage VCUG',
                'mod':'FL'
            },
            'FLWAITING':{
                "PRESENT":false,
                'lbl':'Waiting',
                'mod':'FL'
            },
            'FLSCHEDULING':{
                "PRESENT":false,
                'lbl':'Scheduling',
                'mod':'FL'
            },
            'FLNURSETECH':{
                "PRESENT":false,
                'lbl':'NurseTechnologist',
                'id':'NurseTechnologist',
                'mod':'FL'
            },
            'USNEWORDER':{
                "PRESENT":false,
                'lbl':'New Order',
                'mod':'US'
            },
            'USEXAMPROTOCOL':{
                "PRESENT":false,
                'lbl':'Exam Protocol',
                'mod':'US'
            },
            'USNURSEPRACTITIONER':{
                "PRESENT":false,
                'lbl':'NP Triage',
                'mod':'US'
            },
            'USWAITING':{
                "PRESENT":false,
                'lbl':'Waiting',
                'mod':'US'
            },
            'USSCHEDULING':{
                "PRESENT":false,
                'lbl':'Scheduling',

                'mod':'US'
            },
            'USNURSETECH':{
                "PRESENT":false,
                'lbl':'NurseTechnologist',
                'id':'NurseTechnologist',
                'mod':'US'
            }
        },
        UniqueArr = {};
    /**
     * Determine the Protocol Status and Order type source
     * SPECIFIC: to View type
     * @param orderItem
     * @param aAppObj
     */
    function OutPatOrderConvert(orderItem,aAppObj) {
        var aProtocolStatus = orderItem.PROTOCAL_STATUS,
            viewMod = aAppObj.Data.getOrdState(aAppObj),
            protocol_status,
            modVal,
            /*
            ACTIVITY_SUBTYPE_CD|OC_ACTIVITY_SUBTYPE_DISP  |MNEMONIC
            110440686.00       |PET                       |PT
            61072547.00        |Fluoroscopy               |FL
            633747.00          |Computerized Tomography   |CT
            633748.00          |Interventional Radiology  |IR
            633750.00          |Magnetic Resonance Imaging|MR
            633751.00          |Nuclear Medicine          |NM
            633752.00          |General Diagnostic        |GD
            */
            modGroup        = {
                /**
                 *
                 * @returns {string}     CT
                 */
                'B633747'   : function () {
                    return 'CT';
                },
                /**
                 *
                 * @param ORDER_DESC
                 * @param CATALOG_CD
                 * @returns {string}
                 */
                'B633750': function (ORDER_DESC,CATALOG_CD) {
                    var retVal = 'MR';

                    if ( CATALOG_CD ===  69219888.0 ||
                        CATALOG_CD ===  815366.0 ||
                        CATALOG_CD ===  815364.0 ||
                        CATALOG_CD ===  815362.0 ||
                        CATALOG_CD ===  978359.0 ||
                        CATALOG_CD ===  1582585223.0 ||
                        CATALOG_CD ===  1549149865.0 ||
                        CATALOG_CD ===  1582585687.0) {
                        retVal = 'MRCARDIO';
                    }
                    return retVal;
                },
                /**
                 *
                 * @returns {string}  IR  "INTRVTN"
                 */
                'B633748'   : function () {
                    var retVal = 'NA';
                    if(chla.OPRADWL.FeatureCtl.F00004_0.Available){
                        retVal = 'IR';
                    }
                    return retVal;
                },
                /**
                 *
                 * @returns {string} "PET"
                 */
                'B110440686': function () {
                    return "PT";
                },
                /**
                 *
                 * @param ORDER_DESC {string} 'NUCMED'
                 * @param CATALOG_CD {number}
                 * @param record {Object}
                 * @returns {string}
                 */
                'B633751'   : function (ORDER_DESC,CATALOG_CD,record) {
                    var retVal;
                    retVal = (ORDER_DESC.indexOf('PET') > -1 ? 'PT' : 'NA');
                    if (retVal === 'NA') {
                        if(chla.OPRADWL.FeatureCtl.F00002_0.Available) {
                            if (record.SEDATION !== "Awake") {
                                retVal = 'NM'
                            }
                        }
                    }
                    return retVal;
                },
                /**
                 * FL - Fluoroscopy
                 * @returns {string}
                 */
                'B61072547' : function (ORDER_DESC,CATALOG_CD,record) {
                    var retVal = 'NA';
                    if(chla.OPRADWL.FeatureCtl.F00005_0.Available) {
                        if (record.CATALOG_CD === 814952 || record.CATALOG_CD === 814958) {
                            retVal = 'FLVCUG';
                        }
                    }
                    return retVal;
                },
                /**
                 *
                 * @returns {string}
                 */
                'B633753'   : function () {
                    return "US";
                }

            },
            NpByPass = [];
        /*=============================*/
        /*Base Modularity Determination*/
        /*=============================*/
        orderItem.MODALIAS = '';
        modVal              = 'B' + orderItem.MODTYPE.toString();
        if (typeof modGroup[modVal] === 'undefined') {
            orderItem.MODTYPELBL = 'NA';
        } else {
            orderItem.MODTYPELBL = modGroup[modVal](orderItem.ORDER_DESC,orderItem.CATALOG_CD,orderItem);
        }

        /*=============================*/
        /*Protocol Phase Determination*/
        /*=============================*/
        if (aProtocolStatus.indexOf('Initalized') > -1) {
            protocol_status          = 'Exam Protocol';
        }
        if (aProtocolStatus.indexOf('|Exam Protocol') > -1) {
            protocol_status      = 'Nurse Practitioner';
        }
        if (aProtocolStatus.indexOf('|Nurse Practitioner') > -1) {
            protocol_status = 'Waiting';
        }
        if (aProtocolStatus.indexOf('|Scheduling') > -1) {
            protocol_status         = 'Nurse Tech';
        }
        if (aProtocolStatus.indexOf('|Nurse Tech') > -1) {
            protocol_status         = 'Completed';
        }
        /*=============================*/
        /*Modularity Modification      */
        /*=============================*/
        if(chla.OPRADWL.FeatureCtl.F00005_0.Available) {
            if (orderItem.MODTYPELBL === 'FL') {
                orderItem.MODALIAS = 'Fluoro';
            }
        }
        /*====================*/
        /*====ACTIVE VIEW=====*/
        /*====================*/
        if (viewMod === 'ACTIVE') {
            protocol_status = 'Nurse Tech';
            if ( orderItem.MODTYPELBL === 'MRCARDIO'){
                orderItem.MODTYPELBL = 'MR';
            }
        /*====================*/
        /*=======NEW VIEW=====*/
        /*====================*/
        }else if (viewMod === 'NEW') {
            protocol_status = 'New Order';
            if ( orderItem.MODTYPELBL === 'MRCARDIO'){
                orderItem.MODTYPELBL = 'MR';
            }
        /*====================*/
        /*======HOLD VIEW=====*/
        /*====================*/
        }else if (viewMod === 'HOLD') {
            if ( orderItem.MODTYPELBL === 'MRCARDIO'){
                orderItem.MODTYPELBL = 'MR';
            }
            if ( orderItem.ARIND === 95){  //AR3 code
                protocol_status = 'HOLD';
                orderItem.MODTYPELBL = 'AR3';
            }
        /*====================*/
        /*====FUTURE VIEW=====*/
        /*====================*/
        }else if (viewMod === 'FUTURE') {
            if ( orderItem.MODTYPELBL === 'MRCARDIO'){
                orderItem.MODTYPELBL = 'MR';
                if (protocol_status === 'Exam Protocol') {
                  orderItem.MODTYPELBL2 = 'MRCARDIO';
                  orderItem.SUBTYPE_CD = 99;
                }
            }
            if (protocol_status === 'Nurse Practitioner') {
                if (orderItem.NP_HOLD_STATUS !== '' ||
                    orderItem.EP_REORDER_FLAG.toUpperCase() === 'YES') {
                    orderItem.MODTYPELBL = 'NA';
                }
            }
            if( orderItem.EP_HOLD_STATUS2 !== ''){
                orderItem.MODTYPELBL = 'NA';
            }
            if (protocol_status === 'Exam Protocol') {
                if (orderItem.EP_HOLD_STATUS !== '') {
                    orderItem.MODTYPELBL = 'NA';
                }
            }
            if ( orderItem.ENCNTRID === 0) {
                orderItem.MODTYPELBL = 'NA';
                protocol_status = 'NA';
            }
            if (protocol_status === 'New' && orderItem.FORM_ACTIVITY_ID > 0) {
                protocol_status = 'Exam Protocol';
            }
            if(chla.OPRADWL.FeatureCtl.F00005_0.Available) {
                if (orderItem.MODTYPELBL === 'FL' && protocol_status === 'Exam Protocol') {
                    orderItem.MODTYPELBL2 = 'FLVCUG';
                    orderItem.SUBTYPE_CD = 99;
                    protocol_status = 'Nurse Practitioner';
                }
            }
            if (chla.OPRADWL.FeatureCtl.F00006_0.Available){
                NpByPass.push( '|' , orderItem.CATALOG_CD, '|');
                if (protocol_status !== 'Nurse Practitioner') {
                    if ('|1618441103|69219890|1618438833|1549149497|2185854|632645303|392359937|392360543|198702384|814900|814902|814898|392360457|814652|'.indexOf(NpByPass.join('')) > -1) {
                        protocol_status = 'Nurse Practitioner';
                        orderItem.PROTOCAL_STATUS = orderItem.PROTOCAL_STATUS + '|Exam Protocol';
                        orderItem.SUBTYPE_CD = 99;
                    }
		    if ('|211949507|814662|392359879|814664|814666|814814|392360525|814816|814818|198701997|198702134|392360367|814910|814912|814914|1549149585|161844110|'.indexOf(NpByPass.join('')) > -1) {
                        protocol_status = 'Nurse Practitioner';
                        orderItem.PROTOCAL_STATUS = orderItem.PROTOCAL_STATUS + '|Exam Protocol';
                        orderItem.SUBTYPE_CD = 99;
                    }
                }
            }
            if(chla.OPRADWL.FeatureCtl.F00002_0.Available) {
                if (orderItem.MODTYPELBL === 'NM' && protocol_status === 'Exam Protocol') {
                    protocol_status = 'Nurse Practitioner';
                    orderItem.PROTOCAL_STATUS = orderItem.PROTOCAL_STATUS + '|Exam Protocol';
                    orderItem.SUBTYPE_CD = 99;
                }
            }
        /*====================*/
        /*====MODIFY VIEW=====*/
        /*====================*/
        }else if (viewMod === 'MODIFY') {
            if (orderItem.EP_REORDER_FLAG.toUpperCase() === 'YES') {
                protocol_status = 'Scheduling';
            }
            if ( orderItem.MODTYPELBL === 'MRCARDIO'){
                orderItem.MODTYPELBL = 'MR';
            }
        }
        /*====================================*/
        /*====UNDEFINED ORDER Processing =====*/
        /*====================================*/
        if(typeof aAppObj.View.H5H6BuilderList[viewMod].H6List[protocol_status] === 'undefined'){
            orderItem.MODTYPELBL = 'NA';
            protocol_status = 'NA'
        }
        /*FILTER zzkids patient from worklist display*/
        if (chla.eApps.filterZzKids === "test") {
            if ((orderItem.NAME_FULL_FORMATTED).toUpperCase().indexOf('ZZKIDS') == -1) {
                orderItem.MODTYPELBL = 'NA';
                protocol_status      = 'NA'
            }
        } else  if (chla.eApps.filterZzKids) {
            if ((orderItem.NAME_FULL_FORMATTED).toUpperCase().indexOf('ZZKIDS')>-1) {
                orderItem.MODTYPELBL = 'NA';
                protocol_status      = 'NA'
            }
        }
        orderItem.CTLPROTOCAL_STATUS = protocol_status;
        /* this variable was used to denote out of processing NP Triage done before Exam Protocol */
        orderItem.ORDERSEQERROR = 'No';
    }

    /**
     *
     * @param aOrders {Object}
     */
    function pPP(aOrders) {
        aOrders.forEach(
            /**
             * Process Modalities
             * @param value
             */
            function (value) {
                var protocol_status = value.CTLPROTOCAL_STATUS,
                    subType_cd = value.SUBTYPE_CD,
                    protocol_node,
                    lblMode = value.MODTYPELBL,
                    arrTreeStructure = [],
                    strWrk,
                    lblProt;
                value.ORDER_LBL = value.ORDER_DESC;
                arrTreeStructure.push(lblMode);
                arrTreeStructure.push(protocol_status.replace(/ /g, '').toUpperCase());
                /*convert protocol phase into display label */
                protocol_status = trSt[arrTreeStructure.join('').toUpperCase()].lbl;
                if (subType_cd > 0 && aAppObj.Data.getOrdState(aAppObj) === 'NEW') {
                    if (arrTreeStructure[1].indexOf('NEWORDER') > -1) {
                        if ('CTMR'.indexOf(arrTreeStructure[0])> -1) {
                            if (subType_cd === 99) {
                                arrTreeStructure[0] = value.MODTYPELBL2;
                            }
                            arrTreeStructure.push('SS' + subType_cd);
                            protocol_node = arrTreeStructure.join('').toUpperCase();
                            protocol_status = trSt[protocol_node].lbl;
                        }
                    }
                } else if (subType_cd > 0 && aAppObj.Data.getOrdState(aAppObj) === 'FUTURE') {
                    strWrk = arrTreeStructure.join('');
                    if (arrTreeStructure[1].indexOf('EXAMPROTOCOL') > -1) {
                        if (subType_cd === 99) {
                            arrTreeStructure[0] = value.MODTYPELBL2;
                        }
                        arrTreeStructure.push('SS' + subType_cd);
                        protocol_node = arrTreeStructure.join('').toUpperCase();
                        protocol_status = trSt[protocol_node].lbl;
                    }
                    if (strWrk === 'FLNURSEPRACTITIONER' && subType_cd === 99) {
                        arrTreeStructure[0] = value.MODTYPELBL2;
                        arrTreeStructure.push('SS' + subType_cd);
                        protocol_node = arrTreeStructure.join('').toUpperCase();
                        protocol_status = trSt[protocol_node].lbl;
                    }
                }
                lblProt = protocol_status;
                value.LEVEL = 3;
                value.ProtocolID = lblProt.replace(/ /g, '').replace(/[\(\)\.\,]/g, '');
                value.ModID = lblMode;
                objRow = aAppObj.View.H5H6Builder(aAppObj, lblMode, lblProt, value);
                if (typeof value.HOLDBY !== 'undefined') {
                    arrRetDto.fltrs.cbHldBy.push(value.HOLDBY);
                }
                arrRetDto.fltrs.cbOrdId.push(value.ORDERID);
                arrRetDto.fltrs.cbPat.push(objRow.H6Body.NAME);
                arrRetDto.tblData[objRow.H5id].bdCont[objRow.H6id].bdCont.push(objRow.H6Body);
            }
        );
    }
    /*==================================================*/
    /*           Begin Processing Orders array          */
    /*==================================================*/
    if(chla.OPRADWL.FeatureCtl.F00003_0.Available) {
        chla.OPRADWL.View.GROUP_PF_ID = {};
    }
    chla.OPRADWL.View.PROTOSTAT = {};
    /* Filter valid orders for display */
    chla.eAppsUtil.Logger.LogInfo(' Begin Processing Orders array: orders  '+ (typeof Orders));
    Orders.forEach(
        function(item) {
            var arrTreeStructure = [],
                protocol_status,
                protocol1,
                lblMode,
                lblAlias,
                Group_PF_id,
                itemOrderId,
                protocol2;
            OutPatOrderConvert(item,aAppObj);
            lblMode = item.MODTYPELBL;
            protocol_status = item.CTLPROTOCAL_STATUS;
            itemOrderId = 'B' + item.ORDERID;
            if (typeof UniqueArr[itemOrderId] === 'undefined'){
                UniqueArr[itemOrderId] = 1;
            } else {
                item.MODTYPELBL = "NA";
                lblMode = "NA";
            }
            if (lblMode !== "NA" && protocol_status !== 'NA') {
                if (protocol_status === 'Exam Protocol') {
                    chla.OPRADWL.View.PROTOSTAT[itemOrderId] = '^EP^';
                } else if (protocol_status === 'Nurse Practitioner') {
                    chla.OPRADWL.View.PROTOSTAT[itemOrderId] = '^NP^';
                } else {
                    chla.OPRADWL.View.PROTOSTAT[itemOrderId] = '^^';
                }
                if(chla.OPRADWL.FeatureCtl.F00003_0.Available) {
                    if (item.GROUP_PF_ID > 0) {
                        Group_PF_id = "G" + item.GROUP_PF_ID;
                        if (typeof chla.OPRADWL.View.GROUP_PF_ID[Group_PF_id] === 'undefined') {
                            chla.OPRADWL.View.GROUP_PF_ID[Group_PF_id] = [];
                        }
                        chla.OPRADWL.View.GROUP_PF_ID[Group_PF_id].push(item.ORDERID + '@' + item.ORDER_DESC+ '@' + item.ORIGORDDT);

                    }
                }
                if (aAppObj.Data.getOrdState(aAppObj) !== 'ACTIVE'){
                    item.HoldID = item.EP_HOLD_STATUSID.replace(/ /g,'').replace(/[\(\)\.\,]/g,'') +
                        item.NP_HOLD_STATUSID.replace(/ /g,'').replace(/[\(\)\.\,]/g,'');
                }
                item.NameID = item.NAME_FULL_FORMATTED.replace(/ /g,'').replace(/[\(\)\.\,]/g,'');
                arrTreeStructure.push(lblMode);
                arrTreeStructure.push(protocol_status.replace(/ /g, ''));
                protocol1 = arrTreeStructure.join('').toUpperCase();

                if (typeof item.MODTYPELBL2 !== 'undefined'){
                    arrTreeStructure[0]= item.MODTYPELBL2;
                }
                arrTreeStructure.push('SS' + item.SUBTYPE_CD);
                protocol2 = arrTreeStructure.join('').toUpperCase();
                if (trSt[lblMode] === false) {
                    trSt[lblMode] = true;
                    lblAlias = (item.MODALIAS === ""? lblMode: item.MODALIAS);
                    arrRetDto.fltrs.cbMod.push(lblAlias);
                    arrRetDto.tblData[lblMode] = {
                        Lbl        : lblAlias,
                        SectId     : lblMode + '1',
                        bdCont: {},
                        Count      : 0
                    };
                }
                item.arrTreeStructureP1 = protocol1;
                item.arrTreeStructureP2 = protocol2;
                if (typeof trSt[protocol1] ==='undefined' ) {
                    trSt[protocol1].PRESENT = true;
                }
                if (item.SUBTYPE_CD === 0 && trSt[protocol1].PRESENT === false) {
                    trSt[protocol1].PRESENT = true;
                }
                if (item.SUBTYPE_CD > 0  ) {
                    if (typeof trSt[protocol2] === "undefined" && 'CTMR'.indexOf(lblMode) === -1 ){
                         alert('treeStructure[protocol2]: '+ protocol2 +' undefined');
                        // null;
                    } else {
                        if (aAppObj.Data.getOrdState(aAppObj) === 'FUTURE') {
                            if (protocol2.toUpperCase().indexOf('EXAMPROTOCOL') > -1) {
                                trSt[protocol2].PRESENT = true;
                            } else if (protocol2.toUpperCase() === 'FLVCUGNURSEPRACTITIONERSS99') {
                                trSt[protocol2].PRESENT = true;
                            } else {
                                trSt[protocol1].PRESENT = true;
                            }
                        } else if (aAppObj.Data.getOrdState(aAppObj) === 'NEW') {
                                trSt[protocol2].PRESENT = true;
                        } else {
                                trSt[protocol1].PRESENT = true;
                        }
                    }
                }
            }
        }
    );
    if (FilterOp){
        vViewOrders  = Orders.slice();
    }else {
        vViewOrders   =  Orders.filter(
            function (value) {
                return (value.MODTYPELBL !== 'NA');
            }
        );
        aAppObj.Data.setBaseViewOrders(aAppObj,vViewOrders.slice());
    }
    /*Create the sub-segment group per protocol stage*/
    displayTree.forEach(
        function (item,index) {
            var lblMode,
                H6Id,
                H6SecId;
            if(trSt[item].PRESENT) {
                lblMode = trSt[item].mod;
                H6Id    = trSt[item].lbl;
                // H6SecId = lblMode + 'NO1';
                H6SecId = lblMode + index;
                arrRetDto.fltrs.cbProt.push(H6Id);
                arrRetDto.tblData[lblMode].bdCont[H6Id] = {
                    Lbl        : (H6Id === 'NurseTechnologist'? 'Nurse / Technologist':H6Id),
                    SectId     : H6SecId,
                    bdCont: [],
                    Count      : 0
                };
            }
        });
    pPP(vViewOrders);
    arrRetDto.fltrs.cbOrdId = arrRetDto.fltrs.cbOrdId.filter(chla.eApps.gFuncs.onlyUnique).sort();
    arrRetDto.fltrs.cbHldBy = arrRetDto.fltrs.cbHldBy.filter(chla.eApps.gFuncs.onlyUnique).sort();
    arrRetDto.fltrs.cbProt  = arrRetDto.fltrs.cbProt.filter(chla.eApps.gFuncs.onlyUnique);
    arrRetDto.fltrs.cbMod   = arrRetDto.fltrs.cbMod.filter(chla.eApps.gFuncs.onlyUnique);
    arrRetDto.fltrs.cbPat   = arrRetDto.fltrs.cbPat.filter(chla.eApps.gFuncs.onlyUnique);
    arrRetDto.fltrs.cbPat.sort();
    arrH5Keys = Object.keys(arrRetDto.tblData);
    arrH5Keys.forEach(
        function (value) {
            var objWrkH5 = arrRetDto.tblData[value];
            arrH6Keys    = Object.keys(objWrkH5.bdCont);
            arrH6Keys.forEach(
                function (value1) {
                    var objWrkH6   = objWrkH5.bdCont[value1];
                    objWrkH6.Count = objWrkH6.bdCont.length;
                    objWrkH5.Count += objWrkH6.bdCont.length;
                }
            )
        }
    );
    return arrRetDto;
};